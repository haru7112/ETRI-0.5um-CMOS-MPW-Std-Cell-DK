#!/bin/tcsh -f
#-------------------------------------------
# qflow variables for project ~/MyChip_Work/Projects/MyChip_Games/bricks_out/ETRI050_MyChip
#-------------------------------------------

set qflowversion=1.4.100
set projectpath=~/MyChip_Work/Projects/MyChip_Games/bricks_out/ETRI050_MyChip
set techdir=/usr/local/share/qflow/tech/etri050
set sourcedir=~/MyChip_Work/Projects/MyChip_Games/bricks_out/ETRI050_MyChip/source
set synthdir=~/MyChip_Work/Projects/MyChip_Games/bricks_out/ETRI050_MyChip/synthesis
set layoutdir=~/MyChip_Work/Projects/MyChip_Games/bricks_out/ETRI050_MyChip/layout
set techname=etri050
set scriptdir=/usr/local/share/qflow/scripts
set bindir=/usr/local/share/qflow/bin
set logdir=~/MyChip_Work/Projects/MyChip_Games/bricks_out/ETRI050_MyChip/log
#-------------------------------------------

