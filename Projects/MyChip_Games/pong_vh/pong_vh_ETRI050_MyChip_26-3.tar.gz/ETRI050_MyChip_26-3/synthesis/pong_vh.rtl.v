/* Verilog module written by vlog2Verilog (qflow) */
/* With explicit power connections */

module pong_vh(
    inout vdd,
    inout gnd,
    input clk,
    input reset,
    output v_sync,
    output pixel,
    output p_tick,
    input btn_up,
    input btn_down,
    input btn_left,
    input btn_right,
    output game_over,
    input game_new
);

wire _588_ ;
wire _168_ ;
wire _60_ ;
wire _397_ ;
wire \u_ball.sign_x  ;
wire _703_ ;
wire _19_ ;
wire _512_ ;
wire _741_ ;
wire _321_ ;
wire _57_ ;
wire _550_ ;
wire _130_ ;
wire btn_down ;
wire _606_ ;
wire _415_ ;
wire _95_ ;
wire _644_ ;
wire _224_ ;
wire _453_ ;
wire _509_ ;
wire _682_ ;
wire _262_ ;
wire _738_ ;
wire _318_ ;
wire _491_ ;
wire _547_ ;
wire _127_ ;
wire _356_ ;
wire btn_right ;
wire _585_ ;
wire _165_ ;
wire _394_ ;
wire _679_ ;
wire _259_ ;
wire _488_ ;
wire _700_ ;
wire _297_ ;
wire _16_ ;
wire _54_ ;
wire _603_ ;
wire _412_ ;
wire _92_ ;
wire _641_ ;
wire _221_ ;
wire _450_ ;
wire _506_ ;
wire _735_ ;
wire _315_ ;
wire _544_ ;
wire _124_ ;
wire _353_ ;
wire _409_ ;
wire _89_ ;
wire _582_ ;
wire _162_ ;
wire _638_ ;
wire _218_ ;
wire _391_ ;
wire _447_ ;
wire _676_ ;
wire _256_ ;
wire _485_ ;
wire _294_ ;
wire _13_ ;
wire _579_ ;
wire _159_ ;
wire _51_ ;
wire _388_ ;
wire _600_ ;
wire _197_ ;
wire _7_ ;
wire _503_ ;
wire _732_ ;
wire _312_ ;
wire _48_ ;
wire _541_ ;
wire _121_ ;
wire _350_ ;
wire _406_ ;
wire _86_ ;
wire _635_ ;
wire _215_ ;
wire _444_ ;
wire _673_ ;
wire _253_ ;
wire _729_ ;
wire _309_ ;
wire _482_ ;
wire _538_ ;
wire _118_ ;
wire _291_ ;
wire _10_ ;
wire _347_ ;
wire _576_ ;
wire _156_ ;
wire _385_ ;
wire pixel ;
wire _194_ ;
wire _479_ ;
wire _288_ ;
wire _4_ ;
wire _500_ ;
wire _45_ ;
wire _403_ ;
wire _83_ ;
wire _632_ ;
wire _212_ ;
wire _441_ ;
wire _670_ ;
wire _250_ ;
wire _726_ ;
wire _306_ ;
wire _535_ ;
wire _115_ ;
wire _764_ ;
wire _344_ ;
wire _573_ ;
wire _153_ ;
wire _629_ ;
wire _209_ ;
wire _382_ ;
wire _438_ ;
wire _191_ ;
wire _667_ ;
wire _247_ ;
wire _476_ ;
wire clk_bF$buf0 ;
wire clk_bF$buf1 ;
wire clk_bF$buf2 ;
wire clk_bF$buf3 ;
wire clk_bF$buf4 ;
wire clk_bF$buf5 ;
wire clk_bF$buf6 ;
wire clk_bF$buf7 ;
wire _285_ ;
wire _1_ ;
wire _42_ ;
wire _379_ ;
wire _188_ ;
wire _400_ ;
wire _80_ ;
wire _723_ ;
wire _303_ ;
wire [6:0] \u_ball.x_ball  ;
wire _39_ ;
wire _532_ ;
wire _112_ ;
wire _761_ ;
wire _341_ ;
wire clk ;
wire _77_ ;
wire _570_ ;
wire _150_ ;
wire _626_ ;
wire _206_ ;
wire _435_ ;
wire _664_ ;
wire _244_ ;
wire _473_ ;
wire _529_ ;
wire _109_ ;
wire _282_ ;
wire _758_ ;
wire _338_ ;
wire _567_ ;
wire _147_ ;
wire _376_ ;
wire _185_ ;
wire _699_ ;
wire _279_ ;
wire _720_ ;
wire _300_ ;
wire _36_ ;
wire _74_ ;
wire _623_ ;
wire _203_ ;
wire _432_ ;
wire pixel_paddle ;
wire _661_ ;
wire _241_ ;
wire _717_ ;
wire _470_ ;
wire _526_ ;
wire _106_ ;
wire _755_ ;
wire _335_ ;
wire _564_ ;
wire _144_ ;
wire [2:0] \u_ctrl.cnt_v_sync  ;
wire _373_ ;
wire _429_ ;
wire _182_ ;
wire _658_ ;
wire _238_ ;
wire _467_ ;
wire _696_ ;
wire _276_ ;
wire [5:0] \u_ball.y_init  ;
wire _33_ ;
wire _599_ ;
wire _179_ ;
wire _71_ ;
wire _620_ ;
wire _200_ ;
wire _714_ ;
wire _523_ ;
wire _103_ ;
wire \u_ctrl.State_3_bF$buf3  ;
wire _752_ ;
wire _332_ ;
wire _68_ ;
wire _561_ ;
wire _141_ ;
wire _617_ ;
wire _370_ ;
wire _426_ ;
wire _655_ ;
wire _235_ ;
wire load_option_bF$buf0 ;
wire load_option_bF$buf1 ;
wire load_option_bF$buf2 ;
wire load_option_bF$buf3 ;
wire _464_ ;
wire _693_ ;
wire _273_ ;
wire _749_ ;
wire _329_ ;
wire _558_ ;
wire _138_ ;
wire _30_ ;
wire _367_ ;
wire _596_ ;
wire _176_ ;
wire _499_ ;
wire _711_ ;
wire _27_ ;
wire _520_ ;
wire _100_ ;
wire \u_ctrl.State_3_bF$buf0  ;
wire _65_ ;
wire _614_ ;
wire _423_ ;
wire _652_ ;
wire _232_ ;
wire _708_ ;
wire _461_ ;
wire _517_ ;
wire _690_ ;
wire _270_ ;
wire _746_ ;
wire _326_ ;
wire _555_ ;
wire _135_ ;
wire _364_ ;
wire _593_ ;
wire _173_ ;
wire _649_ ;
wire _229_ ;
wire _458_ ;
wire _687_ ;
wire _267_ ;
wire _496_ ;
wire _24_ ;
wire _62_ ;
wire _399_ ;
wire _611_ ;
wire _420_ ;
wire _705_ ;
wire _514_ ;
wire _743_ ;
wire _323_ ;
wire _59_ ;
wire _552_ ;
wire _132_ ;
wire _608_ ;
wire _361_ ;
wire _417_ ;
wire _97_ ;
wire _590_ ;
wire _170_ ;
wire _646_ ;
wire _226_ ;
wire _455_ ;
wire _684_ ;
wire _264_ ;
wire _493_ ;
wire [6:1] paddle_h ;
wire [5:0] paddle_v ;
wire _549_ ;
wire _129_ ;
wire _21_ ;
wire _358_ ;
wire _712__bF$buf0 ;
wire _712__bF$buf1 ;
wire _712__bF$buf2 ;
wire _712__bF$buf3 ;
wire _587_ ;
wire _167_ ;
wire _396_ ;
wire _702_ ;
wire _299_ ;
wire _18_ ;
wire _511_ ;
wire _740_ ;
wire _320_ ;
wire _56_ ;
wire _605_ ;
wire _414_ ;
wire _94_ ;
wire _643_ ;
wire _223_ ;
wire _452_ ;
wire _508_ ;
wire _681_ ;
wire _261_ ;
wire _737_ ;
wire _317_ ;
wire _490_ ;
wire _546_ ;
wire _126_ ;
wire _355_ ;
wire game_over ;
wire _584_ ;
wire _164_ ;
wire _393_ ;
wire _449_ ;
wire _678_ ;
wire _258_ ;
wire _487_ ;
wire _296_ ;
wire _15_ ;
wire _53_ ;
wire _602_ ;
wire _199_ ;
wire _411_ ;
wire _91_ ;
wire _640_ ;
wire _220_ ;
wire _9_ ;
wire _505_ ;
wire _734_ ;
wire _314_ ;
wire _543_ ;
wire _123_ ;
wire _352_ ;
wire _408_ ;
wire _88_ ;
wire _581_ ;
wire _161_ ;
wire _637_ ;
wire _217_ ;
wire _390_ ;
wire _446_ ;
wire _675_ ;
wire _255_ ;
wire _484_ ;
wire _293_ ;
wire _12_ ;
wire _349_ ;
wire _578_ ;
wire _158_ ;
wire _50_ ;
wire _387_ ;
wire _196_ ;
wire _6_ ;
wire _502_ ;
wire _731_ ;
wire _311_ ;
wire _47_ ;
wire _540_ ;
wire _120_ ;
wire _405_ ;
wire _85_ ;
wire _634_ ;
wire _214_ ;
wire _443_ ;
wire _672_ ;
wire _252_ ;
wire _728_ ;
wire _308_ ;
wire _481_ ;
wire _537_ ;
wire _117_ ;
wire _290_ ;
wire _766_ ;
wire _346_ ;
wire _575_ ;
wire _155_ ;
wire _384_ ;
wire _193_ ;
wire _669_ ;
wire _249_ ;
wire _478_ ;
wire _287_ ;
wire _3_ ;
wire _44_ ;
wire _402_ ;
wire _82_ ;
wire _631_ ;
wire _211_ ;
wire _440_ ;
wire _725_ ;
wire _305_ ;
wire _534_ ;
wire _114_ ;
wire _763_ ;
wire _343_ ;
wire _79_ ;
wire _572_ ;
wire _152_ ;
wire _628_ ;
wire _208_ ;
wire _381_ ;
wire [5:0] \u_ball.y_pos  ;
wire _437_ ;
wire _190_ ;
wire _666_ ;
wire _246_ ;
wire pixel_ball ;
wire _475_ ;
wire _284_ ;
wire _0_ ;
wire v_sync ;
wire _569_ ;
wire _149_ ;
wire _41_ ;
wire _378_ ;
wire _187_ ;
wire _722_ ;
wire _302_ ;
wire _38_ ;
wire _531_ ;
wire _111_ ;
wire _760_ ;
wire _340_ ;
wire _76_ ;
wire _625_ ;
wire _205_ ;
wire _434_ ;
wire _663_ ;
wire _243_ ;
wire _719_ ;
wire _472_ ;
wire _528_ ;
wire _108_ ;
wire _281_ ;
wire _757_ ;
wire _337_ ;
wire _566_ ;
wire _146_ ;
wire _375_ ;
wire _184_ ;
wire btn_up ;
wire _469_ ;
wire _698_ ;
wire _278_ ;
wire _35_ ;
wire _73_ ;
wire _622_ ;
wire _202_ ;
wire _431_ ;
wire _660_ ;
wire _240_ ;
wire _716_ ;
wire _525_ ;
wire _105_ ;
wire _754_ ;
wire _334_ ;
wire _563_ ;
wire _143_ ;
wire _619_ ;
wire _372_ ;
wire _428_ ;
wire _181_ ;
wire _657_ ;
wire _237_ ;
wire _466_ ;
wire _695_ ;
wire _275_ ;
wire _32_ ;
wire _369_ ;
wire _598_ ;
wire _178_ ;
wire _70_ ;
wire _713_ ;
wire _29_ ;
wire _522_ ;
wire _102_ ;
wire \u_ctrl.State_3_bF$buf2  ;
wire _751_ ;
wire _331_ ;
wire _67_ ;
wire _560_ ;
wire _140_ ;
wire _616_ ;
wire _425_ ;
wire _654_ ;
wire _234_ ;
wire _463_ ;
wire _519_ ;
wire _692_ ;
wire _272_ ;
wire _748_ ;
wire _328_ ;
wire _557_ ;
wire _137_ ;
wire [4:0] \u_ctrl.State  ;
wire _366_ ;
wire _595_ ;
wire _175_ ;
wire _689_ ;
wire _269_ ;
wire _498_ ;
wire _710_ ;
wire _26_ ;
wire _64_ ;
wire _613_ ;
wire _422_ ;
wire _651_ ;
wire _231_ ;
wire _707_ ;
wire _460_ ;
wire _516_ ;
wire [5:0] \u_ball.y_ball  ;
wire _745_ ;
wire _325_ ;
wire _554_ ;
wire _134_ ;
wire _363_ ;
wire _419_ ;
wire _99_ ;
wire _592_ ;
wire _172_ ;
wire _648_ ;
wire _228_ ;
wire _457_ ;
wire _686_ ;
wire _266_ ;
wire _495_ ;
wire _23_ ;
wire _589_ ;
wire _169_ ;
wire _61_ ;
wire _398_ ;
wire _610_ ;
wire \u_ball.sign_y  ;
wire _704_ ;
wire _513_ ;
wire _742_ ;
wire _322_ ;
wire _58_ ;
wire _551_ ;
wire _131_ ;
wire _607_ ;
wire _360_ ;
wire _416_ ;
wire _96_ ;
wire _645_ ;
wire _225_ ;
wire load_option ;
wire game_new ;
wire _454_ ;
wire _683_ ;
wire _263_ ;
wire _739_ ;
wire _319_ ;
wire _492_ ;
wire _548_ ;
wire _128_ ;
wire _20_ ;
wire _357_ ;
wire _586_ ;
wire _166_ ;
wire _395_ ;
wire _489_ ;
wire _701_ ;
wire _298_ ;
wire _17_ ;
wire _510_ ;
wire _55_ ;
wire _604_ ;
wire _413_ ;
wire _93_ ;
wire _642_ ;
wire _222_ ;
wire _451_ ;
wire _507_ ;
wire _680_ ;
wire _260_ ;
wire _736_ ;
wire _316_ ;
wire _545_ ;
wire _125_ ;
wire _354_ ;
wire _583_ ;
wire _163_ ;
wire _639_ ;
wire _219_ ;
wire _392_ ;
wire _448_ ;
wire _677_ ;
wire _257_ ;
wire _486_ ;
wire _295_ ;
wire _14_ ;
wire _52_ ;
wire _389_ ;
wire _601_ ;
wire _198_ ;
wire _410_ ;
wire _90_ ;
wire _8_ ;
wire _504_ ;
wire _733_ ;
wire _313_ ;
wire _49_ ;
wire _542_ ;
wire _122_ ;
wire _351_ ;
wire _407_ ;
wire _87_ ;
wire _580_ ;
wire _160_ ;
wire _636_ ;
wire _216_ ;
wire _445_ ;
wire btn_left ;
wire _674_ ;
wire _254_ ;
wire _483_ ;
wire [6:0] \u_ball.x_init  ;
wire _539_ ;
wire _119_ ;
wire _292_ ;
wire _11_ ;
wire _348_ ;
wire _577_ ;
wire _157_ ;
wire _386_ ;
wire _195_ ;
wire _765__bF$buf0 ;
wire _765__bF$buf1 ;
wire _765__bF$buf2 ;
wire _765__bF$buf3 ;
wire _289_ ;
wire _5_ ;
wire _501_ ;
wire _730_ ;
wire _310_ ;
wire _46_ ;
wire _404_ ;
wire _84_ ;
wire _633_ ;
wire _213_ ;
wire _442_ ;
wire _671_ ;
wire _251_ ;
wire _727_ ;
wire _307_ ;
wire _480_ ;
wire _536_ ;
wire _116_ ;
wire _765_ ;
wire _345_ ;
wire _574_ ;
wire _154_ ;
wire _383_ ;
wire _439_ ;
wire _192_ ;
wire _668_ ;
wire _248_ ;
wire _477_ ;
wire _286_ ;
wire _2_ ;
wire _43_ ;
wire _189_ ;
wire _401_ ;
wire _81_ ;
wire _630_ ;
wire _210_ ;
wire _724_ ;
wire _304_ ;
wire _533_ ;
wire _113_ ;
wire _762_ ;
wire _342_ ;
wire _78_ ;
wire _571_ ;
wire _151_ ;
wire [6:0] \u_ball.x_pos  ;
wire _627_ ;
wire _207_ ;
wire _380_ ;
wire _436_ ;
wire _665_ ;
wire _245_ ;
wire _474_ ;
wire _283_ ;
wire _759_ ;
wire _339_ ;
wire _568_ ;
wire _148_ ;
wire _40_ ;
wire _377_ ;
wire _186_ ;
wire _721_ ;
wire _301_ ;
wire _37_ ;
wire _530_ ;
wire _110_ ;
wire _75_ ;
wire _624_ ;
wire _204_ ;
wire _433_ ;
wire _662_ ;
wire _242_ ;
wire _718_ ;
wire _471_ ;
wire _527_ ;
wire _107_ ;
wire _280_ ;
wire _756_ ;
wire _336_ ;
wire _565_ ;
wire _145_ ;
wire _374_ ;
wire _183_ ;
wire _659_ ;
wire _239_ ;
wire _468_ ;
wire _697_ ;
wire _277_ ;
wire _34_ ;
wire _72_ ;
wire _621_ ;
wire _201_ ;
wire _430_ ;
wire _715_ ;
wire _524_ ;
wire _104_ ;
wire _753_ ;
wire _333_ ;
wire _69_ ;
wire _562_ ;
wire _142_ ;
wire _618_ ;
wire _371_ ;
wire _427_ ;
wire _180_ ;
wire _656_ ;
wire _236_ ;
wire _465_ ;
wire _694_ ;
wire _274_ ;
wire _559_ ;
wire _139_ ;
wire _31_ ;
wire _368_ ;
wire _597_ ;
wire _177_ ;
wire _712_ ;
wire _28_ ;
wire _521_ ;
wire _101_ ;
wire \u_ctrl.State_3_bF$buf1  ;
wire _750_ ;
wire _330_ ;
wire _66_ ;
wire _615_ ;
wire _424_ ;
wire _653_ ;
wire _233_ ;
wire _709_ ;
wire _462_ ;
wire _518_ ;
wire _691_ ;
wire _271_ ;
wire p_tick ;
wire _747_ ;
wire _327_ ;
wire _556_ ;
wire _136_ ;
wire _365_ ;
wire _594_ ;
wire _174_ ;
wire _459_ ;
wire _688_ ;
wire _268_ ;
wire _497_ ;
wire _25_ ;
wire _63_ ;
wire _612_ ;
wire reset ;
wire _421_ ;
wire _650_ ;
wire _230_ ;
wire _706_ ;
wire _515_ ;
wire _744_ ;
wire _324_ ;
wire _553_ ;
wire _133_ ;
wire _609_ ;
wire _362_ ;
wire _418_ ;
wire _98_ ;
wire _591_ ;
wire _171_ ;
wire _647_ ;
wire _227_ ;
wire _456_ ;
wire _685_ ;
wire _265_ ;
wire _494_ ;
wire _22_ ;
wire _359_ ;

FILL FILL_0__1241_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1402_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1257_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [2]),
    .B(_240_),
    .C(_237_),
    .Y(_236_)
);

FILL FILL_0__1470_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1050_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _800_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_37_),
    .B(_511_),
    .C(paddle_v[0]),
    .Y(_38_)
);

OAI21X1 _1486_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_635_),
    .B(_656_),
    .C(_637_),
    .Y(_613_)
);

OAI22X1 _1066_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_368_),
    .B(_379_),
    .C(_54_),
    .D(_55_),
    .Y(_413_)
);

FILL FILL_1__848_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1526_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1106_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1295_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [2]),
    .B(paddle_h[2]),
    .Y(_274_)
);

FILL FILL_0__1335_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL82950x150 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__886_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1564_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1144_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1305_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0_BUFX2_insert20 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0_BUFX2_insert21 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0_BUFX2_insert22 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0_BUFX2_insert23 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1373_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1534_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1114_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1389_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_368_),
    .B(paddle_v[1]),
    .C(_366_),
    .Y(_365_)
);

FILL FILL_0__1429_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1182_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1601_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_712__bF$buf1),
    .S(vdd),
    .D(_534_),
    .CLK(clk_bF$buf4),
    .Q(\u_ctrl.State [3])
);

INVX1 _932_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_545_),
    .Y(_547_)
);

FILL FILL_1__1343_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1198_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [1]),
    .B(_181_),
    .Y(_180_)
);

FILL FILL_0__1238_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1410_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(load_option_bF$buf3),
    .B(_765__bF$buf0),
    .Y(_383_)
);

FILL FILL_1__1572_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__789_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1467_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _970_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_502_),
    .B(_500_),
    .C(paddle_v[2]),
    .Y(_505_)
);

FILL FILL_1__1381_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1276_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1085_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1504_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_642_),
    .B(_669_),
    .Y(_627_)
);

FILL FILL_0__832_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _835_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_4_),
    .Y(_5_)
);

FILL FILL_1__1246_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1313_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.sign_x ),
    .B(_309_),
    .Y(_291_)
);

FILL FILL_1__1475_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1055_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI22X1 _1542_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_701_),
    .B(_669_),
    .C(_657_),
    .D(\u_ctrl.State_3_bF$buf1 ),
    .Y(_720_)
);

AOI21X1 _1122_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_105_),
    .B(\u_ball.x_ball [4]),
    .C(\u_ball.x_ball [5]),
    .Y(_104_)
);

FILL FILL_0__870_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__904_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _873_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [4]),
    .Y(_730_)
);

FILL FILL_1__1284_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1179_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__926_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _929_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(paddle_h[1]),
    .Y(_550_)
);

NOR2X1 _1351_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [4]),
    .B(\u_ball.x_ball [5]),
    .Y(_327_)
);

AOI22X1 _1407_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [5]),
    .B(_383_),
    .C(_381_),
    .D(\u_ball.y_init [5]),
    .Y(_380_)
);

OAI21X1 _1580_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_688_),
    .B(_689_),
    .C(\u_ctrl.State_3_bF$buf2 ),
    .Y(_687_)
);

NOR2X1 _1160_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [4]),
    .B(_394_),
    .Y(_142_)
);

FILL FILL_1__942_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1200_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _1216_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [0]),
    .B(_217_),
    .C(_210_),
    .Y(_198_)
);

FILL FILL_0__964_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _967_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(paddle_v[4]),
    .B(_507_),
    .C(paddle_v[5]),
    .Y(_508_)
);

DFFSR _1445_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_712__bF$buf2),
    .D(_722_),
    .CLK(clk_bF$buf2),
    .Q(\u_ball.x_pos [1])
);

OAI21X1 _1025_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(load_option_bF$buf1),
    .B(_466_),
    .C(_447_),
    .Y(_455_)
);

DFFSR _776_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_491_),
    .S(vdd),
    .D(_489_),
    .CLK(clk_bF$buf1),
    .Q(paddle_v[0])
);

FILL FILL_1__1187_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__829_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _1254_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [2]),
    .B(_363_),
    .C(_368_),
    .Y(_233_)
);

INVX1 _1483_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_763_),
    .Y(_611_)
);

AOI22X1 _1063_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [2]),
    .B(_383_),
    .C(_381_),
    .D(\u_ball.y_init [2]),
    .Y(_51_)
);

FILL FILL_1__845_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1523_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1103_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1539_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_655_),
    .B(_656_),
    .Y(_654_)
);

NAND2X1 _1119_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [4]),
    .B(_102_),
    .Y(_101_)
);

FILL FILL_0__867_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI22X1 _1292_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(paddle_h[2]),
    .B(_309_),
    .C(_272_),
    .D(paddle_h[3]),
    .Y(_271_)
);

FILL FILL_0__1332_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1348_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_325_),
    .B(_330_),
    .Y(_424_)
);

FILL FILL_1__883_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1561_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1141_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1302_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1577_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [2]),
    .Y(_685_)
);

OAI21X1 _1157_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_154_),
    .B(_142_),
    .C(_140_),
    .Y(_139_)
);

FILL FILL_0__1370_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1531_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI22X1 _1386_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(paddle_v[3]),
    .B(_363_),
    .C(_402_),
    .D(paddle_v[2]),
    .Y(_362_)
);

FILL FILL_0__1426_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1006_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1340_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1195_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [0]),
    .B(_336_),
    .Y(_177_)
);

FILL FILL_0__1235_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__999_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__786_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1464_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1205_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1273_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1014_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1289_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(paddle_h[4]),
    .Y(_268_)
);

FILL FILL_0__1329_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1082_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL83850x46950 (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _1501_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State [1]),
    .B(\u_ctrl.cnt_v_sync [2]),
    .C(_648_),
    .Y(_624_)
);

NAND2X1 _832_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_559_),
    .B(_7_),
    .Y(_8_)
);

FILL FILL_1__1243_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _1098_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_81_),
    .B(_83_),
    .C(_82_),
    .Y(_80_)
);

FILL FILL_0__1558_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1138_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _1310_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_312_),
    .B(_294_),
    .C(_289_),
    .Y(_288_)
);

FILL FILL_1__1472_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1052_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1367_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__901_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _870_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_732_),
    .Y(_733_)
);

FILL FILL_1__1281_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1596_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1176_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__923_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _926_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(btn_left),
    .B(_525_),
    .Y(_553_)
);

NOR2X1 _1404_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_393_),
    .B(_390_),
    .Y(_378_)
);

FILL FILL_1__1146_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _1213_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_209_),
    .B(_210_),
    .C(_196_),
    .Y(_195_)
);

FILL FILL_0__961_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _964_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_506_),
    .B(_509_),
    .C(_508_),
    .Y(_511_)
);

DFFSR _1442_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_712__bF$buf1),
    .S(vdd),
    .D(_705_),
    .CLK(clk_bF$buf6),
    .Q(\u_ctrl.cnt_v_sync [0])
);

INVX1 _1022_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_init [3]),
    .Y(_449_)
);

FILL FILL_0__770_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__804_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _773_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_491_),
    .S(vdd),
    .D(_486_),
    .CLK(clk_bF$buf1),
    .Q(paddle_v[2])
);

FILL FILL_1__1184_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1499_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1079_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__826_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _829_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [2]),
    .Y(_11_)
);

OAI21X1 _1251_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_233_),
    .B(_231_),
    .C(\u_ball.sign_y ),
    .Y(_230_)
);

NAND2X1 _1307_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_286_),
    .B(_287_),
    .Y(_285_)
);

OAI21X1 _1480_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_609_),
    .B(_651_),
    .C(_616_),
    .Y(_608_)
);

NAND2X1 _1060_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_405_),
    .B(_406_),
    .Y(_49_)
);

FILL FILL_1__842_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1520_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1100_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1536_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State [4]),
    .Y(_652_)
);

NOR2X1 _1116_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_104_),
    .B(_107_),
    .Y(_98_)
);

FILL FILL_0__864_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _867_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(paddle_v[0]),
    .B(_734_),
    .C(_735_),
    .Y(_736_)
);

INVX1 _1345_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_323_),
    .Y(_322_)
);

FILL FILL_1__880_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1574_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [2]),
    .B(_689_),
    .Y(_682_)
);

OAI21X1 _1154_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_218_),
    .B(_216_),
    .C(_214_),
    .Y(_136_)
);

FILL FILL_0__958_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI22X1 _1383_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_408_),
    .B(paddle_v[5]),
    .C(_394_),
    .D(paddle_v[4]),
    .Y(_359_)
);

FILL FILL_0__1423_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1003_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1439_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_712__bF$buf0),
    .D(_728_),
    .CLK(clk_bF$buf4),
    .Q(\u_ball.y_pos [0])
);

INVX2 _1019_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(reset),
    .Y(_458_)
);

FILL FILL_0__767_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1192_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_178_),
    .B(_175_),
    .Y(_174_)
);

FILL FILL_1__974_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1232_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1248_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_765__bF$buf0),
    .B(_290_),
    .Y(_228_)
);

FILL FILL_0__996_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _999_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(load_option_bF$buf0),
    .B(_479_),
    .C(_480_),
    .Y(_469_)
);

FILL FILL_1__783_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1461_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1202_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1477_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_608_),
    .Y(_605_)
);

OAI21X1 _1057_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_765__bF$buf1),
    .B(\u_ball.y_init [3]),
    .C(_379_),
    .Y(_46_)
);

FILL FILL_1__839_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1517_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1270_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1431_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1286_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_267_),
    .B(_270_),
    .C(_266_),
    .Y(_265_)
);

FILL FILL_0__1326_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1240_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL82950x18150 (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _1095_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_81_),
    .B(_85_),
    .C(_88_),
    .Y(_77_)
);

FILL FILL_0__1555_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1135_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__899_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1364_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL83550x79350 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1593_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1173_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__920_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _923_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_547_),
    .B(_544_),
    .C(paddle_h[3]),
    .Y(_556_)
);

OAI21X1 _1189_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_336_),
    .B(\u_ball.x_pos [0]),
    .C(_176_),
    .Y(_171_)
);

FILL FILL_0__1229_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _1401_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_377_),
    .B(_376_),
    .C(_409_),
    .Y(_375_)
);

FILL FILL_1__1563_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1143_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1210_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_193_),
    .B(_200_),
    .Y(_192_)
);

NAND2X1 _961_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_513_),
    .B(_503_),
    .Y(_514_)
);

FILL FILL_1__1372_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL83850x32550 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1267_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1428_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__801_ (
    .gnd(gnd),
    .vdd(vdd)
);

BUFX2 _770_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_0_),
    .Y(game_over)
);

FILL FILL_1__1181_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1496_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1076_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__823_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1_BUFX2_insert9 (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _826_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_557_),
    .B(_11_),
    .C(_13_),
    .Y(_14_)
);

FILL FILL_1__1237_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1304_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_283_),
    .B(_284_),
    .C(_317_),
    .Y(_422_)
);

NAND2X1 _1533_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State [2]),
    .B(_651_),
    .Y(_650_)
);

NAND2X1 _1113_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_116_),
    .B(_96_),
    .Y(_95_)
);

FILL FILL_0__861_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI22X1 _864_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_737_),
    .B(paddle_v[2]),
    .C(paddle_v[1]),
    .D(_738_),
    .Y(_739_)
);

FILL FILL_0__917_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1342_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_336_),
    .B(_320_),
    .C(_765__bF$buf0),
    .Y(_319_)
);

FILL FILL_1__1084_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1399_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1571_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_685_),
    .B(_693_),
    .C(_680_),
    .Y(_726_)
);

AOI21X1 _1151_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_363_),
    .B(\u_ball.y_pos [3]),
    .C(_153_),
    .Y(_133_)
);

NAND2X1 _1207_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_190_),
    .B(_191_),
    .Y(_189_)
);

FILL FILL_0__955_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _958_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(paddle_v[3]),
    .Y(_517_)
);

FILL FILL_1__1369_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1380_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(paddle_v[4]),
    .Y(_356_)
);

FILL FILL_0__1420_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1000_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX2 _1436_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_765__bF$buf2),
    .Y(_409_)
);

INVX1 _1016_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_init [5]),
    .Y(_452_)
);

BUFX2 _767_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_765__bF$buf1),
    .Y(v_sync)
);

FILL FILL_1__1178_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__971_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1245_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_311_),
    .B(_294_),
    .Y(_226_)
);

FILL FILL_0__993_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX2 _996_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(reset),
    .Y(_471_)
);

FILL FILL_1__780_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1474_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.cnt_v_sync [0]),
    .Y(_603_)
);

NAND3X1 _1054_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [2]),
    .B(\u_ball.x_ball [3]),
    .C(_45_),
    .Y(_44_)
);

FILL FILL_0__1514_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__858_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1283_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [5]),
    .B(_280_),
    .Y(_262_)
);

FILL FILL_0__1323_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL83250x57750 (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1339_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [6]),
    .B(_383_),
    .Y(_317_)
);

NAND2X1 _1092_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_75_),
    .B(_79_),
    .Y(_74_)
);

FILL FILL_0__1552_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1132_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1568_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [3]),
    .B(_683_),
    .Y(_677_)
);

INVX1 _1148_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [4]),
    .Y(_130_)
);

FILL FILL_0__896_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _899_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(paddle_h[5]),
    .B(_578_),
    .Y(_579_)
);

FILL FILL_0__1361_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1522_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1102_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX2 _1377_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [0]),
    .Y(_353_)
);

FILL FILL_0__1417_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1590_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1170_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _920_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_540_),
    .B(_558_),
    .Y(_559_)
);

FILL FILL_1__1331_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL83550x10950 (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _1186_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_173_),
    .B(_169_),
    .C(_192_),
    .Y(_168_)
);

FILL FILL_1__968_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1226_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1560_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1140_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__799_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1264_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1425_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1005_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1493_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1073_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__820_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _823_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_16_),
    .B(_15_),
    .Y(_17_)
);

OR2X2 _1089_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_304_),
    .B(_312_),
    .Y(_73_)
);

FILL FILL_0__1549_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1129_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1301_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(paddle_h[5]),
    .Y(_280_)
);

FILL FILL_0__1358_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1519_ (
    .gnd(gnd),
    .vdd(vdd)
);

OR2X2 _1530_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.cnt_v_sync [0]),
    .B(\u_ctrl.cnt_v_sync [1]),
    .Y(_648_)
);

NAND2X1 _1110_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_209_),
    .B(_210_),
    .Y(_92_)
);

OAI21X1 _861_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(paddle_v[3]),
    .B(_740_),
    .C(_737_),
    .Y(_742_)
);

FILL FILL_0__1587_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1167_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__914_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _917_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_557_),
    .B(_545_),
    .C(_560_),
    .Y(_562_)
);

FILL FILL_1__1328_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1081_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1396_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1557_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1137_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__930_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _1204_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_188_),
    .B(_187_),
    .C(_189_),
    .Y(_186_)
);

FILL FILL_0__952_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _955_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_504_),
    .B(_519_),
    .Y(_520_)
);

FILL FILL_1__1366_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1433_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_407_),
    .Y(_406_)
);

DFFSR _1013_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_458_),
    .S(vdd),
    .D(_456_),
    .CLK(clk_bF$buf0),
    .Q(\u_ball.y_init [2])
);

FILL FILL_0__817_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1242_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_305_),
    .B(_225_),
    .C(_224_),
    .Y(_223_)
);

FILL FILL_0__990_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _993_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(load_option_bF$buf0),
    .B(_482_),
    .C(_490_),
    .Y(_472_)
);

FILL FILL_0__1299_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1471_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_626_),
    .B(_602_),
    .C(_601_),
    .Y(_705_)
);

AOI21X1 _1051_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_42_),
    .B(_43_),
    .C(_0_),
    .Y(_41_)
);

FILL FILL_0__1511_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _1527_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [4]),
    .B(\u_ball.y_pos [5]),
    .C(_678_),
    .Y(_645_)
);

AOI21X1 _1107_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_91_),
    .B(_90_),
    .C(_92_),
    .Y(_89_)
);

FILL FILL_0__855_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _858_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_744_),
    .Y(_745_)
);

FILL FILL_1__1269_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1280_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_262_),
    .B(_260_),
    .C(_261_),
    .Y(_259_)
);

FILL FILL_0__1320_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1336_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_316_),
    .B(_315_),
    .Y(_314_)
);

FILL FILL_1__1498_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1078_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__871_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1565_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_679_),
    .B(_693_),
    .C(_675_),
    .Y(_725_)
);

OR2X2 _1145_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_309_),
    .B(\u_ball.x_pos [2]),
    .Y(_127_)
);

FILL FILL_0__893_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__927_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _896_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(btn_right),
    .B(_525_),
    .C(_541_),
    .Y(_582_)
);

FILL FILL_0__949_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI22X1 _1374_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_368_),
    .B(paddle_v[1]),
    .C(_402_),
    .D(_351_),
    .Y(_350_)
);

FILL FILL_0__1414_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1183_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [0]),
    .B(\u_ball.y_ball [1]),
    .C(_402_),
    .Y(_165_)
);

FILL FILL_1__965_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1223_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1239_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_221_),
    .B(_223_),
    .Y(_220_)
);

FILL FILL_0__987_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1032_ (
    .gnd(gnd),
    .vdd(vdd)
);

AND2X2 _1468_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_599_),
    .B(_645_),
    .Y(_598_)
);

DFFSR _1048_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_417_),
    .S(vdd),
    .D(_419_),
    .CLK(clk_bF$buf7),
    .Q(\u_ball.x_ball [3])
);

FILL FILL_0__796_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _799_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(paddle_v[0]),
    .B(_511_),
    .C(_37_),
    .Y(_39_)
);

FILL FILL_0__1508_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1261_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1422_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1002_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1277_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_276_),
    .B(_269_),
    .C(paddle_h[4]),
    .Y(_256_)
);

FILL FILL_0__1317_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1490_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1070_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI22X1 _820_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_6_),
    .B(_8_),
    .C(_19_),
    .D(_760_),
    .Y(_20_)
);

OAI22X1 _1086_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_315_),
    .B(_379_),
    .C(_71_),
    .D(_72_),
    .Y(_416_)
);

FILL FILL_1__868_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1546_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1126_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1355_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1516_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1584_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1164_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__911_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _914_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_564_),
    .B(_545_),
    .C(_560_),
    .Y(_565_)
);

FILL FILL_1__1325_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1393_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1554_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1029_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1201_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_185_),
    .B(_184_),
    .Y(_183_)
);

NOR2X1 _952_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(paddle_v[5]),
    .B(paddle_v[1]),
    .Y(_523_)
);

FILL FILL_1__1363_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1258_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1430_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.sign_y ),
    .Y(_403_)
);

DFFSR _1010_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_458_),
    .S(vdd),
    .D(_459_),
    .CLK(clk_bF$buf0),
    .Q(\u_ball.y_init [4])
);

FILL FILL_0__1487_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1067_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL83550x18150 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__814_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI22X1 _817_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_569_),
    .B(_4_),
    .C(_22_),
    .D(\u_ball.x_pos [5]),
    .Y(_23_)
);

FILL FILL_1__1228_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _990_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_init [6]),
    .B(\u_ball.x_init [5]),
    .Y(_443_)
);

FILL FILL_0__1296_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__830_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1524_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_645_),
    .B(_697_),
    .Y(_643_)
);

AOI22X1 _1104_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_210_),
    .B(_216_),
    .C(_92_),
    .D(_87_),
    .Y(_86_)
);

FILL FILL_0__852_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _855_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(paddle_v[4]),
    .B(_730_),
    .C(_731_),
    .Y(_748_)
);

FILL FILL_1__1266_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__908_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1333_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.sign_x ),
    .B(\u_ball.x_ball [3]),
    .Y(_311_)
);

FILL FILL_1__1495_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1562_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_678_),
    .Y(_672_)
);

NAND2X1 _1142_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [0]),
    .B(\u_ball.x_pos [0]),
    .Y(_124_)
);

FILL FILL_0__890_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__924_ (
    .gnd(gnd),
    .vdd(vdd)
);

AND2X2 _893_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_581_),
    .B(_583_),
    .Y(_585_)
);

FILL FILL_0__1199_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__946_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _949_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(btn_up),
    .B(_525_),
    .Y(_526_)
);

NAND2X1 _1371_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_360_),
    .B(_351_),
    .Y(_347_)
);

FILL FILL_0__1411_ (
    .gnd(gnd),
    .vdd(vdd)
);

AND2X2 _1427_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_401_),
    .B(_404_),
    .Y(_400_)
);

INVX1 _1007_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_init [1]),
    .Y(_475_)
);

FILL FILL_1__1169_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1180_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [3]),
    .Y(_162_)
);

FILL FILL_0__1220_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1236_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [1]),
    .B(_219_),
    .Y(_218_)
);

NAND2X1 _987_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_init [0]),
    .B(_477_),
    .Y(_446_)
);

NAND2X1 _1465_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.cnt_v_sync [0]),
    .B(\u_ctrl.cnt_v_sync [1]),
    .Y(_596_)
);

DFFSR _1045_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_417_),
    .S(vdd),
    .D(_423_),
    .CLK(clk_bF$buf4),
    .Q(\u_ball.x_ball [1])
);

FILL FILL_0__793_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__827_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _796_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(paddle_h[1]),
    .B(_578_),
    .Y(_418_)
);

FILL FILL_0__1505_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__849_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1274_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(gnd),
    .B(_336_),
    .Y(_253_)
);

FILL FILL_0__1314_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL82950x46950 (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1083_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_303_),
    .B(_69_),
    .Y(_68_)
);

FILL FILL_1__865_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1543_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1123_ (
    .gnd(gnd),
    .vdd(vdd)
);

OR2X2 _1559_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_670_),
    .B(_673_),
    .Y(_724_)
);

AOI22X1 _1139_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [3]),
    .B(_128_),
    .C(_122_),
    .D(_126_),
    .Y(_121_)
);

FILL FILL_0__887_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1352_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1513_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1368_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_358_),
    .B(_345_),
    .C(_346_),
    .Y(_344_)
);

FILL FILL_0__1408_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1581_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1161_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _911_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_558_),
    .Y(_568_)
);

FILL FILL_1__1322_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1597_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_491_),
    .S(vdd),
    .D(_496_),
    .CLK(clk_bF$buf2),
    .Q(paddle_h[6])
);

NAND2X1 _1177_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_160_),
    .B(_161_),
    .Y(_159_)
);

FILL FILL_0__1217_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1390_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__768_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1026_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1255_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1484_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1064_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__811_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _814_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_557_),
    .B(\u_ball.x_pos [2]),
    .C(_12_),
    .Y(_26_)
);

FILL FILL_1__1225_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL83550x39750 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1293_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1349_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _1521_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_643_),
    .B(\u_ctrl.State_3_bF$buf3 ),
    .C(_641_),
    .Y(_640_)
);

OAI21X1 _1101_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_199_),
    .B(_197_),
    .C(_201_),
    .Y(_83_)
);

NOR2X1 _852_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_750_),
    .B(_745_),
    .Y(_751_)
);

FILL FILL_1__1263_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1578_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1158_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__905_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _908_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_570_),
    .Y(_571_)
);

NOR2X1 _1330_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_316_),
    .B(_309_),
    .Y(_308_)
);

FILL FILL_0__1387_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1128_ (
    .gnd(gnd),
    .vdd(vdd)
);

AND2X2 _890_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_515_),
    .B(_512_),
    .Y(_587_)
);

FILL FILL_0__1196_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__943_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _946_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_528_),
    .Y(_529_)
);

AOI21X1 _1424_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_403_),
    .B(_398_),
    .C(_399_),
    .Y(_397_)
);

INVX2 _1004_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(load_option_bF$buf3),
    .Y(_477_)
);

FILL FILL_1__1586_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1166_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__808_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1233_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [2]),
    .Y(_215_)
);

DFFSR _984_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_471_),
    .S(vdd),
    .D(_470_),
    .CLK(clk_bF$buf3),
    .Q(\u_ball.x_init [4])
);

FILL FILL_1__1395_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1462_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.cnt_v_sync [1]),
    .B(_626_),
    .Y(_593_)
);

DFFSR _1042_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_417_),
    .S(vdd),
    .D(_414_),
    .CLK(clk_bF$buf0),
    .Q(\u_ball.y_ball [0])
);

FILL FILL_0__790_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__824_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _793_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_561_),
    .Y(_429_)
);

FILL FILL_0__1502_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1099_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI22X1 _1518_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State [0]),
    .B(game_new),
    .C(_649_),
    .D(\u_ctrl.State_3_bF$buf3 ),
    .Y(_638_)
);

FILL FILL_0__846_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI22X1 _849_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(paddle_v[2]),
    .B(\u_ball.y_pos [2]),
    .C(_752_),
    .D(_753_),
    .Y(_754_)
);

NOR2X1 _1271_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(paddle_h[2]),
    .B(paddle_h[3]),
    .Y(_250_)
);

FILL FILL_0__1311_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _1327_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_307_),
    .B(_306_),
    .C(_308_),
    .Y(_305_)
);

AOI21X1 _1080_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_304_),
    .B(_312_),
    .C(_314_),
    .Y(_65_)
);

FILL FILL_1__862_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1540_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1120_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1556_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [1]),
    .Y(_668_)
);

OAI21X1 _1136_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_129_),
    .B(_121_),
    .C(_119_),
    .Y(_118_)
);

FILL FILL_0__884_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _887_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_530_),
    .B(_518_),
    .Y(_589_)
);

NAND3X1 _1365_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_347_),
    .B(_342_),
    .C(_348_),
    .Y(_341_)
);

FILL FILL_0__1405_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL82650x79350 (
    .gnd(gnd),
    .vdd(vdd)
);

INVX2 _1594_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [4]),
    .Y(_700_)
);

NOR2X1 _1174_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_363_),
    .B(_157_),
    .Y(_156_)
);

FILL FILL_1__956_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1214_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__978_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1023_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1459_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_712__bF$buf0),
    .S(vdd),
    .D(_533_),
    .CLK(clk_bF$buf6),
    .Q(\u_ctrl.State [4])
);

DFFSR _1039_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_417_),
    .D(_426_),
    .CLK(clk_bF$buf7),
    .Q(\u_ball.y_ball [4])
);

FILL FILL_0__787_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1252_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1413_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _1268_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_275_),
    .B(_251_),
    .C(_248_),
    .Y(_247_)
);

FILL FILL_0__1308_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1481_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1061_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI22X1 _811_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_540_),
    .B(\u_ball.x_pos [4]),
    .C(_564_),
    .D(\u_ball.x_pos [3]),
    .Y(_29_)
);

FILL FILL_1__1222_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1497_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [5]),
    .B(_698_),
    .Y(_621_)
);

OAI21X1 _1077_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_382_),
    .B(_63_),
    .C(_409_),
    .Y(_62_)
);

FILL FILL_0__1537_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1117_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1290_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1031_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1346_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1575_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1155_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__902_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _905_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_573_),
    .B(_572_),
    .Y(_574_)
);

FILL FILL_0__1384_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1545_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1125_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1193_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__940_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _943_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_516_),
    .B(_518_),
    .C(_531_),
    .Y(_532_)
);

FILL FILL_1__1354_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1249_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX2 _1421_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [4]),
    .Y(_394_)
);

INVX1 _1001_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_init [3]),
    .Y(_479_)
);

FILL FILL_1__1583_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1163_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1478_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1058_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__805_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _808_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(paddle_h[5]),
    .B(_760_),
    .C(_5_),
    .Y(_32_)
);

FILL FILL_1__1219_ (
    .gnd(gnd),
    .vdd(vdd)
);

AND2X2 _1230_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_214_),
    .B(_213_),
    .Y(_212_)
);

DFFSR _981_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_471_),
    .D(_474_),
    .CLK(clk_bF$buf3),
    .Q(\u_ball.x_init [0])
);

FILL FILL_1__1392_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1287_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__821_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _790_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_550_),
    .B(_431_),
    .C(_555_),
    .Y(_432_)
);

FILL FILL_0__1096_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1515_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_701_),
    .B(_637_),
    .Y(_636_)
);

FILL FILL_0__843_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _846_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_740_),
    .B(_507_),
    .C(_756_),
    .Y(_757_)
);

INVX1 _1324_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_303_),
    .Y(_302_)
);

FILL FILL_1__1486_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1066_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1553_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_666_),
    .B(_668_),
    .Y(_665_)
);

NAND2X1 _1133_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [3]),
    .B(\u_ball.x_pos [3]),
    .Y(_115_)
);

FILL FILL_0__881_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _884_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_590_),
    .B(_591_),
    .C(_528_),
    .Y(_592_)
);

FILL FILL_1__1295_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1_CLKBUF1_insert1 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1_CLKBUF1_insert2 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1_CLKBUF1_insert4 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1_CLKBUF1_insert5 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1_CLKBUF1_insert7 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__937_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1362_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_349_),
    .B(_343_),
    .C(_339_),
    .Y(_338_)
);

FILL FILL_0__1402_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1418_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.sign_y ),
    .B(\u_ball.y_ball [3]),
    .C(_395_),
    .Y(_391_)
);

NAND3X1 _1591_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [5]),
    .B(\u_ball.x_pos [6]),
    .C(_698_),
    .Y(_697_)
);

OAI21X1 _1171_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [4]),
    .B(_155_),
    .C(_154_),
    .Y(_153_)
);

FILL FILL_1__953_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1211_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1227_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [1]),
    .B(_219_),
    .Y(_209_)
);

FILL FILL_0__975_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _978_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(paddle_v[5]),
    .Y(_497_)
);

FILL FILL_1__1389_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1020_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1456_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_712__bF$buf2),
    .D(_719_),
    .CLK(clk_bF$buf5),
    .Q(\u_ball.x_pos [4])
);

DFFSR _1036_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_417_),
    .D(_411_),
    .CLK(clk_bF$buf7),
    .Q(\u_ball.y_ball [3])
);

FILL FILL_0__784_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _787_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_566_),
    .B(_563_),
    .Y(_434_)
);

FILL FILL_1__991_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1410_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _1265_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_247_),
    .B(_245_),
    .C(_254_),
    .Y(_244_)
);

FILL FILL_0__1305_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI22X1 _1494_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_635_),
    .B(_669_),
    .C(_619_),
    .D(\u_ctrl.State_3_bF$buf1 ),
    .Y(_710_)
);

INVX1 _1074_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_232_),
    .Y(_60_)
);

FILL FILL_0__1534_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1114_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__878_ (
    .gnd(gnd),
    .vdd(vdd)
);

BUFX2 BUFX2_insert8 (
    .gnd(gnd),
    .vdd(vdd),
    .A(load_option),
    .Y(load_option_bF$buf3)
);

BUFX2 BUFX2_insert9 (
    .gnd(gnd),
    .vdd(vdd),
    .A(load_option),
    .Y(load_option_bF$buf2)
);

FILL FILL_0__1343_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1504_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX2 _1359_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [1]),
    .Y(_335_)
);

FILL FILL_1__894_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1572_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1152_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _902_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_575_),
    .B(_576_),
    .C(_555_),
    .Y(_577_)
);

FILL FILL_1__1313_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1588_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State_3_bF$buf0 ),
    .B(\u_ctrl.State [0]),
    .C(_695_),
    .Y(_694_)
);

OAI21X1 _1168_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_163_),
    .B(_158_),
    .C(_151_),
    .Y(_150_)
);

FILL FILL_0__1208_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1381_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1542_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1122_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1397_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_381_),
    .Y(_372_)
);

FILL FILL_0__1017_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1190_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _940_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_529_),
    .B(_538_),
    .C(paddle_v[5]),
    .Y(_539_)
);

FILL FILL_1__1351_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__988_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1246_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1407_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1580_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1160_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1475_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1055_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL83550x46950 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__802_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _805_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(paddle_h[6]),
    .B(_759_),
    .C(_34_),
    .Y(_35_)
);

FILL FILL_0__1284_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1093_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _1512_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_700_),
    .B(_635_),
    .C(_634_),
    .Y(_633_)
);

FILL FILL_0__840_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _843_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [5]),
    .Y(_760_)
);

FILL FILL_0__1569_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1149_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1321_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [6]),
    .Y(_299_)
);

FILL FILL_1__1483_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1063_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1378_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1539_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1119_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1550_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [2]),
    .Y(_663_)
);

NAND3X1 _1130_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_130_),
    .B(_145_),
    .C(_113_),
    .Y(_112_)
);

FILL FILL_1__912_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _881_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_537_),
    .B(_504_),
    .Y(_714_)
);

FILL FILL_1__1292_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1187_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__934_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX2 _937_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(paddle_h[5]),
    .Y(_541_)
);

FILL FILL_1__1348_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _1415_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_408_),
    .B(_392_),
    .C(_389_),
    .Y(_388_)
);

FILL FILL_1__950_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _1224_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_210_),
    .B(_207_),
    .C(_208_),
    .Y(_206_)
);

FILL FILL_0__972_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _975_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_499_),
    .B(_498_),
    .C(_497_),
    .Y(_500_)
);

FILL FILL83850x54150 (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1453_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_712__bF$buf1),
    .S(vdd),
    .D(_709_),
    .CLK(clk_bF$buf6),
    .Q(load_option)
);

NAND2X1 _1033_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_init [5]),
    .B(\u_ball.y_init [4]),
    .Y(_461_)
);

FILL FILL_0__781_ (
    .gnd(gnd),
    .vdd(vdd)
);

AND2X2 _784_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_567_),
    .B(_572_),
    .Y(_436_)
);

OAI21X1 _1509_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_685_),
    .B(_688_),
    .C(_631_),
    .Y(_630_)
);

FILL FILL_0__837_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1262_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_260_),
    .B(_261_),
    .Y(_241_)
);

FILL FILL_0__1302_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1318_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_297_),
    .B(_298_),
    .Y(_296_)
);

AOI21X1 _1491_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(game_new),
    .B(_618_),
    .C(_617_),
    .Y(_709_)
);

NAND3X1 _1071_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.sign_y ),
    .B(_398_),
    .C(_167_),
    .Y(_58_)
);

FILL FILL_1__853_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1531_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1111_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI22X1 _1547_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_663_),
    .B(_669_),
    .C(_661_),
    .D(\u_ctrl.State_3_bF$buf1 ),
    .Y(_721_)
);

NAND2X1 _1127_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_110_),
    .B(_112_),
    .Y(_109_)
);

FILL FILL_0__875_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__909_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _878_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_528_),
    .B(_716_),
    .C(_715_),
    .Y(_717_)
);

FILL FILL_1__1289_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1340_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1501_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1356_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_765__bF$buf3),
    .B(_333_),
    .Y(_332_)
);

FILL FILL_1__891_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1310_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1585_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_702_),
    .B(_692_),
    .C(_693_),
    .Y(_691_)
);

NOR2X1 _1165_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [6]),
    .B(_148_),
    .Y(_147_)
);

FILL FILL_1__947_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1205_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__969_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1394_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(paddle_v[5]),
    .B(_408_),
    .Y(_370_)
);

FILL FILL_0__1434_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1014_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__778_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1243_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1404_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1259_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [6]),
    .B(_282_),
    .C(_765__bF$buf3),
    .Y(_238_)
);

FILL FILL83850x7350 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__794_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1472_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1052_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX4 _802_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(reset),
    .Y(_491_)
);

FILL FILL82650x18150 (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1488_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_765__bF$buf3),
    .B(_615_),
    .Y(_614_)
);

AOI21X1 _1068_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_58_),
    .B(_56_),
    .C(_409_),
    .Y(_55_)
);

FILL FILL_0__1528_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1108_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1281_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1022_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1297_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(paddle_h[2]),
    .Y(_276_)
);

FILL FILL_0__1337_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1090_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _840_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [4]),
    .B(\u_ball.x_pos [3]),
    .C(\u_ball.x_pos [2]),
    .Y(_766_)
);

FILL FILL83250x79350 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1251_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__888_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1566_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1146_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1307_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1480_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1060_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1375_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1536_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1184_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__931_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR3X1 _934_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_541_),
    .B(_542_),
    .C(_543_),
    .Y(_544_)
);

FILL FILL_1__1345_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1412_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [5]),
    .B(_386_),
    .Y(_385_)
);

FILL FILL_0__1469_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1221_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [0]),
    .B(_353_),
    .Y(_203_)
);

NOR2X1 _972_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_502_),
    .B(_500_),
    .Y(_503_)
);

FILL FILL_0__1278_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1019_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1450_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_712__bF$buf0),
    .D(_723_),
    .CLK(clk_bF$buf4),
    .Q(\u_ball.x_pos [0])
);

INVX1 _1030_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(load_option_bF$buf1),
    .Y(_464_)
);

FILL FILL_1__812_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _781_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_582_),
    .Y(_439_)
);

FILL FILL_1__1192_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL83850x75750 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1087_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1506_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_636_),
    .B(_633_),
    .C(_628_),
    .Y(_764_)
);

FILL FILL_0__834_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _837_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_569_),
    .Y(_3_)
);

FILL FILL_1__1248_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1315_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_308_),
    .Y(_293_)
);

FILL FILL_1__1477_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__850_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1544_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_663_),
    .B(_667_),
    .C(_701_),
    .Y(_658_)
);

NOR2X1 _1124_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [1]),
    .B(\u_ball.x_ball [2]),
    .Y(_106_)
);

FILL FILL_0__872_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__906_ (
    .gnd(gnd),
    .vdd(vdd)
);

OR2X2 _875_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_529_),
    .B(paddle_v[0]),
    .Y(_729_)
);

FILL FILL_1__1286_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__928_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1353_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [6]),
    .B(\u_ball.x_ball [3]),
    .Y(_329_)
);

INVX1 _1409_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(load_option_bF$buf3),
    .Y(_382_)
);

NOR2X1 _1582_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_702_),
    .B(_690_),
    .Y(_689_)
);

OAI21X1 _1162_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_149_),
    .B(_145_),
    .C(_147_),
    .Y(_144_)
);

FILL FILL_0__1202_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _1218_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_211_),
    .B(_206_),
    .C(_201_),
    .Y(_200_)
);

FILL FILL_0__966_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _969_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(paddle_v[1]),
    .Y(_506_)
);

INVX1 _1391_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(paddle_v[0]),
    .Y(_367_)
);

FILL FILL_0__1431_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1447_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_712__bF$buf3),
    .D(_707_),
    .CLK(clk_bF$buf4),
    .Q(\u_ball.x_pos [6])
);

INVX1 _1027_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_init [1]),
    .Y(_466_)
);

FILL FILL_1__809_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _778_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_438_),
    .B(_441_),
    .Y(_496_)
);

FILL FILL_1__1189_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1240_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1256_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_241_),
    .B(_236_),
    .Y(_235_)
);

FILL FILL_1__791_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1210_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1485_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_697_),
    .B(_613_),
    .Y(_612_)
);

NOR2X1 _1065_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_397_),
    .B(_400_),
    .Y(_53_)
);

FILL FILL_1__847_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1525_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1105_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__869_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI22X1 _1294_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_335_),
    .B(paddle_h[1]),
    .C(_275_),
    .D(_274_),
    .Y(_273_)
);

FILL FILL_0__1334_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1563_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1143_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1304_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0_BUFX2_insert10 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0_BUFX2_insert11 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0_BUFX2_insert12 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0_BUFX2_insert13 (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1579_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_687_),
    .B(_693_),
    .Y(_686_)
);

FILL FILL_0_BUFX2_insert14 (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1159_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [5]),
    .Y(_141_)
);

FILL FILL_0_BUFX2_insert15 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0_BUFX2_insert16 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0_BUFX2_insert17 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0_BUFX2_insert18 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL83250x10950 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0_BUFX2_insert19 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1372_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI22X1 _1388_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_402_),
    .B(paddle_v[2]),
    .C(_368_),
    .D(paddle_v[1]),
    .Y(_364_)
);

FILL FILL_0__1428_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1181_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1600_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_417_),
    .S(vdd),
    .D(_410_),
    .CLK(clk_bF$buf3),
    .Q(_0_)
);

NOR2X1 _931_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(paddle_h[2]),
    .B(paddle_h[3]),
    .Y(_548_)
);

NAND2X1 _1197_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_188_),
    .B(_180_),
    .Y(_179_)
);

FILL FILL_0__1237_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1151_ (
    .gnd(gnd),
    .vdd(vdd)
);

BUFX2 BUFX2_insert20 (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State [3]),
    .Y(\u_ctrl.State_3_bF$buf3 )
);

BUFX2 BUFX2_insert21 (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State [3]),
    .Y(\u_ctrl.State_3_bF$buf2 )
);

BUFX2 BUFX2_insert22 (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State [3]),
    .Y(\u_ctrl.State_3_bF$buf1 )
);

BUFX2 BUFX2_insert23 (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State [3]),
    .Y(\u_ctrl.State_3_bF$buf0 )
);

FILL FILL_1__788_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1466_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1207_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1275_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1436_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1016_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1084_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _1503_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_695_),
    .B(_627_),
    .C(_644_),
    .Y(_626_)
);

FILL FILL_0__831_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _834_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [4]),
    .Y(_6_)
);

FILL FILL_1__1245_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1312_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_292_),
    .B(_291_),
    .C(_307_),
    .Y(_290_)
);

FILL FILL_0__1369_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1541_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_698_),
    .Y(_656_)
);

OAI21X1 _1121_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_104_),
    .B(_107_),
    .C(\u_ball.x_pos [5]),
    .Y(_103_)
);

NAND2X1 _872_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [5]),
    .B(_497_),
    .Y(_731_)
);

FILL FILL_0__1178_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__925_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _928_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(paddle_h[4]),
    .B(paddle_h[5]),
    .Y(_551_)
);

NAND3X1 _1350_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [0]),
    .B(_335_),
    .C(_327_),
    .Y(_326_)
);

FILL FILL_1__1092_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1406_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_409_),
    .B(_384_),
    .C(_380_),
    .Y(_427_)
);

FILL FILL_1__1568_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1148_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI22X1 _1215_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_214_),
    .B(_213_),
    .C(_198_),
    .D(_209_),
    .Y(_197_)
);

FILL FILL_0__963_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _966_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_502_),
    .Y(_509_)
);

FILL FILL_1__1377_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL83850x28950 (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1444_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_712__bF$buf3),
    .S(vdd),
    .D(_706_),
    .CLK(clk_bF$buf4),
    .Q(_763_)
);

NAND2X1 _1024_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_init [2]),
    .B(_464_),
    .Y(_448_)
);

FILL FILL_1__806_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _775_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_491_),
    .S(vdd),
    .D(_484_),
    .CLK(clk_bF$buf2),
    .Q(paddle_h[4])
);

FILL FILL_1__1186_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__828_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1253_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_353_),
    .B(_409_),
    .Y(_232_)
);

OAI21X1 _1309_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_303_),
    .B(_288_),
    .C(_300_),
    .Y(_287_)
);

NOR3X1 _1482_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_692_),
    .B(_645_),
    .C(_697_),
    .Y(_610_)
);

OAI21X1 _1062_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_53_),
    .B(_52_),
    .C(_51_),
    .Y(_412_)
);

FILL FILL_1__844_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1522_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1102_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI22X1 _1538_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_700_),
    .B(_669_),
    .C(_654_),
    .D(\u_ctrl.State_3_bF$buf2 ),
    .Y(_719_)
);

NAND2X1 _1118_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_101_),
    .B(_103_),
    .Y(_100_)
);

FILL FILL_0__866_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _869_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [0]),
    .Y(_734_)
);

AOI21X1 _1291_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_273_),
    .B(_277_),
    .C(_271_),
    .Y(_270_)
);

FILL FILL_0__1331_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1347_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.sign_x ),
    .B(\u_ball.x_ball [1]),
    .Y(_324_)
);

FILL FILL_1__1089_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1560_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1140_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _1576_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [0]),
    .B(\u_ball.y_pos [1]),
    .C(\u_ball.y_pos [2]),
    .Y(_684_)
);

AOI21X1 _1156_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_154_),
    .B(_142_),
    .C(_139_),
    .Y(_138_)
);

FILL FILL_1__938_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1110_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _1385_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_365_),
    .B(_364_),
    .C(_362_),
    .Y(_361_)
);

FILL FILL_0__1425_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1005_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__769_ (
    .gnd(gnd),
    .vdd(vdd)
);

AND2X2 _1194_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_188_),
    .B(_180_),
    .Y(_176_)
);

FILL FILL_1__976_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1234_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__998_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__785_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1463_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1204_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR3X1 _1479_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_641_),
    .B(_608_),
    .C(_610_),
    .Y(_607_)
);

OAI21X1 _1059_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_49_),
    .B(_50_),
    .C(_765__bF$buf1),
    .Y(_48_)
);

FILL FILL_0__1519_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1272_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1433_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI22X1 _1288_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [3]),
    .B(_269_),
    .C(\u_ball.x_ball [4]),
    .D(_268_),
    .Y(_267_)
);

FILL FILL_0__1328_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1081_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1500_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_624_),
    .B(_646_),
    .Y(_623_)
);

NOR2X1 _831_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_6_),
    .B(_8_),
    .Y(_9_)
);

NAND3X1 _1097_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_94_),
    .B(_84_),
    .C(_80_),
    .Y(_79_)
);

FILL FILL_0__1557_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1137_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1366_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1527_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1107_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1595_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1175_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__922_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _925_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_549_),
    .B(_552_),
    .C(_553_),
    .Y(_554_)
);

FILL FILL_1__1336_ (
    .gnd(gnd),
    .vdd(vdd)
);

OR2X2 _1403_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_391_),
    .B(_378_),
    .Y(_377_)
);

FILL FILL_1__1565_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1145_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL83250x18150 (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _1212_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_210_),
    .B(_216_),
    .C(_195_),
    .Y(_194_)
);

FILL FILL_0__960_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _963_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(paddle_v[0]),
    .B(_511_),
    .C(_510_),
    .Y(_512_)
);

FILL FILL_1__1374_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1269_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1441_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_712__bF$buf3),
    .D(_721_),
    .CLK(clk_bF$buf2),
    .Q(\u_ball.x_pos [2])
);

NAND2X1 _1021_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(load_option_bF$buf2),
    .B(\u_ball.y_init [2]),
    .Y(_450_)
);

FILL FILL_1__803_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _772_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_491_),
    .S(vdd),
    .D(_493_),
    .CLK(clk_bF$buf5),
    .Q(paddle_h[1])
);

FILL FILL_0__1498_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1078_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__825_ (
    .gnd(gnd),
    .vdd(vdd)
);

OR2X2 _828_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_550_),
    .B(\u_ball.x_pos [1]),
    .Y(_12_)
);

OAI21X1 _1250_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_263_),
    .B(_234_),
    .C(_230_),
    .Y(_421_)
);

AOI21X1 _1306_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_285_),
    .B(_295_),
    .C(_409_),
    .Y(_284_)
);

FILL FILL_1__1468_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _1535_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_653_),
    .B(_652_),
    .C(game_new),
    .Y(_533_)
);

AOI22X1 _1115_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_99_),
    .B(_107_),
    .C(_98_),
    .D(_120_),
    .Y(_97_)
);

FILL FILL_0__863_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _866_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [2]),
    .Y(_737_)
);

FILL FILL_1__1277_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__919_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _1344_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_322_),
    .B(_324_),
    .C(\u_ball.x_ball [0]),
    .Y(_321_)
);

FILL FILL_1__1086_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL83850x14550 (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1573_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_683_),
    .B(_682_),
    .C(\u_ctrl.State_3_bF$buf2 ),
    .Y(_681_)
);

OAI21X1 _1153_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [2]),
    .B(_215_),
    .C(_136_),
    .Y(_135_)
);

FILL FILL_1__935_ (
    .gnd(gnd),
    .vdd(vdd)
);

OR2X2 _1209_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [2]),
    .B(\u_ball.x_pos [2]),
    .Y(_191_)
);

FILL FILL_0__957_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1382_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(paddle_v[4]),
    .B(_394_),
    .C(_363_),
    .Y(_358_)
);

FILL FILL_0__1422_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1002_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1438_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_712__bF$buf1),
    .S(vdd),
    .D(_703_),
    .CLK(clk_bF$buf6),
    .Q(\u_ctrl.cnt_v_sync [1])
);

NAND2X1 _1018_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_init [4]),
    .B(_464_),
    .Y(_451_)
);

BUFX2 _769_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_763_),
    .Y(p_tick)
);

NAND2X1 _1191_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_182_),
    .B(_174_),
    .Y(_173_)
);

FILL FILL_1__973_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1231_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI22X1 _1247_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [2]),
    .B(_383_),
    .C(_381_),
    .D(\u_ball.x_init [2]),
    .Y(_227_)
);

FILL FILL_0__995_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _998_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_init [4]),
    .B(_477_),
    .Y(_481_)
);

FILL FILL_1__1201_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL82650x46950 (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _1476_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_606_),
    .B(_605_),
    .C(_640_),
    .Y(_604_)
);

OAI22X1 _1056_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_363_),
    .B(_379_),
    .C(_46_),
    .D(_47_),
    .Y(_411_)
);

FILL FILL_0__1516_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1430_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1285_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [5]),
    .B(_280_),
    .C(_265_),
    .Y(_264_)
);

FILL FILL_0__1325_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1_BUFX2_insert20 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1_BUFX2_insert22 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1_BUFX2_insert23 (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _1094_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_93_),
    .B(_83_),
    .C(_82_),
    .Y(_76_)
);

FILL FILL_1__876_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1554_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1134_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__898_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1363_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1524_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1104_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _1379_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [4]),
    .B(_356_),
    .C(_370_),
    .Y(_355_)
);

FILL FILL_0__1419_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1592_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1172_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX2 _922_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(paddle_h[2]),
    .Y(_557_)
);

FILL FILL_1__1333_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1188_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_172_),
    .B(_171_),
    .Y(_170_)
);

FILL FILL_0__1228_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1400_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_765__bF$buf1),
    .B(\u_ball.y_init [4]),
    .C(_379_),
    .Y(_374_)
);

FILL FILL_1__1562_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1142_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _960_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_505_),
    .B(_514_),
    .Y(_515_)
);

FILL FILL_1__1371_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1266_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1007_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1495_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1075_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__822_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _825_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [3]),
    .B(_10_),
    .C(_14_),
    .Y(_15_)
);

INVX1 _1303_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(paddle_h[6]),
    .Y(_282_)
);

FILL FILL_1__1465_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1532_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_652_),
    .B(_696_),
    .C(_650_),
    .Y(_534_)
);

AND2X2 _1112_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_174_),
    .B(_182_),
    .Y(_94_)
);

FILL FILL_0__860_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _863_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [3]),
    .Y(_740_)
);

FILL FILL_1__1274_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1589_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1169_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__916_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _919_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(paddle_h[5]),
    .B(paddle_h[6]),
    .C(_559_),
    .Y(_560_)
);

AOI22X1 _1341_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [1]),
    .B(_383_),
    .C(_381_),
    .D(\u_ball.x_init [1]),
    .Y(_318_)
);

FILL FILL_1__1083_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1398_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1570_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [3]),
    .Y(_679_)
);

AOI21X1 _1150_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_134_),
    .B(_133_),
    .C(_137_),
    .Y(_132_)
);

FILL FILL_1__932_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1206_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [1]),
    .B(_335_),
    .Y(_188_)
);

FILL FILL_0__954_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _957_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_517_),
    .B(_503_),
    .Y(_518_)
);

INVX2 _1435_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [5]),
    .Y(_408_)
);

NAND2X1 _1015_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(load_option_bF$buf2),
    .B(\u_ball.y_init [4]),
    .Y(_453_)
);

FILL FILL_1__970_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__819_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1244_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_226_),
    .Y(_225_)
);

FILL FILL_0__992_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _995_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_init [5]),
    .Y(_482_)
);

AOI21X1 _1473_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_603_),
    .B(\u_ctrl.State [1]),
    .C(\u_ctrl.State_3_bF$buf3 ),
    .Y(_602_)
);

INVX1 _1053_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_239_),
    .Y(_43_)
);

FILL FILL_1__835_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1513_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1529_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.cnt_v_sync [2]),
    .B(_648_),
    .Y(_647_)
);

NAND2X1 _1109_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_353_),
    .B(_217_),
    .Y(_91_)
);

FILL FILL_0__857_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI22X1 _1282_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_282_),
    .B(\u_ball.x_ball [6]),
    .C(\u_ball.x_ball [5]),
    .D(_280_),
    .Y(_261_)
);

FILL FILL_0__1322_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX2 _1338_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.sign_x ),
    .Y(_316_)
);

NOR3X1 _1091_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_131_),
    .B(_74_),
    .C(_95_),
    .Y(pixel_ball)
);

FILL FILL_1__873_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1551_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1131_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1567_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_678_),
    .B(_677_),
    .C(\u_ctrl.State_3_bF$buf2 ),
    .Y(_676_)
);

NOR2X1 _1147_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [4]),
    .B(_130_),
    .Y(_129_)
);

FILL FILL_0__895_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__929_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _898_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_573_),
    .Y(_580_)
);

FILL FILL_0__1360_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1521_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1101_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI22X1 _1376_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(paddle_v[1]),
    .B(_368_),
    .C(_353_),
    .D(paddle_v[0]),
    .Y(_352_)
);

FILL FILL_0__1416_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1330_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1185_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_399_),
    .Y(_167_)
);

FILL FILL_0__1225_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__989_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__798_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1263_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1279_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_276_),
    .B(_269_),
    .Y(_258_)
);

FILL FILL_0__1319_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1492_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1072_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _822_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(paddle_h[5]),
    .B(_559_),
    .Y(_18_)
);

FILL FILL_1__1233_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _1088_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_73_),
    .B(_288_),
    .C(_409_),
    .Y(_72_)
);

FILL FILL_0__1548_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1128_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1300_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(paddle_h[1]),
    .Y(_279_)
);

FILL FILL_1__1462_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1357_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1518_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI22X1 _860_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_741_),
    .B(_742_),
    .C(_736_),
    .D(_739_),
    .Y(_743_)
);

FILL FILL_1__1271_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1586_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1166_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__913_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _916_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(paddle_h[1]),
    .B(_562_),
    .C(_561_),
    .Y(_563_)
);

FILL FILL_1__1327_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1395_ (
    .gnd(gnd),
    .vdd(vdd)
);

AND2X2 _1203_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_191_),
    .B(_190_),
    .Y(_185_)
);

FILL FILL_0__951_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _954_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(paddle_v[2]),
    .B(paddle_v[3]),
    .Y(_521_)
);

NAND2X1 _1432_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.sign_y ),
    .B(\u_ball.y_ball [3]),
    .Y(_405_)
);

DFFSR _1012_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_458_),
    .S(vdd),
    .D(_457_),
    .CLK(clk_bF$buf0),
    .Q(\u_ball.y_init [3])
);

FILL FILL_1__1594_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1174_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1489_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1069_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__816_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _819_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_9_),
    .B(_17_),
    .C(_20_),
    .Y(_21_)
);

INVX1 _1241_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_init [3]),
    .Y(_222_)
);

NAND2X1 _992_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_init [6]),
    .B(_477_),
    .Y(_442_)
);

FILL FILL_0__1298_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1470_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [5]),
    .Y(_600_)
);

AOI21X1 _1050_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_41_),
    .B(_44_),
    .C(load_option_bF$buf3),
    .Y(_410_)
);

FILL FILL_1__832_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1510_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1526_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_645_),
    .B(_697_),
    .C(\u_ctrl.State_3_bF$buf1 ),
    .Y(_644_)
);

OAI21X1 _1106_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_199_),
    .B(_197_),
    .C(_89_),
    .Y(_88_)
);

FILL FILL_0__854_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _857_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_498_),
    .B(\u_ball.y_pos [4]),
    .C(_745_),
    .Y(_746_)
);

FILL FILL_1__1268_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1335_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.sign_x ),
    .B(\u_ball.x_ball [4]),
    .Y(_313_)
);

FILL FILL_1__870_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1564_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [4]),
    .Y(_674_)
);

OAI21X1 _1144_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_185_),
    .B(_184_),
    .C(_127_),
    .Y(_126_)
);

FILL FILL_0__892_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _895_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_541_),
    .B(_570_),
    .C(_582_),
    .Y(_583_)
);

FILL FILL_0__948_ (
    .gnd(gnd),
    .vdd(vdd)
);

AND2X2 _1373_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_350_),
    .B(_352_),
    .Y(_349_)
);

FILL FILL_0__1413_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX2 _1429_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [2]),
    .Y(_402_)
);

DFFSR _1009_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_458_),
    .S(vdd),
    .D(_454_),
    .CLK(clk_bF$buf0),
    .Q(\u_ball.y_init [0])
);

NAND2X1 _1182_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [2]),
    .B(_399_),
    .Y(_164_)
);

FILL FILL_0__1222_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1238_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_272_),
    .B(_379_),
    .C(_220_),
    .Y(_419_)
);

FILL FILL_0__986_ (
    .gnd(gnd),
    .vdd(vdd)
);

OR2X2 _989_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_init [6]),
    .B(\u_ball.x_init [5]),
    .Y(_444_)
);

FILL FILL_0__1031_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1467_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_692_),
    .B(_598_),
    .C(_693_),
    .Y(_597_)
);

DFFSR _1047_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_417_),
    .S(vdd),
    .D(_427_),
    .CLK(clk_bF$buf7),
    .Q(\u_ball.y_ball [5])
);

FILL FILL_0__795_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__829_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _798_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_528_),
    .B(_39_),
    .Y(_40_)
);

FILL FILL_0__1507_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1260_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1276_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_256_),
    .B(_257_),
    .Y(_255_)
);

FILL FILL_0__1316_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1230_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1085_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_314_),
    .Y(_70_)
);

FILL FILL_0__1545_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1125_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__889_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1354_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1583_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1163_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__910_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _913_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_565_),
    .B(_556_),
    .Y(_566_)
);

DFFSR _1599_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_458_),
    .D(_460_),
    .CLK(clk_bF$buf0),
    .Q(\u_ball.y_init [5])
);

OAI21X1 _1179_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [2]),
    .B(_167_),
    .C(_363_),
    .Y(_161_)
);

FILL FILL_0__1219_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1392_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1133_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1028_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL83250x46950 (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1200_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_186_),
    .B(_183_),
    .Y(_182_)
);

NAND3X1 _951_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_521_),
    .B(_522_),
    .C(_523_),
    .Y(_524_)
);

FILL FILL_1__999_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1257_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1418_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1591_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1171_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1486_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1066_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__813_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI22X1 _816_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_3_),
    .B(_5_),
    .C(_21_),
    .D(_23_),
    .Y(_24_)
);

FILL FILL_1__1227_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1295_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1523_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State [1]),
    .Y(_642_)
);

NAND3X1 _1103_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_206_),
    .B(_86_),
    .C(_211_),
    .Y(_85_)
);

FILL FILL_0__851_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _854_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [3]),
    .B(_521_),
    .C(_748_),
    .Y(_749_)
);

FILL FILL_0__907_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1332_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.sign_x ),
    .B(\u_ball.x_ball [3]),
    .Y(_310_)
);

FILL FILL_1__1074_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1389_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1561_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [4]),
    .B(_672_),
    .C(\u_ctrl.State_3_bF$buf2 ),
    .Y(_671_)
);

AOI22X1 _1141_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_191_),
    .B(_190_),
    .C(_125_),
    .D(_124_),
    .Y(_123_)
);

OAI21X1 _892_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_584_),
    .B(_585_),
    .C(_555_),
    .Y(_586_)
);

FILL FILL_0__1198_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__945_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _948_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_526_),
    .B(_524_),
    .Y(_527_)
);

FILL FILL_1__1359_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1370_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_363_),
    .B(_347_),
    .C(_348_),
    .Y(_346_)
);

FILL FILL_0__1410_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL83550x54150 (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1426_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [0]),
    .B(\u_ball.y_ball [1]),
    .Y(_399_)
);

NAND2X1 _1006_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_init [0]),
    .B(load_option_bF$buf1),
    .Y(_476_)
);

FILL FILL_1__1588_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1168_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__961_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1235_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [0]),
    .Y(_217_)
);

NAND2X1 _986_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_446_),
    .B(_445_),
    .Y(_474_)
);

FILL FILL_1__1397_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1464_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_596_),
    .B(_648_),
    .Y(_595_)
);

DFFSR _1044_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_417_),
    .S(vdd),
    .D(_415_),
    .CLK(clk_bF$buf7),
    .Q(\u_ball.x_ball [5])
);

FILL FILL_0__792_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__826_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _795_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_550_),
    .B(_555_),
    .Y(_428_)
);

FILL FILL_0__1504_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__848_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1273_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [1]),
    .B(_279_),
    .C(_253_),
    .Y(_252_)
);

FILL FILL_0__1313_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1329_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_336_),
    .B(_323_),
    .C(_324_),
    .Y(_307_)
);

NAND3X1 _1082_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_70_),
    .B(_68_),
    .C(_288_),
    .Y(_67_)
);

FILL FILL_0__1542_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1122_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1558_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State_3_bF$buf0 ),
    .B(\u_ctrl.State [0]),
    .Y(_669_)
);

INVX1 _1138_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [5]),
    .Y(_120_)
);

FILL FILL_0__886_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _889_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_512_),
    .B(_515_),
    .C(_528_),
    .Y(_588_)
);

FILL FILL_0__1351_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1367_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_402_),
    .B(_351_),
    .C(_344_),
    .Y(_343_)
);

FILL FILL_0__1407_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1580_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1160_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _910_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(paddle_h[4]),
    .B(_568_),
    .C(paddle_h[5]),
    .Y(_569_)
);

INVX1 _1596_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [0]),
    .Y(_702_)
);

OAI22X1 _1176_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_215_),
    .B(_166_),
    .C(_162_),
    .D(_159_),
    .Y(_158_)
);

FILL FILL_1__958_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1216_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1550_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1130_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1025_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__789_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__996_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1254_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1415_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1483_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1063_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__810_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI22X1 _813_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(paddle_h[2]),
    .B(_11_),
    .C(_25_),
    .D(_26_),
    .Y(_27_)
);

NOR2X1 _1499_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State_3_bF$buf3 ),
    .B(_623_),
    .Y(_622_)
);

OAI21X1 _1079_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_68_),
    .B(_65_),
    .C(_765__bF$buf2),
    .Y(_64_)
);

FILL FILL_0__1539_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1119_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1292_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1348_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1509_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1520_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_649_),
    .B(_640_),
    .Y(_536_)
);

NAND3X1 _1100_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_211_),
    .B(_206_),
    .C(_194_),
    .Y(_82_)
);

NAND3X1 _851_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(paddle_v[0]),
    .B(_734_),
    .C(_735_),
    .Y(_752_)
);

FILL FILL_1__899_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1577_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1157_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__904_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _907_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_540_),
    .B(_571_),
    .Y(_572_)
);

FILL FILL_1__1318_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1491_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1071_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1386_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1547_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1127_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__920_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL82950x14550 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1195_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__942_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _945_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_502_),
    .B(_500_),
    .C(paddle_v[3]),
    .Y(_530_)
);

FILL FILL_1__1356_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1423_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_397_),
    .B(_400_),
    .Y(_396_)
);

NAND2X1 _1003_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_init [2]),
    .B(_477_),
    .Y(_478_)
);

FILL FILL_1__1585_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__807_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1232_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [2]),
    .B(_215_),
    .Y(_214_)
);

DFFSR _983_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_471_),
    .S(vdd),
    .D(_469_),
    .CLK(clk_bF$buf3),
    .Q(\u_ball.x_init [3])
);

FILL FILL_1__1394_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1289_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1461_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_626_),
    .B(_594_),
    .C(_593_),
    .Y(_703_)
);

DFFSR _1041_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_417_),
    .S(vdd),
    .D(_422_),
    .CLK(clk_bF$buf7),
    .Q(\u_ball.x_ball [6])
);

AOI21X1 _792_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_429_),
    .B(_562_),
    .C(paddle_h[1]),
    .Y(_430_)
);

FILL FILL_0__1501_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1098_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1517_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_651_),
    .B(_639_),
    .C(_638_),
    .Y(_546_)
);

FILL FILL_0__845_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _848_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_751_),
    .B(_749_),
    .C(_754_),
    .Y(_755_)
);

FILL FILL_1__1259_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1270_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_250_),
    .B(_258_),
    .Y(_249_)
);

FILL FILL_0__1310_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1326_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_310_),
    .B(_305_),
    .C(_311_),
    .Y(_304_)
);

FILL FILL_1__1488_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1068_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1555_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [0]),
    .B(\u_ball.x_pos [1]),
    .Y(_667_)
);

AOI21X1 _1135_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_149_),
    .B(\u_ball.x_pos [5]),
    .C(_147_),
    .Y(_117_)
);

FILL FILL_0__883_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__917_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _886_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_589_),
    .B(_516_),
    .Y(_590_)
);

FILL FILL_1__1297_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__939_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _1364_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_408_),
    .B(paddle_v[5]),
    .C(_355_),
    .Y(_340_)
);

FILL FILL_0__1404_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _1593_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [0]),
    .B(\u_ball.x_pos [1]),
    .C(\u_ball.x_pos [2]),
    .Y(_699_)
);

INVX1 _1173_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [4]),
    .Y(_155_)
);

FILL FILL_1__955_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1213_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1229_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_218_),
    .B(_216_),
    .C(_212_),
    .Y(_211_)
);

FILL FILL_0__977_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1022_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1458_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_712__bF$buf2),
    .D(_724_),
    .CLK(clk_bF$buf2),
    .Q(\u_ball.y_pos [4])
);

DFFSR _1038_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_417_),
    .D(_412_),
    .CLK(clk_bF$buf7),
    .Q(\u_ball.y_ball [2])
);

FILL FILL_0__786_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI22X1 _789_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_557_),
    .B(_555_),
    .C(_430_),
    .D(_432_),
    .Y(_494_)
);

FILL FILL_1__993_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1251_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1412_ (
    .gnd(gnd),
    .vdd(vdd)
);

OR2X2 _1267_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_258_),
    .B(_250_),
    .Y(_246_)
);

FILL FILL_0__1307_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1480_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1060_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI22X1 _810_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [5]),
    .B(_541_),
    .C(_540_),
    .D(\u_ball.x_pos [4]),
    .Y(_30_)
);

OAI21X1 _1496_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_700_),
    .B(_659_),
    .C(_635_),
    .Y(_620_)
);

OAI21X1 _1076_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_66_),
    .B(_64_),
    .C(_62_),
    .Y(_61_)
);

FILL FILL_1__858_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1536_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1116_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1345_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1506_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__896_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1574_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1154_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__901_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _904_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_567_),
    .B(_574_),
    .Y(_575_)
);

FILL FILL_1__1315_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1383_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1544_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1124_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI22X1 _1399_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_394_),
    .B(_379_),
    .C(_374_),
    .D(_375_),
    .Y(_426_)
);

FILL FILL_0__1019_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1192_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _942_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(paddle_v[4]),
    .B(_503_),
    .Y(_537_)
);

FILL FILL_1__1353_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1248_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1420_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.sign_y ),
    .B(_394_),
    .Y(_393_)
);

NAND2X1 _1000_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(load_option_bF$buf0),
    .B(\u_ball.x_init [2]),
    .Y(_480_)
);

FILL FILL_1__799_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1477_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1057_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__804_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _807_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_737_),
    .B(_740_),
    .Y(_33_)
);

DFFSR _980_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_471_),
    .S(vdd),
    .D(_473_),
    .CLK(clk_bF$buf3),
    .Q(\u_ball.x_init [6])
);

FILL FILL_0__1286_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1027_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1095_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1514_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [5]),
    .Y(_635_)
);

FILL FILL_0__842_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _845_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_732_),
    .B(_757_),
    .C(_755_),
    .Y(_758_)
);

FILL FILL_1__1256_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _1323_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_312_),
    .B(_302_),
    .C(_304_),
    .Y(_301_)
);

FILL FILL_1__1485_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1065_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1552_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_667_),
    .B(_665_),
    .Y(_664_)
);

NOR3X1 _1132_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [0]),
    .B(\u_ball.x_ball [1]),
    .C(\u_ball.x_ball [2]),
    .Y(_114_)
);

FILL FILL_0__880_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__914_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _883_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_517_),
    .B(_528_),
    .C(_592_),
    .Y(_487_)
);

FILL FILL_1__1294_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1189_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__936_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _939_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_520_),
    .B(_539_),
    .Y(_483_)
);

NAND3X1 _1361_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [6]),
    .B(\u_ball.x_ball [4]),
    .C(\u_ball.x_ball [5]),
    .Y(_337_)
);

FILL FILL83550x28950 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1401_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1417_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [4]),
    .B(_403_),
    .Y(_390_)
);

INVX1 _1590_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(game_new),
    .Y(_696_)
);

INVX1 _1170_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_153_),
    .Y(_152_)
);

FILL FILL_1__952_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1210_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1226_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_353_),
    .B(\u_ball.y_pos [0]),
    .C(_209_),
    .Y(_208_)
);

FILL FILL_0__974_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _977_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(paddle_v[4]),
    .Y(_498_)
);

DFFSR _1455_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_712__bF$buf3),
    .D(_710_),
    .CLK(clk_bF$buf2),
    .Q(\u_ball.x_pos [5])
);

DFFSR _1035_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_417_),
    .S(vdd),
    .D(_424_),
    .CLK(clk_bF$buf1),
    .Q(\u_ball.sign_x )
);

FILL FILL_0__783_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__817_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _786_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_555_),
    .B(_434_),
    .C(_433_),
    .Y(_435_)
);

FILL FILL_1__1197_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__990_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__839_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1264_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_281_),
    .B(_262_),
    .Y(_243_)
);

FILL FILL_0__1304_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1493_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_653_),
    .B(_652_),
    .Y(_618_)
);

OAI21X1 _1073_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_init [0]),
    .B(_372_),
    .C(_60_),
    .Y(_59_)
);

FILL FILL_1__855_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1533_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1113_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1549_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_666_),
    .B(_668_),
    .C(_663_),
    .Y(_662_)
);

NAND2X1 _1129_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [3]),
    .B(_272_),
    .Y(_111_)
);

FILL FILL_0__877_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1342_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1503_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1358_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [2]),
    .B(\u_ball.x_ball [3]),
    .Y(_334_)
);

FILL FILL_1__893_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1571_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1151_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _901_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_540_),
    .B(_555_),
    .C(_577_),
    .Y(_484_)
);

FILL FILL_1__1312_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _1587_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_697_),
    .B(\u_ctrl.State_3_bF$buf0 ),
    .C(_694_),
    .Y(_693_)
);

INVX2 _1167_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [5]),
    .Y(_149_)
);

FILL FILL83850x36150 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1207_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1380_ (
    .gnd(gnd),
    .vdd(vdd)
);

MUX2X1 _1396_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_383_),
    .B(_765__bF$buf2),
    .S(\u_ball.x_ball [0]),
    .Y(_371_)
);

FILL FILL_0__1436_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1016_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1245_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__796_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1474_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1054_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__801_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _804_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_32_),
    .B(_31_),
    .C(_35_),
    .Y(_36_)
);

FILL FILL_1__1215_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1283_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1024_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1299_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [1]),
    .B(_279_),
    .Y(_278_)
);

FILL FILL_0__1339_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1092_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1511_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_679_),
    .B(_674_),
    .Y(_632_)
);

NOR2X1 _842_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_759_),
    .B(_760_),
    .Y(_761_)
);

FILL FILL_1__1253_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1568_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1148_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1309_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1320_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_316_),
    .B(_299_),
    .Y(_298_)
);

FILL FILL_1__1482_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1377_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__911_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _880_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_531_),
    .B(_519_),
    .C(_714_),
    .Y(_715_)
);

FILL FILL_1__1291_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1186_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__933_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _936_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(paddle_h[6]),
    .Y(_542_)
);

INVX1 _1414_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_390_),
    .Y(_387_)
);

FILL FILL_1__1576_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1156_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1223_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [1]),
    .B(_219_),
    .C(_216_),
    .Y(_205_)
);

FILL FILL_0__971_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _974_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(btn_down),
    .Y(_501_)
);

FILL FILL_1__1385_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1452_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_712__bF$buf1),
    .D(_546_),
    .CLK(clk_bF$buf6),
    .Q(\u_ctrl.State [0])
);

OR2X2 _1032_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_init [5]),
    .B(\u_ball.y_init [4]),
    .Y(_462_)
);

FILL FILL_0__780_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__814_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0_CLKBUF1_insert0 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0_CLKBUF1_insert1 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0_CLKBUF1_insert2 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0_CLKBUF1_insert3 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0_CLKBUF1_insert4 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0_CLKBUF1_insert5 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0_CLKBUF1_insert6 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0_CLKBUF1_insert7 (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _783_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_541_),
    .B(_570_),
    .Y(_437_)
);

FILL FILL_1__1194_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1089_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1508_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(pixel_ball),
    .B(pixel_paddle),
    .Y(_629_)
);

FILL FILL_0__836_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _839_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_766_),
    .B(_762_),
    .Y(_1_)
);

OAI21X1 _1261_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_353_),
    .B(_368_),
    .C(_363_),
    .Y(_240_)
);

FILL FILL_0__1301_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _1317_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_300_),
    .B(_296_),
    .C(_301_),
    .Y(_295_)
);

NAND2X1 _1490_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_669_),
    .B(_639_),
    .Y(_616_)
);

INVX1 _1070_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_398_),
    .Y(_57_)
);

FILL FILL_1__852_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1530_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1110_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL83550x14550 (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1546_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_701_),
    .B(_699_),
    .Y(_660_)
);

AOI21X1 _1126_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_126_),
    .B(_115_),
    .C(_109_),
    .Y(_108_)
);

FILL FILL_0__874_ (
    .gnd(gnd),
    .vdd(vdd)
);

AND2X2 _877_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_717_),
    .B(_713_),
    .Y(_488_)
);

FILL FILL_1__1500_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1355_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_337_),
    .B(_332_),
    .Y(_331_)
);

FILL FILL_1__1097_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1584_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_702_),
    .B(_693_),
    .C(_691_),
    .Y(_728_)
);

NAND3X1 _1164_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_336_),
    .B(_335_),
    .C(_309_),
    .Y(_146_)
);

FILL FILL_0__1204_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__968_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL83850x57750 (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1393_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_370_),
    .Y(_369_)
);

FILL FILL_0__1433_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1449_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_712__bF$buf0),
    .S(vdd),
    .D(_708_),
    .CLK(clk_bF$buf4),
    .Q(_765_)
);

NAND2X1 _1029_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_init [0]),
    .B(_464_),
    .Y(_465_)
);

FILL FILL_0__1242_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1258_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_239_),
    .B(_238_),
    .Y(_237_)
);

FILL FILL_1__793_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1471_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1051_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _801_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_510_),
    .Y(_37_)
);

FILL FILL_1__1212_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1487_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_692_),
    .B(_615_),
    .C(_614_),
    .Y(_708_)
);

OAI21X1 _1067_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_765__bF$buf1),
    .B(\u_ball.y_init [1]),
    .C(_379_),
    .Y(_54_)
);

FILL FILL_0__1527_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1107_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1280_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1021_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1296_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_309_),
    .B(_276_),
    .Y(_275_)
);

FILL FILL_0__1336_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1250_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1565_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1145_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1374_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1115_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1183_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__930_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _933_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(btn_right),
    .B(_525_),
    .Y(_545_)
);

INVX1 _1199_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [1]),
    .Y(_181_)
);

FILL FILL_0__1239_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1411_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_388_),
    .B(_385_),
    .Y(_384_)
);

FILL FILL_1__1573_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1153_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1468_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1209_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1220_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_204_),
    .B(_218_),
    .C(_203_),
    .Y(_202_)
);

AND2X2 _971_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_503_),
    .B(paddle_v[4]),
    .Y(_504_)
);

FILL FILL_1__1382_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1277_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1018_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__811_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI22X1 _780_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_581_),
    .B(_439_),
    .C(_436_),
    .D(_437_),
    .Y(_440_)
);

FILL FILL_1__1191_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1086_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX8 _1505_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(reset),
    .Y(_712_)
);

FILL FILL_0__833_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _836_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(paddle_h[6]),
    .B(_759_),
    .Y(_4_)
);

NOR2X1 _1314_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [2]),
    .B(_316_),
    .Y(_292_)
);

FILL FILL_1__1056_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1543_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_658_),
    .B(_659_),
    .Y(_657_)
);

AOI21X1 _1123_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_106_),
    .B(_336_),
    .C(_272_),
    .Y(_105_)
);

FILL FILL_0__871_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _874_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_718_),
    .B(_729_),
    .Y(_489_)
);

FILL FILL_0__927_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _1352_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [2]),
    .B(_765__bF$buf3),
    .C(_329_),
    .Y(_328_)
);

FILL FILL_1__1094_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1408_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_765__bF$buf2),
    .B(_382_),
    .Y(_381_)
);

NOR2X1 _1581_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [0]),
    .B(\u_ball.y_pos [1]),
    .Y(_688_)
);

OAI21X1 _1161_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_363_),
    .B(_157_),
    .C(_153_),
    .Y(_143_)
);

FILL FILL_1__943_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1201_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _1217_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_208_),
    .B(_210_),
    .C(_207_),
    .Y(_199_)
);

FILL FILL_0__965_ (
    .gnd(gnd),
    .vdd(vdd)
);

AND2X2 _968_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(paddle_v[2]),
    .B(paddle_v[3]),
    .Y(_507_)
);

FILL FILL_1__1379_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1390_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [0]),
    .B(_367_),
    .Y(_366_)
);

FILL FILL_0__1430_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1446_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_712__bF$buf3),
    .S(vdd),
    .D(_535_),
    .CLK(clk_bF$buf6),
    .Q(\u_ctrl.State [2])
);

NAND2X1 _1026_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_init [0]),
    .B(load_option_bF$buf1),
    .Y(_447_)
);

FILL FILL_1__808_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _777_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_491_),
    .S(vdd),
    .D(_488_),
    .CLK(clk_bF$buf1),
    .Q(paddle_v[4])
);

FILL FILL_1__1400_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1255_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_235_),
    .B(_242_),
    .Y(_234_)
);

AOI22X1 _1484_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_637_),
    .B(_669_),
    .C(_612_),
    .D(\u_ctrl.State_3_bF$buf1 ),
    .Y(_707_)
);

NAND2X1 _1064_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_765__bF$buf2),
    .B(_396_),
    .Y(_52_)
);

FILL FILL_0__1524_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1104_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__868_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX2 _1293_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [3]),
    .Y(_272_)
);

FILL FILL_0__1333_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1349_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_328_),
    .B(_326_),
    .C(\u_ball.sign_x ),
    .Y(_325_)
);

FILL FILL_1__884_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1562_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1142_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL83850x43350 (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1578_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_690_),
    .B(_693_),
    .C(_686_),
    .Y(_727_)
);

AOI22X1 _1158_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_148_),
    .B(\u_ball.x_ball [6]),
    .C(\u_ball.y_ball [5]),
    .D(_141_),
    .Y(_140_)
);

FILL FILL_0__1371_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1532_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1112_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX4 _1387_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [3]),
    .Y(_363_)
);

FILL FILL_0__1427_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1007_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1180_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _930_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_548_),
    .Y(_549_)
);

FILL FILL_1__1341_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1196_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_336_),
    .B(\u_ball.x_pos [0]),
    .C(_179_),
    .Y(_178_)
);

FILL FILL_1__978_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1236_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1570_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1150_ (
    .gnd(gnd),
    .vdd(vdd)
);

BUFX2 BUFX2_insert10 (
    .gnd(gnd),
    .vdd(vdd),
    .A(load_option),
    .Y(load_option_bF$buf1)
);

BUFX2 BUFX2_insert11 (
    .gnd(gnd),
    .vdd(vdd),
    .A(load_option),
    .Y(load_option_bF$buf0)
);

BUFX2 BUFX2_insert12 (
    .gnd(gnd),
    .vdd(vdd),
    .A(_765_),
    .Y(_765__bF$buf3)
);

BUFX2 BUFX2_insert13 (
    .gnd(gnd),
    .vdd(vdd),
    .A(_765_),
    .Y(_765__bF$buf2)
);

BUFX2 BUFX2_insert14 (
    .gnd(gnd),
    .vdd(vdd),
    .A(_765_),
    .Y(_765__bF$buf1)
);

BUFX2 BUFX2_insert15 (
    .gnd(gnd),
    .vdd(vdd),
    .A(_765_),
    .Y(_765__bF$buf0)
);

BUFX2 BUFX2_insert16 (
    .gnd(gnd),
    .vdd(vdd),
    .A(_712_),
    .Y(_712__bF$buf3)
);

BUFX2 BUFX2_insert17 (
    .gnd(gnd),
    .vdd(vdd),
    .A(_712_),
    .Y(_712__bF$buf2)
);

BUFX2 BUFX2_insert18 (
    .gnd(gnd),
    .vdd(vdd),
    .A(_712_),
    .Y(_712__bF$buf1)
);

BUFX2 BUFX2_insert19 (
    .gnd(gnd),
    .vdd(vdd),
    .A(_712_),
    .Y(_712__bF$buf0)
);

FILL FILL_0__1465_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1274_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1435_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1083_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1502_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.cnt_v_sync [2]),
    .B(_626_),
    .Y(_625_)
);

FILL FILL_0__830_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _833_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(paddle_h[4]),
    .B(_568_),
    .Y(_7_)
);

INVX1 _1099_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_93_),
    .Y(_81_)
);

FILL FILL_0__1559_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1139_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _1311_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_311_),
    .B(_293_),
    .C(_290_),
    .Y(_289_)
);

FILL FILL_1__1473_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1053_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1368_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1529_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1109_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1540_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_701_),
    .B(_699_),
    .C(_700_),
    .Y(_655_)
);

NAND2X1 _1120_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_145_),
    .B(_113_),
    .Y(_102_)
);

FILL FILL_1__902_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _871_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(paddle_v[4]),
    .B(_730_),
    .C(_731_),
    .Y(_732_)
);

FILL FILL_1__1282_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1177_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__924_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _927_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_550_),
    .B(_542_),
    .C(_551_),
    .Y(_552_)
);

FILL FILL_1__1338_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1091_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX2 _1405_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_383_),
    .Y(_379_)
);

FILL FILL_1__1567_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__940_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1214_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [0]),
    .B(_217_),
    .Y(_196_)
);

FILL FILL_0__962_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _965_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_508_),
    .B(_509_),
    .C(_506_),
    .Y(_510_)
);

FILL FILL_1__1376_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1443_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_712__bF$buf2),
    .D(_725_),
    .CLK(clk_bF$buf5),
    .Q(\u_ball.y_pos [3])
);

OAI21X1 _1023_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_464_),
    .B(_466_),
    .C(_448_),
    .Y(_456_)
);

DFFSR _774_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_491_),
    .S(vdd),
    .D(_492_),
    .CLK(clk_bF$buf1),
    .Q(paddle_v[1])
);

FILL FILL_0__827_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _1252_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_408_),
    .B(_394_),
    .C(_232_),
    .Y(_231_)
);

INVX1 _1308_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_296_),
    .Y(_286_)
);

NOR2X1 _1481_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State_3_bF$buf3 ),
    .B(\u_ctrl.State [1]),
    .Y(_609_)
);

OAI21X1 _1061_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_403_),
    .B(_402_),
    .C(_396_),
    .Y(_50_)
);

FILL FILL_0__1521_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1101_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1537_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State [0]),
    .Y(_653_)
);

INVX1 _1117_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_147_),
    .Y(_99_)
);

FILL FILL_0__865_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _868_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [1]),
    .B(_506_),
    .Y(_735_)
);

FILL FILL_1__1279_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1290_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(paddle_h[3]),
    .Y(_269_)
);

FILL FILL_0__1330_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1346_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.sign_x ),
    .B(\u_ball.x_ball [1]),
    .Y(_323_)
);

FILL FILL_1__1088_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__881_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1300_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1575_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_684_),
    .Y(_683_)
);

NAND3X1 _1155_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_144_),
    .B(_138_),
    .C(_143_),
    .Y(_137_)
);

FILL FILL_1__937_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__959_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1384_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(paddle_v[3]),
    .Y(_360_)
);

FILL FILL_0__1424_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1004_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__768_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1193_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_177_),
    .B(_176_),
    .Y(_175_)
);

FILL FILL_0__1233_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _1249_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_293_),
    .B(_306_),
    .C(_307_),
    .Y(_229_)
);

FILL FILL_0__997_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1462_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1478_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State [0]),
    .B(\u_ctrl.State [2]),
    .Y(_606_)
);

AOI21X1 _1058_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_50_),
    .B(_49_),
    .C(_48_),
    .Y(_47_)
);

FILL FILL_0__1518_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1271_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI22X1 _1287_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_280_),
    .B(\u_ball.x_ball [5]),
    .C(\u_ball.x_ball [4]),
    .D(_268_),
    .Y(_266_)
);

FILL FILL_0__1327_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1080_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _830_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_558_),
    .B(_549_),
    .Y(_10_)
);

FILL FILL_1__1241_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1096_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_182_),
    .B(_174_),
    .Y(_78_)
);

FILL FILL_1__878_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1556_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1136_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1470_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1050_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1365_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1526_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1106_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1594_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1174_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__921_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _924_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_544_),
    .B(_547_),
    .C(_554_),
    .Y(_555_)
);

FILL FILL_1__1335_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1402_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_378_),
    .B(_391_),
    .Y(_376_)
);

OAI21X1 _1211_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_199_),
    .B(_197_),
    .C(_194_),
    .Y(_193_)
);

INVX1 _962_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(paddle_v[2]),
    .Y(_513_)
);

FILL FILL_0__1268_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1440_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_712__bF$buf2),
    .D(_704_),
    .CLK(clk_bF$buf2),
    .Q(\u_ball.y_pos [5])
);

OAI21X1 _1020_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(load_option_bF$buf2),
    .B(_449_),
    .C(_450_),
    .Y(_457_)
);

DFFSR _771_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_491_),
    .S(vdd),
    .D(_483_),
    .CLK(clk_bF$buf1),
    .Q(paddle_v[5])
);

FILL FILL_1__1182_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1497_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1077_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__824_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _827_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(paddle_h[2]),
    .B(\u_ball.x_pos [2]),
    .C(_12_),
    .Y(_13_)
);

FILL FILL_1__1238_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1305_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_765__bF$buf0),
    .B(\u_ball.x_init [6]),
    .C(_379_),
    .Y(_283_)
);

FILL FILL_1__1467_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__840_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1534_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_0_),
    .B(_696_),
    .Y(_651_)
);

OAI21X1 _1114_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_100_),
    .B(_108_),
    .C(_97_),
    .Y(_96_)
);

FILL FILL_0__862_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _865_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [1]),
    .Y(_738_)
);

FILL FILL_1__1276_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__918_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1343_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_324_),
    .B(_322_),
    .Y(_320_)
);

NAND2X1 _1572_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_681_),
    .B(_693_),
    .Y(_680_)
);

OAI21X1 _1152_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_363_),
    .B(\u_ball.y_pos [3]),
    .C(_135_),
    .Y(_134_)
);

FILL FILL_1__934_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1208_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [2]),
    .B(\u_ball.x_pos [2]),
    .Y(_190_)
);

FILL FILL_0__956_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _959_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_512_),
    .B(_515_),
    .C(_505_),
    .Y(_516_)
);

OAI21X1 _1381_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_360_),
    .B(_358_),
    .C(_359_),
    .Y(_357_)
);

FILL FILL_0__1421_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1001_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1437_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_491_),
    .S(vdd),
    .D(_494_),
    .CLK(clk_bF$buf5),
    .Q(paddle_h[2])
);

OAI21X1 _1017_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_464_),
    .B(_449_),
    .C(_451_),
    .Y(_459_)
);

BUFX2 _768_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_764_),
    .Y(pixel)
);

FILL FILL_1__1179_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1190_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_177_),
    .B(_179_),
    .Y(_172_)
);

FILL FILL_0__1230_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1246_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_229_),
    .B(_228_),
    .C(_227_),
    .Y(_420_)
);

FILL FILL_0__994_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _997_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_477_),
    .B(_479_),
    .C(_481_),
    .Y(_470_)
);

FILL FILL_1__781_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1475_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_611_),
    .B(_607_),
    .C(_604_),
    .Y(_706_)
);

INVX1 _1055_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_337_),
    .Y(_45_)
);

FILL FILL_1__837_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1515_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__859_ (
    .gnd(gnd),
    .vdd(vdd)
);

AND2X2 _1284_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_264_),
    .B(_281_),
    .Y(_263_)
);

FILL FILL_0__1324_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1_BUFX2_insert10 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1_BUFX2_insert12 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1_BUFX2_insert14 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1_BUFX2_insert15 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1_BUFX2_insert17 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1_BUFX2_insert19 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL83250x150 (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _1093_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_78_),
    .B(_77_),
    .C(_76_),
    .Y(_75_)
);

FILL FILL_1__875_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1553_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1133_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1569_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_679_),
    .B(_684_),
    .Y(_678_)
);

NAND3X1 _1149_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_150_),
    .B(_132_),
    .C(_168_),
    .Y(_131_)
);

FILL FILL_0__897_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1362_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI22X1 _1378_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_369_),
    .B(_357_),
    .C(_361_),
    .D(_355_),
    .Y(_354_)
);

FILL FILL_0__1418_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1591_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1171_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _921_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(paddle_h[2]),
    .B(paddle_h[3]),
    .Y(_558_)
);

NAND3X1 _1187_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_186_),
    .B(_183_),
    .C(_170_),
    .Y(_169_)
);

FILL FILL_0__1227_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__778_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1265_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1426_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1494_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1074_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__821_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _824_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_548_),
    .B(_568_),
    .C(\u_ball.x_pos [3]),
    .Y(_16_)
);

FILL FILL_1__1235_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1302_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [6]),
    .B(_282_),
    .Y(_281_)
);

FILL FILL_1__1464_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL83850x3750 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1359_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1531_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_651_),
    .Y(_649_)
);

NAND2X1 _1111_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_124_),
    .B(_125_),
    .Y(_93_)
);

OAI21X1 _862_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(paddle_v[3]),
    .B(_740_),
    .C(paddle_v[2]),
    .Y(_741_)
);

FILL FILL_1__1273_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1588_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1168_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__915_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _918_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_560_),
    .B(_545_),
    .C(_557_),
    .Y(_561_)
);

OAI21X1 _1340_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_321_),
    .B(_319_),
    .C(_318_),
    .Y(_423_)
);

FILL FILL_0__1397_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1558_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1138_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI22X1 _1205_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [0]),
    .B(_336_),
    .C(_335_),
    .D(\u_ball.x_pos [1]),
    .Y(_187_)
);

FILL FILL_0__953_ (
    .gnd(gnd),
    .vdd(vdd)
);

AND2X2 _956_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_516_),
    .B(_518_),
    .Y(_519_)
);

FILL FILL_1__1367_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1434_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.sign_y ),
    .B(\u_ball.y_ball [3]),
    .Y(_407_)
);

OAI21X1 _1014_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(load_option_bF$buf2),
    .B(_452_),
    .C(_453_),
    .Y(_460_)
);

FILL FILL_1__1596_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1176_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__818_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _1243_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_225_),
    .B(_305_),
    .C(_409_),
    .Y(_224_)
);

FILL FILL_0__991_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _994_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(load_option_bF$buf0),
    .B(\u_ball.x_init [4]),
    .Y(_490_)
);

NAND2X1 _1472_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.cnt_v_sync [0]),
    .B(_626_),
    .Y(_601_)
);

NOR2X1 _1052_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_363_),
    .B(_402_),
    .Y(_42_)
);

FILL FILL_1__834_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1512_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1528_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State [1]),
    .B(_647_),
    .Y(_646_)
);

NAND2X1 _1108_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [0]),
    .B(\u_ball.y_pos [0]),
    .Y(_90_)
);

FILL FILL_0__856_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _859_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [3]),
    .B(_517_),
    .Y(_744_)
);

OAI21X1 _1281_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_276_),
    .B(_269_),
    .C(_268_),
    .Y(_260_)
);

FILL FILL_0__1321_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1337_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [4]),
    .Y(_315_)
);

FILL FILL_1__1079_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX8 _1090_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(reset),
    .Y(_417_)
);

FILL FILL_0__1550_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1130_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1566_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_676_),
    .B(_693_),
    .Y(_675_)
);

INVX1 _1146_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [3]),
    .Y(_128_)
);

FILL FILL_0__894_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _897_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_567_),
    .B(_572_),
    .C(_580_),
    .Y(_581_)
);

INVX1 _1375_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(paddle_v[2]),
    .Y(_351_)
);

FILL FILL_0__1415_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1184_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_218_),
    .B(_216_),
    .C(_167_),
    .Y(_166_)
);

FILL FILL_1__966_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1224_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__988_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1033_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1469_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_674_),
    .B(_672_),
    .C(_600_),
    .Y(_599_)
);

DFFSR _1049_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_417_),
    .S(vdd),
    .D(_420_),
    .CLK(clk_bF$buf4),
    .Q(\u_ball.x_ball [2])
);

FILL FILL_0__797_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1509_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1262_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1423_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1003_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1278_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_268_),
    .B(_258_),
    .Y(_257_)
);

FILL FILL_0__1318_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1491_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1071_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _821_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_18_),
    .B(_3_),
    .Y(_19_)
);

FILL FILL_1__1232_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _1087_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(load_option_bF$buf3),
    .B(\u_ball.x_init [4]),
    .C(_765__bF$buf0),
    .Y(_71_)
);

FILL FILL_0__1547_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1127_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1356_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1585_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1165_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__912_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _915_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(paddle_h[3]),
    .Y(_564_)
);

FILL FILL_0__1394_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1555_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1135_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1202_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_188_),
    .B(_187_),
    .Y(_184_)
);

FILL FILL_0__950_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _953_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(paddle_v[4]),
    .B(paddle_v[0]),
    .Y(_522_)
);

FILL FILL_1__1364_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1259_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1431_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.sign_y ),
    .B(\u_ball.y_ball [2]),
    .Y(_404_)
);

DFFSR _1011_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_458_),
    .S(vdd),
    .D(_455_),
    .CLK(clk_bF$buf0),
    .Q(\u_ball.y_init [1])
);

FILL FILL_1__1593_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1173_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1488_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1068_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__815_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _818_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_19_),
    .Y(_22_)
);

OAI21X1 _1240_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_382_),
    .B(_222_),
    .C(_409_),
    .Y(_221_)
);

OAI21X1 _991_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_477_),
    .B(_482_),
    .C(_442_),
    .Y(_473_)
);

FILL FILL_0__1297_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _1525_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_644_),
    .B(_646_),
    .C(_649_),
    .Y(_535_)
);

NAND2X1 _1105_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [0]),
    .B(_353_),
    .Y(_87_)
);

FILL FILL_0__853_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _856_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_746_),
    .B(_743_),
    .C(_733_),
    .Y(_747_)
);

FILL FILL_0__909_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1334_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_313_),
    .B(_314_),
    .Y(_312_)
);

FILL FILL_1__1496_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL83250x28950 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1076_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _1563_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_693_),
    .B(_678_),
    .C(_674_),
    .Y(_673_)
);

OR2X2 _1143_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [0]),
    .B(\u_ball.x_pos [0]),
    .Y(_125_)
);

FILL FILL_0__891_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__925_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _894_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_583_),
    .B(_581_),
    .Y(_584_)
);

FILL FILL_0__947_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1372_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [4]),
    .B(_356_),
    .C(_370_),
    .Y(_348_)
);

FILL FILL_0__1412_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1428_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_403_),
    .B(_402_),
    .Y(_401_)
);

DFFSR _1008_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_491_),
    .S(vdd),
    .D(_495_),
    .CLK(clk_bF$buf2),
    .Q(paddle_h[3])
);

AOI22X1 _1181_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_165_),
    .B(_164_),
    .C(_166_),
    .D(_215_),
    .Y(_163_)
);

FILL FILL_1__963_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1221_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1237_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [1]),
    .Y(_219_)
);

NAND3X1 _988_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(load_option_bF$buf3),
    .B(_443_),
    .C(_444_),
    .Y(_445_)
);

FILL FILL_1__1399_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1030_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1466_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_600_),
    .B(_693_),
    .C(_597_),
    .Y(_704_)
);

DFFSR _1046_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_417_),
    .S(vdd),
    .D(_416_),
    .CLK(clk_bF$buf7),
    .Q(\u_ball.x_ball [4])
);

FILL FILL_0__794_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI22X1 _797_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_506_),
    .B(_528_),
    .C(_38_),
    .D(_40_),
    .Y(_492_)
);

FILL FILL_0__1506_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1420_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1000_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1275_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [4]),
    .B(_255_),
    .Y(_254_)
);

FILL FILL_0__1315_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1084_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_316_),
    .B(_149_),
    .Y(_69_)
);

FILL FILL_1__866_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1544_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1124_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__888_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1353_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1514_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1369_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(paddle_v[3]),
    .B(paddle_v[2]),
    .Y(_345_)
);

FILL FILL_0__1409_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1582_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1162_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _912_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_566_),
    .B(_563_),
    .C(_556_),
    .Y(_567_)
);

FILL FILL_1__1323_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1598_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_471_),
    .S(vdd),
    .D(_468_),
    .CLK(clk_bF$buf3),
    .Q(\u_ball.x_init [2])
);

NAND3X1 _1178_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [3]),
    .B(_402_),
    .C(_399_),
    .Y(_160_)
);

FILL FILL_0__1218_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1391_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1552_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1132_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL83850x79350 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__769_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1027_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _950_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_765__bF$buf3),
    .Y(_525_)
);

FILL FILL_1__1361_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__998_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1256_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1417_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1590_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1485_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1065_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__812_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _815_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_550_),
    .B(\u_ball.x_pos [1]),
    .C(\u_ball.x_pos [0]),
    .Y(_25_)
);

FILL FILL_0__1294_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1522_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_642_),
    .B(_647_),
    .Y(_641_)
);

NAND3X1 _1102_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_93_),
    .B(_85_),
    .C(_88_),
    .Y(_84_)
);

FILL FILL_0__850_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _853_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(paddle_v[4]),
    .B(_730_),
    .C(paddle_v[2]),
    .Y(_750_)
);

FILL FILL_1__1264_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1579_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1159_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__906_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _909_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_542_),
    .B(_569_),
    .C(_545_),
    .Y(_570_)
);

INVX2 _1331_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [2]),
    .Y(_309_)
);

FILL FILL_1__1493_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1073_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1388_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1549_ (
    .gnd(gnd),
    .vdd(vdd)
);

AND2X2 _1560_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_693_),
    .B(_671_),
    .Y(_670_)
);

AOI22X1 _1140_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_272_),
    .B(\u_ball.x_pos [3]),
    .C(_176_),
    .D(_123_),
    .Y(_122_)
);

FILL FILL_1__922_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _891_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_579_),
    .B(_586_),
    .Y(_485_)
);

FILL FILL83550x150 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1197_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__944_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _947_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_500_),
    .B(_502_),
    .C(_527_),
    .Y(_528_)
);

FILL FILL_1__1358_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1425_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [0]),
    .B(\u_ball.y_ball [1]),
    .Y(_398_)
);

OAI21X1 _1005_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(load_option_bF$buf1),
    .B(_475_),
    .C(_476_),
    .Y(_467_)
);

FILL FILL_1__960_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__809_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI22X1 _1234_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_217_),
    .B(\u_ball.y_ball [0]),
    .C(\u_ball.y_ball [1]),
    .D(_219_),
    .Y(_216_)
);

DFFSR _985_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_471_),
    .S(vdd),
    .D(_467_),
    .CLK(clk_bF$buf3),
    .Q(\u_ball.x_init [1])
);

AOI21X1 _1463_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_595_),
    .B(\u_ctrl.State [1]),
    .C(\u_ctrl.State_3_bF$buf3 ),
    .Y(_594_)
);

DFFSR _1043_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_417_),
    .S(vdd),
    .D(_425_),
    .CLK(clk_bF$buf7),
    .Q(\u_ball.x_ball [0])
);

FILL FILL_0__791_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _794_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_428_),
    .B(_418_),
    .Y(_493_)
);

FILL FILL_0__1503_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1519_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State [1]),
    .B(\u_ctrl.State [2]),
    .Y(_639_)
);

FILL FILL83250x14550 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__847_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _1272_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_278_),
    .B(_274_),
    .C(_252_),
    .Y(_251_)
);

FILL FILL_0__1312_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1328_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_316_),
    .B(_309_),
    .Y(_306_)
);

INVX1 _1081_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_67_),
    .Y(_66_)
);

FILL FILL_1__863_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1541_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1121_ (
    .gnd(gnd),
    .vdd(vdd)
);

MUX2X1 _1557_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State_3_bF$buf0 ),
    .B(_669_),
    .S(\u_ball.x_pos [0]),
    .Y(_723_)
);

AOI22X1 _1137_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_130_),
    .B(\u_ball.x_ball [4]),
    .C(\u_ball.x_ball [5]),
    .D(_120_),
    .Y(_119_)
);

FILL FILL_0__885_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__919_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI22X1 _888_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_513_),
    .B(_528_),
    .C(_588_),
    .D(_587_),
    .Y(_486_)
);

FILL FILL_1__1299_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1350_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1511_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL83550x57750 (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1366_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_360_),
    .B(_351_),
    .C(\u_ball.y_ball [3]),
    .Y(_342_)
);

FILL FILL_0__1406_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1320_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX2 _1595_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [3]),
    .Y(_701_)
);

NOR2X1 _1175_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [2]),
    .B(_167_),
    .Y(_157_)
);

FILL FILL_0__1215_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1024_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__788_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL83850x10950 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__995_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1253_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1269_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_272_),
    .B(_249_),
    .Y(_248_)
);

FILL FILL_0__1309_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1482_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1062_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _812_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_564_),
    .B(\u_ball.x_pos [3]),
    .C(_27_),
    .Y(_28_)
);

FILL FILL_1__1223_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1498_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_626_),
    .B(_622_),
    .C(_625_),
    .Y(_711_)
);

INVX1 _1078_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_init [5]),
    .Y(_63_)
);

FILL FILL_0__1538_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1118_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1291_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1032_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1347_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1508_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI22X1 _850_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_738_),
    .B(paddle_v[1]),
    .C(_513_),
    .D(_737_),
    .Y(_753_)
);

FILL FILL_1__1261_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__898_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1576_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1156_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__903_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _906_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_547_),
    .B(_544_),
    .C(paddle_h[4]),
    .Y(_573_)
);

FILL FILL_1__1317_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1490_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1070_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1385_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1194_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__941_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _944_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_530_),
    .Y(_531_)
);

NAND3X1 _1422_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_405_),
    .B(_404_),
    .C(_396_),
    .Y(_395_)
);

OAI21X1 _1002_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_475_),
    .B(_477_),
    .C(_478_),
    .Y(_468_)
);

FILL FILL_1__1164_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL82650x150 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1479_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1059_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__806_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _809_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_28_),
    .B(_29_),
    .C(_30_),
    .Y(_31_)
);

NAND2X1 _1231_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [2]),
    .B(_402_),
    .Y(_213_)
);

DFFSR _982_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_471_),
    .S(vdd),
    .D(_472_),
    .CLK(clk_bF$buf3),
    .Q(\u_ball.x_init [5])
);

FILL FILL_0__1288_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1029_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1460_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_712__bF$buf0),
    .D(_720_),
    .CLK(clk_bF$buf5),
    .Q(\u_ball.x_pos [3])
);

DFFSR _1040_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_417_),
    .D(_413_),
    .CLK(clk_bF$buf0),
    .Q(\u_ball.y_ball [1])
);

FILL FILL_1__822_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _791_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_562_),
    .B(_429_),
    .Y(_431_)
);

FILL FILL_0__1500_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1097_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1516_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [6]),
    .Y(_637_)
);

FILL FILL_0__844_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _847_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_521_),
    .B(_748_),
    .Y(_756_)
);

FILL FILL_1__1258_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1325_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.sign_x ),
    .B(\u_ball.x_ball [5]),
    .Y(_303_)
);

FILL FILL_1__860_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1554_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [0]),
    .Y(_666_)
);

NAND2X1 _1134_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_117_),
    .B(_118_),
    .Y(_116_)
);

FILL FILL_0__882_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__916_ (
    .gnd(gnd),
    .vdd(vdd)
);

AND2X2 _885_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_516_),
    .B(_589_),
    .Y(_591_)
);

FILL FILL_0__938_ (
    .gnd(gnd),
    .vdd(vdd)
);

AND2X2 _1363_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_340_),
    .B(_341_),
    .Y(_339_)
);

FILL FILL_0__1403_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _1419_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_406_),
    .B(_393_),
    .C(_395_),
    .Y(_392_)
);

NOR3X1 _1592_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_701_),
    .B(_700_),
    .C(_699_),
    .Y(_698_)
);

NAND2X1 _1172_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [5]),
    .B(_408_),
    .Y(_154_)
);

FILL FILL_0__1212_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1228_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [1]),
    .B(_368_),
    .Y(_210_)
);

FILL FILL_0__976_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _979_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_491_),
    .S(vdd),
    .D(_487_),
    .CLK(clk_bF$buf1),
    .Q(paddle_v[3])
);

FILL FILL_0__1021_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1457_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_712__bF$buf3),
    .S(vdd),
    .D(_711_),
    .CLK(clk_bF$buf6),
    .Q(\u_ctrl.cnt_v_sync [2])
);

DFFSR _1037_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_417_),
    .S(vdd),
    .D(_421_),
    .CLK(clk_bF$buf1),
    .Q(\u_ball.sign_y )
);

FILL FILL_0__785_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__819_ (
    .gnd(gnd),
    .vdd(vdd)
);

OR2X2 _788_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_563_),
    .B(_566_),
    .Y(_433_)
);

FILL FILL_1__1199_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1250_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI22X1 _1266_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [3]),
    .B(_246_),
    .C(_255_),
    .D(\u_ball.x_ball [4]),
    .Y(_245_)
);

FILL FILL_0__1306_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1220_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1495_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_621_),
    .B(_620_),
    .Y(_619_)
);

OAI21X1 _1075_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_149_),
    .B(_379_),
    .C(_61_),
    .Y(_415_)
);

FILL FILL_1__857_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1535_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1115_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__879_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1344_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1573_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1153_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__900_ (
    .gnd(gnd),
    .vdd(vdd)
);

AND2X2 _903_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_574_),
    .B(_567_),
    .Y(_576_)
);

OAI21X1 _1589_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_0_),
    .B(_696_),
    .C(\u_ctrl.State_3_bF$buf0 ),
    .Y(_695_)
);

AOI22X1 _1169_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_162_),
    .B(_159_),
    .C(_156_),
    .D(_152_),
    .Y(_151_)
);

FILL FILL_0__1209_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1382_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1398_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_init [0]),
    .Y(_373_)
);

FILL FILL_0__1018_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1191_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI22X1 _941_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_532_),
    .B(_537_),
    .C(_504_),
    .D(_519_),
    .Y(_538_)
);

FILL FILL_0__1247_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1408_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1581_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1161_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__798_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1476_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1056_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__803_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _806_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [4]),
    .B(\u_ball.y_pos [5]),
    .C(_33_),
    .Y(_34_)
);

FILL FILL_1__1217_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1390_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0_BUFX2_insert8 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0_BUFX2_insert9 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1285_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1026_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1094_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL83850x18150 (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1513_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [0]),
    .B(\u_ball.x_pos [1]),
    .C(\u_ball.x_pos [2]),
    .Y(_634_)
);

FILL FILL_0__841_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _844_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [6]),
    .Y(_759_)
);

FILL FILL_1__1255_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1322_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [4]),
    .B(\u_ball.x_ball [5]),
    .C(\u_ball.sign_x ),
    .Y(_300_)
);

FILL FILL_0__1379_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI22X1 _1551_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_668_),
    .B(_669_),
    .C(_664_),
    .D(\u_ctrl.State_3_bF$buf1 ),
    .Y(_722_)
);

OAI21X1 _1131_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_272_),
    .B(_114_),
    .C(_315_),
    .Y(_113_)
);

NAND2X1 _882_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_498_),
    .B(_529_),
    .Y(_713_)
);

FILL FILL_0__1188_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__935_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _938_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(paddle_h[4]),
    .Y(_540_)
);

FILL FILL_1__1349_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX4 _1360_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [0]),
    .Y(_336_)
);

FILL FILL_0__1400_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1416_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_390_),
    .B(_391_),
    .Y(_389_)
);

FILL FILL_1__1578_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1158_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1225_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_214_),
    .B(_213_),
    .Y(_207_)
);

FILL FILL_0__973_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _976_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(paddle_v[2]),
    .B(paddle_v[3]),
    .Y(_499_)
);

FILL FILL_1__1387_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1454_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_712__bF$buf2),
    .D(_726_),
    .CLK(clk_bF$buf5),
    .Q(\u_ball.y_pos [2])
);

DFFSR _1034_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_491_),
    .S(vdd),
    .D(_485_),
    .CLK(clk_bF$buf5),
    .Q(paddle_h[5])
);

FILL FILL_0__782_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__816_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _785_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_564_),
    .B(_555_),
    .C(_435_),
    .Y(_495_)
);

FILL FILL_1__1196_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__838_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1263_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_243_),
    .B(_244_),
    .C(_259_),
    .Y(_242_)
);

FILL FILL_0__1303_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1319_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.sign_x ),
    .B(\u_ball.x_ball [6]),
    .Y(_297_)
);

AOI21X1 _1492_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_652_),
    .B(\u_ctrl.State [0]),
    .C(load_option_bF$buf0),
    .Y(_617_)
);

AOI21X1 _1072_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_353_),
    .B(_383_),
    .C(_59_),
    .Y(_414_)
);

FILL FILL_0__1532_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1112_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1548_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_699_),
    .B(_662_),
    .Y(_661_)
);

OAI21X1 _1128_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_272_),
    .B(_114_),
    .C(_111_),
    .Y(_110_)
);

FILL FILL_0__876_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _879_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_504_),
    .B(_537_),
    .C(_532_),
    .Y(_716_)
);

FILL FILL_0__1341_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1357_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_336_),
    .B(_335_),
    .C(_334_),
    .Y(_333_)
);

FILL FILL_1__1099_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1570_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1150_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _900_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_555_),
    .Y(_578_)
);

INVX1 _1586_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State_3_bF$buf2 ),
    .Y(_692_)
);

INVX1 _1166_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [6]),
    .Y(_148_)
);

FILL FILL_1__948_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1206_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1540_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1120_ (
    .gnd(gnd),
    .vdd(vdd)
);

CLKBUF1 CLKBUF1_insert0 (
    .gnd(gnd),
    .vdd(vdd),
    .A(clk),
    .Y(clk_bF$buf7)
);

CLKBUF1 CLKBUF1_insert1 (
    .gnd(gnd),
    .vdd(vdd),
    .A(clk),
    .Y(clk_bF$buf6)
);

CLKBUF1 CLKBUF1_insert2 (
    .gnd(gnd),
    .vdd(vdd),
    .A(clk),
    .Y(clk_bF$buf5)
);

CLKBUF1 CLKBUF1_insert3 (
    .gnd(gnd),
    .vdd(vdd),
    .A(clk),
    .Y(clk_bF$buf4)
);

CLKBUF1 CLKBUF1_insert4 (
    .gnd(gnd),
    .vdd(vdd),
    .A(clk),
    .Y(clk_bF$buf3)
);

CLKBUF1 CLKBUF1_insert5 (
    .gnd(gnd),
    .vdd(vdd),
    .A(clk),
    .Y(clk_bF$buf2)
);

CLKBUF1 CLKBUF1_insert6 (
    .gnd(gnd),
    .vdd(vdd),
    .A(clk),
    .Y(clk_bF$buf1)
);

CLKBUF1 CLKBUF1_insert7 (
    .gnd(gnd),
    .vdd(vdd),
    .A(clk),
    .Y(clk_bF$buf0)
);

OAI21X1 _1395_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_373_),
    .B(_372_),
    .C(_371_),
    .Y(_425_)
);

FILL FILL_0__1435_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1015_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__779_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__986_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1244_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1405_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1473_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1053_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL83850x150 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__800_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _803_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_36_),
    .B(_24_),
    .C(_2_),
    .Y(pixel_paddle)
);

FILL FILL_1__1214_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _1489_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_695_),
    .B(_616_),
    .C(_644_),
    .Y(_615_)
);

OAI21X1 _1069_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_399_),
    .B(_57_),
    .C(_403_),
    .Y(_56_)
);

FILL FILL_0__1529_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1109_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1282_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _1298_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_336_),
    .B(gnd),
    .C(_278_),
    .Y(_277_)
);

FILL FILL_0__1338_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1091_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1510_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [5]),
    .B(_632_),
    .Y(_631_)
);

OAI21X1 _841_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_497_),
    .B(\u_ball.y_pos [5]),
    .C(_761_),
    .Y(_762_)
);

FILL FILL83850x72150 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__889_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL83850x39750 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1567_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1147_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1061_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1376_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1537_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1117_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1185_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__932_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _935_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(paddle_h[2]),
    .B(paddle_h[3]),
    .C(paddle_h[4]),
    .Y(_543_)
);

FILL FILL_1__1346_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1413_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_395_),
    .B(_387_),
    .C(_392_),
    .Y(_386_)
);

FILL FILL_1__1575_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1155_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1222_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [1]),
    .B(_368_),
    .Y(_204_)
);

FILL FILL_0__970_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _973_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_765__bF$buf3),
    .B(_501_),
    .Y(_502_)
);

FILL FILL_1__1384_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1279_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1451_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_712__bF$buf1),
    .S(vdd),
    .D(_536_),
    .CLK(clk_bF$buf6),
    .Q(\u_ctrl.State [1])
);

NAND3X1 _1031_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(load_option_bF$buf2),
    .B(_461_),
    .C(_462_),
    .Y(_463_)
);

NAND2X1 _782_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_437_),
    .B(_436_),
    .Y(_438_)
);

FILL FILL_0__1088_ (
    .gnd(gnd),
    .vdd(vdd)
);

AND2X2 _1507_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_630_),
    .B(_629_),
    .Y(_628_)
);

FILL FILL_0__835_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _838_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_747_),
    .B(_1_),
    .C(_758_),
    .Y(_2_)
);

NAND2X1 _1260_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [5]),
    .B(\u_ball.y_ball [4]),
    .Y(_239_)
);

FILL FILL_0__1300_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1316_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_310_),
    .Y(_294_)
);

FILL FILL_1__1478_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1058_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1545_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_660_),
    .Y(_659_)
);

NOR2X1 _1125_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_149_),
    .B(_145_),
    .Y(_107_)
);

FILL FILL_0__873_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__907_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _876_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(paddle_v[0]),
    .B(_529_),
    .Y(_718_)
);

FILL FILL_1__1287_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__929_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _1354_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_354_),
    .B(_331_),
    .C(_338_),
    .Y(_330_)
);

FILL FILL_1__1096_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1583_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [1]),
    .Y(_690_)
);

NAND3X1 _1163_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [3]),
    .B(\u_ball.x_ball [4]),
    .C(_146_),
    .Y(_145_)
);

FILL FILL_1__945_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1203_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1219_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_205_),
    .B(_202_),
    .Y(_201_)
);

FILL FILL_0__967_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX2 _1392_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [1]),
    .Y(_368_)
);

FILL FILL82950x79350 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1432_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1448_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_712__bF$buf0),
    .D(_727_),
    .CLK(clk_bF$buf5),
    .Q(\u_ball.y_pos [1])
);

NAND2X1 _1028_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_465_),
    .B(_463_),
    .Y(_454_)
);

OAI21X1 _779_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_578_),
    .B(_440_),
    .C(paddle_h[6]),
    .Y(_441_)
);

endmodule
