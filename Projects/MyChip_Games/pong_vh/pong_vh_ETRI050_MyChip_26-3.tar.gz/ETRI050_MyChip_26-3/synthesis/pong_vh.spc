*SPICE netlist created from verilog structural netlist module pong_vh by vlog2Spice (qflow)
*This file may contain array delimiters, not for use in simulation.

** Start of included library /usr/local/share/qflow/tech/etri050/etri050_stdcells.sp
* NGSPICE file created from khu_etri050_stdcells.ext - technology: scmos

.subckt AOI22X1 A B C D Y vdd gnd
M1000 gnd C a_56_14# gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=1.8p ps=6.6u
M1001 vdd A a_7_146# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=25.2p ps=28.2u
M1002 Y D a_7_146# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1003 a_28_14# A gnd gnd nfet w=6u l=0.6u
+  ad=1.8p pd=6.6u as=12.6p ps=16.2u
M1004 Y B a_28_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=1.8p ps=6.6u
M1005 a_7_146# C Y vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=14.4p ps=14.4u
M1006 a_7_146# B vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1007 a_56_14# D Y gnd nfet w=6u l=0.6u
+  ad=1.8p pd=6.6u as=7.2p ps=8.4u
.ends

.subckt CLKBUF3 A Y vdd gnd
M1000 a_145_14# a_105_14# vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1001 a_65_14# a_25_14# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1002 a_105_14# a_65_14# vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1003 a_145_14# a_105_14# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1004 gnd a_145_14# a_185_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1005 a_25_14# A vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=25.2p ps=28.2u
M1006 a_65_14# a_25_14# vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1007 a_265_14# a_225_14# vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1008 a_265_14# a_225_14# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1009 a_225_14# a_185_14# vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1010 gnd a_265_14# Y gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1011 a_25_14# A gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
M1012 gnd a_25_14# a_65_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1013 a_105_14# a_65_14# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1014 Y a_265_14# vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1015 gnd a_105_14# a_145_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1016 vdd a_65_14# a_105_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1017 vdd a_105_14# a_145_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1018 a_225_14# a_185_14# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1019 gnd a_225_14# a_265_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1020 vdd a_25_14# a_65_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1021 gnd A a_25_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1022 vdd A a_25_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1023 vdd a_185_14# a_225_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1024 vdd a_225_14# a_265_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1025 vdd a_145_14# a_185_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1026 gnd a_65_14# a_105_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1027 a_185_14# a_145_14# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1028 gnd a_185_14# a_225_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1029 Y a_265_14# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1030 vdd a_265_14# Y vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=14.4p ps=14.4u
M1031 a_185_14# a_145_14# vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
.ends

.subckt INVX8 A Y vdd gnd
M1000 Y A gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1001 Y A vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=25.2p ps=28.2u
M1002 Y A vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1003 Y A gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
M1004 gnd A Y gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1005 vdd A Y vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=14.4p ps=14.4u
M1006 gnd A Y gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1007 vdd A Y vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
.ends

.subckt NOR3X1 A B C Y vdd gnd
M1000 gnd B Y gnd nfet w=3u l=0.6u
+  ad=3.6p pd=5.4u as=3.6p ps=5.4u
M1001 a_7_166# A vdd vdd pfet w=9u l=0.6u
+  ad=10.8p pd=11.4u as=10.8p ps=11.4u
M1002 a_7_166# B a_65_166# vdd pfet w=9u l=0.6u
+  ad=18.9p pd=22.2u as=10.8p ps=11.4u
M1003 a_65_166# C Y vdd pfet w=9u l=0.6u
+  ad=18.9p pd=22.2u as=10.8p ps=11.4u
M1004 Y C gnd gnd nfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=3.6p ps=5.4u
M1005 a_65_166# B a_7_166# vdd pfet w=9u l=0.6u
+  ad=10.8p pd=11.4u as=10.8p ps=11.4u
M1006 vdd A a_7_166# vdd pfet w=9u l=0.6u
+  ad=10.8p pd=11.4u as=18.9p ps=22.2u
M1007 Y C a_65_166# vdd pfet w=9u l=0.6u
+  ad=10.8p pd=11.4u as=18.9p ps=22.2u
M1008 Y A gnd gnd nfet w=3u l=0.6u
+  ad=3.6p pd=5.4u as=7.2p ps=10.8u
.ends

.subckt CLKBUF1 A Y vdd gnd
M1000 Y a_105_14# vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1001 a_65_14# a_25_14# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1002 a_105_14# a_65_14# vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1003 Y a_105_14# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1004 a_25_14# A vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=25.2p ps=28.2u
M1005 a_65_14# a_25_14# vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1006 a_25_14# A gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
M1007 gnd a_25_14# a_65_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1008 a_105_14# a_65_14# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1009 gnd a_105_14# Y gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1010 vdd a_65_14# a_105_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1011 vdd a_105_14# Y vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=14.4p ps=14.4u
M1012 vdd a_25_14# a_65_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1013 gnd A a_25_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1014 vdd A a_25_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1015 gnd a_65_14# a_105_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
.ends

.subckt MUX2X1 A B S Y vdd gnd
M1000 a_75_22# S Y gnd nfet w=6u l=0.6u
+  ad=2.7p pd=6.9u as=7.2p ps=8.4u
M1001 gnd S a_7_22# gnd nfet w=3u l=0.6u
+  ad=6.3p pd=8.4u as=6.3p ps=10.2u
M1002 Y S a_45_138# vdd pfet w=12u l=0.6u
+  ad=14.49p pd=15.6u as=5.4p ps=12.9u
M1003 gnd A a_75_22# gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=2.7p ps=6.9u
M1004 vdd A a_75_146# vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=5.4p ps=12.9u
M1005 a_45_138# B vdd vdd pfet w=12u l=0.6u
+  ad=5.4p pd=12.9u as=11.7p ps=14.4u
M1006 a_45_22# B gnd gnd nfet w=6u l=0.6u
+  ad=2.7p pd=6.9u as=6.3p ps=8.4u
M1007 Y a_7_22# a_45_22# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=2.7p ps=6.9u
M1008 a_75_146# a_7_22# Y vdd pfet w=12u l=0.6u
+  ad=5.4p pd=12.9u as=14.49p ps=15.6u
M1009 vdd S a_7_22# vdd pfet w=6u l=0.6u
+  ad=11.7p pd=14.4u as=12.6p ps=16.2u
.ends

.subckt NAND3X1 A B C Y vdd gnd
M1000 Y C a_34_14# gnd nfet w=9u l=0.6u
+  ad=18.9p pd=22.2u as=2.7p ps=9.6u
M1001 a_26_14# A gnd gnd nfet w=9u l=0.6u
+  ad=2.7p pd=9.6u as=18.9p ps=22.2u
M1002 vdd B Y vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1003 a_34_14# B a_26_14# gnd nfet w=9u l=0.6u
+  ad=2.7p pd=9.6u as=2.7p ps=9.6u
M1004 Y C vdd vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1005 Y A vdd vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
.ends

.subckt XOR2X1 A B Y vdd gnd
M1000 a_74_166# a_6_14# Y vdd pfet w=12u l=0.6u
+  ad=5.4p pd=12.9u as=14.4p ps=14.4u
M1001 a_28_58# B vdd vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=14.4p ps=14.4u
M1002 a_74_14# A Y gnd nfet w=6u l=0.6u
+  ad=2.7p pd=6.9u as=7.2p ps=8.4u
M1003 gnd A a_6_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
M1004 vdd A a_6_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=25.2p ps=28.2u
M1005 gnd B a_74_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=2.7p ps=6.9u
M1006 a_28_58# B gnd gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1007 Y A a_44_166# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=5.4p ps=12.9u
M1008 a_44_14# a_28_58# gnd gnd nfet w=6u l=0.6u
+  ad=2.7p pd=6.9u as=7.2p ps=8.4u
M1009 vdd B a_74_166# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=5.4p ps=12.9u
M1010 Y a_6_14# a_44_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=2.7p ps=6.9u
M1011 a_44_166# a_28_58# vdd vdd pfet w=12u l=0.6u
+  ad=5.4p pd=12.9u as=14.4p ps=14.4u
.ends

.subckt BUFX4 A Y vdd gnd
M1000 Y a_7_14# vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=15.3p ps=14.7u
M1001 gnd A a_7_14# gnd nfet w=4.5u l=0.6u
+  ad=7.65p pd=8.7u as=9.45p ps=13.2u
M1002 vdd a_7_14# Y vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=14.4p ps=14.4u
M1003 vdd A a_7_14# vdd pfet w=9u l=0.6u
+  ad=15.3p pd=14.7u as=18.9p ps=22.2u
M1004 Y a_7_14# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.65p ps=8.7u
M1005 gnd a_7_14# Y gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
.ends

.subckt INVX4 A Y vdd gnd
M1000 Y A vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=25.2p ps=28.2u
M1001 Y A gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
M1002 gnd A Y gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1003 vdd A Y vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=14.4p ps=14.4u
.ends

.subckt OAI21X1 A B C Y vdd gnd
M1000 Y C a_7_14# gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1001 a_30_146# A vdd vdd pfet w=12u l=0.6u
+  ad=3.6p pd=12.6u as=25.2p ps=28.2u
M1002 vdd C Y vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=14.4p ps=14.7u
M1003 gnd A a_7_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
M1004 Y B a_30_146# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.7u as=3.6p ps=12.6u
M1005 a_7_14# B gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
.ends

.subckt TBUFX2 A EN Y vdd gnd
M1000 vdd A a_44_166# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1001 Y a_22_14# a_44_166# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=25.2p ps=28.2u
M1002 a_22_14# EN vdd vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=25.2p ps=28.2u
M1003 gnd A a_44_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1004 a_44_14# A gnd gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1005 a_44_166# A vdd vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=14.4p ps=14.4u
M1006 a_44_166# a_22_14# Y vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1007 Y EN a_44_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
M1008 a_22_14# EN gnd gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=12.6p ps=16.2u
M1009 a_44_14# EN Y gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
.ends

.subckt DFFNEGX1 D CLK Q vdd gnd
M1000 a_163_14# a_7_14# a_153_14# gnd nfet w=3u l=0.6u
+  ad=3.6p pd=5.4u as=1.35p ps=3.9u
M1001 a_77_186# CLK a_57_14# vdd pfet w=6u l=0.6u
+  ad=3.6p pd=7.2u as=7.2p ps=8.4u
M1002 a_77_14# a_7_14# a_57_14# gnd nfet w=3u l=0.6u
+  ad=1.35p pd=3.9u as=3.6p ps=5.4u
M1003 vdd a_83_10# a_77_186# vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=3.6p ps=7.2u
M1004 vdd CLK a_7_14# vdd pfet w=12u l=0.6u
+  ad=12.15p pd=14.4u as=25.2p ps=28.2u
M1005 Q a_163_14# vdd vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=11.025p ps=14.4u
M1006 a_83_10# a_57_14# gnd gnd nfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=4.05p ps=5.7u
M1007 gnd CLK a_7_14# gnd nfet w=6u l=0.6u
+  ad=6.075p pd=8.4u as=12.6p ps=16.2u
M1008 gnd a_83_10# a_77_14# gnd nfet w=3u l=0.6u
+  ad=4.05p pd=5.7u as=1.35p ps=3.9u
M1009 vdd Q a_183_206# vdd pfet w=3u l=0.6u
+  ad=11.025p pd=14.4u as=1.35p ps=3.9u
M1010 a_154_186# a_83_10# vdd vdd pfet w=6u l=0.6u
+  ad=2.25p pd=6.75u as=12.6p ps=16.2u
M1011 a_183_14# CLK a_163_14# gnd nfet w=3u l=0.6u
+  ad=1.35p pd=3.9u as=3.6p ps=5.4u
M1012 a_45_186# D vdd vdd pfet w=6u l=0.6u
+  ad=3.6p pd=7.2u as=12.15p ps=14.4u
M1013 a_83_10# a_57_14# vdd vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1014 a_57_14# a_7_14# a_45_186# vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=3.6p ps=7.2u
M1015 gnd Q a_183_14# gnd nfet w=3u l=0.6u
+  ad=6.075p pd=8.4u as=1.35p ps=3.9u
M1016 a_183_206# a_7_14# a_163_14# vdd pfet w=3u l=0.6u
+  ad=1.35p pd=3.9u as=5.85p ps=8.4u
M1017 a_45_14# D gnd gnd nfet w=3u l=0.6u
+  ad=1.8p pd=4.2u as=6.075p ps=8.4u
M1018 a_57_14# CLK a_45_14# gnd nfet w=3u l=0.6u
+  ad=3.6p pd=5.4u as=1.8p ps=4.2u
M1019 a_153_14# a_83_10# gnd gnd nfet w=3u l=0.6u
+  ad=1.35p pd=3.9u as=6.3p ps=10.2u
M1020 Q a_163_14# gnd gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=6.075p ps=8.4u
M1021 a_163_14# CLK a_154_186# vdd pfet w=6u l=0.6u
+  ad=5.85p pd=8.4u as=2.25p ps=6.75u
.ends

.subckt AOI21X1 A B C Y vdd gnd
M1000 vdd A a_7_146# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=25.2p ps=28.2u
M1001 Y C a_7_146# vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=14.4p ps=14.4u
M1002 a_28_14# A gnd gnd nfet w=6u l=0.6u
+  ad=1.8p pd=6.6u as=12.6p ps=16.2u
M1003 Y B a_28_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.7u as=1.8p ps=6.6u
M1004 a_7_146# B vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1005 gnd C Y gnd nfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=7.2p ps=8.7u
.ends

.subckt BUFX2 A Y vdd gnd
M1000 Y a_7_14# vdd vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=14.4p ps=14.7u
M1001 gnd A a_7_14# gnd nfet w=3u l=0.6u
+  ad=7.2p pd=8.7u as=6.3p ps=10.2u
M1002 Y a_7_14# gnd gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.7u
M1003 vdd A a_7_14# vdd pfet w=6u l=0.6u
+  ad=14.4p pd=14.7u as=12.6p ps=16.2u
.ends

.subckt INVX2 A Y vdd gnd
M1000 Y A vdd vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=25.2p ps=28.2u
M1001 Y A gnd gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=12.6p ps=16.2u
.ends

.subckt FAX1 A B C YS YC vdd gnd
M1000 a_64_14# C a_6_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1001 YS a_174_14# vdd vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=14.13p ps=16.8u
M1002 a_206_14# B a_196_14# gnd nfet w=6u l=0.6u
+  ad=2.7p pd=6.9u as=2.7p ps=6.9u
M1003 gnd a_64_14# YC gnd nfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=6.3p ps=10.2u
M1004 gnd A a_206_14# gnd nfet w=6u l=0.6u
+  ad=5.85p pd=8.4u as=2.7p ps=6.9u
M1005 vdd A a_206_150# vdd pfet w=14.4u l=0.6u
+  ad=14.13p pd=16.8u as=6.48p ps=15.3u
M1006 gnd A a_6_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
M1007 a_114_14# C gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1008 a_64_14# C a_6_166# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1009 vdd A a_6_166# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=25.2p ps=28.2u
M1010 a_84_14# B a_64_14# gnd nfet w=6u l=0.6u
+  ad=2.7p pd=6.9u as=7.2p ps=8.4u
M1011 a_174_14# a_64_14# a_114_166# vdd pfet w=10.8u l=0.6u
+  ad=17.82p pd=17.1u as=12.96p ps=13.2u
M1012 vdd B a_114_166# vdd pfet w=10.8u l=0.6u
+  ad=12.96p pd=13.2u as=13.86p ps=14.4u
M1013 a_196_150# C a_174_14# vdd pfet w=14.4u l=0.6u
+  ad=6.48p pd=15.3u as=17.82p ps=17.1u
M1014 a_206_150# B a_196_150# vdd pfet w=14.4u l=0.6u
+  ad=6.48p pd=15.3u as=6.48p ps=15.3u
M1015 gnd A a_84_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=2.7p ps=6.9u
M1016 vdd A a_84_166# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=5.4p ps=12.9u
M1017 a_114_14# A gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1018 YS a_174_14# gnd gnd nfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=5.85p ps=8.4u
M1019 a_174_14# a_64_14# a_114_14# gnd nfet w=6u l=0.6u
+  ad=8.1p pd=8.7u as=7.2p ps=8.4u
M1020 a_6_14# B gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1021 YC a_64_14# vdd vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=12.6p ps=16.2u
M1022 a_84_166# B a_64_14# vdd pfet w=12u l=0.6u
+  ad=5.4p pd=12.9u as=14.4p ps=14.4u
M1023 a_6_166# B vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1024 a_114_166# A vdd vdd pfet w=12u l=0.6u
+  ad=13.86p pd=14.4u as=14.4p ps=14.4u
M1025 a_114_166# C vdd vdd pfet w=10.8u l=0.6u
+  ad=12.96p pd=13.2u as=12.96p ps=13.2u
M1026 gnd B a_114_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1027 a_196_14# C a_174_14# gnd nfet w=6u l=0.6u
+  ad=2.7p pd=6.9u as=8.1p ps=8.7u
.ends

.subckt NOR2X1 A B Y vdd gnd
M1000 a_25_146# A vdd vdd pfet w=12u l=0.6u
+  ad=3.6p pd=12.6u as=25.2p ps=28.2u
M1001 Y A gnd gnd nfet w=3u l=0.6u
+  ad=3.6p pd=5.4u as=6.3p ps=10.2u
M1002 Y B a_25_146# vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=3.6p ps=12.6u
M1003 gnd B Y gnd nfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=3.6p ps=5.4u
.ends

.subckt AND2X1 A B Y vdd gnd
M1000 gnd B a_25_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.7u as=1.8p ps=6.6u
M1001 a_25_14# A a_7_14# gnd nfet w=6u l=0.6u
+  ad=1.8p pd=6.6u as=12.6p ps=16.2u
M1002 vdd B a_7_14# vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1003 Y a_7_14# gnd gnd nfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=7.2p ps=8.7u
M1004 Y a_7_14# vdd vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1005 a_7_14# A vdd vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
.ends

.subckt DFFPOSX1 D CLK Q vdd gnd
M1000 vdd Q a_189_206# vdd pfet w=3u l=0.6u
+  ad=10.125p pd=14.7u as=0.9p ps=3.6u
M1001 a_83_186# a_11_14# a_59_14# vdd pfet w=6u l=0.6u
+  ad=3.6p pd=7.2u as=7.2p ps=8.4u
M1002 a_87_10# a_59_14# gnd gnd nfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=4.05p ps=5.7u
M1003 gnd CLK a_11_14# gnd nfet w=6u l=0.6u
+  ad=5.85p pd=8.4u as=12.6p ps=16.2u
M1004 gnd a_87_10# a_81_14# gnd nfet w=3u l=0.6u
+  ad=4.05p pd=5.7u as=1.35p ps=3.9u
M1005 a_159_14# a_87_10# gnd gnd nfet w=3u l=0.6u
+  ad=0.9p pd=3.6u as=6.3p ps=10.2u
M1006 a_49_186# D vdd vdd pfet w=6u l=0.6u
+  ad=4.5p pd=7.5u as=11.25p ps=14.4u
M1007 vdd a_87_10# a_83_186# vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=3.6p ps=7.2u
M1008 Q a_167_14# gnd gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=6.975p ps=8.7u
M1009 Q a_167_14# vdd vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=10.125p ps=14.7u
M1010 a_167_14# CLK a_159_14# gnd nfet w=3u l=0.6u
+  ad=3.6p pd=5.4u as=0.9p ps=3.6u
M1011 a_49_14# D gnd gnd nfet w=3u l=0.6u
+  ad=1.35p pd=3.9u as=5.85p ps=8.4u
M1012 a_87_10# a_59_14# vdd vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1013 a_59_14# CLK a_49_186# vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=4.5p ps=7.5u
M1014 a_161_186# a_87_10# vdd vdd pfet w=6u l=0.6u
+  ad=1.8p pd=6.6u as=12.6p ps=16.2u
M1015 a_189_206# CLK a_167_14# vdd pfet w=3u l=0.6u
+  ad=0.9p pd=3.6u as=6.075p ps=8.4u
M1016 a_59_14# a_11_14# a_49_14# gnd nfet w=3u l=0.6u
+  ad=4.05p pd=5.7u as=1.35p ps=3.9u
M1017 a_187_14# a_11_14# a_167_14# gnd nfet w=3u l=0.6u
+  ad=1.35p pd=3.9u as=3.6p ps=5.4u
M1018 vdd CLK a_11_14# vdd pfet w=12u l=0.6u
+  ad=11.25p pd=14.4u as=25.2p ps=28.2u
M1019 gnd Q a_187_14# gnd nfet w=3u l=0.6u
+  ad=6.975p pd=8.7u as=1.35p ps=3.9u
M1020 a_167_14# a_11_14# a_161_186# vdd pfet w=6u l=0.6u
+  ad=6.075p pd=8.4u as=1.8p ps=6.6u
M1021 a_81_14# CLK a_59_14# gnd nfet w=3u l=0.6u
+  ad=1.35p pd=3.9u as=4.05p ps=5.7u
.ends

.subckt NAND2X1 A B Y vdd gnd
M1000 a_27_14# A gnd gnd nfet w=6u l=0.6u
+  ad=2.7p pd=6.9u as=12.6p ps=16.2u
M1001 Y B a_27_14# gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=2.7p ps=6.9u
M1002 vdd B Y vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1003 Y A vdd vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
.ends

.subckt OR2X1 A B Y vdd gnd
M1000 Y a_7_146# gnd gnd nfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=3.6p ps=5.4u
M1001 a_25_146# A a_7_146# vdd pfet w=12u l=0.6u
+  ad=5.4p pd=12.9u as=25.2p ps=28.2u
M1002 a_7_146# A gnd gnd nfet w=3u l=0.6u
+  ad=3.6p pd=5.4u as=6.3p ps=10.2u
M1003 Y a_7_146# vdd vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=14.4p ps=14.7u
M1004 gnd B a_7_146# gnd nfet w=3u l=0.6u
+  ad=3.6p pd=5.4u as=3.6p ps=5.4u
M1005 vdd B a_25_146# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.7u as=5.4p ps=12.9u
.ends

.subckt CLKBUF2 A Y vdd gnd
M1000 a_145_14# a_105_14# vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1001 a_65_14# a_25_14# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1002 a_105_14# a_65_14# vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1003 a_145_14# a_105_14# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1004 gnd a_145_14# a_185_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1005 a_25_14# A vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=25.2p ps=28.2u
M1006 a_65_14# a_25_14# vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1007 Y a_185_14# vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1008 a_25_14# A gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
M1009 gnd a_25_14# a_65_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1010 a_105_14# a_65_14# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1011 gnd a_105_14# a_145_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1012 vdd a_65_14# a_105_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1013 vdd a_105_14# a_145_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1014 Y a_185_14# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1015 vdd a_25_14# a_65_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1016 gnd A a_25_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1017 vdd A a_25_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1018 vdd a_185_14# Y vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=14.4p ps=14.4u
M1019 vdd a_145_14# a_185_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1020 gnd a_65_14# a_105_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1021 a_185_14# a_145_14# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1022 gnd a_185_14# Y gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1023 a_185_14# a_145_14# vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
.ends

.subckt LATCH D CLK Q vdd gnd
M1000 a_48_206# D vdd vdd pfet w=6u l=0.6u
+  ad=2.7p pd=6.9u as=14.4p ps=14.7u
M1001 a_86_226# CLK a_58_14# vdd pfet w=3u l=0.6u
+  ad=1.35p pd=3.9u as=9.225p ps=9.6u
M1002 gnd CLK a_8_14# gnd nfet w=6u l=0.6u
+  ad=6.3p pd=8.4u as=12.6p ps=16.2u
M1003 a_86_14# a_8_14# a_58_14# gnd nfet w=3u l=0.6u
+  ad=1.35p pd=3.9u as=5.4p ps=6.6u
M1004 Q a_58_14# gnd gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.7u
M1005 gnd Q a_86_14# gnd nfet w=3u l=0.6u
+  ad=7.2p pd=8.7u as=1.35p ps=3.9u
M1006 a_46_14# D gnd gnd nfet w=3u l=0.6u
+  ad=1.8p pd=4.2u as=6.3p ps=8.4u
M1007 Q a_58_14# vdd vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=13.5p ps=14.7u
M1008 a_58_14# CLK a_46_14# gnd nfet w=3u l=0.6u
+  ad=5.4p pd=6.6u as=1.8p ps=4.2u
M1009 vdd CLK a_8_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.7u as=25.2p ps=28.2u
M1010 a_58_14# a_8_14# a_48_206# vdd pfet w=6u l=0.6u
+  ad=9.225p pd=9.6u as=2.7p ps=6.9u
M1011 vdd Q a_86_226# vdd pfet w=3u l=0.6u
+  ad=13.5p pd=14.7u as=1.35p ps=3.9u
.ends

.subckt HAX1 A B YS YC vdd gnd
M1000 a_6_206# B a_24_14# gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=1.8p ps=6.6u
M1001 vdd a_6_206# YC vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
M1002 gnd a_6_206# YC gnd nfet w=3u l=0.6u
+  ad=6.075p pd=8.4u as=6.21p ps=10.2u
M1003 a_24_14# A gnd gnd nfet w=6u l=0.6u
+  ad=1.8p pd=6.6u as=12.6p ps=16.2u
M1004 a_6_206# B vdd vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1005 a_128_166# B a_108_206# vdd pfet w=12u l=0.6u
+  ad=3.6p pd=12.6u as=13.5p ps=14.4u
M1006 a_108_206# a_6_206# vdd vdd pfet w=6u l=0.6u
+  ad=13.5p pd=14.4u as=7.2p ps=8.4u
M1007 YS a_108_206# gnd gnd nfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=6.3p ps=10.2u
M1008 a_96_14# a_6_206# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=6.075p ps=8.4u
M1009 a_108_206# B a_96_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1010 vdd A a_128_166# vdd pfet w=12u l=0.6u
+  ad=11.25p pd=14.4u as=3.6p ps=12.6u
M1011 YS a_108_206# vdd vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=11.25p ps=14.4u
M1012 a_96_14# A a_108_206# gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1013 vdd A a_6_206# vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
.ends

.subckt DFFSR R S D CLK Q vdd gnd
M1000 a_146_14# a_122_10# a_60_10# vdd pfet w=3u l=0.6u
+  ad=6.3p pd=8.4u as=3.6p ps=5.4u
M1001 a_64_14# a_60_10# gnd gnd nfet w=6u l=0.6u
+  ad=3.6p pd=7.2u as=9p ps=9u
M1002 vdd S a_301_14# vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1003 a_146_14# a_115_95# a_60_10# gnd nfet w=3u l=0.6u
+  ad=3.6p pd=5.4u as=3.6p ps=5.4u
M1004 a_36_10# a_60_10# vdd vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1005 a_391_14# a_334_14# gnd gnd nfet w=6u l=0.6u
+  ad=3.6p pd=7.2u as=9.45p ps=9.15u
M1006 a_8_14# R vdd vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
M1007 a_36_10# S a_64_14# gnd nfet w=6u l=0.6u
+  ad=14.4p pd=16.8u as=3.6p ps=7.2u
M1008 gnd a_334_14# Q gnd nfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=6.3p ps=10.2u
M1009 a_281_14# a_122_10# a_36_10# gnd nfet w=3u l=0.6u
+  ad=3.6p pd=5.4u as=6.3p ps=10.2u
M1010 a_28_14# R a_8_14# gnd nfet w=6u l=0.6u
+  ad=3.6p pd=7.2u as=14.4p ps=16.8u
M1011 a_301_14# S a_391_14# gnd nfet w=6u l=0.6u
+  ad=14.4p pd=16.8u as=3.6p ps=7.2u
M1012 gnd a_36_10# a_28_14# gnd nfet w=6u l=0.6u
+  ad=9p pd=9u as=3.6p ps=7.2u
M1013 gnd a_115_95# a_122_10# gnd nfet w=3u l=0.6u
+  ad=3.6p pd=5.4u as=6.3p ps=10.2u
M1014 a_301_14# a_334_14# vdd vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1015 vdd D a_146_14# vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=6.3p ps=8.4u
M1016 a_334_14# a_281_14# vdd vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
M1017 vdd a_115_95# a_122_10# vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
M1018 a_301_14# a_122_10# a_281_14# vdd pfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=3.6p ps=5.4u
M1019 gnd D a_146_14# gnd nfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=3.6p ps=5.4u
M1020 a_60_10# a_115_95# a_8_14# vdd pfet w=3u l=0.6u
+  ad=3.6p pd=5.4u as=6.3p ps=10.2u
M1021 a_301_14# a_115_95# a_281_14# gnd nfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=3.6p ps=5.4u
M1022 vdd S a_36_10# vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1023 vdd a_36_10# a_8_14# vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1024 a_115_95# CLK gnd gnd nfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=3.6p ps=5.4u
M1025 a_60_10# a_122_10# a_8_14# gnd nfet w=3u l=0.6u
+  ad=3.6p pd=5.4u as=6.3p ps=10.2u
M1026 a_354_14# a_281_14# a_334_14# gnd nfet w=6u l=0.6u
+  ad=3.6p pd=7.2u as=14.4p ps=16.8u
M1027 vdd R a_334_14# vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1028 a_115_95# CLK vdd vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1029 a_281_14# a_115_95# a_36_10# vdd pfet w=3u l=0.6u
+  ad=3.6p pd=5.4u as=6.3p ps=10.2u
M1030 gnd R a_354_14# gnd nfet w=6u l=0.6u
+  ad=9.45p pd=9.15u as=3.6p ps=7.2u
M1031 vdd a_334_14# Q vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=12.6p ps=16.2u
.ends

.subckt TBUFX1 A EN Y vdd gnd
M1000 a_68_166# a_26_14# Y vdd pfet w=12u l=0.6u
+  ad=5.4p pd=12.9u as=25.2p ps=28.2u
M1001 gnd A a_68_14# gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=2.7p ps=6.9u
M1002 a_26_14# EN gnd gnd nfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=6.3p ps=10.2u
M1003 a_26_14# EN vdd vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=12.6p ps=16.2u
M1004 vdd A a_68_166# vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=5.4p ps=12.9u
M1005 a_68_14# EN Y gnd nfet w=6u l=0.6u
+  ad=2.7p pd=6.9u as=12.6p ps=16.2u
.ends

.subckt XNOR2X1 A B Y vdd gnd
M1000 a_74_166# A Y vdd pfet w=12u l=0.6u
+  ad=3.6p pd=12.6u as=14.4p ps=14.4u
M1001 a_29_58# B vdd vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=16.2p ps=14.7u
M1002 gnd A a_6_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
M1003 vdd A a_6_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=25.2p ps=28.2u
M1004 Y A a_44_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=1.8p ps=6.6u
M1005 a_29_58# B gnd gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=8.1p ps=8.7u
M1006 vdd B a_74_166# vdd pfet w=12u l=0.6u
+  ad=16.2p pd=14.7u as=3.6p ps=12.6u
M1007 Y a_6_14# a_44_166# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=5.4p ps=12.9u
M1008 a_44_14# a_29_58# gnd gnd nfet w=6u l=0.6u
+  ad=1.8p pd=6.6u as=7.2p ps=8.4u
M1009 a_72_14# a_6_14# Y gnd nfet w=6u l=0.6u
+  ad=2.7p pd=6.9u as=7.2p ps=8.4u
M1010 a_44_166# a_29_58# vdd vdd pfet w=12u l=0.6u
+  ad=5.4p pd=12.9u as=14.4p ps=14.4u
M1011 gnd B a_72_14# gnd nfet w=6u l=0.6u
+  ad=8.1p pd=8.7u as=2.7p ps=6.9u
.ends

.subckt AND2X2 A B Y vdd gnd
M1000 a_25_14# A a_7_14# gnd nfet w=6u l=0.6u
+  ad=2.7p pd=6.9u as=12.6p ps=16.2u
M1001 gnd B a_25_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=2.7p ps=6.9u
M1002 vdd B a_7_14# vdd pfet w=6u l=0.6u
+  ad=14.4p pd=14.7u as=8.1p ps=8.7u
M1003 Y a_7_14# gnd gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1004 Y a_7_14# vdd vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=14.4p ps=14.7u
M1005 a_7_14# A vdd vdd pfet w=6u l=0.6u
+  ad=8.1p pd=8.7u as=12.6p ps=16.2u
.ends

.subckt INVX1 A Y vdd gnd
M1000 Y A gnd gnd nfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=6.3p ps=10.2u
M1001 Y A vdd vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=12.6p ps=16.2u
.ends

.subckt OAI22X1 A B C D Y vdd gnd
M1000 Y D a_7_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1001 a_25_146# A vdd vdd pfet w=12u l=0.6u
+  ad=5.4p pd=12.9u as=25.2p ps=28.2u
M1002 a_65_146# D Y vdd pfet w=12u l=0.6u
+  ad=5.4p pd=12.9u as=23.4p ps=15.9u
M1003 gnd A a_7_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
M1004 a_7_14# C Y gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1005 a_7_14# B gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1006 Y B a_25_146# vdd pfet w=12u l=0.6u
+  ad=23.4p pd=15.9u as=5.4p ps=12.9u
M1007 vdd C a_65_146# vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=5.4p ps=12.9u
.ends

.subckt OR2X2 A B Y vdd gnd
M1000 Y a_7_146# gnd gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=6.3p ps=8.4u
M1001 a_25_146# A a_7_146# vdd pfet w=12u l=0.6u
+  ad=5.4p pd=12.9u as=25.2p ps=28.2u
M1002 a_7_146# A gnd gnd nfet w=3u l=0.6u
+  ad=3.6p pd=5.4u as=6.3p ps=10.2u
M1003 Y a_7_146# vdd vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=14.4p ps=14.4u
M1004 gnd B a_7_146# gnd nfet w=3u l=0.6u
+  ad=6.3p pd=8.4u as=3.6p ps=5.4u
M1005 vdd B a_25_146# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=5.4p ps=12.9u
.ends

.subckt khu_etri050_stdcells vdd gnd
XAOI22X1_0 AOI22X1_0/A AOI22X1_0/B AOI22X1_0/C AOI22X1_0/D AOI22X1_0/Y vdd gnd AOI22X1
XCLKBUF3_0 CLKBUF3_0/A CLKBUF3_0/Y vdd gnd CLKBUF3
XINVX8_0 INVX8_0/A INVX8_0/Y vdd gnd INVX8
XNOR3X1_0 NOR3X1_0/A NOR3X1_0/B NOR3X1_0/C NOR3X1_0/Y vdd gnd NOR3X1
XCLKBUF1_0 CLKBUF1_0/A CLKBUF1_0/Y vdd gnd CLKBUF1
XMUX2X1_0 MUX2X1_0/A MUX2X1_0/B MUX2X1_0/S MUX2X1_0/Y vdd gnd MUX2X1
XNAND3X1_0 NAND3X1_0/A NAND3X1_0/B NAND3X1_0/C NAND3X1_0/Y vdd gnd NAND3X1
XXOR2X1_0 XOR2X1_0/A XOR2X1_0/B XOR2X1_0/Y vdd gnd XOR2X1
XBUFX4_0 BUFX4_0/A BUFX4_0/Y vdd gnd BUFX4
XINVX4_0 INVX4_0/A INVX4_0/Y vdd gnd INVX4
XOAI21X1_0 OAI21X1_0/A OAI21X1_0/B OAI21X1_0/C OAI21X1_0/Y vdd gnd OAI21X1
XTBUFX2_0 TBUFX2_0/A TBUFX2_0/EN TBUFX2_0/Y vdd gnd TBUFX2
XDFFNEGX1_0 DFFNEGX1_0/D DFFNEGX1_0/CLK DFFNEGX1_0/Q vdd gnd DFFNEGX1
XAOI21X1_0 AOI21X1_0/A AOI21X1_0/B AOI21X1_0/C AOI21X1_0/Y vdd gnd AOI21X1
XBUFX2_0 BUFX2_0/A BUFX2_0/Y vdd gnd BUFX2
XINVX2_0 INVX2_0/A INVX2_0/Y vdd gnd INVX2
XFAX1_0 FAX1_0/A FAX1_0/B FAX1_0/C FAX1_0/YS FAX1_0/YC vdd gnd FAX1
XNOR2X1_0 NOR2X1_0/A NOR2X1_0/B NOR2X1_0/Y vdd gnd NOR2X1
XAND2X1_0 AND2X1_0/A AND2X1_0/B AND2X1_0/Y vdd gnd AND2X1
XDFFPOSX1_0 DFFPOSX1_0/D DFFPOSX1_0/CLK DFFPOSX1_0/Q vdd gnd DFFPOSX1
XNAND2X1_0 NAND2X1_0/A NAND2X1_0/B NAND2X1_0/Y vdd gnd NAND2X1
XOR2X1_0 OR2X1_0/A OR2X1_0/B OR2X1_0/Y vdd gnd OR2X1
XCLKBUF2_0 CLKBUF2_0/A CLKBUF2_0/Y vdd gnd CLKBUF2
XLATCH_0 LATCH_0/D LATCH_0/CLK LATCH_0/Q vdd gnd LATCH
XHAX1_0 HAX1_0/A HAX1_0/B HAX1_0/YS HAX1_0/YC vdd gnd HAX1
XDFFSR_0 DFFSR_0/R DFFSR_0/S DFFSR_0/D DFFSR_0/CLK DFFSR_0/Q vdd gnd DFFSR
XTBUFX1_0 TBUFX1_0/A TBUFX1_0/EN TBUFX1_0/Y vdd gnd TBUFX1
XXNOR2X1_0 XNOR2X1_0/A XNOR2X1_0/B XNOR2X1_0/Y vdd gnd XNOR2X1
XAND2X2_0 AND2X2_0/A AND2X2_0/B AND2X2_0/Y vdd gnd AND2X2
XINVX1_0 INVX1_0/A INVX1_0/Y vdd gnd INVX1
XOAI22X1_0 OAI22X1_0/A OAI22X1_0/B OAI22X1_0/C OAI22X1_0/D OAI22X1_0/Y vdd gnd OAI22X1
XOR2X2_0 OR2X2_0/A OR2X2_0/B OR2X2_0/Y vdd gnd OR2X2
.ends

** End of included library /usr/local/share/qflow/tech/etri050/etri050_stdcells.sp

.subckt pong_vh vdd gnd clk reset v_sync pixel p_tick
+ btn_up btn_down btn_left btn_right game_over game_new 

XFILL_0__1241_ gnd vdd FILL
XFILL_1__1402_ gnd vdd FILL
X_1257_ _u_ball.y_ball_[2] _240_ _237_ _236_ vdd gnd OAI21X1
XFILL_0__1470_ gnd vdd FILL
XFILL_0__1050_ gnd vdd FILL
X_800_ _37_ _511_ paddle_v[0] _38_ vdd gnd AOI21X1
X_1486_ _635_ _656_ _637_ _613_ vdd gnd OAI21X1
X_1066_ _368_ _379_ _54_ _55_ _413_ vdd 
+ gnd
+ OAI22X1
XFILL_1__848_ gnd vdd FILL
XFILL_0__1526_ gnd vdd FILL
XFILL_0__1106_ gnd vdd FILL
X_1295_ _u_ball.x_ball_[2] paddle_h[2] _274_ vdd gnd NAND2X1
XFILL_0__1335_ gnd vdd FILL
XFILL82950x150 gnd vdd FILL
XFILL_1__886_ gnd vdd FILL
XFILL_0__1564_ gnd vdd FILL
XFILL_0__1144_ gnd vdd FILL
XFILL_1__1305_ gnd vdd FILL
XFILL_0_BUFX2_insert20 gnd vdd FILL
XFILL_0_BUFX2_insert21 gnd vdd FILL
XFILL_0_BUFX2_insert22 gnd vdd FILL
XFILL_0_BUFX2_insert23 gnd vdd FILL
XFILL_0__1373_ gnd vdd FILL
XFILL_1__1534_ gnd vdd FILL
XFILL_1__1114_ gnd vdd FILL
X_1389_ _368_ paddle_v[1] _366_ _365_ vdd gnd OAI21X1
XFILL_0__1429_ gnd vdd FILL
XFILL_0__1182_ gnd vdd FILL
X_1601_ _712__bF$buf1 vdd _534_ clk_bF$buf4 _u_ctrl.State_[3] vdd 
+ gnd
+ DFFSR
X_932_ _545_ _547_ vdd gnd INVX1
XFILL_1__1343_ gnd vdd FILL
X_1198_ _u_ball.x_ball_[1] _181_ _180_ vdd gnd NAND2X1
XFILL_0__1238_ gnd vdd FILL
X_1410_ load_option_bF$buf3 _765__bF$buf0 _383_ vdd gnd NOR2X1
XFILL_1__1572_ gnd vdd FILL
XFILL_1__789_ gnd vdd FILL
XFILL_0__1467_ gnd vdd FILL
X_970_ _502_ _500_ paddle_v[2] _505_ vdd gnd OAI21X1
XFILL_1__1381_ gnd vdd FILL
XFILL_0__1276_ gnd vdd FILL
XFILL_0__1085_ gnd vdd FILL
X_1504_ _642_ _669_ _627_ vdd gnd NAND2X1
XFILL_0__832_ gnd vdd FILL
X_835_ _4_ _5_ vdd gnd INVX1
XFILL_1__1246_ gnd vdd FILL
X_1313_ _u_ball.sign_x_ _309_ _291_ vdd gnd NOR2X1
XFILL_1__1475_ gnd vdd FILL
XFILL_1__1055_ gnd vdd FILL
X_1542_ _701_ _669_ _657_ _u_ctrl.State_3_bF$buf1_ _720_ vdd 
+ gnd
+ AOI22X1
X_1122_ _105_ _u_ball.x_ball_[4] _u_ball.x_ball_[5] _104_ vdd gnd AOI21X1
XFILL_0__870_ gnd vdd FILL
XFILL_1__904_ gnd vdd FILL
X_873_ _u_ball.y_pos_[4] _730_ vdd gnd INVX1
XFILL_1__1284_ gnd vdd FILL
XFILL_0__1179_ gnd vdd FILL
XFILL_0__926_ gnd vdd FILL
X_929_ paddle_h[1] _550_ vdd gnd INVX1
X_1351_ _u_ball.x_ball_[4] _u_ball.x_ball_[5] _327_ vdd gnd NOR2X1
X_1407_ _u_ball.y_ball_[5] _383_ _381_ _u_ball.y_init_[5] _380_ vdd 
+ gnd
+ AOI22X1
X_1580_ _688_ _689_ _u_ctrl.State_3_bF$buf2_ _687_ vdd gnd OAI21X1
X_1160_ _u_ball.y_pos_[4] _394_ _142_ vdd gnd NOR2X1
XFILL_1__942_ gnd vdd FILL
XFILL_0__1200_ gnd vdd FILL
X_1216_ _u_ball.y_ball_[0] _217_ _210_ _198_ vdd gnd NAND3X1
XFILL_0__964_ gnd vdd FILL
X_967_ paddle_v[4] _507_ paddle_v[5] _508_ vdd gnd OAI21X1
X_1445_ vdd _712__bF$buf2 _722_ clk_bF$buf2 _u_ball.x_pos_[1] vdd 
+ gnd
+ DFFSR
X_1025_ load_option_bF$buf1 _466_ _447_ _455_ vdd gnd OAI21X1
X_776_ _491_ vdd _489_ clk_bF$buf1 paddle_v[0] vdd 
+ gnd
+ DFFSR
XFILL_1__1187_ gnd vdd FILL
XFILL_0__829_ gnd vdd FILL
X_1254_ _u_ball.y_ball_[2] _363_ _368_ _233_ vdd gnd NAND3X1
X_1483_ _763_ _611_ vdd gnd INVX1
X_1063_ _u_ball.y_ball_[2] _383_ _381_ _u_ball.y_init_[2] _51_ vdd 
+ gnd
+ AOI22X1
XFILL_1__845_ gnd vdd FILL
XFILL_0__1523_ gnd vdd FILL
XFILL_0__1103_ gnd vdd FILL
X_1539_ _655_ _656_ _654_ vdd gnd NAND2X1
X_1119_ _u_ball.x_pos_[4] _102_ _101_ vdd gnd NAND2X1
XFILL_0__867_ gnd vdd FILL
X_1292_ paddle_h[2] _309_ _272_ paddle_h[3] _271_ vdd 
+ gnd
+ OAI22X1
XFILL_0__1332_ gnd vdd FILL
X_1348_ _325_ _330_ _424_ vdd gnd NAND2X1
XFILL_1__883_ gnd vdd FILL
XFILL_0__1561_ gnd vdd FILL
XFILL_0__1141_ gnd vdd FILL
XFILL_1__1302_ gnd vdd FILL
X_1577_ _u_ball.y_pos_[2] _685_ vdd gnd INVX1
X_1157_ _154_ _142_ _140_ _139_ vdd gnd OAI21X1
XFILL_0__1370_ gnd vdd FILL
XFILL_1__1531_ gnd vdd FILL
X_1386_ paddle_v[3] _363_ _402_ paddle_v[2] _362_ vdd 
+ gnd
+ OAI22X1
XFILL_0__1426_ gnd vdd FILL
XFILL_0__1006_ gnd vdd FILL
XFILL_1__1340_ gnd vdd FILL
X_1195_ _u_ball.x_pos_[0] _336_ _177_ vdd gnd NOR2X1
XFILL_0__1235_ gnd vdd FILL
XFILL_0__999_ gnd vdd FILL
XFILL_1__786_ gnd vdd FILL
XFILL_0__1464_ gnd vdd FILL
XFILL_1__1205_ gnd vdd FILL
XFILL_0__1273_ gnd vdd FILL
XFILL_1__1014_ gnd vdd FILL
X_1289_ paddle_h[4] _268_ vdd gnd INVX1
XFILL_0__1329_ gnd vdd FILL
XFILL_0__1082_ gnd vdd FILL
XFILL83850x46950 gnd vdd FILL
X_1501_ _u_ctrl.State_[1] _u_ctrl.cnt_v_sync_[2] _648_ _624_ vdd gnd NAND3X1
X_832_ _559_ _7_ _8_ vdd gnd NAND2X1
XFILL_1__1243_ gnd vdd FILL
X_1098_ _81_ _83_ _82_ _80_ vdd gnd NAND3X1
XFILL_0__1558_ gnd vdd FILL
XFILL_0__1138_ gnd vdd FILL
X_1310_ _312_ _294_ _289_ _288_ vdd gnd NAND3X1
XFILL_1__1472_ gnd vdd FILL
XFILL_1__1052_ gnd vdd FILL
XFILL_0__1367_ gnd vdd FILL
XFILL_1__901_ gnd vdd FILL
X_870_ _732_ _733_ vdd gnd INVX1
XFILL_1__1281_ gnd vdd FILL
XFILL_0__1596_ gnd vdd FILL
XFILL_0__1176_ gnd vdd FILL
XFILL_0__923_ gnd vdd FILL
X_926_ btn_left _525_ _553_ vdd gnd NOR2X1
X_1404_ _393_ _390_ _378_ vdd gnd NOR2X1
XFILL_1__1146_ gnd vdd FILL
X_1213_ _209_ _210_ _196_ _195_ vdd gnd AOI21X1
XFILL_0__961_ gnd vdd FILL
X_964_ _506_ _509_ _508_ _511_ vdd gnd NAND3X1
X_1442_ _712__bF$buf1 vdd _705_ clk_bF$buf6 _u_ctrl.cnt_v_sync_[0] vdd 
+ gnd
+ DFFSR
X_1022_ _u_ball.y_init_[3] _449_ vdd gnd INVX1
XFILL_0__770_ gnd vdd FILL
XFILL_1__804_ gnd vdd FILL
X_773_ _491_ vdd _486_ clk_bF$buf1 paddle_v[2] vdd 
+ gnd
+ DFFSR
XFILL_1__1184_ gnd vdd FILL
XFILL_0__1499_ gnd vdd FILL
XFILL_0__1079_ gnd vdd FILL
XFILL_0__826_ gnd vdd FILL
X_829_ _u_ball.x_pos_[2] _11_ vdd gnd INVX1
X_1251_ _233_ _231_ _u_ball.sign_y_ _230_ vdd gnd OAI21X1
X_1307_ _286_ _287_ _285_ vdd gnd NAND2X1
X_1480_ _609_ _651_ _616_ _608_ vdd gnd OAI21X1
X_1060_ _405_ _406_ _49_ vdd gnd NAND2X1
XFILL_1__842_ gnd vdd FILL
XFILL_0__1520_ gnd vdd FILL
XFILL_0__1100_ gnd vdd FILL
X_1536_ _u_ctrl.State_[4] _652_ vdd gnd INVX1
X_1116_ _104_ _107_ _98_ vdd gnd NOR2X1
XFILL_0__864_ gnd vdd FILL
X_867_ paddle_v[0] _734_ _735_ _736_ vdd gnd OAI21X1
X_1345_ _323_ _322_ vdd gnd INVX1
XFILL_1__880_ gnd vdd FILL
X_1574_ _u_ball.y_pos_[2] _689_ _682_ vdd gnd NOR2X1
X_1154_ _218_ _216_ _214_ _136_ vdd gnd OAI21X1
XFILL_0__958_ gnd vdd FILL
X_1383_ _408_ paddle_v[5] _394_ paddle_v[4] _359_ vdd 
+ gnd
+ AOI22X1
XFILL_0__1423_ gnd vdd FILL
XFILL_0__1003_ gnd vdd FILL
X_1439_ vdd _712__bF$buf0 _728_ clk_bF$buf4 _u_ball.y_pos_[0] vdd 
+ gnd
+ DFFSR
X_1019_ reset _458_ vdd gnd INVX2
XFILL_0__767_ gnd vdd FILL
X_1192_ _178_ _175_ _174_ vdd gnd NAND2X1
XFILL_1__974_ gnd vdd FILL
XFILL_0__1232_ gnd vdd FILL
X_1248_ _765__bF$buf0 _290_ _228_ vdd gnd NAND2X1
XFILL_0__996_ gnd vdd FILL
X_999_ load_option_bF$buf0 _479_ _480_ _469_ vdd gnd OAI21X1
XFILL_1__783_ gnd vdd FILL
XFILL_0__1461_ gnd vdd FILL
XFILL_1__1202_ gnd vdd FILL
X_1477_ _608_ _605_ vdd gnd INVX1
X_1057_ _765__bF$buf1 _u_ball.y_init_[3] _379_ _46_ vdd gnd OAI21X1
XFILL_1__839_ gnd vdd FILL
XFILL_0__1517_ gnd vdd FILL
XFILL_0__1270_ gnd vdd FILL
XFILL_1__1431_ gnd vdd FILL
X_1286_ _267_ _270_ _266_ _265_ vdd gnd OAI21X1
XFILL_0__1326_ gnd vdd FILL
XFILL_1__1240_ gnd vdd FILL
XFILL82950x18150 gnd vdd FILL
X_1095_ _81_ _85_ _88_ _77_ vdd gnd NAND3X1
XFILL_0__1555_ gnd vdd FILL
XFILL_0__1135_ gnd vdd FILL
XFILL_0__899_ gnd vdd FILL
XFILL_0__1364_ gnd vdd FILL
XFILL83550x79350 gnd vdd FILL
XFILL_0__1593_ gnd vdd FILL
XFILL_0__1173_ gnd vdd FILL
XFILL_0__920_ gnd vdd FILL
X_923_ _547_ _544_ paddle_h[3] _556_ vdd gnd OAI21X1
X_1189_ _336_ _u_ball.x_pos_[0] _176_ _171_ vdd gnd OAI21X1
XFILL_0__1229_ gnd vdd FILL
X_1401_ _377_ _376_ _409_ _375_ vdd gnd AOI21X1
XFILL_1__1563_ gnd vdd FILL
XFILL_1__1143_ gnd vdd FILL
X_1210_ _193_ _200_ _192_ vdd gnd NAND2X1
X_961_ _513_ _503_ _514_ vdd gnd NAND2X1
XFILL_1__1372_ gnd vdd FILL
XFILL83850x32550 gnd vdd FILL
XFILL_0__1267_ gnd vdd FILL
XFILL_1__1428_ gnd vdd FILL
XFILL_1__801_ gnd vdd FILL
X_770_ _0_ game_over vdd gnd BUFX2
XFILL_1__1181_ gnd vdd FILL
XFILL_0__1496_ gnd vdd FILL
XFILL_0__1076_ gnd vdd FILL
XFILL_0__823_ gnd vdd FILL
XFILL_1_BUFX2_insert9 gnd vdd FILL
X_826_ _557_ _11_ _13_ _14_ vdd gnd OAI21X1
XFILL_1__1237_ gnd vdd FILL
X_1304_ _283_ _284_ _317_ _422_ vdd gnd OAI21X1
X_1533_ _u_ctrl.State_[2] _651_ _650_ vdd gnd NAND2X1
X_1113_ _116_ _96_ _95_ vdd gnd NAND2X1
XFILL_0__861_ gnd vdd FILL
X_864_ _737_ paddle_v[2] paddle_v[1] _738_ _739_ vdd 
+ gnd
+ AOI22X1
XFILL_0__917_ gnd vdd FILL
X_1342_ _336_ _320_ _765__bF$buf0 _319_ vdd gnd OAI21X1
XFILL_1__1084_ gnd vdd FILL
XFILL_0__1399_ gnd vdd FILL
X_1571_ _685_ _693_ _680_ _726_ vdd gnd OAI21X1
X_1151_ _363_ _u_ball.y_pos_[3] _153_ _133_ vdd gnd AOI21X1
X_1207_ _190_ _191_ _189_ vdd gnd NAND2X1
XFILL_0__955_ gnd vdd FILL
X_958_ paddle_v[3] _517_ vdd gnd INVX1
XFILL_1__1369_ gnd vdd FILL
X_1380_ paddle_v[4] _356_ vdd gnd INVX1
XFILL_0__1420_ gnd vdd FILL
XFILL_0__1000_ gnd vdd FILL
X_1436_ _765__bF$buf2 _409_ vdd gnd INVX2
X_1016_ _u_ball.y_init_[5] _452_ vdd gnd INVX1
X_767_ _765__bF$buf1 v_sync vdd gnd BUFX2
XFILL_1__1178_ gnd vdd FILL
XFILL_1__971_ gnd vdd FILL
X_1245_ _311_ _294_ _226_ vdd gnd NAND2X1
XFILL_0__993_ gnd vdd FILL
X_996_ reset _471_ vdd gnd INVX2
XFILL_1__780_ gnd vdd FILL
X_1474_ _u_ctrl.cnt_v_sync_[0] _603_ vdd gnd INVX1
X_1054_ _u_ball.x_ball_[2] _u_ball.x_ball_[3] _45_ _44_ vdd gnd NAND3X1
XFILL_0__1514_ gnd vdd FILL
XFILL_0__858_ gnd vdd FILL
X_1283_ _u_ball.x_ball_[5] _280_ _262_ vdd gnd NOR2X1
XFILL_0__1323_ gnd vdd FILL
XFILL83250x57750 gnd vdd FILL
X_1339_ _u_ball.x_ball_[6] _383_ _317_ vdd gnd NAND2X1
X_1092_ _75_ _79_ _74_ vdd gnd NAND2X1
XFILL_0__1552_ gnd vdd FILL
XFILL_0__1132_ gnd vdd FILL
X_1568_ _u_ball.y_pos_[3] _683_ _677_ vdd gnd NOR2X1
X_1148_ _u_ball.x_pos_[4] _130_ vdd gnd INVX1
XFILL_0__896_ gnd vdd FILL
X_899_ paddle_h[5] _578_ _579_ vdd gnd NAND2X1
XFILL_0__1361_ gnd vdd FILL
XFILL_1__1522_ gnd vdd FILL
XFILL_1__1102_ gnd vdd FILL
X_1377_ _u_ball.y_ball_[0] _353_ vdd gnd INVX2
XFILL_0__1417_ gnd vdd FILL
XFILL_0__1590_ gnd vdd FILL
XFILL_0__1170_ gnd vdd FILL
X_920_ _540_ _558_ _559_ vdd gnd NAND2X1
XFILL_1__1331_ gnd vdd FILL
XFILL83550x10950 gnd vdd FILL
X_1186_ _173_ _169_ _192_ _168_ vdd gnd NAND3X1
XFILL_1__968_ gnd vdd FILL
XFILL_0__1226_ gnd vdd FILL
XFILL_1__1560_ gnd vdd FILL
XFILL_1__1140_ gnd vdd FILL
XFILL_0__799_ gnd vdd FILL
XFILL_0__1264_ gnd vdd FILL
XFILL_1__1425_ gnd vdd FILL
XFILL_1__1005_ gnd vdd FILL
XFILL_0__1493_ gnd vdd FILL
XFILL_0__1073_ gnd vdd FILL
XFILL_0__820_ gnd vdd FILL
X_823_ _16_ _15_ _17_ vdd gnd NAND2X1
X_1089_ _304_ _312_ _73_ vdd gnd OR2X2
XFILL_0__1549_ gnd vdd FILL
XFILL_0__1129_ gnd vdd FILL
X_1301_ paddle_h[5] _280_ vdd gnd INVX1
XFILL_0__1358_ gnd vdd FILL
XFILL_1__1519_ gnd vdd FILL
X_1530_ _u_ctrl.cnt_v_sync_[0] _u_ctrl.cnt_v_sync_[1] _648_ vdd gnd OR2X2
X_1110_ _209_ _210_ _92_ vdd gnd NAND2X1
X_861_ paddle_v[3] _740_ _737_ _742_ vdd gnd OAI21X1
XFILL_0__1587_ gnd vdd FILL
XFILL_0__1167_ gnd vdd FILL
XFILL_0__914_ gnd vdd FILL
X_917_ _557_ _545_ _560_ _562_ vdd gnd NAND3X1
XFILL_1__1328_ gnd vdd FILL
XFILL_1__1081_ gnd vdd FILL
XFILL_0__1396_ gnd vdd FILL
XFILL_1__1557_ gnd vdd FILL
XFILL_1__1137_ gnd vdd FILL
XFILL_1__930_ gnd vdd FILL
X_1204_ _188_ _187_ _189_ _186_ vdd gnd NAND3X1
XFILL_0__952_ gnd vdd FILL
X_955_ _504_ _519_ _520_ vdd gnd NAND2X1
XFILL_1__1366_ gnd vdd FILL
X_1433_ _407_ _406_ vdd gnd INVX1
X_1013_ _458_ vdd _456_ clk_bF$buf0 _u_ball.y_init_[2] vdd 
+ gnd
+ DFFSR
XFILL_0__817_ gnd vdd FILL
X_1242_ _305_ _225_ _224_ _223_ vdd gnd OAI21X1
XFILL_0__990_ gnd vdd FILL
X_993_ load_option_bF$buf0 _482_ _490_ _472_ vdd gnd OAI21X1
XFILL_0__1299_ gnd vdd FILL
X_1471_ _626_ _602_ _601_ _705_ vdd gnd OAI21X1
X_1051_ _42_ _43_ _0_ _41_ vdd gnd AOI21X1
XFILL_0__1511_ gnd vdd FILL
X_1527_ _u_ball.y_pos_[4] _u_ball.y_pos_[5] _678_ _645_ vdd gnd NAND3X1
X_1107_ _91_ _90_ _92_ _89_ vdd gnd AOI21X1
XFILL_0__855_ gnd vdd FILL
X_858_ _744_ _745_ vdd gnd INVX1
XFILL_1__1269_ gnd vdd FILL
X_1280_ _262_ _260_ _261_ _259_ vdd gnd OAI21X1
XFILL_0__1320_ gnd vdd FILL
X_1336_ _316_ _315_ _314_ vdd gnd NOR2X1
XFILL_1__1498_ gnd vdd FILL
XFILL_1__1078_ gnd vdd FILL
XFILL_1__871_ gnd vdd FILL
X_1565_ _679_ _693_ _675_ _725_ vdd gnd OAI21X1
X_1145_ _309_ _u_ball.x_pos_[2] _127_ vdd gnd OR2X2
XFILL_0__893_ gnd vdd FILL
XFILL_1__927_ gnd vdd FILL
X_896_ btn_right _525_ _541_ _582_ vdd gnd OAI21X1
XFILL_0__949_ gnd vdd FILL
X_1374_ _368_ paddle_v[1] _402_ _351_ _350_ vdd 
+ gnd
+ AOI22X1
XFILL_0__1414_ gnd vdd FILL
X_1183_ _u_ball.y_ball_[0] _u_ball.y_ball_[1] _402_ _165_ vdd gnd OAI21X1
XFILL_1__965_ gnd vdd FILL
XFILL_0__1223_ gnd vdd FILL
X_1239_ _221_ _223_ _220_ vdd gnd NAND2X1
XFILL_0__987_ gnd vdd FILL
XFILL_0__1032_ gnd vdd FILL
X_1468_ _599_ _645_ _598_ vdd gnd AND2X2
X_1048_ _417_ vdd _419_ clk_bF$buf7 _u_ball.x_ball_[3] vdd 
+ gnd
+ DFFSR
XFILL_0__796_ gnd vdd FILL
X_799_ paddle_v[0] _511_ _37_ _39_ vdd gnd NAND3X1
XFILL_0__1508_ gnd vdd FILL
XFILL_0__1261_ gnd vdd FILL
XFILL_1__1422_ gnd vdd FILL
XFILL_1__1002_ gnd vdd FILL
X_1277_ _276_ _269_ paddle_h[4] _256_ vdd gnd OAI21X1
XFILL_0__1317_ gnd vdd FILL
XFILL_0__1490_ gnd vdd FILL
XFILL_0__1070_ gnd vdd FILL
X_820_ _6_ _8_ _19_ _760_ _20_ vdd 
+ gnd
+ AOI22X1
X_1086_ _315_ _379_ _71_ _72_ _416_ vdd 
+ gnd
+ OAI22X1
XFILL_1__868_ gnd vdd FILL
XFILL_0__1546_ gnd vdd FILL
XFILL_0__1126_ gnd vdd FILL
XFILL_0__1355_ gnd vdd FILL
XFILL_1__1516_ gnd vdd FILL
XFILL_0__1584_ gnd vdd FILL
XFILL_0__1164_ gnd vdd FILL
XFILL_0__911_ gnd vdd FILL
X_914_ _564_ _545_ _560_ _565_ vdd gnd NAND3X1
XFILL_1__1325_ gnd vdd FILL
XFILL_0__1393_ gnd vdd FILL
XFILL_1__1554_ gnd vdd FILL
XFILL_0__1029_ gnd vdd FILL
X_1201_ _185_ _184_ _183_ vdd gnd NAND2X1
X_952_ paddle_v[5] paddle_v[1] _523_ vdd gnd NOR2X1
XFILL_1__1363_ gnd vdd FILL
XFILL_0__1258_ gnd vdd FILL
X_1430_ _u_ball.sign_y_ _403_ vdd gnd INVX1
X_1010_ _458_ vdd _459_ clk_bF$buf0 _u_ball.y_init_[4] vdd 
+ gnd
+ DFFSR
XFILL_0__1487_ gnd vdd FILL
XFILL_0__1067_ gnd vdd FILL
XFILL83550x18150 gnd vdd FILL
XFILL_0__814_ gnd vdd FILL
X_817_ _569_ _4_ _22_ _u_ball.x_pos_[5] _23_ vdd 
+ gnd
+ AOI22X1
XFILL_1__1228_ gnd vdd FILL
X_990_ _u_ball.x_init_[6] _u_ball.x_init_[5] _443_ vdd gnd NAND2X1
XFILL_0__1296_ gnd vdd FILL
XFILL_1__830_ gnd vdd FILL
X_1524_ _645_ _697_ _643_ vdd gnd NOR2X1
X_1104_ _210_ _216_ _92_ _87_ _86_ vdd 
+ gnd
+ AOI22X1
XFILL_0__852_ gnd vdd FILL
X_855_ paddle_v[4] _730_ _731_ _748_ vdd gnd AOI21X1
XFILL_1__1266_ gnd vdd FILL
XFILL_0__908_ gnd vdd FILL
X_1333_ _u_ball.sign_x_ _u_ball.x_ball_[3] _311_ vdd gnd NAND2X1
XFILL_1__1495_ gnd vdd FILL
X_1562_ _678_ _672_ vdd gnd INVX1
X_1142_ _u_ball.x_ball_[0] _u_ball.x_pos_[0] _124_ vdd gnd NAND2X1
XFILL_0__890_ gnd vdd FILL
XFILL_1__924_ gnd vdd FILL
X_893_ _581_ _583_ _585_ vdd gnd AND2X2
XFILL_0__1199_ gnd vdd FILL
XFILL_0__946_ gnd vdd FILL
X_949_ btn_up _525_ _526_ vdd gnd NOR2X1
X_1371_ _360_ _351_ _347_ vdd gnd NAND2X1
XFILL_0__1411_ gnd vdd FILL
X_1427_ _401_ _404_ _400_ vdd gnd AND2X2
X_1007_ _u_ball.x_init_[1] _475_ vdd gnd INVX1
XFILL_1__1169_ gnd vdd FILL
X_1180_ _u_ball.y_pos_[3] _162_ vdd gnd INVX1
XFILL_0__1220_ gnd vdd FILL
X_1236_ _u_ball.y_ball_[1] _219_ _218_ vdd gnd NOR2X1
X_987_ _u_ball.x_init_[0] _477_ _446_ vdd gnd NAND2X1
X_1465_ _u_ctrl.cnt_v_sync_[0] _u_ctrl.cnt_v_sync_[1] _596_ vdd gnd NAND2X1
X_1045_ _417_ vdd _423_ clk_bF$buf4 _u_ball.x_ball_[1] vdd 
+ gnd
+ DFFSR
XFILL_0__793_ gnd vdd FILL
XFILL_1__827_ gnd vdd FILL
X_796_ paddle_h[1] _578_ _418_ vdd gnd NAND2X1
XFILL_0__1505_ gnd vdd FILL
XFILL_0__849_ gnd vdd FILL
X_1274_ gnd _336_ _253_ vdd gnd NOR2X1
XFILL_0__1314_ gnd vdd FILL
XFILL82950x46950 gnd vdd FILL
X_1083_ _303_ _69_ _68_ vdd gnd NOR2X1
XFILL_1__865_ gnd vdd FILL
XFILL_0__1543_ gnd vdd FILL
XFILL_0__1123_ gnd vdd FILL
X_1559_ _670_ _673_ _724_ vdd gnd OR2X2
X_1139_ _u_ball.x_ball_[3] _128_ _122_ _126_ _121_ vdd 
+ gnd
+ AOI22X1
XFILL_0__887_ gnd vdd FILL
XFILL_0__1352_ gnd vdd FILL
XFILL_1__1513_ gnd vdd FILL
X_1368_ _358_ _345_ _346_ _344_ vdd gnd OAI21X1
XFILL_0__1408_ gnd vdd FILL
XFILL_0__1581_ gnd vdd FILL
XFILL_0__1161_ gnd vdd FILL
X_911_ _558_ _568_ vdd gnd INVX1
XFILL_1__1322_ gnd vdd FILL
X_1597_ _491_ vdd _496_ clk_bF$buf2 paddle_h[6] vdd 
+ gnd
+ DFFSR
X_1177_ _160_ _161_ _159_ vdd gnd NAND2X1
XFILL_0__1217_ gnd vdd FILL
XFILL_0__1390_ gnd vdd FILL
XFILL_1__768_ gnd vdd FILL
XFILL_0__1026_ gnd vdd FILL
XFILL_0__1255_ gnd vdd FILL
XFILL_0__1484_ gnd vdd FILL
XFILL_0__1064_ gnd vdd FILL
XFILL_0__811_ gnd vdd FILL
X_814_ _557_ _u_ball.x_pos_[2] _12_ _26_ vdd gnd OAI21X1
XFILL_1__1225_ gnd vdd FILL
XFILL83550x39750 gnd vdd FILL
XFILL_0__1293_ gnd vdd FILL
XFILL_0__1349_ gnd vdd FILL
X_1521_ _643_ _u_ctrl.State_3_bF$buf3_ _641_ _640_ vdd gnd AOI21X1
X_1101_ _199_ _197_ _201_ _83_ vdd gnd OAI21X1
X_852_ _750_ _745_ _751_ vdd gnd NOR2X1
XFILL_1__1263_ gnd vdd FILL
XFILL_0__1578_ gnd vdd FILL
XFILL_0__1158_ gnd vdd FILL
XFILL_0__905_ gnd vdd FILL
X_908_ _570_ _571_ vdd gnd INVX1
X_1330_ _316_ _309_ _308_ vdd gnd NOR2X1
XFILL_0__1387_ gnd vdd FILL
XFILL_1__1128_ gnd vdd FILL
X_890_ _515_ _512_ _587_ vdd gnd AND2X2
XFILL_0__1196_ gnd vdd FILL
XFILL_0__943_ gnd vdd FILL
X_946_ _528_ _529_ vdd gnd INVX1
X_1424_ _403_ _398_ _399_ _397_ vdd gnd AOI21X1
X_1004_ load_option_bF$buf3 _477_ vdd gnd INVX2
XFILL_1__1586_ gnd vdd FILL
XFILL_1__1166_ gnd vdd FILL
XFILL_0__808_ gnd vdd FILL
X_1233_ _u_ball.y_pos_[2] _215_ vdd gnd INVX1
X_984_ _471_ vdd _470_ clk_bF$buf3 _u_ball.x_init_[4] vdd 
+ gnd
+ DFFSR
XFILL_1__1395_ gnd vdd FILL
X_1462_ _u_ctrl.cnt_v_sync_[1] _626_ _593_ vdd gnd NAND2X1
X_1042_ _417_ vdd _414_ clk_bF$buf0 _u_ball.y_ball_[0] vdd 
+ gnd
+ DFFSR
XFILL_0__790_ gnd vdd FILL
XFILL_1__824_ gnd vdd FILL
X_793_ _561_ _429_ vdd gnd INVX1
XFILL_0__1502_ gnd vdd FILL
XFILL_0__1099_ gnd vdd FILL
X_1518_ _u_ctrl.State_[0] game_new _649_ _u_ctrl.State_3_bF$buf3_ _638_ vdd 
+ gnd
+ AOI22X1
XFILL_0__846_ gnd vdd FILL
X_849_ paddle_v[2] _u_ball.y_pos_[2] _752_ _753_ _754_ vdd 
+ gnd
+ AOI22X1
X_1271_ paddle_h[2] paddle_h[3] _250_ vdd gnd NOR2X1
XFILL_0__1311_ gnd vdd FILL
X_1327_ _307_ _306_ _308_ _305_ vdd gnd AOI21X1
X_1080_ _304_ _312_ _314_ _65_ vdd gnd AOI21X1
XFILL_1__862_ gnd vdd FILL
XFILL_0__1540_ gnd vdd FILL
XFILL_0__1120_ gnd vdd FILL
X_1556_ _u_ball.x_pos_[1] _668_ vdd gnd INVX1
X_1136_ _129_ _121_ _119_ _118_ vdd gnd OAI21X1
XFILL_0__884_ gnd vdd FILL
X_887_ _530_ _518_ _589_ vdd gnd NAND2X1
X_1365_ _347_ _342_ _348_ _341_ vdd gnd NAND3X1
XFILL_0__1405_ gnd vdd FILL
XFILL82650x79350 gnd vdd FILL
X_1594_ _u_ball.x_pos_[4] _700_ vdd gnd INVX2
X_1174_ _363_ _157_ _156_ vdd gnd NOR2X1
XFILL_1__956_ gnd vdd FILL
XFILL_0__1214_ gnd vdd FILL
XFILL_0__978_ gnd vdd FILL
XFILL_0__1023_ gnd vdd FILL
X_1459_ _712__bF$buf0 vdd _533_ clk_bF$buf6 _u_ctrl.State_[4] vdd 
+ gnd
+ DFFSR
X_1039_ vdd _417_ _426_ clk_bF$buf7 _u_ball.y_ball_[4] vdd 
+ gnd
+ DFFSR
XFILL_0__787_ gnd vdd FILL
XFILL_0__1252_ gnd vdd FILL
XFILL_1__1413_ gnd vdd FILL
X_1268_ _275_ _251_ _248_ _247_ vdd gnd NAND3X1
XFILL_0__1308_ gnd vdd FILL
XFILL_0__1481_ gnd vdd FILL
XFILL_0__1061_ gnd vdd FILL
X_811_ _540_ _u_ball.x_pos_[4] _564_ _u_ball.x_pos_[3] _29_ vdd 
+ gnd
+ AOI22X1
XFILL_1__1222_ gnd vdd FILL
X_1497_ _u_ball.x_pos_[5] _698_ _621_ vdd gnd NAND2X1
X_1077_ _382_ _63_ _409_ _62_ vdd gnd OAI21X1
XFILL_0__1537_ gnd vdd FILL
XFILL_0__1117_ gnd vdd FILL
XFILL_0__1290_ gnd vdd FILL
XFILL_1__1031_ gnd vdd FILL
XFILL_0__1346_ gnd vdd FILL
XFILL_0__1575_ gnd vdd FILL
XFILL_0__1155_ gnd vdd FILL
XFILL_0__902_ gnd vdd FILL
X_905_ _573_ _572_ _574_ vdd gnd NAND2X1
XFILL_0__1384_ gnd vdd FILL
XFILL_1__1545_ gnd vdd FILL
XFILL_1__1125_ gnd vdd FILL
XFILL_0__1193_ gnd vdd FILL
XFILL_0__940_ gnd vdd FILL
X_943_ _516_ _518_ _531_ _532_ vdd gnd AOI21X1
XFILL_1__1354_ gnd vdd FILL
XFILL_0__1249_ gnd vdd FILL
X_1421_ _u_ball.y_ball_[4] _394_ vdd gnd INVX2
X_1001_ _u_ball.x_init_[3] _479_ vdd gnd INVX1
XFILL_1__1583_ gnd vdd FILL
XFILL_1__1163_ gnd vdd FILL
XFILL_0__1478_ gnd vdd FILL
XFILL_0__1058_ gnd vdd FILL
XFILL_0__805_ gnd vdd FILL
X_808_ paddle_h[5] _760_ _5_ _32_ vdd gnd OAI21X1
XFILL_1__1219_ gnd vdd FILL
X_1230_ _214_ _213_ _212_ vdd gnd AND2X2
X_981_ vdd _471_ _474_ clk_bF$buf3 _u_ball.x_init_[0] vdd 
+ gnd
+ DFFSR
XFILL_1__1392_ gnd vdd FILL
XFILL_0__1287_ gnd vdd FILL
XFILL_1__821_ gnd vdd FILL
X_790_ _550_ _431_ _555_ _432_ vdd gnd OAI21X1
XFILL_0__1096_ gnd vdd FILL
X_1515_ _701_ _637_ _636_ vdd gnd NAND2X1
XFILL_0__843_ gnd vdd FILL
X_846_ _740_ _507_ _756_ _757_ vdd gnd OAI21X1
X_1324_ _303_ _302_ vdd gnd INVX1
XFILL_1__1486_ gnd vdd FILL
XFILL_1__1066_ gnd vdd FILL
X_1553_ _666_ _668_ _665_ vdd gnd NAND2X1
X_1133_ _u_ball.x_ball_[3] _u_ball.x_pos_[3] _115_ vdd gnd NAND2X1
XFILL_0__881_ gnd vdd FILL
X_884_ _590_ _591_ _528_ _592_ vdd gnd OAI21X1
XFILL_1__1295_ gnd vdd FILL
XFILL_1_CLKBUF1_insert1 gnd vdd FILL
XFILL_1_CLKBUF1_insert2 gnd vdd FILL
XFILL_1_CLKBUF1_insert4 gnd vdd FILL
XFILL_1_CLKBUF1_insert5 gnd vdd FILL
XFILL_1_CLKBUF1_insert7 gnd vdd FILL
XFILL_0__937_ gnd vdd FILL
X_1362_ _349_ _343_ _339_ _338_ vdd gnd OAI21X1
XFILL_0__1402_ gnd vdd FILL
X_1418_ _u_ball.sign_y_ _u_ball.y_ball_[3] _395_ _391_ vdd gnd OAI21X1
X_1591_ _u_ball.x_pos_[5] _u_ball.x_pos_[6] _698_ _697_ vdd gnd NAND3X1
X_1171_ _u_ball.y_ball_[4] _155_ _154_ _153_ vdd gnd OAI21X1
XFILL_1__953_ gnd vdd FILL
XFILL_0__1211_ gnd vdd FILL
X_1227_ _u_ball.y_ball_[1] _219_ _209_ vdd gnd NAND2X1
XFILL_0__975_ gnd vdd FILL
X_978_ paddle_v[5] _497_ vdd gnd INVX1
XFILL_1__1389_ gnd vdd FILL
XFILL_0__1020_ gnd vdd FILL
X_1456_ vdd _712__bF$buf2 _719_ clk_bF$buf5 _u_ball.x_pos_[4] vdd 
+ gnd
+ DFFSR
X_1036_ vdd _417_ _411_ clk_bF$buf7 _u_ball.y_ball_[3] vdd 
+ gnd
+ DFFSR
XFILL_0__784_ gnd vdd FILL
X_787_ _566_ _563_ _434_ vdd gnd NAND2X1
XFILL_1__991_ gnd vdd FILL
XFILL_1__1410_ gnd vdd FILL
X_1265_ _247_ _245_ _254_ _244_ vdd gnd AOI21X1
XFILL_0__1305_ gnd vdd FILL
X_1494_ _635_ _669_ _619_ _u_ctrl.State_3_bF$buf1_ _710_ vdd 
+ gnd
+ AOI22X1
X_1074_ _232_ _60_ vdd gnd INVX1
XFILL_0__1534_ gnd vdd FILL
XFILL_0__1114_ gnd vdd FILL
XFILL_0__878_ gnd vdd FILL
XBUFX2_insert8 load_option load_option_bF$buf3 vdd gnd BUFX2
XBUFX2_insert9 load_option load_option_bF$buf2 vdd gnd BUFX2
XFILL_0__1343_ gnd vdd FILL
XFILL_1__1504_ gnd vdd FILL
X_1359_ _u_ball.x_ball_[1] _335_ vdd gnd INVX2
XFILL_1__894_ gnd vdd FILL
XFILL_0__1572_ gnd vdd FILL
XFILL_0__1152_ gnd vdd FILL
X_902_ _575_ _576_ _555_ _577_ vdd gnd OAI21X1
XFILL_1__1313_ gnd vdd FILL
X_1588_ _u_ctrl.State_3_bF$buf0_ _u_ctrl.State_[0] _695_ _694_ vdd gnd OAI21X1
X_1168_ _163_ _158_ _151_ _150_ vdd gnd OAI21X1
XFILL_0__1208_ gnd vdd FILL
XFILL_0__1381_ gnd vdd FILL
XFILL_1__1542_ gnd vdd FILL
XFILL_1__1122_ gnd vdd FILL
X_1397_ _381_ _372_ vdd gnd INVX1
XFILL_0__1017_ gnd vdd FILL
XFILL_0__1190_ gnd vdd FILL
X_940_ _529_ _538_ paddle_v[5] _539_ vdd gnd OAI21X1
XFILL_1__1351_ gnd vdd FILL
XFILL_1__988_ gnd vdd FILL
XFILL_0__1246_ gnd vdd FILL
XFILL_1__1407_ gnd vdd FILL
XFILL_1__1580_ gnd vdd FILL
XFILL_1__1160_ gnd vdd FILL
XFILL_0__1475_ gnd vdd FILL
XFILL_0__1055_ gnd vdd FILL
XFILL83550x46950 gnd vdd FILL
XFILL_0__802_ gnd vdd FILL
X_805_ paddle_h[6] _759_ _34_ _35_ vdd gnd AOI21X1
XFILL_0__1284_ gnd vdd FILL
XFILL_0__1093_ gnd vdd FILL
X_1512_ _700_ _635_ _634_ _633_ vdd gnd NAND3X1
XFILL_0__840_ gnd vdd FILL
X_843_ _u_ball.x_pos_[5] _760_ vdd gnd INVX1
XFILL_0__1569_ gnd vdd FILL
XFILL_0__1149_ gnd vdd FILL
X_1321_ _u_ball.x_ball_[6] _299_ vdd gnd INVX1
XFILL_1__1483_ gnd vdd FILL
XFILL_1__1063_ gnd vdd FILL
XFILL_0__1378_ gnd vdd FILL
XFILL_1__1539_ gnd vdd FILL
XFILL_1__1119_ gnd vdd FILL
X_1550_ _u_ball.x_pos_[2] _663_ vdd gnd INVX1
X_1130_ _130_ _145_ _113_ _112_ vdd gnd NAND3X1
XFILL_1__912_ gnd vdd FILL
X_881_ _537_ _504_ _714_ vdd gnd NOR2X1
XFILL_1__1292_ gnd vdd FILL
XFILL_0__1187_ gnd vdd FILL
XFILL_0__934_ gnd vdd FILL
X_937_ paddle_h[5] _541_ vdd gnd INVX2
XFILL_1__1348_ gnd vdd FILL
X_1415_ _408_ _392_ _389_ _388_ vdd gnd NAND3X1
XFILL_1__950_ gnd vdd FILL
X_1224_ _210_ _207_ _208_ _206_ vdd gnd NAND3X1
XFILL_0__972_ gnd vdd FILL
X_975_ _499_ _498_ _497_ _500_ vdd gnd AOI21X1
XFILL83850x54150 gnd vdd FILL
X_1453_ _712__bF$buf1 vdd _709_ clk_bF$buf6 load_option vdd 
+ gnd
+ DFFSR
X_1033_ _u_ball.y_init_[5] _u_ball.y_init_[4] _461_ vdd gnd NAND2X1
XFILL_0__781_ gnd vdd FILL
X_784_ _567_ _572_ _436_ vdd gnd AND2X2
X_1509_ _685_ _688_ _631_ _630_ vdd gnd OAI21X1
XFILL_0__837_ gnd vdd FILL
X_1262_ _260_ _261_ _241_ vdd gnd NOR2X1
XFILL_0__1302_ gnd vdd FILL
X_1318_ _297_ _298_ _296_ vdd gnd NAND2X1
X_1491_ game_new _618_ _617_ _709_ vdd gnd AOI21X1
X_1071_ _u_ball.sign_y_ _398_ _167_ _58_ vdd gnd NAND3X1
XFILL_1__853_ gnd vdd FILL
XFILL_0__1531_ gnd vdd FILL
XFILL_0__1111_ gnd vdd FILL
X_1547_ _663_ _669_ _661_ _u_ctrl.State_3_bF$buf1_ _721_ vdd 
+ gnd
+ AOI22X1
X_1127_ _110_ _112_ _109_ vdd gnd NAND2X1
XFILL_0__875_ gnd vdd FILL
XFILL_1__909_ gnd vdd FILL
X_878_ _528_ _716_ _715_ _717_ vdd gnd NAND3X1
XFILL_1__1289_ gnd vdd FILL
XFILL_0__1340_ gnd vdd FILL
XFILL_1__1501_ gnd vdd FILL
X_1356_ _765__bF$buf3 _333_ _332_ vdd gnd NAND2X1
XFILL_1__891_ gnd vdd FILL
XFILL_1__1310_ gnd vdd FILL
X_1585_ _702_ _692_ _693_ _691_ vdd gnd OAI21X1
X_1165_ _u_ball.x_ball_[6] _148_ _147_ vdd gnd NOR2X1
XFILL_1__947_ gnd vdd FILL
XFILL_0__1205_ gnd vdd FILL
XFILL_0__969_ gnd vdd FILL
X_1394_ paddle_v[5] _408_ _370_ vdd gnd NOR2X1
XFILL_0__1434_ gnd vdd FILL
XFILL_0__1014_ gnd vdd FILL
XFILL_0__778_ gnd vdd FILL
XFILL_0__1243_ gnd vdd FILL
XFILL_1__1404_ gnd vdd FILL
X_1259_ _u_ball.x_ball_[6] _282_ _765__bF$buf3 _238_ vdd gnd OAI21X1
XFILL83850x7350 gnd vdd FILL
XFILL_1__794_ gnd vdd FILL
XFILL_0__1472_ gnd vdd FILL
XFILL_0__1052_ gnd vdd FILL
X_802_ reset _491_ vdd gnd INVX4
XFILL82650x18150 gnd vdd FILL
X_1488_ _765__bF$buf3 _615_ _614_ vdd gnd NAND2X1
X_1068_ _58_ _56_ _409_ _55_ vdd gnd AOI21X1
XFILL_0__1528_ gnd vdd FILL
XFILL_0__1108_ gnd vdd FILL
XFILL_0__1281_ gnd vdd FILL
XFILL_1__1022_ gnd vdd FILL
X_1297_ paddle_h[2] _276_ vdd gnd INVX1
XFILL_0__1337_ gnd vdd FILL
XFILL_0__1090_ gnd vdd FILL
X_840_ _u_ball.x_pos_[4] _u_ball.x_pos_[3] _u_ball.x_pos_[2] _766_ vdd gnd NAND3X1
XFILL83250x79350 gnd vdd FILL
XFILL_1__1251_ gnd vdd FILL
XFILL_1__888_ gnd vdd FILL
XFILL_0__1566_ gnd vdd FILL
XFILL_0__1146_ gnd vdd FILL
XFILL_1__1307_ gnd vdd FILL
XFILL_1__1480_ gnd vdd FILL
XFILL_1__1060_ gnd vdd FILL
XFILL_0__1375_ gnd vdd FILL
XFILL_1__1536_ gnd vdd FILL
XFILL_0__1184_ gnd vdd FILL
XFILL_0__931_ gnd vdd FILL
X_934_ _541_ _542_ _543_ _544_ vdd gnd NOR3X1
XFILL_1__1345_ gnd vdd FILL
X_1412_ _u_ball.y_ball_[5] _386_ _385_ vdd gnd NAND2X1
XFILL_0__1469_ gnd vdd FILL
X_1221_ _u_ball.y_pos_[0] _353_ _203_ vdd gnd NOR2X1
X_972_ _502_ _500_ _503_ vdd gnd NOR2X1
XFILL_0__1278_ gnd vdd FILL
XFILL_1__1019_ gnd vdd FILL
X_1450_ vdd _712__bF$buf0 _723_ clk_bF$buf4 _u_ball.x_pos_[0] vdd 
+ gnd
+ DFFSR
X_1030_ load_option_bF$buf1 _464_ vdd gnd INVX1
XFILL_1__812_ gnd vdd FILL
X_781_ _582_ _439_ vdd gnd INVX1
XFILL_1__1192_ gnd vdd FILL
XFILL83850x75750 gnd vdd FILL
XFILL_0__1087_ gnd vdd FILL
X_1506_ _636_ _633_ _628_ _764_ vdd gnd OAI21X1
XFILL_0__834_ gnd vdd FILL
X_837_ _569_ _3_ vdd gnd INVX1
XFILL_1__1248_ gnd vdd FILL
X_1315_ _308_ _293_ vdd gnd INVX1
XFILL_1__1477_ gnd vdd FILL
XFILL_1__850_ gnd vdd FILL
X_1544_ _663_ _667_ _701_ _658_ vdd gnd OAI21X1
X_1124_ _u_ball.x_ball_[1] _u_ball.x_ball_[2] _106_ vdd gnd NOR2X1
XFILL_0__872_ gnd vdd FILL
XFILL_1__906_ gnd vdd FILL
X_875_ _529_ paddle_v[0] _729_ vdd gnd OR2X2
XFILL_1__1286_ gnd vdd FILL
XFILL_0__928_ gnd vdd FILL
X_1353_ _u_ball.x_ball_[6] _u_ball.x_ball_[3] _329_ vdd gnd NOR2X1
X_1409_ load_option_bF$buf3 _382_ vdd gnd INVX1
X_1582_ _702_ _690_ _689_ vdd gnd NOR2X1
X_1162_ _149_ _145_ _147_ _144_ vdd gnd OAI21X1
XFILL_0__1202_ gnd vdd FILL
X_1218_ _211_ _206_ _201_ _200_ vdd gnd NAND3X1
XFILL_0__966_ gnd vdd FILL
X_969_ paddle_v[1] _506_ vdd gnd INVX1
X_1391_ paddle_v[0] _367_ vdd gnd INVX1
XFILL_0__1431_ gnd vdd FILL
X_1447_ vdd _712__bF$buf3 _707_ clk_bF$buf4 _u_ball.x_pos_[6] vdd 
+ gnd
+ DFFSR
X_1027_ _u_ball.y_init_[1] _466_ vdd gnd INVX1
XFILL_1__809_ gnd vdd FILL
X_778_ _438_ _441_ _496_ vdd gnd NAND2X1
XFILL_1__1189_ gnd vdd FILL
XFILL_0__1240_ gnd vdd FILL
X_1256_ _241_ _236_ _235_ vdd gnd NOR2X1
XFILL_1__791_ gnd vdd FILL
XFILL_1__1210_ gnd vdd FILL
X_1485_ _697_ _613_ _612_ vdd gnd NAND2X1
X_1065_ _397_ _400_ _53_ vdd gnd NOR2X1
XFILL_1__847_ gnd vdd FILL
XFILL_0__1525_ gnd vdd FILL
XFILL_0__1105_ gnd vdd FILL
XFILL_0__869_ gnd vdd FILL
X_1294_ _335_ paddle_h[1] _275_ _274_ _273_ vdd 
+ gnd
+ AOI22X1
XFILL_0__1334_ gnd vdd FILL
XFILL_0__1563_ gnd vdd FILL
XFILL_0__1143_ gnd vdd FILL
XFILL_1__1304_ gnd vdd FILL
XFILL_0_BUFX2_insert10 gnd vdd FILL
XFILL_0_BUFX2_insert11 gnd vdd FILL
XFILL_0_BUFX2_insert12 gnd vdd FILL
XFILL_0_BUFX2_insert13 gnd vdd FILL
X_1579_ _687_ _693_ _686_ vdd gnd NAND2X1
XFILL_0_BUFX2_insert14 gnd vdd FILL
X_1159_ _u_ball.y_pos_[5] _141_ vdd gnd INVX1
XFILL_0_BUFX2_insert15 gnd vdd FILL
XFILL_0_BUFX2_insert16 gnd vdd FILL
XFILL_0_BUFX2_insert17 gnd vdd FILL
XFILL_0_BUFX2_insert18 gnd vdd FILL
XFILL83250x10950 gnd vdd FILL
XFILL_0_BUFX2_insert19 gnd vdd FILL
XFILL_0__1372_ gnd vdd FILL
X_1388_ _402_ paddle_v[2] _368_ paddle_v[1] _364_ vdd 
+ gnd
+ AOI22X1
XFILL_0__1428_ gnd vdd FILL
XFILL_0__1181_ gnd vdd FILL
X_1600_ _417_ vdd _410_ clk_bF$buf3 _0_ vdd 
+ gnd
+ DFFSR
X_931_ paddle_h[2] paddle_h[3] _548_ vdd gnd NOR2X1
X_1197_ _188_ _180_ _179_ vdd gnd NAND2X1
XFILL_0__1237_ gnd vdd FILL
XFILL_1__1151_ gnd vdd FILL
XBUFX2_insert20 _u_ctrl.State_[3] _u_ctrl.State_3_bF$buf3_ vdd gnd BUFX2
XBUFX2_insert21 _u_ctrl.State_[3] _u_ctrl.State_3_bF$buf2_ vdd gnd BUFX2
XBUFX2_insert22 _u_ctrl.State_[3] _u_ctrl.State_3_bF$buf1_ vdd gnd BUFX2
XBUFX2_insert23 _u_ctrl.State_[3] _u_ctrl.State_3_bF$buf0_ vdd gnd BUFX2
XFILL_1__788_ gnd vdd FILL
XFILL_0__1466_ gnd vdd FILL
XFILL_1__1207_ gnd vdd FILL
XFILL_0__1275_ gnd vdd FILL
XFILL_1__1436_ gnd vdd FILL
XFILL_1__1016_ gnd vdd FILL
XFILL_0__1084_ gnd vdd FILL
X_1503_ _695_ _627_ _644_ _626_ vdd gnd NAND3X1
XFILL_0__831_ gnd vdd FILL
X_834_ _u_ball.x_pos_[4] _6_ vdd gnd INVX1
XFILL_1__1245_ gnd vdd FILL
X_1312_ _292_ _291_ _307_ _290_ vdd gnd OAI21X1
XFILL_0__1369_ gnd vdd FILL
X_1541_ _698_ _656_ vdd gnd INVX1
X_1121_ _104_ _107_ _u_ball.x_pos_[5] _103_ vdd gnd OAI21X1
X_872_ _u_ball.y_pos_[5] _497_ _731_ vdd gnd NAND2X1
XFILL_0__1178_ gnd vdd FILL
XFILL_0__925_ gnd vdd FILL
X_928_ paddle_h[4] paddle_h[5] _551_ vdd gnd NOR2X1
X_1350_ _u_ball.x_ball_[0] _335_ _327_ _326_ vdd gnd NAND3X1
XFILL_1__1092_ gnd vdd FILL
X_1406_ _409_ _384_ _380_ _427_ vdd gnd OAI21X1
XFILL_1__1568_ gnd vdd FILL
XFILL_1__1148_ gnd vdd FILL
X_1215_ _214_ _213_ _198_ _209_ _197_ vdd 
+ gnd
+ AOI22X1
XFILL_0__963_ gnd vdd FILL
X_966_ _502_ _509_ vdd gnd INVX1
XFILL_1__1377_ gnd vdd FILL
XFILL83850x28950 gnd vdd FILL
X_1444_ _712__bF$buf3 vdd _706_ clk_bF$buf4 _763_ vdd 
+ gnd
+ DFFSR
X_1024_ _u_ball.y_init_[2] _464_ _448_ vdd gnd NAND2X1
XFILL_1__806_ gnd vdd FILL
X_775_ _491_ vdd _484_ clk_bF$buf2 paddle_h[4] vdd 
+ gnd
+ DFFSR
XFILL_1__1186_ gnd vdd FILL
XFILL_0__828_ gnd vdd FILL
X_1253_ _353_ _409_ _232_ vdd gnd NOR2X1
X_1309_ _303_ _288_ _300_ _287_ vdd gnd OAI21X1
X_1482_ _692_ _645_ _697_ _610_ vdd gnd NOR3X1
X_1062_ _53_ _52_ _51_ _412_ vdd gnd OAI21X1
XFILL_1__844_ gnd vdd FILL
XFILL_0__1522_ gnd vdd FILL
XFILL_0__1102_ gnd vdd FILL
X_1538_ _700_ _669_ _654_ _u_ctrl.State_3_bF$buf2_ _719_ vdd 
+ gnd
+ AOI22X1
X_1118_ _101_ _103_ _100_ vdd gnd NAND2X1
XFILL_0__866_ gnd vdd FILL
X_869_ _u_ball.y_pos_[0] _734_ vdd gnd INVX1
X_1291_ _273_ _277_ _271_ _270_ vdd gnd AOI21X1
XFILL_0__1331_ gnd vdd FILL
X_1347_ _u_ball.sign_x_ _u_ball.x_ball_[1] _324_ vdd gnd NAND2X1
XFILL_1__1089_ gnd vdd FILL
XFILL_0__1560_ gnd vdd FILL
XFILL_0__1140_ gnd vdd FILL
X_1576_ _u_ball.y_pos_[0] _u_ball.y_pos_[1] _u_ball.y_pos_[2] _684_ vdd gnd NAND3X1
X_1156_ _154_ _142_ _139_ _138_ vdd gnd AOI21X1
XFILL_1__938_ gnd vdd FILL
XFILL_1__1110_ gnd vdd FILL
X_1385_ _365_ _364_ _362_ _361_ vdd gnd AOI21X1
XFILL_0__1425_ gnd vdd FILL
XFILL_0__1005_ gnd vdd FILL
XFILL_0__769_ gnd vdd FILL
X_1194_ _188_ _180_ _176_ vdd gnd AND2X2
XFILL_1__976_ gnd vdd FILL
XFILL_0__1234_ gnd vdd FILL
XFILL_0__998_ gnd vdd FILL
XFILL_1__785_ gnd vdd FILL
XFILL_0__1463_ gnd vdd FILL
XFILL_1__1204_ gnd vdd FILL
X_1479_ _641_ _608_ _610_ _607_ vdd gnd NOR3X1
X_1059_ _49_ _50_ _765__bF$buf1 _48_ vdd gnd OAI21X1
XFILL_0__1519_ gnd vdd FILL
XFILL_0__1272_ gnd vdd FILL
XFILL_1__1433_ gnd vdd FILL
X_1288_ _u_ball.x_ball_[3] _269_ _u_ball.x_ball_[4] _268_ _267_ vdd 
+ gnd
+ OAI22X1
XFILL_0__1328_ gnd vdd FILL
XFILL_0__1081_ gnd vdd FILL
X_1500_ _624_ _646_ _623_ vdd gnd NAND2X1
X_831_ _6_ _8_ _9_ vdd gnd NOR2X1
X_1097_ _94_ _84_ _80_ _79_ vdd gnd NAND3X1
XFILL_0__1557_ gnd vdd FILL
XFILL_0__1137_ gnd vdd FILL
XFILL_0__1366_ gnd vdd FILL
XFILL_1__1527_ gnd vdd FILL
XFILL_1__1107_ gnd vdd FILL
XFILL_0__1595_ gnd vdd FILL
XFILL_0__1175_ gnd vdd FILL
XFILL_0__922_ gnd vdd FILL
X_925_ _549_ _552_ _553_ _554_ vdd gnd OAI21X1
XFILL_1__1336_ gnd vdd FILL
X_1403_ _391_ _378_ _377_ vdd gnd OR2X2
XFILL_1__1565_ gnd vdd FILL
XFILL_1__1145_ gnd vdd FILL
XFILL83250x18150 gnd vdd FILL
X_1212_ _210_ _216_ _195_ _194_ vdd gnd AOI21X1
XFILL_0__960_ gnd vdd FILL
X_963_ paddle_v[0] _511_ _510_ _512_ vdd gnd AOI21X1
XFILL_1__1374_ gnd vdd FILL
XFILL_0__1269_ gnd vdd FILL
X_1441_ vdd _712__bF$buf3 _721_ clk_bF$buf2 _u_ball.x_pos_[2] vdd 
+ gnd
+ DFFSR
X_1021_ load_option_bF$buf2 _u_ball.y_init_[2] _450_ vdd gnd NAND2X1
XFILL_1__803_ gnd vdd FILL
X_772_ _491_ vdd _493_ clk_bF$buf5 paddle_h[1] vdd 
+ gnd
+ DFFSR
XFILL_0__1498_ gnd vdd FILL
XFILL_0__1078_ gnd vdd FILL
XFILL_0__825_ gnd vdd FILL
X_828_ _550_ _u_ball.x_pos_[1] _12_ vdd gnd OR2X2
X_1250_ _263_ _234_ _230_ _421_ vdd gnd OAI21X1
X_1306_ _285_ _295_ _409_ _284_ vdd gnd AOI21X1
XFILL_1__1468_ gnd vdd FILL
X_1535_ _653_ _652_ game_new _533_ vdd gnd AOI21X1
X_1115_ _99_ _107_ _98_ _120_ _97_ vdd 
+ gnd
+ AOI22X1
XFILL_0__863_ gnd vdd FILL
X_866_ _u_ball.y_pos_[2] _737_ vdd gnd INVX1
XFILL_1__1277_ gnd vdd FILL
XFILL_0__919_ gnd vdd FILL
X_1344_ _322_ _324_ _u_ball.x_ball_[0] _321_ vdd gnd AOI21X1
XFILL_1__1086_ gnd vdd FILL
XFILL83850x14550 gnd vdd FILL
X_1573_ _683_ _682_ _u_ctrl.State_3_bF$buf2_ _681_ vdd gnd OAI21X1
X_1153_ _u_ball.y_ball_[2] _215_ _136_ _135_ vdd gnd OAI21X1
XFILL_1__935_ gnd vdd FILL
X_1209_ _u_ball.x_ball_[2] _u_ball.x_pos_[2] _191_ vdd gnd OR2X2
XFILL_0__957_ gnd vdd FILL
X_1382_ paddle_v[4] _394_ _363_ _358_ vdd gnd OAI21X1
XFILL_0__1422_ gnd vdd FILL
XFILL_0__1002_ gnd vdd FILL
X_1438_ _712__bF$buf1 vdd _703_ clk_bF$buf6 _u_ctrl.cnt_v_sync_[1] vdd 
+ gnd
+ DFFSR
X_1018_ _u_ball.y_init_[4] _464_ _451_ vdd gnd NAND2X1
X_769_ _763_ p_tick vdd gnd BUFX2
X_1191_ _182_ _174_ _173_ vdd gnd NAND2X1
XFILL_1__973_ gnd vdd FILL
XFILL_0__1231_ gnd vdd FILL
X_1247_ _u_ball.x_ball_[2] _383_ _381_ _u_ball.x_init_[2] _227_ vdd 
+ gnd
+ AOI22X1
XFILL_0__995_ gnd vdd FILL
X_998_ _u_ball.x_init_[4] _477_ _481_ vdd gnd NAND2X1
XFILL_1__1201_ gnd vdd FILL
XFILL82650x46950 gnd vdd FILL
X_1476_ _606_ _605_ _640_ _604_ vdd gnd NAND3X1
X_1056_ _363_ _379_ _46_ _47_ _411_ vdd 
+ gnd
+ OAI22X1
XFILL_0__1516_ gnd vdd FILL
XFILL_1__1430_ gnd vdd FILL
X_1285_ _u_ball.x_ball_[5] _280_ _265_ _264_ vdd gnd OAI21X1
XFILL_0__1325_ gnd vdd FILL
XFILL_1_BUFX2_insert20 gnd vdd FILL
XFILL_1_BUFX2_insert22 gnd vdd FILL
XFILL_1_BUFX2_insert23 gnd vdd FILL
X_1094_ _93_ _83_ _82_ _76_ vdd gnd NAND3X1
XFILL_1__876_ gnd vdd FILL
XFILL_0__1554_ gnd vdd FILL
XFILL_0__1134_ gnd vdd FILL
XFILL_0__898_ gnd vdd FILL
XFILL_0__1363_ gnd vdd FILL
XFILL_1__1524_ gnd vdd FILL
XFILL_1__1104_ gnd vdd FILL
X_1379_ _u_ball.y_ball_[4] _356_ _370_ _355_ vdd gnd AOI21X1
XFILL_0__1419_ gnd vdd FILL
XFILL_0__1592_ gnd vdd FILL
XFILL_0__1172_ gnd vdd FILL
X_922_ paddle_h[2] _557_ vdd gnd INVX2
XFILL_1__1333_ gnd vdd FILL
X_1188_ _172_ _171_ _170_ vdd gnd NAND2X1
XFILL_0__1228_ gnd vdd FILL
X_1400_ _765__bF$buf1 _u_ball.y_init_[4] _379_ _374_ vdd gnd OAI21X1
XFILL_1__1562_ gnd vdd FILL
XFILL_1__1142_ gnd vdd FILL
X_960_ _505_ _514_ _515_ vdd gnd NAND2X1
XFILL_1__1371_ gnd vdd FILL
XFILL_0__1266_ gnd vdd FILL
XFILL_1__1007_ gnd vdd FILL
XFILL_0__1495_ gnd vdd FILL
XFILL_0__1075_ gnd vdd FILL
XFILL_0__822_ gnd vdd FILL
X_825_ _u_ball.x_pos_[3] _10_ _14_ _15_ vdd gnd OAI21X1
X_1303_ paddle_h[6] _282_ vdd gnd INVX1
XFILL_1__1465_ gnd vdd FILL
X_1532_ _652_ _696_ _650_ _534_ vdd gnd OAI21X1
X_1112_ _174_ _182_ _94_ vdd gnd AND2X2
XFILL_0__860_ gnd vdd FILL
X_863_ _u_ball.y_pos_[3] _740_ vdd gnd INVX1
XFILL_1__1274_ gnd vdd FILL
XFILL_0__1589_ gnd vdd FILL
XFILL_0__1169_ gnd vdd FILL
XFILL_0__916_ gnd vdd FILL
X_919_ paddle_h[5] paddle_h[6] _559_ _560_ vdd gnd NAND3X1
X_1341_ _u_ball.x_ball_[1] _383_ _381_ _u_ball.x_init_[1] _318_ vdd 
+ gnd
+ AOI22X1
XFILL_1__1083_ gnd vdd FILL
XFILL_0__1398_ gnd vdd FILL
X_1570_ _u_ball.y_pos_[3] _679_ vdd gnd INVX1
X_1150_ _134_ _133_ _137_ _132_ vdd gnd AOI21X1
XFILL_1__932_ gnd vdd FILL
X_1206_ _u_ball.x_pos_[1] _335_ _188_ vdd gnd NAND2X1
XFILL_0__954_ gnd vdd FILL
X_957_ _517_ _503_ _518_ vdd gnd NAND2X1
X_1435_ _u_ball.y_ball_[5] _408_ vdd gnd INVX2
X_1015_ load_option_bF$buf2 _u_ball.y_init_[4] _453_ vdd gnd NAND2X1
XFILL_1__970_ gnd vdd FILL
XFILL_0__819_ gnd vdd FILL
X_1244_ _226_ _225_ vdd gnd INVX1
XFILL_0__992_ gnd vdd FILL
X_995_ _u_ball.x_init_[5] _482_ vdd gnd INVX1
X_1473_ _603_ _u_ctrl.State_[1] _u_ctrl.State_3_bF$buf3_ _602_ vdd gnd AOI21X1
X_1053_ _239_ _43_ vdd gnd INVX1
XFILL_1__835_ gnd vdd FILL
XFILL_0__1513_ gnd vdd FILL
X_1529_ _u_ctrl.cnt_v_sync_[2] _648_ _647_ vdd gnd NOR2X1
X_1109_ _353_ _217_ _91_ vdd gnd NAND2X1
XFILL_0__857_ gnd vdd FILL
X_1282_ _282_ _u_ball.x_ball_[6] _u_ball.x_ball_[5] _280_ _261_ vdd 
+ gnd
+ AOI22X1
XFILL_0__1322_ gnd vdd FILL
X_1338_ _u_ball.sign_x_ _316_ vdd gnd INVX2
X_1091_ _131_ _74_ _95_ pixel_ball vdd gnd NOR3X1
XFILL_1__873_ gnd vdd FILL
XFILL_0__1551_ gnd vdd FILL
XFILL_0__1131_ gnd vdd FILL
X_1567_ _678_ _677_ _u_ctrl.State_3_bF$buf2_ _676_ vdd gnd OAI21X1
X_1147_ _u_ball.x_ball_[4] _130_ _129_ vdd gnd NOR2X1
XFILL_0__895_ gnd vdd FILL
XFILL_1__929_ gnd vdd FILL
X_898_ _573_ _580_ vdd gnd INVX1
XFILL_0__1360_ gnd vdd FILL
XFILL_1__1521_ gnd vdd FILL
XFILL_1__1101_ gnd vdd FILL
X_1376_ paddle_v[1] _368_ _353_ paddle_v[0] _352_ vdd 
+ gnd
+ OAI22X1
XFILL_0__1416_ gnd vdd FILL
XFILL_1__1330_ gnd vdd FILL
X_1185_ _399_ _167_ vdd gnd INVX1
XFILL_0__1225_ gnd vdd FILL
XFILL_0__989_ gnd vdd FILL
XFILL_0__798_ gnd vdd FILL
XFILL_0__1263_ gnd vdd FILL
X_1279_ _276_ _269_ _258_ vdd gnd NOR2X1
XFILL_0__1319_ gnd vdd FILL
XFILL_0__1492_ gnd vdd FILL
XFILL_0__1072_ gnd vdd FILL
X_822_ paddle_h[5] _559_ _18_ vdd gnd NOR2X1
XFILL_1__1233_ gnd vdd FILL
X_1088_ _73_ _288_ _409_ _72_ vdd gnd AOI21X1
XFILL_0__1548_ gnd vdd FILL
XFILL_0__1128_ gnd vdd FILL
X_1300_ paddle_h[1] _279_ vdd gnd INVX1
XFILL_1__1462_ gnd vdd FILL
XFILL_0__1357_ gnd vdd FILL
XFILL_1__1518_ gnd vdd FILL
X_860_ _741_ _742_ _736_ _739_ _743_ vdd 
+ gnd
+ AOI22X1
XFILL_1__1271_ gnd vdd FILL
XFILL_0__1586_ gnd vdd FILL
XFILL_0__1166_ gnd vdd FILL
XFILL_0__913_ gnd vdd FILL
X_916_ paddle_h[1] _562_ _561_ _563_ vdd gnd AOI21X1
XFILL_1__1327_ gnd vdd FILL
XFILL_0__1395_ gnd vdd FILL
X_1203_ _191_ _190_ _185_ vdd gnd AND2X2
XFILL_0__951_ gnd vdd FILL
X_954_ paddle_v[2] paddle_v[3] _521_ vdd gnd NOR2X1
X_1432_ _u_ball.sign_y_ _u_ball.y_ball_[3] _405_ vdd gnd NAND2X1
X_1012_ _458_ vdd _457_ clk_bF$buf0 _u_ball.y_init_[3] vdd 
+ gnd
+ DFFSR
XFILL_1__1594_ gnd vdd FILL
XFILL_1__1174_ gnd vdd FILL
XFILL_0__1489_ gnd vdd FILL
XFILL_0__1069_ gnd vdd FILL
XFILL_0__816_ gnd vdd FILL
X_819_ _9_ _17_ _20_ _21_ vdd gnd OAI21X1
X_1241_ _u_ball.x_init_[3] _222_ vdd gnd INVX1
X_992_ _u_ball.x_init_[6] _477_ _442_ vdd gnd NAND2X1
XFILL_0__1298_ gnd vdd FILL
X_1470_ _u_ball.y_pos_[5] _600_ vdd gnd INVX1
X_1050_ _41_ _44_ load_option_bF$buf3 _410_ vdd gnd AOI21X1
XFILL_1__832_ gnd vdd FILL
XFILL_0__1510_ gnd vdd FILL
X_1526_ _645_ _697_ _u_ctrl.State_3_bF$buf1_ _644_ vdd gnd OAI21X1
X_1106_ _199_ _197_ _89_ _88_ vdd gnd OAI21X1
XFILL_0__854_ gnd vdd FILL
X_857_ _498_ _u_ball.y_pos_[4] _745_ _746_ vdd gnd OAI21X1
XFILL_1__1268_ gnd vdd FILL
X_1335_ _u_ball.sign_x_ _u_ball.x_ball_[4] _313_ vdd gnd NOR2X1
XFILL_1__870_ gnd vdd FILL
X_1564_ _u_ball.y_pos_[4] _674_ vdd gnd INVX1
X_1144_ _185_ _184_ _127_ _126_ vdd gnd OAI21X1
XFILL_0__892_ gnd vdd FILL
X_895_ _541_ _570_ _582_ _583_ vdd gnd OAI21X1
XFILL_0__948_ gnd vdd FILL
X_1373_ _350_ _352_ _349_ vdd gnd AND2X2
XFILL_0__1413_ gnd vdd FILL
X_1429_ _u_ball.y_ball_[2] _402_ vdd gnd INVX2
X_1009_ _458_ vdd _454_ clk_bF$buf0 _u_ball.y_init_[0] vdd 
+ gnd
+ DFFSR
X_1182_ _u_ball.y_ball_[2] _399_ _164_ vdd gnd NAND2X1
XFILL_0__1222_ gnd vdd FILL
X_1238_ _272_ _379_ _220_ _419_ vdd gnd OAI21X1
XFILL_0__986_ gnd vdd FILL
X_989_ _u_ball.x_init_[6] _u_ball.x_init_[5] _444_ vdd gnd OR2X2
XFILL_0__1031_ gnd vdd FILL
X_1467_ _692_ _598_ _693_ _597_ vdd gnd OAI21X1
X_1047_ _417_ vdd _427_ clk_bF$buf7 _u_ball.y_ball_[5] vdd 
+ gnd
+ DFFSR
XFILL_0__795_ gnd vdd FILL
XFILL_1__829_ gnd vdd FILL
X_798_ _528_ _39_ _40_ vdd gnd NAND2X1
XFILL_0__1507_ gnd vdd FILL
XFILL_0__1260_ gnd vdd FILL
X_1276_ _256_ _257_ _255_ vdd gnd NAND2X1
XFILL_0__1316_ gnd vdd FILL
XFILL_1__1230_ gnd vdd FILL
X_1085_ _314_ _70_ vdd gnd INVX1
XFILL_0__1545_ gnd vdd FILL
XFILL_0__1125_ gnd vdd FILL
XFILL_0__889_ gnd vdd FILL
XFILL_0__1354_ gnd vdd FILL
XFILL_0__1583_ gnd vdd FILL
XFILL_0__1163_ gnd vdd FILL
XFILL_0__910_ gnd vdd FILL
X_913_ _565_ _556_ _566_ vdd gnd NAND2X1
X_1599_ vdd _458_ _460_ clk_bF$buf0 _u_ball.y_init_[5] vdd 
+ gnd
+ DFFSR
X_1179_ _u_ball.y_ball_[2] _167_ _363_ _161_ vdd gnd OAI21X1
XFILL_0__1219_ gnd vdd FILL
XFILL_0__1392_ gnd vdd FILL
XFILL_1__1133_ gnd vdd FILL
XFILL_0__1028_ gnd vdd FILL
XFILL83250x46950 gnd vdd FILL
X_1200_ _186_ _183_ _182_ vdd gnd NAND2X1
X_951_ _521_ _522_ _523_ _524_ vdd gnd NAND3X1
XFILL_1__999_ gnd vdd FILL
XFILL_0__1257_ gnd vdd FILL
XFILL_1__1418_ gnd vdd FILL
XFILL_1__1591_ gnd vdd FILL
XFILL_1__1171_ gnd vdd FILL
XFILL_0__1486_ gnd vdd FILL
XFILL_0__1066_ gnd vdd FILL
XFILL_0__813_ gnd vdd FILL
X_816_ _3_ _5_ _21_ _23_ _24_ vdd 
+ gnd
+ AOI22X1
XFILL_1__1227_ gnd vdd FILL
XFILL_0__1295_ gnd vdd FILL
X_1523_ _u_ctrl.State_[1] _642_ vdd gnd INVX1
X_1103_ _206_ _86_ _211_ _85_ vdd gnd NAND3X1
XFILL_0__851_ gnd vdd FILL
X_854_ _u_ball.y_pos_[3] _521_ _748_ _749_ vdd gnd AOI21X1
XFILL_0__907_ gnd vdd FILL
X_1332_ _u_ball.sign_x_ _u_ball.x_ball_[3] _310_ vdd gnd NOR2X1
XFILL_1__1074_ gnd vdd FILL
XFILL_0__1389_ gnd vdd FILL
X_1561_ _u_ball.y_pos_[4] _672_ _u_ctrl.State_3_bF$buf2_ _671_ vdd gnd OAI21X1
X_1141_ _191_ _190_ _125_ _124_ _123_ vdd 
+ gnd
+ AOI22X1
X_892_ _584_ _585_ _555_ _586_ vdd gnd OAI21X1
XFILL_0__1198_ gnd vdd FILL
XFILL_0__945_ gnd vdd FILL
X_948_ _526_ _524_ _527_ vdd gnd NAND2X1
XFILL_1__1359_ gnd vdd FILL
X_1370_ _363_ _347_ _348_ _346_ vdd gnd OAI21X1
XFILL_0__1410_ gnd vdd FILL
XFILL83550x54150 gnd vdd FILL
X_1426_ _u_ball.y_ball_[0] _u_ball.y_ball_[1] _399_ vdd gnd NOR2X1
X_1006_ _u_ball.x_init_[0] load_option_bF$buf1 _476_ vdd gnd NAND2X1
XFILL_1__1588_ gnd vdd FILL
XFILL_1__1168_ gnd vdd FILL
XFILL_1__961_ gnd vdd FILL
X_1235_ _u_ball.y_pos_[0] _217_ vdd gnd INVX1
X_986_ _446_ _445_ _474_ vdd gnd NAND2X1
XFILL_1__1397_ gnd vdd FILL
X_1464_ _596_ _648_ _595_ vdd gnd NAND2X1
X_1044_ _417_ vdd _415_ clk_bF$buf7 _u_ball.x_ball_[5] vdd 
+ gnd
+ DFFSR
XFILL_0__792_ gnd vdd FILL
XFILL_1__826_ gnd vdd FILL
X_795_ _550_ _555_ _428_ vdd gnd NAND2X1
XFILL_0__1504_ gnd vdd FILL
XFILL_0__848_ gnd vdd FILL
X_1273_ _u_ball.x_ball_[1] _279_ _253_ _252_ vdd gnd OAI21X1
XFILL_0__1313_ gnd vdd FILL
X_1329_ _336_ _323_ _324_ _307_ vdd gnd OAI21X1
X_1082_ _70_ _68_ _288_ _67_ vdd gnd NAND3X1
XFILL_0__1542_ gnd vdd FILL
XFILL_0__1122_ gnd vdd FILL
X_1558_ _u_ctrl.State_3_bF$buf0_ _u_ctrl.State_[0] _669_ vdd gnd NOR2X1
X_1138_ _u_ball.x_pos_[5] _120_ vdd gnd INVX1
XFILL_0__886_ gnd vdd FILL
X_889_ _512_ _515_ _528_ _588_ vdd gnd OAI21X1
XFILL_0__1351_ gnd vdd FILL
X_1367_ _402_ _351_ _344_ _343_ vdd gnd OAI21X1
XFILL_0__1407_ gnd vdd FILL
XFILL_0__1580_ gnd vdd FILL
XFILL_0__1160_ gnd vdd FILL
X_910_ paddle_h[4] _568_ paddle_h[5] _569_ vdd gnd OAI21X1
X_1596_ _u_ball.y_pos_[0] _702_ vdd gnd INVX1
X_1176_ _215_ _166_ _162_ _159_ _158_ vdd 
+ gnd
+ OAI22X1
XFILL_1__958_ gnd vdd FILL
XFILL_0__1216_ gnd vdd FILL
XFILL_1__1550_ gnd vdd FILL
XFILL_1__1130_ gnd vdd FILL
XFILL_0__1025_ gnd vdd FILL
XFILL_0__789_ gnd vdd FILL
XFILL_1__996_ gnd vdd FILL
XFILL_0__1254_ gnd vdd FILL
XFILL_1__1415_ gnd vdd FILL
XFILL_0__1483_ gnd vdd FILL
XFILL_0__1063_ gnd vdd FILL
XFILL_0__810_ gnd vdd FILL
X_813_ paddle_h[2] _11_ _25_ _26_ _27_ vdd 
+ gnd
+ OAI22X1
X_1499_ _u_ctrl.State_3_bF$buf3_ _623_ _622_ vdd gnd NOR2X1
X_1079_ _68_ _65_ _765__bF$buf2 _64_ vdd gnd OAI21X1
XFILL_0__1539_ gnd vdd FILL
XFILL_0__1119_ gnd vdd FILL
XFILL_0__1292_ gnd vdd FILL
XFILL_0__1348_ gnd vdd FILL
XFILL_1__1509_ gnd vdd FILL
X_1520_ _649_ _640_ _536_ vdd gnd NOR2X1
X_1100_ _211_ _206_ _194_ _82_ vdd gnd NAND3X1
X_851_ paddle_v[0] _734_ _735_ _752_ vdd gnd NAND3X1
XFILL_1__899_ gnd vdd FILL
XFILL_0__1577_ gnd vdd FILL
XFILL_0__1157_ gnd vdd FILL
XFILL_0__904_ gnd vdd FILL
X_907_ _540_ _571_ _572_ vdd gnd NAND2X1
XFILL_1__1318_ gnd vdd FILL
XFILL_1__1491_ gnd vdd FILL
XFILL_1__1071_ gnd vdd FILL
XFILL_0__1386_ gnd vdd FILL
XFILL_1__1547_ gnd vdd FILL
XFILL_1__1127_ gnd vdd FILL
XFILL_1__920_ gnd vdd FILL
XFILL82950x14550 gnd vdd FILL
XFILL_0__1195_ gnd vdd FILL
XFILL_0__942_ gnd vdd FILL
X_945_ _502_ _500_ paddle_v[3] _530_ vdd gnd OAI21X1
XFILL_1__1356_ gnd vdd FILL
X_1423_ _397_ _400_ _396_ vdd gnd NAND2X1
X_1003_ _u_ball.x_init_[2] _477_ _478_ vdd gnd NAND2X1
XFILL_1__1585_ gnd vdd FILL
XFILL_0__807_ gnd vdd FILL
X_1232_ _u_ball.y_ball_[2] _215_ _214_ vdd gnd NAND2X1
X_983_ _471_ vdd _469_ clk_bF$buf3 _u_ball.x_init_[3] vdd 
+ gnd
+ DFFSR
XFILL_1__1394_ gnd vdd FILL
XFILL_0__1289_ gnd vdd FILL
X_1461_ _626_ _594_ _593_ _703_ vdd gnd OAI21X1
X_1041_ _417_ vdd _422_ clk_bF$buf7 _u_ball.x_ball_[6] vdd 
+ gnd
+ DFFSR
X_792_ _429_ _562_ paddle_h[1] _430_ vdd gnd AOI21X1
XFILL_0__1501_ gnd vdd FILL
XFILL_0__1098_ gnd vdd FILL
X_1517_ _651_ _639_ _638_ _546_ vdd gnd OAI21X1
XFILL_0__845_ gnd vdd FILL
X_848_ _751_ _749_ _754_ _755_ vdd gnd OAI21X1
XFILL_1__1259_ gnd vdd FILL
X_1270_ _250_ _258_ _249_ vdd gnd NOR2X1
XFILL_0__1310_ gnd vdd FILL
X_1326_ _310_ _305_ _311_ _304_ vdd gnd OAI21X1
XFILL_1__1488_ gnd vdd FILL
XFILL_1__1068_ gnd vdd FILL
X_1555_ _u_ball.x_pos_[0] _u_ball.x_pos_[1] _667_ vdd gnd NAND2X1
X_1135_ _149_ _u_ball.x_pos_[5] _147_ _117_ vdd gnd AOI21X1
XFILL_0__883_ gnd vdd FILL
XFILL_1__917_ gnd vdd FILL
X_886_ _589_ _516_ _590_ vdd gnd NOR2X1
XFILL_1__1297_ gnd vdd FILL
XFILL_0__939_ gnd vdd FILL
X_1364_ _408_ paddle_v[5] _355_ _340_ vdd gnd AOI21X1
XFILL_0__1404_ gnd vdd FILL
X_1593_ _u_ball.x_pos_[0] _u_ball.x_pos_[1] _u_ball.x_pos_[2] _699_ vdd gnd NAND3X1
X_1173_ _u_ball.y_pos_[4] _155_ vdd gnd INVX1
XFILL_1__955_ gnd vdd FILL
XFILL_0__1213_ gnd vdd FILL
X_1229_ _218_ _216_ _212_ _211_ vdd gnd OAI21X1
XFILL_0__977_ gnd vdd FILL
XFILL_0__1022_ gnd vdd FILL
X_1458_ vdd _712__bF$buf2 _724_ clk_bF$buf2 _u_ball.y_pos_[4] vdd 
+ gnd
+ DFFSR
X_1038_ vdd _417_ _412_ clk_bF$buf7 _u_ball.y_ball_[2] vdd 
+ gnd
+ DFFSR
XFILL_0__786_ gnd vdd FILL
X_789_ _557_ _555_ _430_ _432_ _494_ vdd 
+ gnd
+ OAI22X1
XFILL_1__993_ gnd vdd FILL
XFILL_0__1251_ gnd vdd FILL
XFILL_1__1412_ gnd vdd FILL
X_1267_ _258_ _250_ _246_ vdd gnd OR2X2
XFILL_0__1307_ gnd vdd FILL
XFILL_0__1480_ gnd vdd FILL
XFILL_0__1060_ gnd vdd FILL
X_810_ _u_ball.x_pos_[5] _541_ _540_ _u_ball.x_pos_[4] _30_ vdd 
+ gnd
+ OAI22X1
X_1496_ _700_ _659_ _635_ _620_ vdd gnd OAI21X1
X_1076_ _66_ _64_ _62_ _61_ vdd gnd OAI21X1
XFILL_1__858_ gnd vdd FILL
XFILL_0__1536_ gnd vdd FILL
XFILL_0__1116_ gnd vdd FILL
XFILL_0__1345_ gnd vdd FILL
XFILL_1__1506_ gnd vdd FILL
XFILL_1__896_ gnd vdd FILL
XFILL_0__1574_ gnd vdd FILL
XFILL_0__1154_ gnd vdd FILL
XFILL_0__901_ gnd vdd FILL
X_904_ _567_ _574_ _575_ vdd gnd NOR2X1
XFILL_1__1315_ gnd vdd FILL
XFILL_0__1383_ gnd vdd FILL
XFILL_1__1544_ gnd vdd FILL
XFILL_1__1124_ gnd vdd FILL
X_1399_ _394_ _379_ _374_ _375_ _426_ vdd 
+ gnd
+ OAI22X1
XFILL_0__1019_ gnd vdd FILL
XFILL_0__1192_ gnd vdd FILL
X_942_ paddle_v[4] _503_ _537_ vdd gnd NOR2X1
XFILL_1__1353_ gnd vdd FILL
XFILL_0__1248_ gnd vdd FILL
X_1420_ _u_ball.sign_y_ _394_ _393_ vdd gnd NOR2X1
X_1000_ load_option_bF$buf0 _u_ball.x_init_[2] _480_ vdd gnd NAND2X1
XFILL_1__799_ gnd vdd FILL
XFILL_0__1477_ gnd vdd FILL
XFILL_0__1057_ gnd vdd FILL
XFILL_0__804_ gnd vdd FILL
X_807_ _737_ _740_ _33_ vdd gnd NOR2X1
X_980_ _471_ vdd _473_ clk_bF$buf3 _u_ball.x_init_[6] vdd 
+ gnd
+ DFFSR
XFILL_0__1286_ gnd vdd FILL
XFILL_1__1027_ gnd vdd FILL
XFILL_0__1095_ gnd vdd FILL
X_1514_ _u_ball.x_pos_[5] _635_ vdd gnd INVX1
XFILL_0__842_ gnd vdd FILL
X_845_ _732_ _757_ _755_ _758_ vdd gnd NAND3X1
XFILL_1__1256_ gnd vdd FILL
X_1323_ _312_ _302_ _304_ _301_ vdd gnd NAND3X1
XFILL_1__1485_ gnd vdd FILL
XFILL_1__1065_ gnd vdd FILL
X_1552_ _667_ _665_ _664_ vdd gnd NAND2X1
X_1132_ _u_ball.x_ball_[0] _u_ball.x_ball_[1] _u_ball.x_ball_[2] _114_ vdd gnd NOR3X1
XFILL_0__880_ gnd vdd FILL
XFILL_1__914_ gnd vdd FILL
X_883_ _517_ _528_ _592_ _487_ vdd gnd OAI21X1
XFILL_1__1294_ gnd vdd FILL
XFILL_0__1189_ gnd vdd FILL
XFILL_0__936_ gnd vdd FILL
X_939_ _520_ _539_ _483_ vdd gnd NAND2X1
X_1361_ _u_ball.x_ball_[6] _u_ball.x_ball_[4] _u_ball.x_ball_[5] _337_ vdd gnd NAND3X1
XFILL83550x28950 gnd vdd FILL
XFILL_0__1401_ gnd vdd FILL
X_1417_ _u_ball.y_ball_[4] _403_ _390_ vdd gnd NOR2X1
X_1590_ game_new _696_ vdd gnd INVX1
X_1170_ _153_ _152_ vdd gnd INVX1
XFILL_1__952_ gnd vdd FILL
XFILL_0__1210_ gnd vdd FILL
X_1226_ _353_ _u_ball.y_pos_[0] _209_ _208_ vdd gnd OAI21X1
XFILL_0__974_ gnd vdd FILL
X_977_ paddle_v[4] _498_ vdd gnd INVX1
X_1455_ vdd _712__bF$buf3 _710_ clk_bF$buf2 _u_ball.x_pos_[5] vdd 
+ gnd
+ DFFSR
X_1035_ _417_ vdd _424_ clk_bF$buf1 _u_ball.sign_x_ vdd 
+ gnd
+ DFFSR
XFILL_0__783_ gnd vdd FILL
XFILL_1__817_ gnd vdd FILL
X_786_ _555_ _434_ _433_ _435_ vdd gnd NAND3X1
XFILL_1__1197_ gnd vdd FILL
XFILL_1__990_ gnd vdd FILL
XFILL_0__839_ gnd vdd FILL
X_1264_ _281_ _262_ _243_ vdd gnd NOR2X1
XFILL_0__1304_ gnd vdd FILL
X_1493_ _653_ _652_ _618_ vdd gnd NAND2X1
X_1073_ _u_ball.y_init_[0] _372_ _60_ _59_ vdd gnd OAI21X1
XFILL_1__855_ gnd vdd FILL
XFILL_0__1533_ gnd vdd FILL
XFILL_0__1113_ gnd vdd FILL
X_1549_ _666_ _668_ _663_ _662_ vdd gnd OAI21X1
X_1129_ _u_ball.x_pos_[3] _272_ _111_ vdd gnd NAND2X1
XFILL_0__877_ gnd vdd FILL
XFILL_0__1342_ gnd vdd FILL
XFILL_1__1503_ gnd vdd FILL
X_1358_ _u_ball.x_ball_[2] _u_ball.x_ball_[3] _334_ vdd gnd NOR2X1
XFILL_1__893_ gnd vdd FILL
XFILL_0__1571_ gnd vdd FILL
XFILL_0__1151_ gnd vdd FILL
X_901_ _540_ _555_ _577_ _484_ vdd gnd OAI21X1
XFILL_1__1312_ gnd vdd FILL
X_1587_ _697_ _u_ctrl.State_3_bF$buf0_ _694_ _693_ vdd gnd AOI21X1
X_1167_ _u_ball.x_ball_[5] _149_ vdd gnd INVX2
XFILL83850x36150 gnd vdd FILL
XFILL_0__1207_ gnd vdd FILL
XFILL_0__1380_ gnd vdd FILL
X_1396_ _383_ _765__bF$buf2 _u_ball.x_ball_[0] _371_ vdd gnd MUX2X1
XFILL_0__1436_ gnd vdd FILL
XFILL_0__1016_ gnd vdd FILL
XFILL_0__1245_ gnd vdd FILL
XFILL_1__796_ gnd vdd FILL
XFILL_0__1474_ gnd vdd FILL
XFILL_0__1054_ gnd vdd FILL
XFILL_0__801_ gnd vdd FILL
X_804_ _32_ _31_ _35_ _36_ vdd gnd OAI21X1
XFILL_1__1215_ gnd vdd FILL
XFILL_0__1283_ gnd vdd FILL
XFILL_1__1024_ gnd vdd FILL
X_1299_ _u_ball.x_ball_[1] _279_ _278_ vdd gnd NAND2X1
XFILL_0__1339_ gnd vdd FILL
XFILL_0__1092_ gnd vdd FILL
X_1511_ _679_ _674_ _632_ vdd gnd NAND2X1
X_842_ _759_ _760_ _761_ vdd gnd NOR2X1
XFILL_1__1253_ gnd vdd FILL
XFILL_0__1568_ gnd vdd FILL
XFILL_0__1148_ gnd vdd FILL
XFILL_1__1309_ gnd vdd FILL
X_1320_ _316_ _299_ _298_ vdd gnd NAND2X1
XFILL_1__1482_ gnd vdd FILL
XFILL_0__1377_ gnd vdd FILL
XFILL_1__911_ gnd vdd FILL
X_880_ _531_ _519_ _714_ _715_ vdd gnd OAI21X1
XFILL_1__1291_ gnd vdd FILL
XFILL_0__1186_ gnd vdd FILL
XFILL_0__933_ gnd vdd FILL
X_936_ paddle_h[6] _542_ vdd gnd INVX1
X_1414_ _390_ _387_ vdd gnd INVX1
XFILL_1__1576_ gnd vdd FILL
XFILL_1__1156_ gnd vdd FILL
X_1223_ _u_ball.y_ball_[1] _219_ _216_ _205_ vdd gnd OAI21X1
XFILL_0__971_ gnd vdd FILL
X_974_ btn_down _501_ vdd gnd INVX1
XFILL_1__1385_ gnd vdd FILL
X_1452_ vdd _712__bF$buf1 _546_ clk_bF$buf6 _u_ctrl.State_[0] vdd 
+ gnd
+ DFFSR
X_1032_ _u_ball.y_init_[5] _u_ball.y_init_[4] _462_ vdd gnd OR2X2
XFILL_0__780_ gnd vdd FILL
XFILL_1__814_ gnd vdd FILL
XFILL_0_CLKBUF1_insert0 gnd vdd FILL
XFILL_0_CLKBUF1_insert1 gnd vdd FILL
XFILL_0_CLKBUF1_insert2 gnd vdd FILL
XFILL_0_CLKBUF1_insert3 gnd vdd FILL
XFILL_0_CLKBUF1_insert4 gnd vdd FILL
XFILL_0_CLKBUF1_insert5 gnd vdd FILL
XFILL_0_CLKBUF1_insert6 gnd vdd FILL
XFILL_0_CLKBUF1_insert7 gnd vdd FILL
X_783_ _541_ _570_ _437_ vdd gnd NOR2X1
XFILL_1__1194_ gnd vdd FILL
XFILL_0__1089_ gnd vdd FILL
X_1508_ pixel_ball pixel_paddle _629_ vdd gnd NOR2X1
XFILL_0__836_ gnd vdd FILL
X_839_ _766_ _762_ _1_ vdd gnd NOR2X1
X_1261_ _353_ _368_ _363_ _240_ vdd gnd OAI21X1
XFILL_0__1301_ gnd vdd FILL
X_1317_ _300_ _296_ _301_ _295_ vdd gnd NAND3X1
X_1490_ _669_ _639_ _616_ vdd gnd NAND2X1
X_1070_ _398_ _57_ vdd gnd INVX1
XFILL_1__852_ gnd vdd FILL
XFILL_0__1530_ gnd vdd FILL
XFILL_0__1110_ gnd vdd FILL
XFILL83550x14550 gnd vdd FILL
X_1546_ _701_ _699_ _660_ vdd gnd NOR2X1
X_1126_ _126_ _115_ _109_ _108_ vdd gnd AOI21X1
XFILL_0__874_ gnd vdd FILL
X_877_ _717_ _713_ _488_ vdd gnd AND2X2
XFILL_1__1500_ gnd vdd FILL
X_1355_ _337_ _332_ _331_ vdd gnd NOR2X1
XFILL_1__1097_ gnd vdd FILL
X_1584_ _702_ _693_ _691_ _728_ vdd gnd OAI21X1
X_1164_ _336_ _335_ _309_ _146_ vdd gnd NAND3X1
XFILL_0__1204_ gnd vdd FILL
XFILL_0__968_ gnd vdd FILL
XFILL83850x57750 gnd vdd FILL
X_1393_ _370_ _369_ vdd gnd INVX1
XFILL_0__1433_ gnd vdd FILL
X_1449_ _712__bF$buf0 vdd _708_ clk_bF$buf4 _765_ vdd 
+ gnd
+ DFFSR
X_1029_ _u_ball.y_init_[0] _464_ _465_ vdd gnd NAND2X1
XFILL_0__1242_ gnd vdd FILL
X_1258_ _239_ _238_ _237_ vdd gnd NOR2X1
XFILL_1__793_ gnd vdd FILL
XFILL_0__1471_ gnd vdd FILL
XFILL_0__1051_ gnd vdd FILL
X_801_ _510_ _37_ vdd gnd INVX1
XFILL_1__1212_ gnd vdd FILL
X_1487_ _692_ _615_ _614_ _708_ vdd gnd OAI21X1
X_1067_ _765__bF$buf1 _u_ball.y_init_[1] _379_ _54_ vdd gnd OAI21X1
XFILL_0__1527_ gnd vdd FILL
XFILL_0__1107_ gnd vdd FILL
XFILL_0__1280_ gnd vdd FILL
XFILL_1__1021_ gnd vdd FILL
X_1296_ _309_ _276_ _275_ vdd gnd NAND2X1
XFILL_0__1336_ gnd vdd FILL
XFILL_1__1250_ gnd vdd FILL
XFILL_0__1565_ gnd vdd FILL
XFILL_0__1145_ gnd vdd FILL
XFILL_0__1374_ gnd vdd FILL
XFILL_1__1115_ gnd vdd FILL
XFILL_0__1183_ gnd vdd FILL
XFILL_0__930_ gnd vdd FILL
X_933_ btn_right _525_ _545_ vdd gnd NOR2X1
X_1199_ _u_ball.x_pos_[1] _181_ vdd gnd INVX1
XFILL_0__1239_ gnd vdd FILL
X_1411_ _388_ _385_ _384_ vdd gnd NAND2X1
XFILL_1__1573_ gnd vdd FILL
XFILL_1__1153_ gnd vdd FILL
XFILL_0__1468_ gnd vdd FILL
XFILL_1__1209_ gnd vdd FILL
X_1220_ _204_ _218_ _203_ _202_ vdd gnd OAI21X1
X_971_ _503_ paddle_v[4] _504_ vdd gnd AND2X2
XFILL_1__1382_ gnd vdd FILL
XFILL_0__1277_ gnd vdd FILL
XFILL_1__1018_ gnd vdd FILL
XFILL_1__811_ gnd vdd FILL
X_780_ _581_ _439_ _436_ _437_ _440_ vdd 
+ gnd
+ AOI22X1
XFILL_1__1191_ gnd vdd FILL
XFILL_0__1086_ gnd vdd FILL
X_1505_ reset _712_ vdd gnd INVX8
XFILL_0__833_ gnd vdd FILL
X_836_ paddle_h[6] _759_ _4_ vdd gnd NOR2X1
X_1314_ _u_ball.x_ball_[2] _316_ _292_ vdd gnd NOR2X1
XFILL_1__1056_ gnd vdd FILL
X_1543_ _658_ _659_ _657_ vdd gnd NAND2X1
X_1123_ _106_ _336_ _272_ _105_ vdd gnd AOI21X1
XFILL_0__871_ gnd vdd FILL
X_874_ _718_ _729_ _489_ vdd gnd NAND2X1
XFILL_0__927_ gnd vdd FILL
X_1352_ _u_ball.x_ball_[2] _765__bF$buf3 _329_ _328_ vdd gnd NAND3X1
XFILL_1__1094_ gnd vdd FILL
X_1408_ _765__bF$buf2 _382_ _381_ vdd gnd NOR2X1
X_1581_ _u_ball.y_pos_[0] _u_ball.y_pos_[1] _688_ vdd gnd NOR2X1
X_1161_ _363_ _157_ _153_ _143_ vdd gnd OAI21X1
XFILL_1__943_ gnd vdd FILL
XFILL_0__1201_ gnd vdd FILL
X_1217_ _208_ _210_ _207_ _199_ vdd gnd AOI21X1
XFILL_0__965_ gnd vdd FILL
X_968_ paddle_v[2] paddle_v[3] _507_ vdd gnd AND2X2
XFILL_1__1379_ gnd vdd FILL
X_1390_ _u_ball.y_ball_[0] _367_ _366_ vdd gnd NOR2X1
XFILL_0__1430_ gnd vdd FILL
X_1446_ _712__bF$buf3 vdd _535_ clk_bF$buf6 _u_ctrl.State_[2] vdd 
+ gnd
+ DFFSR
X_1026_ _u_ball.y_init_[0] load_option_bF$buf1 _447_ vdd gnd NAND2X1
XFILL_1__808_ gnd vdd FILL
X_777_ _491_ vdd _488_ clk_bF$buf1 paddle_v[4] vdd 
+ gnd
+ DFFSR
XFILL_1__1400_ gnd vdd FILL
X_1255_ _235_ _242_ _234_ vdd gnd NAND2X1
X_1484_ _637_ _669_ _612_ _u_ctrl.State_3_bF$buf1_ _707_ vdd 
+ gnd
+ AOI22X1
X_1064_ _765__bF$buf2 _396_ _52_ vdd gnd NAND2X1
XFILL_0__1524_ gnd vdd FILL
XFILL_0__1104_ gnd vdd FILL
XFILL_0__868_ gnd vdd FILL
X_1293_ _u_ball.x_ball_[3] _272_ vdd gnd INVX2
XFILL_0__1333_ gnd vdd FILL
X_1349_ _328_ _326_ _u_ball.sign_x_ _325_ vdd gnd OAI21X1
XFILL_1__884_ gnd vdd FILL
XFILL_0__1562_ gnd vdd FILL
XFILL_0__1142_ gnd vdd FILL
XFILL83850x43350 gnd vdd FILL
X_1578_ _690_ _693_ _686_ _727_ vdd gnd OAI21X1
X_1158_ _148_ _u_ball.x_ball_[6] _u_ball.y_ball_[5] _141_ _140_ vdd 
+ gnd
+ AOI22X1
XFILL_0__1371_ gnd vdd FILL
XFILL_1__1532_ gnd vdd FILL
XFILL_1__1112_ gnd vdd FILL
X_1387_ _u_ball.y_ball_[3] _363_ vdd gnd INVX4
XFILL_0__1427_ gnd vdd FILL
XFILL_0__1007_ gnd vdd FILL
XFILL_0__1180_ gnd vdd FILL
X_930_ _548_ _549_ vdd gnd INVX1
XFILL_1__1341_ gnd vdd FILL
X_1196_ _336_ _u_ball.x_pos_[0] _179_ _178_ vdd gnd OAI21X1
XFILL_1__978_ gnd vdd FILL
XFILL_0__1236_ gnd vdd FILL
XFILL_1__1570_ gnd vdd FILL
XFILL_1__1150_ gnd vdd FILL
XBUFX2_insert10 load_option load_option_bF$buf1 vdd gnd BUFX2
XBUFX2_insert11 load_option load_option_bF$buf0 vdd gnd BUFX2
XBUFX2_insert12 _765_ _765__bF$buf3 vdd gnd BUFX2
XBUFX2_insert13 _765_ _765__bF$buf2 vdd gnd BUFX2
XBUFX2_insert14 _765_ _765__bF$buf1 vdd gnd BUFX2
XBUFX2_insert15 _765_ _765__bF$buf0 vdd gnd BUFX2
XBUFX2_insert16 _712_ _712__bF$buf3 vdd gnd BUFX2
XBUFX2_insert17 _712_ _712__bF$buf2 vdd gnd BUFX2
XBUFX2_insert18 _712_ _712__bF$buf1 vdd gnd BUFX2
XBUFX2_insert19 _712_ _712__bF$buf0 vdd gnd BUFX2
XFILL_0__1465_ gnd vdd FILL
XFILL_0__1274_ gnd vdd FILL
XFILL_1__1435_ gnd vdd FILL
XFILL_0__1083_ gnd vdd FILL
X_1502_ _u_ctrl.cnt_v_sync_[2] _626_ _625_ vdd gnd NAND2X1
XFILL_0__830_ gnd vdd FILL
X_833_ paddle_h[4] _568_ _7_ vdd gnd NAND2X1
X_1099_ _93_ _81_ vdd gnd INVX1
XFILL_0__1559_ gnd vdd FILL
XFILL_0__1139_ gnd vdd FILL
X_1311_ _311_ _293_ _290_ _289_ vdd gnd NAND3X1
XFILL_1__1473_ gnd vdd FILL
XFILL_1__1053_ gnd vdd FILL
XFILL_0__1368_ gnd vdd FILL
XFILL_1__1529_ gnd vdd FILL
XFILL_1__1109_ gnd vdd FILL
X_1540_ _701_ _699_ _700_ _655_ vdd gnd OAI21X1
X_1120_ _145_ _113_ _102_ vdd gnd NAND2X1
XFILL_1__902_ gnd vdd FILL
X_871_ paddle_v[4] _730_ _731_ _732_ vdd gnd OAI21X1
XFILL_1__1282_ gnd vdd FILL
XFILL_0__1177_ gnd vdd FILL
XFILL_0__924_ gnd vdd FILL
X_927_ _550_ _542_ _551_ _552_ vdd gnd NAND3X1
XFILL_1__1338_ gnd vdd FILL
XFILL_1__1091_ gnd vdd FILL
X_1405_ _383_ _379_ vdd gnd INVX2
XFILL_1__1567_ gnd vdd FILL
XFILL_1__940_ gnd vdd FILL
X_1214_ _u_ball.y_ball_[0] _217_ _196_ vdd gnd NAND2X1
XFILL_0__962_ gnd vdd FILL
X_965_ _508_ _509_ _506_ _510_ vdd gnd AOI21X1
XFILL_1__1376_ gnd vdd FILL
X_1443_ vdd _712__bF$buf2 _725_ clk_bF$buf5 _u_ball.y_pos_[3] vdd 
+ gnd
+ DFFSR
X_1023_ _464_ _466_ _448_ _456_ vdd gnd OAI21X1
X_774_ _491_ vdd _492_ clk_bF$buf1 paddle_v[1] vdd 
+ gnd
+ DFFSR
XFILL_0__827_ gnd vdd FILL
X_1252_ _408_ _394_ _232_ _231_ vdd gnd NAND3X1
X_1308_ _296_ _286_ vdd gnd INVX1
X_1481_ _u_ctrl.State_3_bF$buf3_ _u_ctrl.State_[1] _609_ vdd gnd NOR2X1
X_1061_ _403_ _402_ _396_ _50_ vdd gnd OAI21X1
XFILL_0__1521_ gnd vdd FILL
XFILL_0__1101_ gnd vdd FILL
X_1537_ _u_ctrl.State_[0] _653_ vdd gnd INVX1
X_1117_ _147_ _99_ vdd gnd INVX1
XFILL_0__865_ gnd vdd FILL
X_868_ _u_ball.y_pos_[1] _506_ _735_ vdd gnd NAND2X1
XFILL_1__1279_ gnd vdd FILL
X_1290_ paddle_h[3] _269_ vdd gnd INVX1
XFILL_0__1330_ gnd vdd FILL
X_1346_ _u_ball.sign_x_ _u_ball.x_ball_[1] _323_ vdd gnd NOR2X1
XFILL_1__1088_ gnd vdd FILL
XFILL_1__881_ gnd vdd FILL
XFILL_1__1300_ gnd vdd FILL
X_1575_ _684_ _683_ vdd gnd INVX1
X_1155_ _144_ _138_ _143_ _137_ vdd gnd NAND3X1
XFILL_1__937_ gnd vdd FILL
XFILL_0__959_ gnd vdd FILL
X_1384_ paddle_v[3] _360_ vdd gnd INVX1
XFILL_0__1424_ gnd vdd FILL
XFILL_0__1004_ gnd vdd FILL
XFILL_0__768_ gnd vdd FILL
X_1193_ _177_ _176_ _175_ vdd gnd NAND2X1
XFILL_0__1233_ gnd vdd FILL
X_1249_ _293_ _306_ _307_ _229_ vdd gnd AOI21X1
XFILL_0__997_ gnd vdd FILL
XFILL_0__1462_ gnd vdd FILL
X_1478_ _u_ctrl.State_[0] _u_ctrl.State_[2] _606_ vdd gnd NOR2X1
X_1058_ _50_ _49_ _48_ _47_ vdd gnd AOI21X1
XFILL_0__1518_ gnd vdd FILL
XFILL_0__1271_ gnd vdd FILL
X_1287_ _280_ _u_ball.x_ball_[5] _u_ball.x_ball_[4] _268_ _266_ vdd 
+ gnd
+ AOI22X1
XFILL_0__1327_ gnd vdd FILL
XFILL_0__1080_ gnd vdd FILL
X_830_ _558_ _549_ _10_ vdd gnd NAND2X1
XFILL_1__1241_ gnd vdd FILL
X_1096_ _182_ _174_ _78_ vdd gnd NOR2X1
XFILL_1__878_ gnd vdd FILL
XFILL_0__1556_ gnd vdd FILL
XFILL_0__1136_ gnd vdd FILL
XFILL_1__1470_ gnd vdd FILL
XFILL_1__1050_ gnd vdd FILL
XFILL_0__1365_ gnd vdd FILL
XFILL_1__1526_ gnd vdd FILL
XFILL_1__1106_ gnd vdd FILL
XFILL_0__1594_ gnd vdd FILL
XFILL_0__1174_ gnd vdd FILL
XFILL_0__921_ gnd vdd FILL
X_924_ _544_ _547_ _554_ _555_ vdd gnd OAI21X1
XFILL_1__1335_ gnd vdd FILL
X_1402_ _378_ _391_ _376_ vdd gnd NAND2X1
X_1211_ _199_ _197_ _194_ _193_ vdd gnd OAI21X1
X_962_ paddle_v[2] _513_ vdd gnd INVX1
XFILL_0__1268_ gnd vdd FILL
X_1440_ vdd _712__bF$buf2 _704_ clk_bF$buf2 _u_ball.y_pos_[5] vdd 
+ gnd
+ DFFSR
X_1020_ load_option_bF$buf2 _449_ _450_ _457_ vdd gnd OAI21X1
X_771_ _491_ vdd _483_ clk_bF$buf1 paddle_v[5] vdd 
+ gnd
+ DFFSR
XFILL_1__1182_ gnd vdd FILL
XFILL_0__1497_ gnd vdd FILL
XFILL_0__1077_ gnd vdd FILL
XFILL_0__824_ gnd vdd FILL
X_827_ paddle_h[2] _u_ball.x_pos_[2] _12_ _13_ vdd gnd OAI21X1
XFILL_1__1238_ gnd vdd FILL
X_1305_ _765__bF$buf0 _u_ball.x_init_[6] _379_ _283_ vdd gnd OAI21X1
XFILL_1__1467_ gnd vdd FILL
XFILL_1__840_ gnd vdd FILL
X_1534_ _0_ _696_ _651_ vdd gnd NOR2X1
X_1114_ _100_ _108_ _97_ _96_ vdd gnd OAI21X1
XFILL_0__862_ gnd vdd FILL
X_865_ _u_ball.y_pos_[1] _738_ vdd gnd INVX1
XFILL_1__1276_ gnd vdd FILL
XFILL_0__918_ gnd vdd FILL
X_1343_ _324_ _322_ _320_ vdd gnd NAND2X1
X_1572_ _681_ _693_ _680_ vdd gnd NAND2X1
X_1152_ _363_ _u_ball.y_pos_[3] _135_ _134_ vdd gnd OAI21X1
XFILL_1__934_ gnd vdd FILL
X_1208_ _u_ball.x_ball_[2] _u_ball.x_pos_[2] _190_ vdd gnd NAND2X1
XFILL_0__956_ gnd vdd FILL
X_959_ _512_ _515_ _505_ _516_ vdd gnd OAI21X1
X_1381_ _360_ _358_ _359_ _357_ vdd gnd OAI21X1
XFILL_0__1421_ gnd vdd FILL
XFILL_0__1001_ gnd vdd FILL
X_1437_ _491_ vdd _494_ clk_bF$buf5 paddle_h[2] vdd 
+ gnd
+ DFFSR
X_1017_ _464_ _449_ _451_ _459_ vdd gnd OAI21X1
X_768_ _764_ pixel vdd gnd BUFX2
XFILL_1__1179_ gnd vdd FILL
X_1190_ _177_ _179_ _172_ vdd gnd NAND2X1
XFILL_0__1230_ gnd vdd FILL
X_1246_ _229_ _228_ _227_ _420_ vdd gnd OAI21X1
XFILL_0__994_ gnd vdd FILL
X_997_ _477_ _479_ _481_ _470_ vdd gnd OAI21X1
XFILL_1__781_ gnd vdd FILL
X_1475_ _611_ _607_ _604_ _706_ vdd gnd OAI21X1
X_1055_ _337_ _45_ vdd gnd INVX1
XFILL_1__837_ gnd vdd FILL
XFILL_0__1515_ gnd vdd FILL
XFILL_0__859_ gnd vdd FILL
X_1284_ _264_ _281_ _263_ vdd gnd AND2X2
XFILL_0__1324_ gnd vdd FILL
XFILL_1_BUFX2_insert10 gnd vdd FILL
XFILL_1_BUFX2_insert12 gnd vdd FILL
XFILL_1_BUFX2_insert14 gnd vdd FILL
XFILL_1_BUFX2_insert15 gnd vdd FILL
XFILL_1_BUFX2_insert17 gnd vdd FILL
XFILL_1_BUFX2_insert19 gnd vdd FILL
XFILL83250x150 gnd vdd FILL
X_1093_ _78_ _77_ _76_ _75_ vdd gnd NAND3X1
XFILL_1__875_ gnd vdd FILL
XFILL_0__1553_ gnd vdd FILL
XFILL_0__1133_ gnd vdd FILL
X_1569_ _679_ _684_ _678_ vdd gnd NOR2X1
X_1149_ _150_ _132_ _168_ _131_ vdd gnd NAND3X1
XFILL_0__897_ gnd vdd FILL
XFILL_0__1362_ gnd vdd FILL
X_1378_ _369_ _357_ _361_ _355_ _354_ vdd 
+ gnd
+ AOI22X1
XFILL_0__1418_ gnd vdd FILL
XFILL_0__1591_ gnd vdd FILL
XFILL_0__1171_ gnd vdd FILL
X_921_ paddle_h[2] paddle_h[3] _558_ vdd gnd NAND2X1
X_1187_ _186_ _183_ _170_ _169_ vdd gnd NAND3X1
XFILL_0__1227_ gnd vdd FILL
XFILL_1__778_ gnd vdd FILL
XFILL_0__1265_ gnd vdd FILL
XFILL_1__1426_ gnd vdd FILL
XFILL_0__1494_ gnd vdd FILL
XFILL_0__1074_ gnd vdd FILL
XFILL_0__821_ gnd vdd FILL
X_824_ _548_ _568_ _u_ball.x_pos_[3] _16_ vdd gnd OAI21X1
XFILL_1__1235_ gnd vdd FILL
X_1302_ _u_ball.x_ball_[6] _282_ _281_ vdd gnd NAND2X1
XFILL_1__1464_ gnd vdd FILL
XFILL83850x3750 gnd vdd FILL
XFILL_0__1359_ gnd vdd FILL
X_1531_ _651_ _649_ vdd gnd INVX1
X_1111_ _124_ _125_ _93_ vdd gnd NAND2X1
X_862_ paddle_v[3] _740_ paddle_v[2] _741_ vdd gnd OAI21X1
XFILL_1__1273_ gnd vdd FILL
XFILL_0__1588_ gnd vdd FILL
XFILL_0__1168_ gnd vdd FILL
XFILL_0__915_ gnd vdd FILL
X_918_ _560_ _545_ _557_ _561_ vdd gnd AOI21X1
X_1340_ _321_ _319_ _318_ _423_ vdd gnd OAI21X1
XFILL_0__1397_ gnd vdd FILL
XFILL_1__1558_ gnd vdd FILL
XFILL_1__1138_ gnd vdd FILL
X_1205_ _u_ball.x_pos_[0] _336_ _335_ _u_ball.x_pos_[1] _187_ vdd 
+ gnd
+ OAI22X1
XFILL_0__953_ gnd vdd FILL
X_956_ _516_ _518_ _519_ vdd gnd AND2X2
XFILL_1__1367_ gnd vdd FILL
X_1434_ _u_ball.sign_y_ _u_ball.y_ball_[3] _407_ vdd gnd NOR2X1
X_1014_ load_option_bF$buf2 _452_ _453_ _460_ vdd gnd OAI21X1
XFILL_1__1596_ gnd vdd FILL
XFILL_1__1176_ gnd vdd FILL
XFILL_0__818_ gnd vdd FILL
X_1243_ _225_ _305_ _409_ _224_ vdd gnd AOI21X1
XFILL_0__991_ gnd vdd FILL
X_994_ load_option_bF$buf0 _u_ball.x_init_[4] _490_ vdd gnd NAND2X1
X_1472_ _u_ctrl.cnt_v_sync_[0] _626_ _601_ vdd gnd NAND2X1
X_1052_ _363_ _402_ _42_ vdd gnd NOR2X1
XFILL_1__834_ gnd vdd FILL
XFILL_0__1512_ gnd vdd FILL
X_1528_ _u_ctrl.State_[1] _647_ _646_ vdd gnd NAND2X1
X_1108_ _u_ball.y_ball_[0] _u_ball.y_pos_[0] _90_ vdd gnd NAND2X1
XFILL_0__856_ gnd vdd FILL
X_859_ _u_ball.y_pos_[3] _517_ _744_ vdd gnd NOR2X1
X_1281_ _276_ _269_ _268_ _260_ vdd gnd OAI21X1
XFILL_0__1321_ gnd vdd FILL
X_1337_ _u_ball.x_ball_[4] _315_ vdd gnd INVX1
XFILL_1__1079_ gnd vdd FILL
X_1090_ reset _417_ vdd gnd INVX8
XFILL_0__1550_ gnd vdd FILL
XFILL_0__1130_ gnd vdd FILL
X_1566_ _676_ _693_ _675_ vdd gnd NAND2X1
X_1146_ _u_ball.x_pos_[3] _128_ vdd gnd INVX1
XFILL_0__894_ gnd vdd FILL
X_897_ _567_ _572_ _580_ _581_ vdd gnd AOI21X1
X_1375_ paddle_v[2] _351_ vdd gnd INVX1
XFILL_0__1415_ gnd vdd FILL
X_1184_ _218_ _216_ _167_ _166_ vdd gnd OAI21X1
XFILL_1__966_ gnd vdd FILL
XFILL_0__1224_ gnd vdd FILL
XFILL_0__988_ gnd vdd FILL
XFILL_0__1033_ gnd vdd FILL
X_1469_ _674_ _672_ _600_ _599_ vdd gnd OAI21X1
X_1049_ _417_ vdd _420_ clk_bF$buf4 _u_ball.x_ball_[2] vdd 
+ gnd
+ DFFSR
XFILL_0__797_ gnd vdd FILL
XFILL_0__1509_ gnd vdd FILL
XFILL_0__1262_ gnd vdd FILL
XFILL_1__1423_ gnd vdd FILL
XFILL_1__1003_ gnd vdd FILL
X_1278_ _268_ _258_ _257_ vdd gnd NAND2X1
XFILL_0__1318_ gnd vdd FILL
XFILL_0__1491_ gnd vdd FILL
XFILL_0__1071_ gnd vdd FILL
X_821_ _18_ _3_ _19_ vdd gnd NOR2X1
XFILL_1__1232_ gnd vdd FILL
X_1087_ load_option_bF$buf3 _u_ball.x_init_[4] _765__bF$buf0 _71_ vdd gnd AOI21X1
XFILL_0__1547_ gnd vdd FILL
XFILL_0__1127_ gnd vdd FILL
XFILL_0__1356_ gnd vdd FILL
XFILL_0__1585_ gnd vdd FILL
XFILL_0__1165_ gnd vdd FILL
XFILL_0__912_ gnd vdd FILL
X_915_ paddle_h[3] _564_ vdd gnd INVX1
XFILL_0__1394_ gnd vdd FILL
XFILL_1__1555_ gnd vdd FILL
XFILL_1__1135_ gnd vdd FILL
X_1202_ _188_ _187_ _184_ vdd gnd NAND2X1
XFILL_0__950_ gnd vdd FILL
X_953_ paddle_v[4] paddle_v[0] _522_ vdd gnd NOR2X1
XFILL_1__1364_ gnd vdd FILL
XFILL_0__1259_ gnd vdd FILL
X_1431_ _u_ball.sign_y_ _u_ball.y_ball_[2] _404_ vdd gnd NAND2X1
X_1011_ _458_ vdd _455_ clk_bF$buf0 _u_ball.y_init_[1] vdd 
+ gnd
+ DFFSR
XFILL_1__1593_ gnd vdd FILL
XFILL_1__1173_ gnd vdd FILL
XFILL_0__1488_ gnd vdd FILL
XFILL_0__1068_ gnd vdd FILL
XFILL_0__815_ gnd vdd FILL
X_818_ _19_ _22_ vdd gnd INVX1
X_1240_ _382_ _222_ _409_ _221_ vdd gnd OAI21X1
X_991_ _477_ _482_ _442_ _473_ vdd gnd OAI21X1
XFILL_0__1297_ gnd vdd FILL
X_1525_ _644_ _646_ _649_ _535_ vdd gnd AOI21X1
X_1105_ _u_ball.y_pos_[0] _353_ _87_ vdd gnd NAND2X1
XFILL_0__853_ gnd vdd FILL
X_856_ _746_ _743_ _733_ _747_ vdd gnd OAI21X1
XFILL_0__909_ gnd vdd FILL
X_1334_ _313_ _314_ _312_ vdd gnd NOR2X1
XFILL_1__1496_ gnd vdd FILL
XFILL83250x28950 gnd vdd FILL
XFILL_1__1076_ gnd vdd FILL
X_1563_ _693_ _678_ _674_ _673_ vdd gnd AOI21X1
X_1143_ _u_ball.x_ball_[0] _u_ball.x_pos_[0] _125_ vdd gnd OR2X2
XFILL_0__891_ gnd vdd FILL
XFILL_1__925_ gnd vdd FILL
X_894_ _583_ _581_ _584_ vdd gnd NOR2X1
XFILL_0__947_ gnd vdd FILL
X_1372_ _u_ball.y_ball_[4] _356_ _370_ _348_ vdd gnd OAI21X1
XFILL_0__1412_ gnd vdd FILL
X_1428_ _403_ _402_ _401_ vdd gnd NAND2X1
X_1008_ _491_ vdd _495_ clk_bF$buf2 paddle_h[3] vdd 
+ gnd
+ DFFSR
X_1181_ _165_ _164_ _166_ _215_ _163_ vdd 
+ gnd
+ AOI22X1
XFILL_1__963_ gnd vdd FILL
XFILL_0__1221_ gnd vdd FILL
X_1237_ _u_ball.y_pos_[1] _219_ vdd gnd INVX1
X_988_ load_option_bF$buf3 _443_ _444_ _445_ vdd gnd NAND3X1
XFILL_1__1399_ gnd vdd FILL
XFILL_0__1030_ gnd vdd FILL
X_1466_ _600_ _693_ _597_ _704_ vdd gnd OAI21X1
X_1046_ _417_ vdd _416_ clk_bF$buf7 _u_ball.x_ball_[4] vdd 
+ gnd
+ DFFSR
XFILL_0__794_ gnd vdd FILL
X_797_ _506_ _528_ _38_ _40_ _492_ vdd 
+ gnd
+ OAI22X1
XFILL_0__1506_ gnd vdd FILL
XFILL_1__1420_ gnd vdd FILL
XFILL_1__1000_ gnd vdd FILL
X_1275_ _u_ball.x_ball_[4] _255_ _254_ vdd gnd NOR2X1
XFILL_0__1315_ gnd vdd FILL
X_1084_ _316_ _149_ _69_ vdd gnd NOR2X1
XFILL_1__866_ gnd vdd FILL
XFILL_0__1544_ gnd vdd FILL
XFILL_0__1124_ gnd vdd FILL
XFILL_0__888_ gnd vdd FILL
XFILL_0__1353_ gnd vdd FILL
XFILL_1__1514_ gnd vdd FILL
X_1369_ paddle_v[3] paddle_v[2] _345_ vdd gnd NAND2X1
XFILL_0__1409_ gnd vdd FILL
XFILL_0__1582_ gnd vdd FILL
XFILL_0__1162_ gnd vdd FILL
X_912_ _566_ _563_ _556_ _567_ vdd gnd OAI21X1
XFILL_1__1323_ gnd vdd FILL
X_1598_ _471_ vdd _468_ clk_bF$buf3 _u_ball.x_init_[2] vdd 
+ gnd
+ DFFSR
X_1178_ _u_ball.y_ball_[3] _402_ _399_ _160_ vdd gnd NAND3X1
XFILL_0__1218_ gnd vdd FILL
XFILL_0__1391_ gnd vdd FILL
XFILL_1__1552_ gnd vdd FILL
XFILL_1__1132_ gnd vdd FILL
XFILL83850x79350 gnd vdd FILL
XFILL_1__769_ gnd vdd FILL
XFILL_0__1027_ gnd vdd FILL
X_950_ _765__bF$buf3 _525_ vdd gnd INVX1
XFILL_1__1361_ gnd vdd FILL
XFILL_1__998_ gnd vdd FILL
XFILL_0__1256_ gnd vdd FILL
XFILL_1__1417_ gnd vdd FILL
XFILL_1__1590_ gnd vdd FILL
XFILL_0__1485_ gnd vdd FILL
XFILL_0__1065_ gnd vdd FILL
XFILL_0__812_ gnd vdd FILL
X_815_ _550_ _u_ball.x_pos_[1] _u_ball.x_pos_[0] _25_ vdd gnd AOI21X1
XFILL_0__1294_ gnd vdd FILL
X_1522_ _642_ _647_ _641_ vdd gnd NOR2X1
X_1102_ _93_ _85_ _88_ _84_ vdd gnd NAND3X1
XFILL_0__850_ gnd vdd FILL
X_853_ paddle_v[4] _730_ paddle_v[2] _750_ vdd gnd OAI21X1
XFILL_1__1264_ gnd vdd FILL
XFILL_0__1579_ gnd vdd FILL
XFILL_0__1159_ gnd vdd FILL
XFILL_0__906_ gnd vdd FILL
X_909_ _542_ _569_ _545_ _570_ vdd gnd OAI21X1
X_1331_ _u_ball.x_ball_[2] _309_ vdd gnd INVX2
XFILL_1__1493_ gnd vdd FILL
XFILL_1__1073_ gnd vdd FILL
XFILL_0__1388_ gnd vdd FILL
XFILL_1__1549_ gnd vdd FILL
X_1560_ _693_ _671_ _670_ vdd gnd AND2X2
X_1140_ _272_ _u_ball.x_pos_[3] _176_ _123_ _122_ vdd 
+ gnd
+ AOI22X1
XFILL_1__922_ gnd vdd FILL
X_891_ _579_ _586_ _485_ vdd gnd NAND2X1
XFILL83550x150 gnd vdd FILL
XFILL_0__1197_ gnd vdd FILL
XFILL_0__944_ gnd vdd FILL
X_947_ _500_ _502_ _527_ _528_ vdd gnd OAI21X1
XFILL_1__1358_ gnd vdd FILL
X_1425_ _u_ball.y_ball_[0] _u_ball.y_ball_[1] _398_ vdd gnd NAND2X1
X_1005_ load_option_bF$buf1 _475_ _476_ _467_ vdd gnd OAI21X1
XFILL_1__960_ gnd vdd FILL
XFILL_0__809_ gnd vdd FILL
X_1234_ _217_ _u_ball.y_ball_[0] _u_ball.y_ball_[1] _219_ _216_ vdd 
+ gnd
+ AOI22X1
X_985_ _471_ vdd _467_ clk_bF$buf3 _u_ball.x_init_[1] vdd 
+ gnd
+ DFFSR
X_1463_ _595_ _u_ctrl.State_[1] _u_ctrl.State_3_bF$buf3_ _594_ vdd gnd AOI21X1
X_1043_ _417_ vdd _425_ clk_bF$buf7 _u_ball.x_ball_[0] vdd 
+ gnd
+ DFFSR
XFILL_0__791_ gnd vdd FILL
X_794_ _428_ _418_ _493_ vdd gnd NAND2X1
XFILL_0__1503_ gnd vdd FILL
X_1519_ _u_ctrl.State_[1] _u_ctrl.State_[2] _639_ vdd gnd NOR2X1
XFILL83250x14550 gnd vdd FILL
XFILL_0__847_ gnd vdd FILL
X_1272_ _278_ _274_ _252_ _251_ vdd gnd NAND3X1
XFILL_0__1312_ gnd vdd FILL
X_1328_ _316_ _309_ _306_ vdd gnd NAND2X1
X_1081_ _67_ _66_ vdd gnd INVX1
XFILL_1__863_ gnd vdd FILL
XFILL_0__1541_ gnd vdd FILL
XFILL_0__1121_ gnd vdd FILL
X_1557_ _u_ctrl.State_3_bF$buf0_ _669_ _u_ball.x_pos_[0] _723_ vdd gnd MUX2X1
X_1137_ _130_ _u_ball.x_ball_[4] _u_ball.x_ball_[5] _120_ _119_ vdd 
+ gnd
+ AOI22X1
XFILL_0__885_ gnd vdd FILL
XFILL_1__919_ gnd vdd FILL
X_888_ _513_ _528_ _588_ _587_ _486_ vdd 
+ gnd
+ OAI22X1
XFILL_1__1299_ gnd vdd FILL
XFILL_0__1350_ gnd vdd FILL
XFILL_1__1511_ gnd vdd FILL
XFILL83550x57750 gnd vdd FILL
X_1366_ _360_ _351_ _u_ball.y_ball_[3] _342_ vdd gnd OAI21X1
XFILL_0__1406_ gnd vdd FILL
XFILL_1__1320_ gnd vdd FILL
X_1595_ _u_ball.x_pos_[3] _701_ vdd gnd INVX2
X_1175_ _u_ball.y_ball_[2] _167_ _157_ vdd gnd NOR2X1
XFILL_0__1215_ gnd vdd FILL
XFILL_0__1024_ gnd vdd FILL
XFILL_0__788_ gnd vdd FILL
XFILL83850x10950 gnd vdd FILL
XFILL_1__995_ gnd vdd FILL
XFILL_0__1253_ gnd vdd FILL
X_1269_ _272_ _249_ _248_ vdd gnd NAND2X1
XFILL_0__1309_ gnd vdd FILL
XFILL_0__1482_ gnd vdd FILL
XFILL_0__1062_ gnd vdd FILL
X_812_ _564_ _u_ball.x_pos_[3] _27_ _28_ vdd gnd OAI21X1
XFILL_1__1223_ gnd vdd FILL
X_1498_ _626_ _622_ _625_ _711_ vdd gnd OAI21X1
X_1078_ _u_ball.x_init_[5] _63_ vdd gnd INVX1
XFILL_0__1538_ gnd vdd FILL
XFILL_0__1118_ gnd vdd FILL
XFILL_0__1291_ gnd vdd FILL
XFILL_1__1032_ gnd vdd FILL
XFILL_0__1347_ gnd vdd FILL
XFILL_1__1508_ gnd vdd FILL
X_850_ _738_ paddle_v[1] _513_ _737_ _753_ vdd 
+ gnd
+ AOI22X1
XFILL_1__1261_ gnd vdd FILL
XFILL_1__898_ gnd vdd FILL
XFILL_0__1576_ gnd vdd FILL
XFILL_0__1156_ gnd vdd FILL
XFILL_0__903_ gnd vdd FILL
X_906_ _547_ _544_ paddle_h[4] _573_ vdd gnd OAI21X1
XFILL_1__1317_ gnd vdd FILL
XFILL_1__1490_ gnd vdd FILL
XFILL_1__1070_ gnd vdd FILL
XFILL_0__1385_ gnd vdd FILL
XFILL_0__1194_ gnd vdd FILL
XFILL_0__941_ gnd vdd FILL
X_944_ _530_ _531_ vdd gnd INVX1
X_1422_ _405_ _404_ _396_ _395_ vdd gnd NAND3X1
X_1002_ _475_ _477_ _478_ _468_ vdd gnd OAI21X1
XFILL_1__1164_ gnd vdd FILL
XFILL82650x150 gnd vdd FILL
XFILL_0__1479_ gnd vdd FILL
XFILL_0__1059_ gnd vdd FILL
XFILL_0__806_ gnd vdd FILL
X_809_ _28_ _29_ _30_ _31_ vdd gnd AOI21X1
X_1231_ _u_ball.y_pos_[2] _402_ _213_ vdd gnd NAND2X1
X_982_ _471_ vdd _472_ clk_bF$buf3 _u_ball.x_init_[5] vdd 
+ gnd
+ DFFSR
XFILL_0__1288_ gnd vdd FILL
XFILL_1__1029_ gnd vdd FILL
X_1460_ vdd _712__bF$buf0 _720_ clk_bF$buf5 _u_ball.x_pos_[3] vdd 
+ gnd
+ DFFSR
X_1040_ vdd _417_ _413_ clk_bF$buf0 _u_ball.y_ball_[1] vdd 
+ gnd
+ DFFSR
XFILL_1__822_ gnd vdd FILL
X_791_ _562_ _429_ _431_ vdd gnd NAND2X1
XFILL_0__1500_ gnd vdd FILL
XFILL_0__1097_ gnd vdd FILL
X_1516_ _u_ball.x_pos_[6] _637_ vdd gnd INVX1
XFILL_0__844_ gnd vdd FILL
X_847_ _521_ _748_ _756_ vdd gnd NOR2X1
XFILL_1__1258_ gnd vdd FILL
X_1325_ _u_ball.sign_x_ _u_ball.x_ball_[5] _303_ vdd gnd NOR2X1
XFILL_1__860_ gnd vdd FILL
X_1554_ _u_ball.x_pos_[0] _666_ vdd gnd INVX1
X_1134_ _117_ _118_ _116_ vdd gnd NAND2X1
XFILL_0__882_ gnd vdd FILL
XFILL_1__916_ gnd vdd FILL
X_885_ _516_ _589_ _591_ vdd gnd AND2X2
XFILL_0__938_ gnd vdd FILL
X_1363_ _340_ _341_ _339_ vdd gnd AND2X2
XFILL_0__1403_ gnd vdd FILL
X_1419_ _406_ _393_ _395_ _392_ vdd gnd NAND3X1
X_1592_ _701_ _700_ _699_ _698_ vdd gnd NOR3X1
X_1172_ _u_ball.y_pos_[5] _408_ _154_ vdd gnd NAND2X1
XFILL_0__1212_ gnd vdd FILL
X_1228_ _u_ball.y_pos_[1] _368_ _210_ vdd gnd NAND2X1
XFILL_0__976_ gnd vdd FILL
X_979_ _491_ vdd _487_ clk_bF$buf1 paddle_v[3] vdd 
+ gnd
+ DFFSR
XFILL_0__1021_ gnd vdd FILL
X_1457_ _712__bF$buf3 vdd _711_ clk_bF$buf6 _u_ctrl.cnt_v_sync_[2] vdd 
+ gnd
+ DFFSR
X_1037_ _417_ vdd _421_ clk_bF$buf1 _u_ball.sign_y_ vdd 
+ gnd
+ DFFSR
XFILL_0__785_ gnd vdd FILL
XFILL_1__819_ gnd vdd FILL
X_788_ _563_ _566_ _433_ vdd gnd OR2X2
XFILL_1__1199_ gnd vdd FILL
XFILL_0__1250_ gnd vdd FILL
X_1266_ _u_ball.x_ball_[3] _246_ _255_ _u_ball.x_ball_[4] _245_ vdd 
+ gnd
+ AOI22X1
XFILL_0__1306_ gnd vdd FILL
XFILL_1__1220_ gnd vdd FILL
X_1495_ _621_ _620_ _619_ vdd gnd NAND2X1
X_1075_ _149_ _379_ _61_ _415_ vdd gnd OAI21X1
XFILL_1__857_ gnd vdd FILL
XFILL_0__1535_ gnd vdd FILL
XFILL_0__1115_ gnd vdd FILL
XFILL_0__879_ gnd vdd FILL
XFILL_0__1344_ gnd vdd FILL
XFILL_0__1573_ gnd vdd FILL
XFILL_0__1153_ gnd vdd FILL
XFILL_0__900_ gnd vdd FILL
X_903_ _574_ _567_ _576_ vdd gnd AND2X2
X_1589_ _0_ _696_ _u_ctrl.State_3_bF$buf0_ _695_ vdd gnd OAI21X1
X_1169_ _162_ _159_ _156_ _152_ _151_ vdd 
+ gnd
+ AOI22X1
XFILL_0__1209_ gnd vdd FILL
XFILL_0__1382_ gnd vdd FILL
X_1398_ _u_ball.x_init_[0] _373_ vdd gnd INVX1
XFILL_0__1018_ gnd vdd FILL
XFILL_0__1191_ gnd vdd FILL
X_941_ _532_ _537_ _504_ _519_ _538_ vdd 
+ gnd
+ AOI22X1
XFILL_0__1247_ gnd vdd FILL
XFILL_1__1408_ gnd vdd FILL
XFILL_1__1581_ gnd vdd FILL
XFILL_1__1161_ gnd vdd FILL
XFILL_1__798_ gnd vdd FILL
XFILL_0__1476_ gnd vdd FILL
XFILL_0__1056_ gnd vdd FILL
XFILL_0__803_ gnd vdd FILL
X_806_ _u_ball.y_pos_[4] _u_ball.y_pos_[5] _33_ _34_ vdd gnd NAND3X1
XFILL_1__1217_ gnd vdd FILL
XFILL_1__1390_ gnd vdd FILL
XFILL_0_BUFX2_insert8 gnd vdd FILL
XFILL_0_BUFX2_insert9 gnd vdd FILL
XFILL_0__1285_ gnd vdd FILL
XFILL_1__1026_ gnd vdd FILL
XFILL_0__1094_ gnd vdd FILL
XFILL83850x18150 gnd vdd FILL
X_1513_ _u_ball.x_pos_[0] _u_ball.x_pos_[1] _u_ball.x_pos_[2] _634_ vdd gnd OAI21X1
XFILL_0__841_ gnd vdd FILL
X_844_ _u_ball.x_pos_[6] _759_ vdd gnd INVX1
XFILL_1__1255_ gnd vdd FILL
X_1322_ _u_ball.x_ball_[4] _u_ball.x_ball_[5] _u_ball.sign_x_ _300_ vdd gnd OAI21X1
XFILL_0__1379_ gnd vdd FILL
X_1551_ _668_ _669_ _664_ _u_ctrl.State_3_bF$buf1_ _722_ vdd 
+ gnd
+ AOI22X1
X_1131_ _272_ _114_ _315_ _113_ vdd gnd OAI21X1
X_882_ _498_ _529_ _713_ vdd gnd NAND2X1
XFILL_0__1188_ gnd vdd FILL
XFILL_0__935_ gnd vdd FILL
X_938_ paddle_h[4] _540_ vdd gnd INVX1
XFILL_1__1349_ gnd vdd FILL
X_1360_ _u_ball.x_ball_[0] _336_ vdd gnd INVX4
XFILL_0__1400_ gnd vdd FILL
X_1416_ _390_ _391_ _389_ vdd gnd NAND2X1
XFILL_1__1578_ gnd vdd FILL
XFILL_1__1158_ gnd vdd FILL
X_1225_ _214_ _213_ _207_ vdd gnd NAND2X1
XFILL_0__973_ gnd vdd FILL
X_976_ paddle_v[2] paddle_v[3] _499_ vdd gnd NAND2X1
XFILL_1__1387_ gnd vdd FILL
X_1454_ vdd _712__bF$buf2 _726_ clk_bF$buf5 _u_ball.y_pos_[2] vdd 
+ gnd
+ DFFSR
X_1034_ _491_ vdd _485_ clk_bF$buf5 paddle_h[5] vdd 
+ gnd
+ DFFSR
XFILL_0__782_ gnd vdd FILL
XFILL_1__816_ gnd vdd FILL
X_785_ _564_ _555_ _435_ _495_ vdd gnd OAI21X1
XFILL_1__1196_ gnd vdd FILL
XFILL_0__838_ gnd vdd FILL
X_1263_ _243_ _244_ _259_ _242_ vdd gnd OAI21X1
XFILL_0__1303_ gnd vdd FILL
X_1319_ _u_ball.sign_x_ _u_ball.x_ball_[6] _297_ vdd gnd NAND2X1
X_1492_ _652_ _u_ctrl.State_[0] load_option_bF$buf0 _617_ vdd gnd AOI21X1
X_1072_ _353_ _383_ _59_ _414_ vdd gnd AOI21X1
XFILL_0__1532_ gnd vdd FILL
XFILL_0__1112_ gnd vdd FILL
X_1548_ _699_ _662_ _661_ vdd gnd NAND2X1
X_1128_ _272_ _114_ _111_ _110_ vdd gnd OAI21X1
XFILL_0__876_ gnd vdd FILL
X_879_ _504_ _537_ _532_ _716_ vdd gnd OAI21X1
XFILL_0__1341_ gnd vdd FILL
X_1357_ _336_ _335_ _334_ _333_ vdd gnd OAI21X1
XFILL_1__1099_ gnd vdd FILL
XFILL_0__1570_ gnd vdd FILL
XFILL_0__1150_ gnd vdd FILL
X_900_ _555_ _578_ vdd gnd INVX1
X_1586_ _u_ctrl.State_3_bF$buf2_ _692_ vdd gnd INVX1
X_1166_ _u_ball.x_pos_[6] _148_ vdd gnd INVX1
XFILL_1__948_ gnd vdd FILL
XFILL_0__1206_ gnd vdd FILL
XFILL_1__1540_ gnd vdd FILL
XFILL_1__1120_ gnd vdd FILL
XCLKBUF1_insert0 clk clk_bF$buf7 vdd gnd CLKBUF1
XCLKBUF1_insert1 clk clk_bF$buf6 vdd gnd CLKBUF1
XCLKBUF1_insert2 clk clk_bF$buf5 vdd gnd CLKBUF1
XCLKBUF1_insert3 clk clk_bF$buf4 vdd gnd CLKBUF1
XCLKBUF1_insert4 clk clk_bF$buf3 vdd gnd CLKBUF1
XCLKBUF1_insert5 clk clk_bF$buf2 vdd gnd CLKBUF1
XCLKBUF1_insert6 clk clk_bF$buf1 vdd gnd CLKBUF1
XCLKBUF1_insert7 clk clk_bF$buf0 vdd gnd CLKBUF1
X_1395_ _373_ _372_ _371_ _425_ vdd gnd OAI21X1
XFILL_0__1435_ gnd vdd FILL
XFILL_0__1015_ gnd vdd FILL
XFILL_0__779_ gnd vdd FILL
XFILL_1__986_ gnd vdd FILL
XFILL_0__1244_ gnd vdd FILL
XFILL_1__1405_ gnd vdd FILL
XFILL_0__1473_ gnd vdd FILL
XFILL_0__1053_ gnd vdd FILL
XFILL83850x150 gnd vdd FILL
XFILL_0__800_ gnd vdd FILL
X_803_ _36_ _24_ _2_ pixel_paddle vdd gnd OAI21X1
XFILL_1__1214_ gnd vdd FILL
X_1489_ _695_ _616_ _644_ _615_ vdd gnd NAND3X1
X_1069_ _399_ _57_ _403_ _56_ vdd gnd OAI21X1
XFILL_0__1529_ gnd vdd FILL
XFILL_0__1109_ gnd vdd FILL
XFILL_0__1282_ gnd vdd FILL
X_1298_ _336_ gnd _278_ _277_ vdd gnd NAND3X1
XFILL_0__1338_ gnd vdd FILL
XFILL_0__1091_ gnd vdd FILL
X_1510_ _u_ball.y_pos_[5] _632_ _631_ vdd gnd NOR2X1
X_841_ _497_ _u_ball.y_pos_[5] _761_ _762_ vdd gnd OAI21X1
XFILL83850x72150 gnd vdd FILL
XFILL_1__889_ gnd vdd FILL
XFILL83850x39750 gnd vdd FILL
XFILL_0__1567_ gnd vdd FILL
XFILL_0__1147_ gnd vdd FILL
XFILL_1__1061_ gnd vdd FILL
XFILL_0__1376_ gnd vdd FILL
XFILL_1__1537_ gnd vdd FILL
XFILL_1__1117_ gnd vdd FILL
XFILL_0__1185_ gnd vdd FILL
XFILL_0__932_ gnd vdd FILL
X_935_ paddle_h[2] paddle_h[3] paddle_h[4] _543_ vdd gnd AOI21X1
XFILL_1__1346_ gnd vdd FILL
X_1413_ _395_ _387_ _392_ _386_ vdd gnd OAI21X1
XFILL_1__1575_ gnd vdd FILL
XFILL_1__1155_ gnd vdd FILL
X_1222_ _u_ball.y_pos_[1] _368_ _204_ vdd gnd NOR2X1
XFILL_0__970_ gnd vdd FILL
X_973_ _765__bF$buf3 _501_ _502_ vdd gnd NAND2X1
XFILL_1__1384_ gnd vdd FILL
XFILL_0__1279_ gnd vdd FILL
X_1451_ _712__bF$buf1 vdd _536_ clk_bF$buf6 _u_ctrl.State_[1] vdd 
+ gnd
+ DFFSR
X_1031_ load_option_bF$buf2 _461_ _462_ _463_ vdd gnd NAND3X1
X_782_ _437_ _436_ _438_ vdd gnd NAND2X1
XFILL_0__1088_ gnd vdd FILL
X_1507_ _630_ _629_ _628_ vdd gnd AND2X2
XFILL_0__835_ gnd vdd FILL
X_838_ _747_ _1_ _758_ _2_ vdd gnd NAND3X1
X_1260_ _u_ball.y_ball_[5] _u_ball.y_ball_[4] _239_ vdd gnd NAND2X1
XFILL_0__1300_ gnd vdd FILL
X_1316_ _310_ _294_ vdd gnd INVX1
XFILL_1__1478_ gnd vdd FILL
XFILL_1__1058_ gnd vdd FILL
X_1545_ _660_ _659_ vdd gnd INVX1
X_1125_ _149_ _145_ _107_ vdd gnd NOR2X1
XFILL_0__873_ gnd vdd FILL
XFILL_1__907_ gnd vdd FILL
X_876_ paddle_v[0] _529_ _718_ vdd gnd NAND2X1
XFILL_1__1287_ gnd vdd FILL
XFILL_0__929_ gnd vdd FILL
X_1354_ _354_ _331_ _338_ _330_ vdd gnd NAND3X1
XFILL_1__1096_ gnd vdd FILL
X_1583_ _u_ball.y_pos_[1] _690_ vdd gnd INVX1
X_1163_ _u_ball.x_ball_[3] _u_ball.x_ball_[4] _146_ _145_ vdd gnd NAND3X1
XFILL_1__945_ gnd vdd FILL
XFILL_0__1203_ gnd vdd FILL
X_1219_ _205_ _202_ _201_ vdd gnd NAND2X1
XFILL_0__967_ gnd vdd FILL
X_1392_ _u_ball.y_ball_[1] _368_ vdd gnd INVX2
XFILL82950x79350 gnd vdd FILL
XFILL_0__1432_ gnd vdd FILL
X_1448_ vdd _712__bF$buf0 _727_ clk_bF$buf5 _u_ball.y_pos_[1] vdd 
+ gnd
+ DFFSR
X_1028_ _465_ _463_ _454_ vdd gnd NAND2X1
X_779_ _578_ _440_ paddle_h[6] _441_ vdd gnd OAI21X1

.ends
.end
