/* Verilog module written by vlog2Verilog (qflow) */
/* With explicit power connections */

module bricks_out(
    inout vdd,
    inout gnd,
    input clk,
    input reset,
    output v_sync,
    output pixel,
    output p_tick,
    input btn_left,
    input btn_right,
    output game_over,
    output game_complete,
    input game_new
);

wire _588_ ;
wire _168_ ;
wire _60_ ;
wire _397_ ;
wire \u_ball.sign_x  ;
wire _703_ ;
wire _19_ ;
wire _512_ ;
wire _321_ ;
wire _57_ ;
wire _550_ ;
wire _130_ ;
wire _606_ ;
wire _415_ ;
wire _95_ ;
wire _644_ ;
wire _224_ ;
wire pixel_brick ;
wire _453_ ;
wire _509_ ;
wire _682_ ;
wire _262_ ;
wire _318_ ;
wire _491_ ;
wire _547_ ;
wire _127_ ;
wire _356_ ;
wire btn_right ;
wire _585_ ;
wire _165_ ;
wire _394_ ;
wire _679_ ;
wire _259_ ;
wire _488_ ;
wire _700_ ;
wire _297_ ;
wire _16_ ;
wire _54_ ;
wire _603_ ;
wire _412_ ;
wire _92_ ;
wire _641_ ;
wire _221_ ;
wire _450_ ;
wire _506_ ;
wire _315_ ;
wire _544_ ;
wire _124_ ;
wire _353_ ;
wire _409_ ;
wire _89_ ;
wire _582_ ;
wire _162_ ;
wire _638_ ;
wire _218_ ;
wire _391_ ;
wire _447_ ;
wire _676_ ;
wire _256_ ;
wire _485_ ;
wire _294_ ;
wire _13_ ;
wire _579_ ;
wire _159_ ;
wire _51_ ;
wire _388_ ;
wire _600_ ;
wire _197_ ;
wire _7_ ;
wire _503_ ;
wire _312_ ;
wire _48_ ;
wire _541_ ;
wire _121_ ;
wire _350_ ;
wire _406_ ;
wire _86_ ;
wire _635_ ;
wire _215_ ;
wire _444_ ;
wire _673_ ;
wire _253_ ;
wire _729_ ;
wire _309_ ;
wire _482_ ;
wire _538_ ;
wire _118_ ;
wire _291_ ;
wire _10_ ;
wire _347_ ;
wire _576_ ;
wire _156_ ;
wire _385_ ;
wire pixel ;
wire _194_ ;
wire _479_ ;
wire _288_ ;
wire _4_ ;
wire _500_ ;
wire hit_brick ;
wire _45_ ;
wire _403_ ;
wire _83_ ;
wire _632_ ;
wire _212_ ;
wire _441_ ;
wire _670_ ;
wire _250_ ;
wire _726_ ;
wire _306_ ;
wire _535_ ;
wire _115_ ;
wire _344_ ;
wire _573_ ;
wire _153_ ;
wire _629_ ;
wire _209_ ;
wire _382_ ;
wire _438_ ;
wire _191_ ;
wire _667_ ;
wire _247_ ;
wire _476_ ;
wire clk_bF$buf0 ;
wire clk_bF$buf1 ;
wire clk_bF$buf2 ;
wire clk_bF$buf3 ;
wire clk_bF$buf4 ;
wire clk_bF$buf5 ;
wire clk_bF$buf6 ;
wire clk_bF$buf7 ;
wire _285_ ;
wire _1_ ;
wire _677__bF$buf0 ;
wire _677__bF$buf1 ;
wire _677__bF$buf2 ;
wire _677__bF$buf3 ;
wire _42_ ;
wire _379_ ;
wire _188_ ;
wire _400_ ;
wire _80_ ;
wire _723_ ;
wire _303_ ;
wire [6:0] \u_ball.x_ball  ;
wire _39_ ;
wire _532_ ;
wire _112_ ;
wire _341_ ;
wire clk ;
wire _77_ ;
wire _570_ ;
wire _150_ ;
wire _626_ ;
wire _206_ ;
wire _435_ ;
wire _664_ ;
wire _244_ ;
wire _473_ ;
wire _529_ ;
wire _109_ ;
wire _282_ ;
wire _338_ ;
wire _567_ ;
wire _147_ ;
wire _376_ ;
wire _185_ ;
wire _699_ ;
wire _279_ ;
wire _720_ ;
wire _300_ ;
wire _36_ ;
wire _74_ ;
wire _623_ ;
wire _203_ ;
wire _432_ ;
wire pixel_paddle ;
wire _661_ ;
wire _241_ ;
wire _717_ ;
wire _470_ ;
wire _526_ ;
wire _106_ ;
wire _335_ ;
wire _564_ ;
wire _144_ ;
wire [2:0] \u_ctrl.cnt_v_sync  ;
wire _373_ ;
wire _429_ ;
wire _182_ ;
wire _658_ ;
wire _238_ ;
wire _467_ ;
wire _696_ ;
wire _276_ ;
wire _33_ ;
wire \u_ball.hit_paddle  ;
wire _599_ ;
wire _179_ ;
wire _71_ ;
wire _620_ ;
wire _200_ ;
wire _714_ ;
wire _523_ ;
wire _103_ ;
wire \u_ctrl.State_3_bF$buf3  ;
wire _332_ ;
wire _68_ ;
wire _561_ ;
wire _141_ ;
wire _617_ ;
wire _370_ ;
wire _426_ ;
wire _655_ ;
wire _235_ ;
wire _464_ ;
wire _693_ ;
wire _273_ ;
wire _329_ ;
wire _558_ ;
wire _138_ ;
wire _30_ ;
wire _367_ ;
wire _596_ ;
wire _176_ ;
wire _499_ ;
wire _711_ ;
wire _27_ ;
wire _520_ ;
wire _100_ ;
wire \u_ctrl.State_3_bF$buf0  ;
wire _65_ ;
wire _614_ ;
wire _423_ ;
wire _652_ ;
wire _232_ ;
wire _708_ ;
wire _461_ ;
wire _517_ ;
wire _690_ ;
wire _270_ ;
wire _326_ ;
wire _555_ ;
wire _135_ ;
wire _364_ ;
wire _593_ ;
wire _173_ ;
wire _649_ ;
wire _229_ ;
wire _458_ ;
wire _687_ ;
wire _267_ ;
wire _496_ ;
wire _24_ ;
wire _62_ ;
wire _399_ ;
wire _611_ ;
wire _420_ ;
wire _705_ ;
wire _514_ ;
wire _323_ ;
wire _59_ ;
wire _552_ ;
wire _132_ ;
wire _608_ ;
wire _361_ ;
wire _417_ ;
wire _97_ ;
wire _590_ ;
wire _170_ ;
wire _646_ ;
wire _226_ ;
wire _455_ ;
wire _684_ ;
wire _264_ ;
wire _493_ ;
wire _549_ ;
wire _129_ ;
wire _21_ ;
wire _358_ ;
wire _587_ ;
wire _167_ ;
wire _396_ ;
wire \u_ball.x2  ;
wire _702_ ;
wire _299_ ;
wire _18_ ;
wire _511_ ;
wire _320_ ;
wire _56_ ;
wire _605_ ;
wire _414_ ;
wire _94_ ;
wire _643_ ;
wire _223_ ;
wire _452_ ;
wire _508_ ;
wire _681_ ;
wire _261_ ;
wire _317_ ;
wire _490_ ;
wire _546_ ;
wire _126_ ;
wire _355_ ;
wire game_over ;
wire _584_ ;
wire _164_ ;
wire _393_ ;
wire _449_ ;
wire _678_ ;
wire _258_ ;
wire _487_ ;
wire _296_ ;
wire _15_ ;
wire _53_ ;
wire _602_ ;
wire _199_ ;
wire _411_ ;
wire _91_ ;
wire _640_ ;
wire _220_ ;
wire _9_ ;
wire _505_ ;
wire _314_ ;
wire _543_ ;
wire _123_ ;
wire _352_ ;
wire _408_ ;
wire _88_ ;
wire _581_ ;
wire _161_ ;
wire _637_ ;
wire _217_ ;
wire _390_ ;
wire _446_ ;
wire _675_ ;
wire _255_ ;
wire _484_ ;
wire _293_ ;
wire _12_ ;
wire _349_ ;
wire _578_ ;
wire _158_ ;
wire _50_ ;
wire _387_ ;
wire _196_ ;
wire _6_ ;
wire _502_ ;
wire _311_ ;
wire _47_ ;
wire _540_ ;
wire _120_ ;
wire [6:1] \u_ball.x_paddle  ;
wire _405_ ;
wire _85_ ;
wire _634_ ;
wire _214_ ;
wire _443_ ;
wire _672_ ;
wire _252_ ;
wire _728_ ;
wire _308_ ;
wire _481_ ;
wire _537_ ;
wire _117_ ;
wire _290_ ;
wire _346_ ;
wire _575_ ;
wire _155_ ;
wire _384_ ;
wire _193_ ;
wire _669_ ;
wire _249_ ;
wire _478_ ;
wire _287_ ;
wire _3_ ;
wire game_complete ;
wire _44_ ;
wire _402_ ;
wire _82_ ;
wire _631_ ;
wire _211_ ;
wire _440_ ;
wire _725_ ;
wire _305_ ;
wire _534_ ;
wire _114_ ;
wire _343_ ;
wire _79_ ;
wire _572_ ;
wire _152_ ;
wire _628_ ;
wire _208_ ;
wire _381_ ;
wire [5:0] \u_ball.y_pos  ;
wire _437_ ;
wire _190_ ;
wire _666_ ;
wire _246_ ;
wire pixel_ball ;
wire _475_ ;
wire _284_ ;
wire _0_ ;
wire v_sync ;
wire _569_ ;
wire _149_ ;
wire _41_ ;
wire _378_ ;
wire _187_ ;
wire _722_ ;
wire _302_ ;
wire _38_ ;
wire _531_ ;
wire _111_ ;
wire _340_ ;
wire _76_ ;
wire _625_ ;
wire _205_ ;
wire _434_ ;
wire _663_ ;
wire _243_ ;
wire _719_ ;
wire _472_ ;
wire _528_ ;
wire _108_ ;
wire _281_ ;
wire _337_ ;
wire _566_ ;
wire _146_ ;
wire _375_ ;
wire _184_ ;
wire _469_ ;
wire _698_ ;
wire _278_ ;
wire _35_ ;
wire _73_ ;
wire _622_ ;
wire _202_ ;
wire _431_ ;
wire _660_ ;
wire _240_ ;
wire _716_ ;
wire _525_ ;
wire _105_ ;
wire _334_ ;
wire _563_ ;
wire _143_ ;
wire _619_ ;
wire _372_ ;
wire _428_ ;
wire _181_ ;
wire _657_ ;
wire _237_ ;
wire _466_ ;
wire _695_ ;
wire _275_ ;
wire _32_ ;
wire _369_ ;
wire _598_ ;
wire _178_ ;
wire _70_ ;
wire _713_ ;
wire _29_ ;
wire _522_ ;
wire _102_ ;
wire \u_ctrl.State_3_bF$buf2  ;
wire _331_ ;
wire _67_ ;
wire _560_ ;
wire _140_ ;
wire _616_ ;
wire _425_ ;
wire _654_ ;
wire _234_ ;
wire _463_ ;
wire _519_ ;
wire _692_ ;
wire _272_ ;
wire game_init ;
wire _328_ ;
wire _557_ ;
wire _137_ ;
wire [4:0] \u_ctrl.State  ;
wire _366_ ;
wire _595_ ;
wire _175_ ;
wire _689_ ;
wire _269_ ;
wire _498_ ;
wire _710_ ;
wire _26_ ;
wire _64_ ;
wire _613_ ;
wire _422_ ;
wire _651_ ;
wire _231_ ;
wire _707_ ;
wire _460_ ;
wire _516_ ;
wire [5:0] \u_ball.y_ball  ;
wire _325_ ;
wire _554_ ;
wire _134_ ;
wire _363_ ;
wire _419_ ;
wire _99_ ;
wire _592_ ;
wire _172_ ;
wire _648_ ;
wire _228_ ;
wire _457_ ;
wire _686_ ;
wire _266_ ;
wire _495_ ;
wire _23_ ;
wire _589_ ;
wire _169_ ;
wire _61_ ;
wire _398_ ;
wire _610_ ;
wire \u_ball.sign_y  ;
wire _704_ ;
wire _513_ ;
wire _322_ ;
wire _58_ ;
wire _551_ ;
wire _131_ ;
wire _607_ ;
wire _360_ ;
wire _416_ ;
wire _96_ ;
wire _645_ ;
wire _225_ ;
wire game_new ;
wire _454_ ;
wire _683_ ;
wire _263_ ;
wire _319_ ;
wire _492_ ;
wire _548_ ;
wire _128_ ;
wire _20_ ;
wire _357_ ;
wire _586_ ;
wire _166_ ;
wire _395_ ;
wire _489_ ;
wire _701_ ;
wire _298_ ;
wire _17_ ;
wire _510_ ;
wire _55_ ;
wire _604_ ;
wire _413_ ;
wire _93_ ;
wire _642_ ;
wire _222_ ;
wire _451_ ;
wire _507_ ;
wire _680_ ;
wire _260_ ;
wire _316_ ;
wire _545_ ;
wire _125_ ;
wire _354_ ;
wire _583_ ;
wire _163_ ;
wire _639_ ;
wire _219_ ;
wire _392_ ;
wire _448_ ;
wire _677_ ;
wire _257_ ;
wire _486_ ;
wire _295_ ;
wire _14_ ;
wire _52_ ;
wire _389_ ;
wire _601_ ;
wire _198_ ;
wire _410_ ;
wire _90_ ;
wire _8_ ;
wire _504_ ;
wire _313_ ;
wire _49_ ;
wire _542_ ;
wire _122_ ;
wire _351_ ;
wire _407_ ;
wire _87_ ;
wire _580_ ;
wire _160_ ;
wire _636_ ;
wire _216_ ;
wire _445_ ;
wire btn_left ;
wire _674_ ;
wire _254_ ;
wire _483_ ;
wire _539_ ;
wire _119_ ;
wire _292_ ;
wire _11_ ;
wire _348_ ;
wire _577_ ;
wire _157_ ;
wire _386_ ;
wire _195_ ;
wire _289_ ;
wire _5_ ;
wire _501_ ;
wire _730_ ;
wire _310_ ;
wire _46_ ;
wire _404_ ;
wire _84_ ;
wire _633_ ;
wire _213_ ;
wire _442_ ;
wire _671_ ;
wire _251_ ;
wire _727_ ;
wire _307_ ;
wire _480_ ;
wire _536_ ;
wire _116_ ;
wire _345_ ;
wire _574_ ;
wire _154_ ;
wire _383_ ;
wire _439_ ;
wire _192_ ;
wire _668_ ;
wire _248_ ;
wire _477_ ;
wire _286_ ;
wire _2_ ;
wire _43_ ;
wire _189_ ;
wire _401_ ;
wire _81_ ;
wire _630_ ;
wire _210_ ;
wire _724_ ;
wire _304_ ;
wire _533_ ;
wire _113_ ;
wire _342_ ;
wire _476__bF$buf0 ;
wire _476__bF$buf1 ;
wire _78_ ;
wire _476__bF$buf2 ;
wire _476__bF$buf3 ;
wire _571_ ;
wire _151_ ;
wire [6:0] \u_ball.x_pos  ;
wire _627_ ;
wire _207_ ;
wire _380_ ;
wire _436_ ;
wire _665_ ;
wire _245_ ;
wire _474_ ;
wire _283_ ;
wire _339_ ;
wire _568_ ;
wire _148_ ;
wire _40_ ;
wire _377_ ;
wire _186_ ;
wire _721_ ;
wire _301_ ;
wire _37_ ;
wire _530_ ;
wire _110_ ;
wire _75_ ;
wire _624_ ;
wire _204_ ;
wire _433_ ;
wire _662_ ;
wire _242_ ;
wire _718_ ;
wire _471_ ;
wire _527_ ;
wire _107_ ;
wire _280_ ;
wire _336_ ;
wire _565_ ;
wire _145_ ;
wire _374_ ;
wire _183_ ;
wire _659_ ;
wire _239_ ;
wire _468_ ;
wire _697_ ;
wire _277_ ;
wire _34_ ;
wire _72_ ;
wire _621_ ;
wire _201_ ;
wire _430_ ;
wire _715_ ;
wire _524_ ;
wire _104_ ;
wire _333_ ;
wire _69_ ;
wire _562_ ;
wire _142_ ;
wire _618_ ;
wire _371_ ;
wire _427_ ;
wire _180_ ;
wire _656_ ;
wire _236_ ;
wire _465_ ;
wire _694_ ;
wire _274_ ;
wire _559_ ;
wire _139_ ;
wire _31_ ;
wire _368_ ;
wire _597_ ;
wire _177_ ;
wire _712_ ;
wire _28_ ;
wire _521_ ;
wire _101_ ;
wire \u_ctrl.State_3_bF$buf1  ;
wire _330_ ;
wire _66_ ;
wire _615_ ;
wire _424_ ;
wire _653_ ;
wire _233_ ;
wire _709_ ;
wire _462_ ;
wire _518_ ;
wire _691_ ;
wire _271_ ;
wire p_tick ;
wire _327_ ;
wire _556_ ;
wire _136_ ;
wire _365_ ;
wire _594_ ;
wire _174_ ;
wire _459_ ;
wire _688_ ;
wire _268_ ;
wire _497_ ;
wire _25_ ;
wire _63_ ;
wire [15:0] \u_bricks.regBricks  ;
wire _612_ ;
wire reset ;
wire _421_ ;
wire _650_ ;
wire _230_ ;
wire _706_ ;
wire _515_ ;
wire _324_ ;
wire _553_ ;
wire _133_ ;
wire _609_ ;
wire _362_ ;
wire _418_ ;
wire _98_ ;
wire _591_ ;
wire _171_ ;
wire _647_ ;
wire _227_ ;
wire _456_ ;
wire _685_ ;
wire _265_ ;
wire _494_ ;
wire _22_ ;
wire _359_ ;

FILL FILL_0__1241_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1402_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _1257_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_422_),
    .B(_408_),
    .C(_326_),
    .Y(_325_)
);

OAI22X1 _800_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_533_),
    .B(_714_),
    .C(_716_),
    .D(_713_),
    .Y(_717_)
);

AOI21X1 _1486_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_656_),
    .B(\u_ctrl.State_3_bF$buf0 ),
    .C(_633_),
    .Y(_632_)
);

NAND2X1 _1066_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [3]),
    .B(_321_),
    .Y(_299_)
);

FILL FILL_0__1106_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL77850x3750 (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1295_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [0]),
    .Y(_360_)
);

FILL FILL_0__1335_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1144_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1373_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1389_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_677__bF$buf0),
    .S(vdd),
    .D(_691_),
    .CLK(clk_bF$buf7),
    .Q(game_init)
);

FILL FILL_0__1429_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1009_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1182_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _932_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.sign_y ),
    .B(_60_),
    .Y(_58_)
);

FILL FILL77550x61350 (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _1198_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_127_),
    .B(_168_),
    .C(\u_ball.x_pos [6]),
    .Y(_126_)
);

NAND2X1 _1410_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State_3_bF$buf3 ),
    .B(_657_),
    .Y(_576_)
);

DFFSR _741_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_476__bF$buf2),
    .S(vdd),
    .D(_472_),
    .CLK(clk_bF$buf1),
    .Q(\u_ball.x_ball [6])
);

FILL FILL_0__1467_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1047_ (
    .gnd(gnd),
    .vdd(vdd)
);

AND2X2 _970_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_209_),
    .B(_206_),
    .Y(_205_)
);

FILL FILL_0__1276_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1085_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1504_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_649_),
    .Y(_648_)
);

NOR2X1 _835_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_556_),
    .B(_558_),
    .Y(_559_)
);

NAND2X1 _1313_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [2]),
    .B(_379_),
    .Y(_378_)
);

DFFSR _1122_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_176_),
    .D(_171_),
    .CLK(clk_bF$buf6),
    .Q(\u_bricks.regBricks [10])
);

AOI21X1 _873_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_38_),
    .B(_34_),
    .C(_516_),
    .Y(_518_)
);

FILL FILL_0__926_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _929_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_63_),
    .B(_57_),
    .C(_56_),
    .Y(_55_)
);

NAND2X1 _1351_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [2]),
    .B(_431_),
    .Y(_412_)
);

OAI21X1 _1407_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [5]),
    .B(_576_),
    .C(_574_),
    .Y(_670_)
);

FILL FILL_0__735_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _738_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_476__bF$buf0),
    .S(vdd),
    .D(_471_),
    .CLK(clk_bF$buf2),
    .Q(_726_)
);

FILL FILL_1__1149_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1160_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_bricks.regBricks [8]),
    .B(\u_bricks.regBricks [14]),
    .Y(_89_)
);

FILL FILL_0__1200_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1216_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_bricks.regBricks [2]),
    .Y(_140_)
);

FILL FILL_0__964_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX2 _967_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [0]),
    .Y(_203_)
);

INVX1 _1445_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State [0]),
    .Y(_599_)
);

NAND3X1 _1025_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [5]),
    .B(\u_ball.x_ball [4]),
    .C(_259_),
    .Y(_258_)
);

FILL FILL_0__773_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _776_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_467_),
    .B(_313_),
    .Y(_11_)
);

FILL FILL_1__980_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__829_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1254_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_437_),
    .S(vdd),
    .D(_439_),
    .CLK(clk_bF$buf0),
    .Q(\u_ball.x_paddle [1])
);

INVX1 _1483_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [1]),
    .Y(_630_)
);

NAND3X1 _1063_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_297_),
    .B(_319_),
    .C(_320_),
    .Y(_296_)
);

FILL FILL_0__1523_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1103_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1119_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_176_),
    .D(_182_),
    .CLK(clk_bF$buf6),
    .Q(\u_bricks.regBricks [2])
);

FILL FILL_0__867_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _1292_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_366_),
    .B(_358_),
    .C(_365_),
    .Y(_357_)
);

FILL FILL_0__1332_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _1348_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_426_),
    .B(_416_),
    .C(_415_),
    .Y(_409_)
);

FILL FILL_1__883_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1157_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_bricks.regBricks [5]),
    .Y(_86_)
);

DFFSR _1386_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_677__bF$buf2),
    .D(_672_),
    .CLK(clk_bF$buf2),
    .Q(\u_ball.x_pos [3])
);

FILL FILL_0__1426_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1195_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_bricks.regBricks [11]),
    .B(\u_ball.x_pos [3]),
    .Y(_123_)
);

FILL FILL_1__977_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__786_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1464_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1289_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [5]),
    .Y(_354_)
);

OAI21X1 _1501_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_647_),
    .B(_648_),
    .C(_646_),
    .Y(_645_)
);

NAND2X1 _832_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_561_),
    .B(_542_),
    .Y(_562_)
);

FILL FILL_1__1243_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1098_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_449_),
    .B(_450_),
    .Y(_448_)
);

INVX1 _1310_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [3]),
    .Y(_375_)
);

FILL FILL_1__1108_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__901_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL77550x14550 (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _870_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_522_),
    .B(_514_),
    .Y(_523_)
);

FILL FILL_1__1281_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1176_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__923_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI22X1 _926_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_60_),
    .B(_235_),
    .C(_53_),
    .D(_55_),
    .Y(_481_)
);

FILL FILL_1__1090_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1404_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.cnt_v_sync [0]),
    .Y(_571_)
);

BUFX2 _735_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_0_),
    .Y(game_complete)
);

FILL FILL_1__1146_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1213_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_bricks.regBricks [7]),
    .Y(_138_)
);

INVX1 _964_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [1]),
    .Y(_201_)
);

OAI21X1 _1442_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_636_),
    .B(_600_),
    .C(_598_),
    .Y(_517_)
);

AND2X2 _1022_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_257_),
    .B(_256_),
    .Y(_255_)
);

FILL FILL_0__770_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__804_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _773_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_13_),
    .B(_10_),
    .Y(_14_)
);

FILL FILL_0__1079_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__826_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _829_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_523_),
    .B(_48_),
    .C(_508_),
    .Y(_566_)
);

DFFSR _1251_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_437_),
    .S(vdd),
    .D(_442_),
    .CLK(clk_bF$buf1),
    .Q(\u_ball.x_paddle [6])
);

NOR2X1 _1307_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_374_),
    .B(_373_),
    .Y(_372_)
);

OAI21X1 _1480_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_628_),
    .B(_629_),
    .C(\u_ctrl.State_3_bF$buf2 ),
    .Y(_627_)
);

NAND3X1 _1060_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_312_),
    .B(_308_),
    .C(_294_),
    .Y(_293_)
);

INVX1 _1116_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.hit_paddle ),
    .Y(_466_)
);

NAND2X1 _867_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [1]),
    .B(_501_),
    .Y(_526_)
);

FILL FILL_1__1278_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1345_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_421_),
    .B(_431_),
    .Y(_406_)
);

NAND3X1 _1154_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_86_),
    .B(_85_),
    .C(_84_),
    .Y(_83_)
);

DFFSR _1383_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_677__bF$buf2),
    .D(_687_),
    .CLK(clk_bF$buf5),
    .Q(\u_ball.x_pos [6])
);

NAND2X1 _1439_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State [1]),
    .B(_663_),
    .Y(_595_)
);

AOI21X1 _1019_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_263_),
    .B(_465_),
    .C(_253_),
    .Y(_252_)
);

OAI21X1 _1192_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_154_),
    .B(_129_),
    .C(_121_),
    .Y(_120_)
);

FILL FILL_0__1232_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1248_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [4]),
    .Y(_167_)
);

FILL FILL_0__996_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _999_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(game_init),
    .B(\u_ball.hit_paddle ),
    .C(_234_),
    .Y(_233_)
);

INVX1 _1477_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [2]),
    .Y(_625_)
);

NOR3X1 _1057_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_460_),
    .B(_459_),
    .C(_291_),
    .Y(_290_)
);

FILL FILL78450x7350 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1431_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1011_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL78450x10950 (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1286_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [6]),
    .B(_352_),
    .Y(_351_)
);

FILL FILL_0__1326_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0_CLKBUF1_insert10 (
    .gnd(gnd),
    .vdd(vdd)
);

OR2X2 _1095_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [1]),
    .B(\u_ball.x_paddle [1]),
    .Y(_445_)
);

FILL FILL_0__1135_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__899_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1364_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1525_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1173_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI22X1 _923_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_444_),
    .B(_51_),
    .C(_227_),
    .D(_202_),
    .Y(_480_)
);

NAND2X1 _1189_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_bricks.regBricks [6]),
    .B(_133_),
    .Y(_117_)
);

FILL FILL_0__1229_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI22X1 _1401_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_572_),
    .B(_569_),
    .C(_592_),
    .D(_573_),
    .Y(_669_)
);

BUFX2 _732_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_728_),
    .Y(pixel)
);

FILL FILL_0__1458_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1038_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1210_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_160_),
    .B(_152_),
    .Y(_136_)
);

NOR2X1 _961_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [1]),
    .B(\u_ball.sign_y ),
    .Y(_198_)
);

FILL FILL_0__1267_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _770_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_15_),
    .B(_16_),
    .C(_9_),
    .Y(_17_)
);

FILL FILL_0__1496_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1076_ (
    .gnd(gnd),
    .vdd(vdd)
);

AND2X2 _826_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_679_),
    .B(_530_),
    .Y(_681_)
);

OAI21X1 _1304_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_413_),
    .B(\u_ball.x_pos [1]),
    .C(_370_),
    .Y(_369_)
);

NAND3X1 _1113_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [1]),
    .B(\u_ball.x_paddle [2]),
    .C(\u_ball.x_paddle [3]),
    .Y(_463_)
);

AOI21X1 _864_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_526_),
    .B(_506_),
    .C(_50_),
    .Y(_529_)
);

FILL FILL_0__917_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1342_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_420_),
    .B(_407_),
    .C(_404_),
    .Y(_403_)
);

FILL FILL_0__1399_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _1151_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_135_),
    .B(_82_),
    .C(_81_),
    .Y(_80_)
);

AOI21X1 _1207_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_144_),
    .B(_141_),
    .C(_135_),
    .Y(_179_)
);

FILL FILL_0__955_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _958_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [0]),
    .B(_197_),
    .C(_196_),
    .Y(_195_)
);

DFFSR _1380_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_677__bF$buf3),
    .S(vdd),
    .D(_669_),
    .CLK(clk_bF$buf2),
    .Q(\u_ctrl.cnt_v_sync [1])
);

FILL FILL_0__1420_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1000_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1436_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State [1]),
    .B(\u_ctrl.State [2]),
    .C(_597_),
    .Y(_594_)
);

OAI22X1 _1016_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [6]),
    .B(_268_),
    .C(_457_),
    .D(_314_),
    .Y(_249_)
);

FILL FILL_0__764_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _767_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_726_),
    .Y(_19_)
);

FILL FILL_1__1178_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1245_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [6]),
    .Y(_164_)
);

FILL FILL_0__993_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _996_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(game_init),
    .B(_231_),
    .Y(_230_)
);

OAI21X1 _1474_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_624_),
    .B(_623_),
    .C(\u_ctrl.State_3_bF$buf2 ),
    .Y(_622_)
);

NOR2X1 _1054_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_290_),
    .B(_288_),
    .Y(_287_)
);

FILL FILL_1__836_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1514_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__858_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _1283_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_419_),
    .B(_353_),
    .C(_349_),
    .Y(_348_)
);

FILL FILL_0__1323_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1339_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_420_),
    .Y(_400_)
);

AOI21X1 _1092_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_443_),
    .B(_445_),
    .C(_446_),
    .Y(_438_)
);

INVX4 _1148_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(reset),
    .Y(_176_)
);

FILL FILL_0__896_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _899_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [1]),
    .B(_47_),
    .C(_44_),
    .Y(_490_)
);

FILL FILL78150x43350 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1361_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1377_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_677__bF$buf3),
    .S(vdd),
    .D(_520_),
    .CLK(clk_bF$buf7),
    .Q(\u_ctrl.State [1])
);

FILL FILL_0__1417_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _920_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_49_),
    .B(_50_),
    .Y(_48_)
);

INVX1 _1186_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [6]),
    .Y(_114_)
);

FILL FILL_0__820_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _823_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_444_),
    .B(_226_),
    .C(_451_),
    .Y(_694_)
);

NAND3X1 _1089_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_452_),
    .B(_323_),
    .C(_324_),
    .Y(_322_)
);

NAND2X1 _1301_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_371_),
    .B(_367_),
    .Y(_366_)
);

FILL FILL_1__1043_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1530_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_437_),
    .S(vdd),
    .D(_435_),
    .CLK(clk_bF$buf6),
    .Q(\u_ball.x_paddle [3])
);

INVX2 _1110_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [4]),
    .Y(_460_)
);

INVX1 _861_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [6]),
    .Y(_533_)
);

FILL FILL78450x18150 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1167_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__914_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _917_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [0]),
    .Y(_45_)
);

FILL FILL_1__1328_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__930_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX2 _1204_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [4]),
    .Y(_132_)
);

FILL FILL_0__952_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _955_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [2]),
    .Y(_193_)
);

OAI21X1 _1433_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_666_),
    .B(_648_),
    .C(_633_),
    .Y(_593_)
);

INVX1 _1013_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_270_),
    .Y(_246_)
);

FILL FILL_0__761_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _764_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [4]),
    .B(\u_ball.y_ball [5]),
    .C(_21_),
    .Y(_22_)
);

AOI21X1 _1242_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_165_),
    .B(_162_),
    .C(_168_),
    .Y(_187_)
);

NAND3X1 _993_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.sign_x ),
    .B(\u_ball.x_ball [1]),
    .C(_236_),
    .Y(_228_)
);

FILL FILL_0__1299_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1471_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [6]),
    .Y(_620_)
);

NAND2X1 _1051_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [2]),
    .B(_448_),
    .Y(_284_)
);

FILL FILL_1__833_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _1527_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_720_),
    .B(_721_),
    .C(_722_),
    .Y(_728_)
);

AOI21X1 _1107_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_461_),
    .B(_458_),
    .C(_464_),
    .Y(_457_)
);

OAI22X1 _858_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [3]),
    .B(_456_),
    .C(_297_),
    .D(\u_ball.x_pos [4]),
    .Y(_536_)
);

OAI21X1 _1280_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_421_),
    .B(\u_ball.x_pos [5]),
    .C(_351_),
    .Y(_345_)
);

AOI22X1 _1336_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_419_),
    .B(_426_),
    .C(_399_),
    .D(_417_),
    .Y(_397_)
);

AOI21X1 _1145_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_77_),
    .B(_162_),
    .C(_78_),
    .Y(_175_)
);

INVX1 _896_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_33_),
    .Y(_493_)
);

FILL FILL78150x64950 (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1374_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_476__bF$buf1),
    .S(vdd),
    .D(_565_),
    .CLK(clk_bF$buf1),
    .Q(\u_ball.hit_paddle )
);

NAND3X1 _1183_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_bricks.regBricks [5]),
    .B(\u_ball.x_pos [3]),
    .C(_112_),
    .Y(_111_)
);

FILL FILL_0__1223_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1239_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [3]),
    .B(\u_ball.x_ball [4]),
    .Y(_159_)
);

FILL FILL_0__987_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1468_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_619_),
    .B(_618_),
    .C(_620_),
    .Y(_617_)
);

NAND2X1 _1048_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [3]),
    .B(_282_),
    .Y(_281_)
);

AOI22X1 _799_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_678_),
    .B(_681_),
    .C(_257_),
    .D(_717_),
    .Y(_718_)
);

AOI21X1 _1277_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_347_),
    .B(_346_),
    .C(_343_),
    .Y(_342_)
);

FILL FILL_0__1317_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1070_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _820_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [0]),
    .B(\u_ball.x_ball [1]),
    .C(_451_),
    .Y(_697_)
);

OAI21X1 _1086_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_455_),
    .B(_454_),
    .C(_460_),
    .Y(_319_)
);

FILL FILL_1__1460_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1040_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1355_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1164_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _914_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [2]),
    .Y(_42_)
);

FILL FILL78450x72150 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL78450x39750 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1449_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1029_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1201_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_133_),
    .B(_132_),
    .Y(_129_)
);

NOR2X1 _952_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [2]),
    .B(\u_ball.sign_y ),
    .Y(_190_)
);

FILL FILL_0__1258_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1430_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_665_),
    .B(_591_),
    .C(_595_),
    .Y(_590_)
);

OAI21X1 _1010_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_244_),
    .B(_245_),
    .C(_264_),
    .Y(_243_)
);

NAND3X1 _761_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_63_),
    .B(_58_),
    .C(_56_),
    .Y(_24_)
);

FILL FILL_0__1487_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1067_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _817_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_696_),
    .B(_699_),
    .Y(_700_)
);

OAI21X1 _990_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x2 ),
    .B(_467_),
    .C(_226_),
    .Y(_225_)
);

FILL FILL_0__1296_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1524_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(pixel_ball),
    .Y(_720_)
);

NAND2X1 _1104_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [1]),
    .B(\u_ball.x_paddle [2]),
    .Y(_454_)
);

OAI22X1 _855_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [5]),
    .B(_464_),
    .C(_313_),
    .D(\u_ball.x_pos [6]),
    .Y(_539_)
);

FILL FILL_0__908_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1333_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_402_),
    .B(_395_),
    .Y(_442_)
);

OR2X2 _1142_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_166_),
    .B(_160_),
    .Y(_75_)
);

FILL FILL_0__890_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _893_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_48_),
    .B(_495_),
    .C(_492_),
    .Y(_496_)
);

FILL FILL_0__946_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _949_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_188_),
    .Y(_178_)
);

INVX1 _1371_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(btn_right),
    .Y(_432_)
);

FILL FILL_0__1411_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1427_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_592_),
    .B(_589_),
    .C(_588_),
    .Y(_676_)
);

INVX1 _1007_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_465_),
    .Y(_240_)
);

FILL FILL_0__755_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _758_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [5]),
    .B(_25_),
    .C(_26_),
    .Y(_470_)
);

NAND2X1 _1180_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_bricks.regBricks [14]),
    .B(_133_),
    .Y(_108_)
);

FILL FILL_1__962_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1236_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [6]),
    .B(_163_),
    .Y(_156_)
);

FILL FILL_0__984_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _987_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.sign_x ),
    .B(_451_),
    .Y(_222_)
);

NOR2X1 _1465_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [3]),
    .B(_624_),
    .Y(_615_)
);

OAI21X1 _1045_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [2]),
    .B(_448_),
    .C(_279_),
    .Y(_278_)
);

FILL FILL_0__793_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _796_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(pixel_brick),
    .B(_563_),
    .C(_718_),
    .Y(_723_)
);

FILL FILL_0__1505_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__849_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1274_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_348_),
    .B(_342_),
    .C(_340_),
    .Y(_339_)
);

FILL FILL_0__1314_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _1083_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_464_),
    .B(_458_),
    .C(_461_),
    .Y(_316_)
);

FILL FILL_1__865_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1139_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_75_),
    .Y(_73_)
);

FILL FILL_0__887_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1368_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [5]),
    .B(\u_ball.x_paddle [1]),
    .Y(_429_)
);

FILL FILL_0__1408_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _911_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_46_),
    .B(_44_),
    .C(_40_),
    .Y(_39_)
);

NAND3X1 _1177_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_bricks.regBricks [13]),
    .B(\u_ball.x_pos [3]),
    .C(_132_),
    .Y(_105_)
);

FILL FILL_1__959_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__768_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1446_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__811_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _814_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_701_),
    .B(_702_),
    .Y(_703_)
);

FILL FILL_1__1225_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1521_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.cnt_v_sync [0]),
    .B(\u_ctrl.cnt_v_sync [1]),
    .Y(_665_)
);

INVX2 _1101_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [2]),
    .Y(_451_)
);

FILL FILL78450x25350 (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _852_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [6]),
    .B(_533_),
    .C(_541_),
    .Y(_542_)
);

FILL FILL_1__1263_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1158_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__905_ (
    .gnd(gnd),
    .vdd(vdd)
);

AND2X2 _908_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_43_),
    .B(_41_),
    .Y(_36_)
);

NAND2X1 _1330_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_394_),
    .B(_399_),
    .Y(_392_)
);

FILL FILL_1__1492_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1072_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _890_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [2]),
    .Y(_499_)
);

FILL FILL_0__1196_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _946_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_177_),
    .B(_178_),
    .C(_71_),
    .Y(_483_)
);

FILL FILL_1__1357_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _1424_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_587_),
    .B(_647_),
    .C(_586_),
    .Y(_675_)
);

NAND3X1 _1004_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_242_),
    .B(_241_),
    .C(_238_),
    .Y(_237_)
);

FILL FILL_0__752_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _755_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.sign_y ),
    .B(_232_),
    .C(_52_),
    .Y(_29_)
);

FILL FILL_0__808_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1233_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_bricks.regBricks [8]),
    .Y(_154_)
);

NAND2X1 _984_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_220_),
    .B(_223_),
    .Y(_219_)
);

OAI21X1 _1462_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_655_),
    .B(_632_),
    .C(_613_),
    .Y(_686_)
);

OR2X2 _1042_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_291_),
    .B(_460_),
    .Y(_275_)
);

FILL FILL_0__790_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _793_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_724_),
    .B(_466_),
    .C(_234_),
    .Y(_565_)
);

FILL FILL_0__1099_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1518_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_666_),
    .B(_663_),
    .Y(_662_)
);

NAND2X1 _849_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [3]),
    .B(_70_),
    .Y(_545_)
);

NAND2X1 _1271_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [4]),
    .B(_419_),
    .Y(_336_)
);

OAI21X1 _1327_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_400_),
    .B(_406_),
    .C(_397_),
    .Y(_390_)
);

FILL FILL_1__1489_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX2 _1080_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [6]),
    .Y(_313_)
);

AOI21X1 _1136_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_151_),
    .B(_162_),
    .C(_85_),
    .Y(_170_)
);

OAI22X1 _887_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [0]),
    .B(_444_),
    .C(_226_),
    .D(\u_ball.x_pos [1]),
    .Y(_502_)
);

FILL FILL_1__1510_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1365_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_431_),
    .B(_427_),
    .Y(_426_)
);

OR2X2 _1174_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [3]),
    .B(\u_ball.y_pos [5]),
    .Y(_102_)
);

FILL FILL_0__1214_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1459_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_653_),
    .Y(_610_)
);

AOI22X1 _1039_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_456_),
    .B(_276_),
    .C(_273_),
    .D(_297_),
    .Y(_272_)
);

FILL FILL_1__1413_ (
    .gnd(gnd),
    .vdd(vdd)
);

AND2X2 _1268_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [4]),
    .B(\u_ball.y_pos [3]),
    .Y(_333_)
);

FILL FILL_0__1308_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1061_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _811_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_456_),
    .B(_682_),
    .C(_297_),
    .Y(_706_)
);

AOI21X1 _1497_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_642_),
    .B(\u_ctrl.State_3_bF$buf0 ),
    .C(_662_),
    .Y(_641_)
);

OAI21X1 _1077_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_457_),
    .B(_314_),
    .C(_311_),
    .Y(_310_)
);

FILL FILL_0__1117_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1290_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1346_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1507_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1260_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1155_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL78450x46950 (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _905_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_38_),
    .B(_34_),
    .Y(_33_)
);

FILL FILL_0__1193_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _943_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_69_),
    .Y(_68_)
);

OAI21X1 _1421_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [1]),
    .B(_585_),
    .C(_584_),
    .Y(_674_)
);

NOR2X1 _1001_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(game_init),
    .B(_729_),
    .Y(_235_)
);

NAND2X1 _752_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_210_),
    .B(_30_),
    .Y(_31_)
);

FILL FILL_0__1478_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1058_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _808_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_705_),
    .B(_706_),
    .Y(_709_)
);

NOR2X1 _1230_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [5]),
    .B(_152_),
    .Y(_151_)
);

NAND2X1 _981_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_218_),
    .B(_217_),
    .Y(_216_)
);

FILL FILL_0__1287_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _790_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_230_),
    .B(_224_),
    .Y(_730_)
);

INVX1 _1515_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [4]),
    .Y(_659_)
);

OAI21X1 _846_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_70_),
    .B(\u_ball.y_pos [3]),
    .C(_41_),
    .Y(_548_)
);

NAND3X1 _1324_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_422_),
    .B(_390_),
    .C(_388_),
    .Y(_387_)
);

DFFSR _1133_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_176_),
    .D(_186_),
    .CLK(clk_bF$buf3),
    .Q(\u_bricks.regBricks [15])
);

FILL FILL_0__881_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _884_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_498_),
    .B(_500_),
    .Y(_505_)
);

FILL FILL_1_CLKBUF1_insert6 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__937_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _1362_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_432_),
    .B(_424_),
    .C(_425_),
    .Y(_423_)
);

FILL FILL_0__1402_ (
    .gnd(gnd),
    .vdd(vdd)
);

MUX2X1 _1418_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_582_),
    .B(\u_ball.x_pos [2]),
    .S(_583_),
    .Y(_673_)
);

DFFSR _749_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_476__bF$buf0),
    .S(vdd),
    .D(_480_),
    .CLK(clk_bF$buf2),
    .Q(\u_ball.x_ball [0])
);

NOR2X1 _1171_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [2]),
    .B(\u_ball.x_pos [0]),
    .Y(_99_)
);

FILL FILL_0__1211_ (
    .gnd(gnd),
    .vdd(vdd)
);

OR2X2 _1227_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_150_),
    .B(_160_),
    .Y(_149_)
);

FILL FILL_0__975_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _978_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_467_),
    .B(_297_),
    .Y(_213_)
);

FILL FILL_0__1440_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1020_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1456_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_661_),
    .B(_608_),
    .C(_632_),
    .Y(_607_)
);

AOI21X1 _1036_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_277_),
    .B(_272_),
    .C(_270_),
    .Y(_269_)
);

FILL FILL_0__784_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__818_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _787_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_223_),
    .B(_220_),
    .C(_1_),
    .Y(_2_)
);

FILL FILL_1__991_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX2 _1265_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(reset),
    .Y(_437_)
);

FILL FILL_0__1305_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _1494_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_640_),
    .B(_639_),
    .C(_641_),
    .Y(_638_)
);

OAI21X1 _1074_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_449_),
    .B(_450_),
    .C(\u_ball.x_ball [2]),
    .Y(_307_)
);

FILL FILL_0__878_ (
    .gnd(gnd),
    .vdd(vdd)
);

BUFX2 BUFX2_insert0 (
    .gnd(gnd),
    .vdd(vdd),
    .A(_476_),
    .Y(_476__bF$buf3)
);

BUFX2 BUFX2_insert1 (
    .gnd(gnd),
    .vdd(vdd),
    .A(_476_),
    .Y(_476__bF$buf2)
);

BUFX2 BUFX2_insert2 (
    .gnd(gnd),
    .vdd(vdd),
    .A(_476_),
    .Y(_476__bF$buf1)
);

BUFX2 BUFX2_insert3 (
    .gnd(gnd),
    .vdd(vdd),
    .A(_476_),
    .Y(_476__bF$buf0)
);

FILL FILL_0__1343_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1359_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_421_),
    .B(_425_),
    .Y(_420_)
);

FILL FILL_1__894_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _902_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_477_),
    .Y(_478_)
);

NAND2X1 _1168_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [2]),
    .B(\u_ball.y_pos [0]),
    .Y(_96_)
);

DFFSR _1397_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_677__bF$buf3),
    .S(vdd),
    .D(_515_),
    .CLK(clk_bF$buf7),
    .Q(\u_ctrl.State [4])
);

OAI21X1 _940_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_67_),
    .B(_66_),
    .C(_68_),
    .Y(_65_)
);

FILL FILL_1__1160_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__797_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__802_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI22X1 _805_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [4]),
    .B(_709_),
    .C(_711_),
    .D(\u_ball.x_pos [5]),
    .Y(_712_)
);

FILL FILL_1__1025_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL78450x150 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL78450x32550 (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _1512_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [6]),
    .B(\u_ball.x_pos [5]),
    .C(_657_),
    .Y(_656_)
);

FILL FILL_0__840_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _843_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [4]),
    .B(_60_),
    .Y(_551_)
);

FILL FILL_0__1149_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1321_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_433_),
    .B(_423_),
    .C(\u_ball.x_paddle [1]),
    .Y(_385_)
);

DFFSR _1130_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_176_),
    .D(_175_),
    .CLK(clk_bF$buf3),
    .Q(\u_bricks.regBricks [6])
);

FILL FILL_1__912_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _881_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_507_),
    .B(_504_),
    .Y(_508_)
);

FILL FILL_1__1292_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1187_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__934_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _937_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_64_),
    .B(_63_),
    .C(_69_),
    .Y(_62_)
);

OAI21X1 _1415_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_661_),
    .B(_658_),
    .C(_580_),
    .Y(_579_)
);

DFFSR _746_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_476__bF$buf3),
    .S(vdd),
    .D(_482_),
    .CLK(clk_bF$buf5),
    .Q(\u_ball.y_ball [3])
);

INVX1 _1224_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_bricks.regBricks [11]),
    .Y(_147_)
);

NAND2X1 _975_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_211_),
    .B(_214_),
    .Y(_210_)
);

AOI21X1 _1453_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_661_),
    .B(_645_),
    .C(_606_),
    .Y(_684_)
);

OAI22X1 _1033_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_313_),
    .B(_267_),
    .C(_285_),
    .D(_269_),
    .Y(_266_)
);

FILL FILL_1__815_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _784_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_467_),
    .B(_451_),
    .C(_219_),
    .Y(_4_)
);

FILL FILL77850x10950 (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1509_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_655_),
    .B(_654_),
    .Y(_653_)
);

OR2X2 _1262_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_330_),
    .B(_413_),
    .Y(_329_)
);

INVX1 _1318_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [2]),
    .Y(_383_)
);

INVX1 _1491_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(game_new),
    .Y(_636_)
);

OAI21X1 _1071_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [2]),
    .B(_305_),
    .C(_452_),
    .Y(_304_)
);

DFFSR _1127_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_176_),
    .D(_180_),
    .CLK(clk_bF$buf3),
    .Q(\u_bricks.regBricks [4])
);

NOR2X1 _878_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [0]),
    .B(_203_),
    .Y(_511_)
);

INVX1 _1356_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_418_),
    .Y(_417_)
);

FILL FILL_1__1310_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _1165_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_98_),
    .B(_94_),
    .C(_101_),
    .Y(_93_)
);

FILL FILL_0__1205_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1394_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_677__bF$buf2),
    .S(vdd),
    .D(_676_),
    .CLK(clk_bF$buf2),
    .Q(\u_ctrl.cnt_v_sync [2])
);

FILL FILL_0__1243_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL78150x10950 (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1259_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_383_),
    .B(_422_),
    .C(_327_),
    .Y(_436_)
);

FILL FILL_0__1052_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _802_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_533_),
    .B(_714_),
    .C(_257_),
    .Y(_715_)
);

INVX1 _1488_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [0]),
    .Y(_634_)
);

INVX1 _1068_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_319_),
    .Y(_301_)
);

FILL FILL_0__1108_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1281_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1442_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1022_ (
    .gnd(gnd),
    .vdd(vdd)
);

OR2X2 _1297_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_363_),
    .B(_376_),
    .Y(_362_)
);

FILL FILL_0__1337_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1090_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _840_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_544_),
    .Y(_554_)
);

FILL FILL_0__1146_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX2 _934_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [4]),
    .Y(_60_)
);

NAND2X1 _1412_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_578_),
    .B(_618_),
    .Y(_577_)
);

DFFSR _743_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_476__bF$buf1),
    .S(vdd),
    .D(_473_),
    .CLK(clk_bF$buf1),
    .Q(\u_ball.x_ball [3])
);

FILL FILL_0__1469_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1049_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1221_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_145_),
    .B(_146_),
    .Y(_144_)
);

NOR2X1 _972_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_467_),
    .B(_464_),
    .Y(_207_)
);

FILL FILL_0__1278_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1450_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_604_),
    .Y(_603_)
);

AOI22X1 _1030_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_266_),
    .B(_264_),
    .C(_292_),
    .D(_310_),
    .Y(_263_)
);

OAI21X1 _781_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_235_),
    .B(_6_),
    .C(_3_),
    .Y(_473_)
);

FILL FILL_0__1087_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1506_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_726_),
    .B(_0_),
    .Y(_650_)
);

NAND2X1 _837_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [5]),
    .B(_543_),
    .Y(_557_)
);

INVX1 _1315_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [1]),
    .Y(_380_)
);

DFFSR _1124_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_176_),
    .D(_172_),
    .CLK(clk_bF$buf6),
    .Q(\u_bricks.regBricks [5])
);

FILL FILL_0__872_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _875_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_39_),
    .B(_35_),
    .C(_513_),
    .Y(_514_)
);

FILL FILL_0__928_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1353_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_415_),
    .Y(_414_)
);

OAI21X1 _1409_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State_3_bF$buf3 ),
    .B(_599_),
    .C(_619_),
    .Y(_575_)
);

NOR2X1 _1162_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_bricks.regBricks [11]),
    .B(\u_bricks.regBricks [2]),
    .Y(_91_)
);

FILL FILL_1__944_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1218_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_159_),
    .B(_142_),
    .Y(_141_)
);

FILL FILL_0__966_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _969_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_206_),
    .B(_209_),
    .C(_230_),
    .Y(_204_)
);

DFFSR _1391_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_677__bF$buf0),
    .S(vdd),
    .D(_684_),
    .CLK(clk_bF$buf7),
    .Q(_729_)
);

FILL FILL_0__1431_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1011_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1447_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_611_),
    .B(_632_),
    .C(_601_),
    .Y(_683_)
);

NOR2X1 _1027_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [0]),
    .B(\u_ball.x_ball [1]),
    .Y(_260_)
);

FILL FILL_0__775_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _778_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_7_),
    .B(_8_),
    .C(_210_),
    .Y(_9_)
);

FILL FILL_1__1189_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1256_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_416_),
    .B(_422_),
    .C(_325_),
    .Y(_435_)
);

OAI21X1 _1485_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_634_),
    .B(_661_),
    .C(_632_),
    .Y(_631_)
);

NAND2X1 _1065_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_299_),
    .B(_300_),
    .Y(_298_)
);

FILL FILL_1__847_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1525_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1105_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__869_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1294_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [1]),
    .B(_380_),
    .C(_360_),
    .Y(_359_)
);

FILL FILL77850x18150 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0_BUFX2_insert13 (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _1159_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_168_),
    .B(_161_),
    .C(_89_),
    .Y(_88_)
);

FILL FILL_0_BUFX2_insert15 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0_BUFX2_insert17 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0_BUFX2_insert19 (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1388_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_677__bF$buf2),
    .D(_673_),
    .CLK(clk_bF$buf5),
    .Q(\u_ball.x_pos [2])
);

FILL FILL_0__1428_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _931_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_59_),
    .B(_58_),
    .Y(_57_)
);

NAND3X1 _1197_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_130_),
    .B(_128_),
    .C(_126_),
    .Y(_125_)
);

DFFSR _740_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_476__bF$buf1),
    .S(vdd),
    .D(_680_),
    .CLK(clk_bF$buf0),
    .Q(hit_brick)
);

FILL FILL_1__1207_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1503_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State_3_bF$buf3 ),
    .B(\u_ctrl.State [0]),
    .Y(_647_)
);

FILL FILL_0__831_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _834_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_555_),
    .B(_553_),
    .C(_559_),
    .Y(_560_)
);

FILL FILL78150x18150 (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1312_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_382_),
    .B(_378_),
    .Y(_377_)
);

FILL FILL_1__1474_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1054_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1121_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_176_),
    .D(_185_),
    .CLK(clk_bF$buf3),
    .Q(\u_bricks.regBricks [8])
);

AOI21X1 _872_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_38_),
    .B(_44_),
    .C(_518_),
    .Y(_521_)
);

FILL FILL_0__1178_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _928_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_56_),
    .B(_63_),
    .C(_57_),
    .Y(_54_)
);

FILL FILL_1__1339_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _1350_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_427_),
    .B(_431_),
    .C(\u_ball.x_paddle [2]),
    .Y(_411_)
);

INVX1 _1406_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.cnt_v_sync [1]),
    .Y(_573_)
);

DFFSR _737_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_476__bF$buf3),
    .S(vdd),
    .D(_484_),
    .CLK(clk_bF$buf4),
    .Q(\u_ball.y_ball [1])
);

FILL FILL_1__941_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1215_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [5]),
    .B(_150_),
    .Y(_139_)
);

INVX2 _966_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_230_),
    .Y(_202_)
);

AOI21X1 _1444_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_600_),
    .B(_599_),
    .C(game_new),
    .Y(_515_)
);

OR2X2 _1024_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_258_),
    .B(_313_),
    .Y(_257_)
);

FILL FILL_0__772_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _775_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.sign_x ),
    .B(\u_ball.x_ball [6]),
    .Y(_12_)
);

DFFSR _1253_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_437_),
    .S(vdd),
    .D(_441_),
    .CLK(clk_bF$buf0),
    .Q(\u_ball.x_paddle [4])
);

NOR2X1 _1309_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [3]),
    .B(_375_),
    .Y(_374_)
);

NOR2X1 _1482_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_634_),
    .B(_630_),
    .Y(_629_)
);

AND2X2 _1062_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_316_),
    .B(_296_),
    .Y(_295_)
);

DFFSR _1118_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_476__bF$buf1),
    .S(vdd),
    .D(_469_),
    .CLK(clk_bF$buf0),
    .Q(\u_ball.sign_y )
);

AOI21X1 _869_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_523_),
    .B(_497_),
    .C(_509_),
    .Y(_524_)
);

OR2X2 _1291_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [1]),
    .B(\u_ball.y_pos [2]),
    .Y(_356_)
);

NAND2X1 _1347_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_409_),
    .B(_410_),
    .Y(_408_)
);

FILL FILL_0__1140_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1156_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_bricks.regBricks [0]),
    .Y(_85_)
);

DFFSR _1385_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_677__bF$buf3),
    .S(vdd),
    .D(_692_),
    .CLK(clk_bF$buf7),
    .Q(_727_)
);

AOI21X1 _1194_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_124_),
    .B(_123_),
    .C(_132_),
    .Y(_122_)
);

FILL FILL_0__1234_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__998_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1043_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1479_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_627_),
    .B(_632_),
    .Y(_626_)
);

NAND2X1 _1059_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_309_),
    .B(_293_),
    .Y(_292_)
);

FILL FILL_0__1519_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1272_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1288_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [5]),
    .B(_354_),
    .Y(_353_)
);

FILL FILL_0__1328_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1081_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1500_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_666_),
    .B(_650_),
    .C(_645_),
    .Y(_644_)
);

AOI21X1 _831_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_525_),
    .B(_532_),
    .C(_562_),
    .Y(_563_)
);

NAND2X1 _1097_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [1]),
    .B(\u_ball.x_paddle [1]),
    .Y(_447_)
);

FILL FILL_0__1137_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL78150x72150 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1471_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL78150x39750 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1366_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1175_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _925_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(game_init),
    .Y(_52_)
);

NOR2X1 _1403_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_571_),
    .B(_573_),
    .Y(_570_)
);

FILL FILL_0__731_ (
    .gnd(gnd),
    .vdd(vdd)
);

BUFX2 _734_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_726_),
    .Y(game_over)
);

AOI21X1 _1212_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_157_),
    .B(_162_),
    .C(_138_),
    .Y(_181_)
);

NAND2X1 _963_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [1]),
    .B(\u_ball.sign_y ),
    .Y(_200_)
);

FILL FILL_0__1269_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1441_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_650_),
    .Y(_597_)
);

OAI21X1 _1021_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [4]),
    .B(_261_),
    .C(_255_),
    .Y(_254_)
);

INVX1 _772_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_208_),
    .Y(_15_)
);

FILL FILL_0__1498_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _828_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_566_),
    .B(_564_),
    .Y(_678_)
);

FILL FILL_1__1239_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1250_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_476__bF$buf2),
    .S(vdd),
    .D(_486_),
    .CLK(clk_bF$buf1),
    .Q(\u_ball.x_ball [5])
);

OAI21X1 _1306_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_381_),
    .B(_376_),
    .C(_372_),
    .Y(_371_)
);

NOR2X1 _1115_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(game_init),
    .B(_466_),
    .Y(_465_)
);

FILL FILL_0__863_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _866_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_526_),
    .B(_506_),
    .C(_50_),
    .Y(_527_)
);

FILL FILL_0__919_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1344_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_419_),
    .B(_426_),
    .Y(_405_)
);

INVX1 _1153_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_bricks.regBricks [10]),
    .Y(_82_)
);

AOI21X1 _1209_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_136_),
    .B(_162_),
    .C(_137_),
    .Y(_180_)
);

FILL FILL_0__957_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1382_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_677__bF$buf2),
    .D(_670_),
    .CLK(clk_bF$buf2),
    .Q(\u_ball.x_pos [5])
);

FILL FILL_0__1422_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1002_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL77850x150 (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _1438_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_596_),
    .B(_595_),
    .C(_597_),
    .Y(_519_)
);

INVX1 _1018_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_309_),
    .Y(_251_)
);

FILL FILL_0__766_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _769_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_230_),
    .B(_17_),
    .C(_14_),
    .Y(_18_)
);

OAI21X1 _1191_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_120_),
    .B(_122_),
    .C(\u_ball.x_pos [6]),
    .Y(_119_)
);

FILL FILL_1__973_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1247_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [3]),
    .B(_167_),
    .Y(_166_)
);

FILL FILL_0__995_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _998_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_233_),
    .Y(_232_)
);

FILL FILL_1__782_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1460_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1040_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1476_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_654_),
    .Y(_624_)
);

OAI21X1 _1056_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_460_),
    .B(_291_),
    .C(_459_),
    .Y(_289_)
);

FILL FILL_0__1516_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1285_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_351_),
    .Y(_350_)
);

FILL FILL_0__1325_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX2 _1094_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [0]),
    .Y(_444_)
);

FILL FILL_1__876_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__898_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1379_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_677__bF$buf0),
    .S(vdd),
    .D(_517_),
    .CLK(clk_bF$buf7),
    .Q(\u_ctrl.State [3])
);

OR2X2 _922_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_444_),
    .B(\u_ball.x_pos [0]),
    .Y(_50_)
);

NAND2X1 _1188_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_bricks.regBricks [7]),
    .B(\u_ball.x_pos [3]),
    .Y(_116_)
);

AOI21X1 _1400_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_571_),
    .B(\u_ctrl.State [1]),
    .C(\u_ctrl.State_3_bF$buf0 ),
    .Y(_568_)
);

BUFX2 _731_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_729_),
    .Y(v_sync)
);

FILL FILL_1__1142_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__779_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _960_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_198_),
    .B(_199_),
    .Y(_197_)
);

FILL FILL_1__1371_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1007_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__800_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__822_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR3X1 _825_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [0]),
    .B(\u_ball.x_ball [1]),
    .C(\u_ball.x_ball [2]),
    .Y(_682_)
);

FILL FILL_1__1236_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1303_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_372_),
    .Y(_368_)
);

INVX1 _1112_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_463_),
    .Y(_462_)
);

FILL FILL_0__860_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _863_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_529_),
    .B(_528_),
    .Y(_530_)
);

FILL FILL_1__1274_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1169_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__916_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL78450x68550 (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _919_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [1]),
    .Y(_47_)
);

NAND3X1 _1341_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_434_),
    .B(_422_),
    .C(_403_),
    .Y(_402_)
);

FILL FILL_1__1083_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1150_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_83_),
    .B(_80_),
    .Y(_79_)
);

INVX1 _1206_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [5]),
    .Y(_134_)
);

OAI21X1 _957_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_201_),
    .B(_234_),
    .C(_195_),
    .Y(_484_)
);

FILL FILL_1__1368_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _1435_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_649_),
    .B(_637_),
    .C(_594_),
    .Y(_531_)
);

AOI22X1 _1015_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_250_),
    .B(_312_),
    .C(_251_),
    .D(_249_),
    .Y(_248_)
);

NOR2X1 _766_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [1]),
    .B(\u_ball.y_ball [2]),
    .Y(_20_)
);

AND2X2 _1244_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_729_),
    .B(hit_brick),
    .Y(_163_)
);

NAND2X1 _995_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.hit_paddle ),
    .B(_230_),
    .Y(_229_)
);

NAND2X1 _1473_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_622_),
    .B(_632_),
    .Y(_621_)
);

NAND2X1 _1053_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_464_),
    .B(_287_),
    .Y(_286_)
);

DFFSR _1529_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_176_),
    .D(_169_),
    .CLK(clk_bF$buf0),
    .Q(\u_bricks.regBricks [12])
);

INVX1 _1109_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [5]),
    .Y(_459_)
);

OAI21X1 _1282_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [3]),
    .B(_375_),
    .C(_371_),
    .Y(_347_)
);

AOI22X1 _1338_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [3]),
    .B(_431_),
    .C(_410_),
    .D(_409_),
    .Y(_399_)
);

OAI21X1 _1091_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_451_),
    .B(_448_),
    .C(_438_),
    .Y(_324_)
);

INVX1 _1147_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_bricks.regBricks [6]),
    .Y(_78_)
);

NAND3X1 _898_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_479_),
    .B(_490_),
    .C(_489_),
    .Y(_491_)
);

FILL FILL_1__1521_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1101_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1376_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_677__bF$buf3),
    .S(vdd),
    .D(_519_),
    .CLK(clk_bF$buf7),
    .Q(\u_ctrl.State [2])
);

NAND3X1 _1185_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_bricks.regBricks [4]),
    .B(_133_),
    .C(_132_),
    .Y(_113_)
);

FILL FILL_0__1225_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__989_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1034_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1263_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1424_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1004_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1279_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_419_),
    .B(\u_ball.x_pos [4]),
    .C(_349_),
    .Y(_344_)
);

FILL FILL_0__1319_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1492_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1072_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _822_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_456_),
    .B(_694_),
    .Y(_695_)
);

NAND2X1 _1088_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_463_),
    .B(_453_),
    .Y(_321_)
);

FILL FILL78150x46950 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL78150x7350 (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1300_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [0]),
    .Y(_365_)
);

FILL FILL_0__1357_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _860_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_498_),
    .B(_506_),
    .C(_502_),
    .Y(_534_)
);

AOI22X1 _916_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_47_),
    .B(\u_ball.y_ball [1]),
    .C(\u_ball.y_ball [0]),
    .D(_45_),
    .Y(_44_)
);

AOI21X1 _1203_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_133_),
    .B(\u_bricks.regBricks [2]),
    .C(_132_),
    .Y(_131_)
);

INVX2 _954_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.sign_y ),
    .Y(_192_)
);

OAI21X1 _1432_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_661_),
    .B(_642_),
    .C(_593_),
    .Y(_592_)
);

AOI21X1 _1012_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_246_),
    .B(_247_),
    .C(_285_),
    .Y(_245_)
);

AOI21X1 _763_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_22_),
    .B(_19_),
    .C(game_init),
    .Y(_471_)
);

FILL FILL_0__1489_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1069_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _819_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_451_),
    .B(_499_),
    .C(_697_),
    .Y(_698_)
);

INVX1 _1241_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_bricks.regBricks [15]),
    .Y(_161_)
);

NAND2X1 _992_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_236_),
    .B(_444_),
    .Y(_227_)
);

INVX1 _1470_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [5]),
    .Y(_619_)
);

NAND2X1 _1050_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_455_),
    .B(_449_),
    .Y(_283_)
);

FILL FILL_0__1510_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL78450x54150 (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1526_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(pixel_brick),
    .Y(_722_)
);

INVX2 _1106_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [3]),
    .Y(_456_)
);

FILL FILL_0__854_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI22X1 _857_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_464_),
    .B(\u_ball.x_pos [5]),
    .C(_297_),
    .D(\u_ball.x_pos [4]),
    .Y(_537_)
);

AOI22X1 _1335_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_397_),
    .B(_406_),
    .C(_400_),
    .D(_398_),
    .Y(_396_)
);

FILL FILL78150x150 (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1144_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_bricks.regBricks [9]),
    .Y(_76_)
);

FILL FILL_0__892_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__926_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _895_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_479_),
    .B(_493_),
    .C(_489_),
    .Y(_494_)
);

FILL FILL_0__948_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1373_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [6]),
    .Y(_434_)
);

FILL FILL_1__735_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1413_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1429_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State_3_bF$buf1 ),
    .B(_590_),
    .Y(_589_)
);

NAND3X1 _1009_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_465_),
    .B(_243_),
    .C(_248_),
    .Y(_242_)
);

FILL FILL_0__757_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _1182_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_114_),
    .B(_113_),
    .C(_111_),
    .Y(_110_)
);

OR2X2 _1238_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_159_),
    .B(_160_),
    .Y(_158_)
);

NAND3X1 _989_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_228_),
    .B(_227_),
    .C(_225_),
    .Y(_224_)
);

FILL FILL_0__1451_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1031_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1467_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_656_),
    .B(_617_),
    .Y(_616_)
);

OAI21X1 _1047_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(gnd),
    .B(_444_),
    .C(_447_),
    .Y(_280_)
);

FILL FILL_0__795_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__829_ (
    .gnd(gnd),
    .vdd(vdd)
);

AND2X2 _798_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_718_),
    .B(_563_),
    .Y(pixel_ball)
);

FILL FILL_0__1507_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1260_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1276_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [5]),
    .Y(_341_)
);

NAND2X1 _1085_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_319_),
    .B(_320_),
    .Y(_318_)
);

FILL FILL_0__910_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _913_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [2]),
    .B(_42_),
    .Y(_41_)
);

AOI21X1 _1179_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_108_),
    .B(_109_),
    .C(_132_),
    .Y(_107_)
);

OR2X2 _1200_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_129_),
    .B(\u_bricks.regBricks [0]),
    .Y(_128_)
);

NOR2X1 _951_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_190_),
    .B(_191_),
    .Y(_189_)
);

AOI21X1 _760_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_24_),
    .B(_23_),
    .C(_231_),
    .Y(_25_)
);

FILL FILL_1__1171_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL78150x32550 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__813_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _816_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [3]),
    .Y(_701_)
);

FILL FILL_1__1456_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1036_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1523_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_727_),
    .Y(_667_)
);

NAND2X1 _1103_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_455_),
    .B(_454_),
    .Y(_453_)
);

FILL FILL_0__851_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _854_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_539_),
    .Y(_540_)
);

OAI21X1 _1332_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_419_),
    .B(btn_left),
    .C(_405_),
    .Y(_394_)
);

OAI21X1 _1141_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_156_),
    .B(_75_),
    .C(\u_bricks.regBricks [13]),
    .Y(_74_)
);

FILL FILL_1__923_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _892_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_48_),
    .Y(_497_)
);

FILL FILL_0__1198_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _948_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_194_),
    .B(_189_),
    .C(_729_),
    .Y(_177_)
);

INVX2 _1370_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(btn_left),
    .Y(_431_)
);

FILL FILL_0__1410_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1426_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [0]),
    .Y(_587_)
);

INVX1 _1006_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_256_),
    .Y(_239_)
);

FILL FILL_0__754_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _757_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_70_),
    .B(_543_),
    .C(_20_),
    .Y(_27_)
);

FILL FILL77550x10950 (
    .gnd(gnd),
    .vdd(vdd)
);

INVX2 _1235_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_156_),
    .Y(_155_)
);

NAND2X1 _986_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [2]),
    .B(_467_),
    .Y(_221_)
);

OAI21X1 _1464_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_653_),
    .B(_615_),
    .C(\u_ctrl.State_3_bF$buf2 ),
    .Y(_614_)
);

NAND3X1 _1044_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_284_),
    .B(_281_),
    .C(_278_),
    .Y(_277_)
);

AOI21X1 _795_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_723_),
    .B(_719_),
    .C(_234_),
    .Y(_680_)
);

OAI21X1 _1273_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [2]),
    .B(_379_),
    .C(_369_),
    .Y(_338_)
);

NAND3X1 _1329_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_422_),
    .B(_392_),
    .C(_393_),
    .Y(_391_)
);

OAI21X1 _1082_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [4]),
    .B(_318_),
    .C(_316_),
    .Y(_315_)
);

AOI21X1 _1138_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_73_),
    .B(_162_),
    .C(_86_),
    .Y(_172_)
);

NAND2X1 _889_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [2]),
    .B(_499_),
    .Y(_500_)
);

NOR2X1 _1367_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [2]),
    .B(\u_ball.x_paddle [3]),
    .Y(_428_)
);

FILL FILL_0__1160_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _910_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [1]),
    .B(_201_),
    .Y(_38_)
);

FILL FILL_1__1321_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _1176_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [6]),
    .B(_105_),
    .C(_106_),
    .Y(_104_)
);

FILL FILL_0__1216_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1025_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1483_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1063_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _813_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [4]),
    .Y(_704_)
);

NOR3X1 _1499_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_662_),
    .B(_644_),
    .C(_651_),
    .Y(_643_)
);

INVX1 _1079_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_461_),
    .Y(_312_)
);

FILL FILL_0__1292_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1453_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1348_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1520_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_665_),
    .Y(_664_)
);

AND2X2 _1100_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [1]),
    .B(\u_ball.x_paddle [2]),
    .Y(_450_)
);

INVX1 _851_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [5]),
    .Y(_543_)
);

FILL FILL78450x3750 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1157_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _907_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_38_),
    .B(_37_),
    .C(_36_),
    .Y(_35_)
);

INVX2 _945_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [3]),
    .Y(_70_)
);

AOI21X1 _1423_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_661_),
    .B(\u_ctrl.State [0]),
    .C(_586_),
    .Y(_585_)
);

OAI21X1 _1003_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_467_),
    .B(_252_),
    .C(_237_),
    .Y(_488_)
);

AOI21X1 _754_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_729_),
    .B(_28_),
    .C(_29_),
    .Y(_469_)
);

INVX1 _1232_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [3]),
    .Y(_153_)
);

FILL FILL_0__980_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _983_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.sign_x ),
    .B(_456_),
    .Y(_218_)
);

FILL FILL_0__1289_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL78450x61350 (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1461_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [5]),
    .Y(_612_)
);

OAI21X1 _1041_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_455_),
    .B(_449_),
    .C(_460_),
    .Y(_274_)
);

INVX8 _792_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(reset),
    .Y(_476_)
);

FILL FILL_0__1501_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX4 _1517_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State_3_bF$buf1 ),
    .Y(_661_)
);

FILL FILL_0__845_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _848_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_38_),
    .B(_43_),
    .C(_37_),
    .Y(_546_)
);

OAI21X1 _1270_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_419_),
    .B(\u_ball.x_pos [4]),
    .C(_353_),
    .Y(_335_)
);

FILL FILL_0__1310_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1326_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_421_),
    .B(_431_),
    .C(_420_),
    .Y(_389_)
);

INVX1 _1135_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_bricks.regBricks [12]),
    .Y(_72_)
);

FILL FILL_0__883_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _886_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [1]),
    .B(_501_),
    .C(_502_),
    .Y(_503_)
);

FILL FILL_0__939_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1364_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_426_),
    .Y(_425_)
);

FILL FILL_0__1404_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1173_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [4]),
    .B(_102_),
    .Y(_101_)
);

FILL FILL_1__955_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _1229_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_155_),
    .B(_151_),
    .C(_154_),
    .Y(_185_)
);

FILL FILL_0__977_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__764_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1442_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1022_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1458_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_611_),
    .B(_610_),
    .C(_612_),
    .Y(_609_)
);

OAI21X1 _1038_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_290_),
    .B(_288_),
    .C(\u_ball.x_ball [5]),
    .Y(_271_)
);

FILL FILL_0__786_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI22X1 _789_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_226_),
    .B(_234_),
    .C(_725_),
    .D(_730_),
    .Y(_475_)
);

OAI21X1 _1267_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_349_),
    .B(_334_),
    .C(_333_),
    .Y(_332_)
);

FILL FILL_0__1307_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1480_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _810_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_704_),
    .B(_705_),
    .C(_706_),
    .Y(_707_)
);

FILL FILL_1__1221_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1496_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_644_),
    .Y(_640_)
);

NOR2X1 _1076_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [6]),
    .B(_313_),
    .Y(_309_)
);

FILL FILL_1__858_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__901_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _904_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_35_),
    .B(_39_),
    .C(_33_),
    .Y(_32_)
);

NAND2X1 _1399_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.cnt_v_sync [0]),
    .B(_592_),
    .Y(_567_)
);

NOR2X1 _942_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_70_),
    .B(_192_),
    .Y(_67_)
);

FILL FILL_1__1353_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1248_ (
    .gnd(gnd),
    .vdd(vdd)
);

CLKBUF1 CLKBUF1_insert10 (
    .gnd(gnd),
    .vdd(vdd),
    .A(clk),
    .Y(clk_bF$buf1)
);

CLKBUF1 CLKBUF1_insert11 (
    .gnd(gnd),
    .vdd(vdd),
    .A(clk),
    .Y(clk_bF$buf0)
);

NAND2X1 _1420_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [1]),
    .B(_586_),
    .Y(_583_)
);

INVX4 _1000_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_235_),
    .Y(_234_)
);

OAI22X1 _751_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_297_),
    .B(_234_),
    .C(_202_),
    .D(_31_),
    .Y(_468_)
);

FILL FILL_0__804_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _807_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_464_),
    .B(_705_),
    .Y(_710_)
);

FILL FILL_1__1218_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _980_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_216_),
    .Y(_215_)
);

NAND3X1 _1514_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [1]),
    .B(\u_ball.x_pos [0]),
    .C(\u_ball.x_pos [2]),
    .Y(_658_)
);

FILL FILL_0__842_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _845_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_548_),
    .B(_547_),
    .C(_545_),
    .Y(_549_)
);

FILL FILL_1__1256_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1323_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_433_),
    .B(_423_),
    .C(\u_ball.x_paddle [5]),
    .Y(_386_)
);

FILL FILL_1__1485_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1065_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1132_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_176_),
    .D(_179_),
    .CLK(clk_bF$buf6),
    .Q(\u_bricks.regBricks [3])
);

FILL FILL_0__880_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _883_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [1]),
    .B(_226_),
    .Y(_506_)
);

FILL FILL_0__1189_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _939_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_67_),
    .Y(_64_)
);

NOR2X1 _1361_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_433_),
    .B(_423_),
    .Y(_422_)
);

OR2X2 _1417_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_658_),
    .B(_661_),
    .Y(_581_)
);

DFFSR _748_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_476__bF$buf0),
    .S(vdd),
    .D(_487_),
    .CLK(clk_bF$buf2),
    .Q(\u_ball.x2 )
);

NAND2X1 _1170_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_100_),
    .B(_99_),
    .Y(_98_)
);

FILL FILL78450x14550 (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1226_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_156_),
    .B(_149_),
    .C(\u_bricks.regBricks [14]),
    .Y(_148_)
);

NOR2X1 _977_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.sign_x ),
    .B(\u_ball.x_ball [4]),
    .Y(_212_)
);

FILL FILL_1__761_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1455_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_612_),
    .B(_632_),
    .C(_607_),
    .Y(_685_)
);

INVX1 _1035_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [6]),
    .Y(_268_)
);

OAI21X1 _786_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_451_),
    .B(_234_),
    .C(_2_),
    .Y(_474_)
);

INVX1 _1264_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_411_),
    .Y(_331_)
);

OAI21X1 _1493_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_667_),
    .B(_643_),
    .C(_638_),
    .Y(_692_)
);

OR2X2 _1073_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [1]),
    .B(\u_ball.x_paddle [2]),
    .Y(_306_)
);

DFFSR _1129_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_176_),
    .D(_184_),
    .CLK(clk_bF$buf3),
    .Q(\u_bricks.regBricks [14])
);

FILL FILL_1__1503_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX2 _1358_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [4]),
    .Y(_419_)
);

FILL FILL_0__1151_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _901_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_38_),
    .B(_37_),
    .C(_40_),
    .Y(_479_)
);

NAND2X1 _1167_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [1]),
    .B(_96_),
    .Y(_95_)
);

FILL FILL_0__1207_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1396_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_677__bF$buf1),
    .D(_683_),
    .CLK(clk_bF$buf4),
    .Q(\u_ball.y_pos [4])
);

FILL FILL_0__1016_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1350_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__987_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1245_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1406_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1474_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1054_ (
    .gnd(gnd),
    .vdd(vdd)
);

AND2X2 _804_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_712_),
    .B(_708_),
    .Y(_713_)
);

FILL FILL_0__1283_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1299_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [1]),
    .B(_380_),
    .C(_377_),
    .Y(_364_)
);

FILL FILL_0__1339_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1092_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1511_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [3]),
    .Y(_655_)
);

OAI21X1 _842_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_545_),
    .B(_551_),
    .C(_544_),
    .Y(_552_)
);

NAND2X1 _1320_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_413_),
    .B(_422_),
    .Y(_384_)
);

INVX1 _880_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_508_),
    .Y(_509_)
);

NAND3X1 _936_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_230_),
    .B(_62_),
    .C(_65_),
    .Y(_61_)
);

OAI21X1 _1414_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [3]),
    .B(_581_),
    .C(_579_),
    .Y(_672_)
);

DFFSR _745_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_476__bF$buf2),
    .S(vdd),
    .D(_474_),
    .CLK(clk_bF$buf1),
    .Q(\u_ball.x_ball [2])
);

NAND2X1 _1223_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [6]),
    .B(_151_),
    .Y(_146_)
);

FILL FILL_0__971_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _974_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_467_),
    .B(_297_),
    .C(_210_),
    .Y(_209_)
);

NOR2X1 _1452_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_611_),
    .B(_610_),
    .Y(_605_)
);

AND2X2 _1032_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_290_),
    .B(\u_ball.x_paddle [6]),
    .Y(_265_)
);

FILL FILL_0_CLKBUF1_insert4 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0_CLKBUF1_insert6 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0_CLKBUF1_insert8 (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _783_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_4_),
    .B(_216_),
    .C(game_init),
    .Y(_5_)
);

NAND3X1 _1508_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [5]),
    .B(\u_ball.y_pos [4]),
    .C(_653_),
    .Y(_652_)
);

FILL FILL_0__836_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _839_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_70_),
    .B(\u_ball.y_pos [3]),
    .C(_554_),
    .Y(_555_)
);

NAND2X1 _1261_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_413_),
    .B(_330_),
    .Y(_328_)
);

FILL FILL_0__1301_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1317_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [2]),
    .B(_383_),
    .Y(_382_)
);

AOI21X1 _1490_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_636_),
    .B(\u_ctrl.State [0]),
    .C(game_init),
    .Y(_635_)
);

AOI21X1 _1070_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_307_),
    .B(_438_),
    .C(_304_),
    .Y(_303_)
);

FILL FILL_0__1110_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1126_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_176_),
    .D(_173_),
    .CLK(clk_bF$buf6),
    .Q(\u_bricks.regBricks [13])
);

FILL FILL_0__874_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__908_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _877_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_46_),
    .B(_510_),
    .C(_511_),
    .Y(_512_)
);

INVX1 _1355_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [3]),
    .Y(_416_)
);

FILL FILL_1__1097_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__890_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _1164_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_103_),
    .B(\u_ball.x_pos [5]),
    .C(_93_),
    .Y(_92_)
);

FILL FILL_0__968_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1393_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_677__bF$buf1),
    .D(_689_),
    .CLK(clk_bF$buf4),
    .Q(\u_ball.y_pos [1])
);

FILL FILL_0__1433_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1013_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1449_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_603_),
    .B(_605_),
    .C(\u_ctrl.State_3_bF$buf2 ),
    .Y(_602_)
);

NOR2X1 _1029_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [2]),
    .B(\u_ball.x_ball [3]),
    .Y(_262_)
);

FILL FILL_0__777_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__984_ (
    .gnd(gnd),
    .vdd(vdd)
);

OR2X2 _1258_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_410_),
    .B(_409_),
    .Y(_326_)
);

FILL FILL_1__793_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1471_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1051_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _801_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [5]),
    .B(_711_),
    .C(_715_),
    .Y(_716_)
);

OAI21X1 _1487_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State_3_bF$buf0 ),
    .B(\u_ctrl.State [0]),
    .C(_649_),
    .Y(_633_)
);

OAI21X1 _1067_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_302_),
    .B(_301_),
    .C(\u_ball.x_ball [4]),
    .Y(_300_)
);

OR2X2 _1296_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_362_),
    .B(_366_),
    .Y(_361_)
);

FILL FILL77850x68550 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__887_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1115_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__930_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _933_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [4]),
    .B(_192_),
    .Y(_59_)
);

NOR2X1 _1199_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [4]),
    .B(_133_),
    .Y(_127_)
);

FILL FILL_0__1239_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI22X1 _1411_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_659_),
    .B(_647_),
    .C(_577_),
    .D(\u_ctrl.State_3_bF$buf3 ),
    .Y(_671_)
);

DFFSR _742_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_476__bF$buf1),
    .D(_481_),
    .CLK(clk_bF$buf0),
    .Q(\u_ball.y_ball [4])
);

FILL FILL_1__1153_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1220_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_144_),
    .Y(_143_)
);

NOR2X1 _971_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_208_),
    .B(_207_),
    .Y(_206_)
);

FILL FILL_1__1438_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1018_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__811_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _780_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_213_),
    .Y(_7_)
);

OAI21X1 _1505_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_726_),
    .B(_0_),
    .C(\u_ctrl.State_3_bF$buf1 ),
    .Y(_649_)
);

FILL FILL_0__833_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _836_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_557_),
    .B(_551_),
    .Y(_558_)
);

FILL FILL78150x68550 (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1314_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [2]),
    .Y(_379_)
);

DFFSR _1123_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_176_),
    .D(_183_),
    .CLK(clk_bF$buf6),
    .Q(\u_bricks.regBricks [11])
);

FILL FILL_1__905_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _874_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [0]),
    .B(_45_),
    .Y(_516_)
);

FILL FILL_1__1285_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1352_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [1]),
    .Y(_413_)
);

FILL FILL_1__1094_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1408_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_661_),
    .B(_618_),
    .C(_575_),
    .Y(_574_)
);

DFFSR _739_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_476__bF$buf2),
    .S(vdd),
    .D(_488_),
    .CLK(clk_bF$buf1),
    .Q(\u_ball.sign_x )
);

NAND3X1 _1161_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_138_),
    .B(_137_),
    .C(_91_),
    .Y(_90_)
);

FILL FILL78450x21750 (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _1217_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_143_),
    .B(_141_),
    .C(_147_),
    .Y(_183_)
);

OAI22X1 _968_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_464_),
    .B(_234_),
    .C(_204_),
    .D(_205_),
    .Y(_486_)
);

DFFSR _1390_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_677__bF$buf0),
    .D(_674_),
    .CLK(clk_bF$buf5),
    .Q(\u_ball.x_pos [1])
);

INVX1 _1446_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State [4]),
    .Y(_600_)
);

AOI21X1 _1026_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_260_),
    .B(_451_),
    .C(_456_),
    .Y(_259_)
);

OAI21X1 _777_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.sign_x ),
    .B(\u_ball.x_ball [5]),
    .C(_9_),
    .Y(_10_)
);

DFFSR _1255_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_437_),
    .S(vdd),
    .D(_440_),
    .CLK(clk_bF$buf0),
    .Q(\u_ball.x_paddle [5])
);

OAI21X1 _1484_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_634_),
    .B(_632_),
    .C(_631_),
    .Y(_690_)
);

INVX2 _1064_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [4]),
    .Y(_297_)
);

NOR2X1 _1293_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_359_),
    .B(_369_),
    .Y(_358_)
);

OAI21X1 _1349_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_413_),
    .B(_411_),
    .C(_412_),
    .Y(_410_)
);

FILL FILL_0__1142_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1303_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1158_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_90_),
    .B(_88_),
    .Y(_87_)
);

FILL FILL_0__1371_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1112_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1387_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_677__bF$buf0),
    .D(_688_),
    .CLK(clk_bF$buf5),
    .Q(\u_ball.y_pos [2])
);

FILL FILL_0__1007_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1180_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _930_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_70_),
    .B(_192_),
    .C(_68_),
    .Y(_56_)
);

NAND2X1 _1196_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_bricks.regBricks [10]),
    .B(_133_),
    .Y(_124_)
);

FILL FILL_0__1236_ (
    .gnd(gnd),
    .vdd(vdd)
);

BUFX2 BUFX2_insert12 (
    .gnd(gnd),
    .vdd(vdd),
    .A(_677_),
    .Y(_677__bF$buf3)
);

BUFX2 BUFX2_insert13 (
    .gnd(gnd),
    .vdd(vdd),
    .A(_677_),
    .Y(_677__bF$buf2)
);

BUFX2 BUFX2_insert14 (
    .gnd(gnd),
    .vdd(vdd),
    .A(_677_),
    .Y(_677__bF$buf1)
);

BUFX2 BUFX2_insert15 (
    .gnd(gnd),
    .vdd(vdd),
    .A(_677_),
    .Y(_677__bF$buf0)
);

BUFX2 BUFX2_insert16 (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State [3]),
    .Y(\u_ctrl.State_3_bF$buf3 )
);

BUFX2 BUFX2_insert17 (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State [3]),
    .Y(\u_ctrl.State_3_bF$buf2 )
);

BUFX2 BUFX2_insert18 (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State [3]),
    .Y(\u_ctrl.State_3_bF$buf1 )
);

BUFX2 BUFX2_insert19 (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State [3]),
    .Y(\u_ctrl.State_3_bF$buf0 )
);

FILL FILL_0__1465_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1045_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1274_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1435_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1083_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1502_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State [1]),
    .B(\u_ctrl.State [2]),
    .C(_649_),
    .Y(_646_)
);

AOI21X1 _833_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_550_),
    .B(_544_),
    .C(_560_),
    .Y(_561_)
);

NOR2X1 _1099_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [1]),
    .B(\u_ball.x_paddle [2]),
    .Y(_449_)
);

FILL FILL_0__1139_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _1311_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [1]),
    .B(_380_),
    .C(_377_),
    .Y(_376_)
);

FILL FILL_0__1368_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1120_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_176_),
    .D(_170_),
    .CLK(clk_bF$buf3),
    .Q(\u_bricks.regBricks [0])
);

NAND3X1 _871_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_479_),
    .B(_489_),
    .C(_521_),
    .Y(_522_)
);

NOR2X1 _927_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_202_),
    .B(_54_),
    .Y(_53_)
);

AOI21X1 _1405_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_666_),
    .B(_599_),
    .C(\u_ctrl.State_3_bF$buf1 ),
    .Y(_572_)
);

FILL FILL_0__733_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _736_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_476__bF$buf3),
    .S(vdd),
    .D(_470_),
    .CLK(clk_bF$buf5),
    .Q(\u_ball.y_ball [5])
);

AOI21X1 _1214_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_139_),
    .B(_162_),
    .C(_140_),
    .Y(_182_)
);

FILL FILL_0__962_ (
    .gnd(gnd),
    .vdd(vdd)
);

MUX2X1 _965_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_202_),
    .B(_234_),
    .S(_203_),
    .Y(_485_)
);

NAND2X1 _1443_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State [2]),
    .B(_650_),
    .Y(_598_)
);

NOR2X1 _1023_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(game_init),
    .B(\u_ball.hit_paddle ),
    .Y(_256_)
);

NAND2X1 _774_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_12_),
    .B(_11_),
    .Y(_13_)
);

FILL FILL_1__1185_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__827_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1252_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_437_),
    .S(vdd),
    .D(_436_),
    .CLK(clk_bF$buf0),
    .Q(\u_ball.x_paddle [2])
);

NOR2X1 _1308_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [3]),
    .B(_416_),
    .Y(_373_)
);

NOR2X1 _1481_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [0]),
    .B(\u_ball.y_pos [1]),
    .Y(_628_)
);

OAI21X1 _1061_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_303_),
    .B(_298_),
    .C(_295_),
    .Y(_294_)
);

FILL FILL_0__1521_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1101_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX2 _1117_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.sign_x ),
    .Y(_467_)
);

FILL FILL_0__865_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _868_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_524_),
    .B(_496_),
    .Y(_525_)
);

AOI21X1 _1290_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_361_),
    .B(_357_),
    .C(_356_),
    .Y(_355_)
);

FILL FILL_0__1330_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _1346_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_417_),
    .B(_414_),
    .C(_408_),
    .Y(_407_)
);

FILL FILL_1_CLKBUF1_insert10 (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1155_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_bricks.regBricks [9]),
    .B(\u_bricks.regBricks [6]),
    .Y(_84_)
);

FILL FILL_1__937_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__959_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1384_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_677__bF$buf2),
    .D(_671_),
    .CLK(clk_bF$buf7),
    .Q(\u_ball.x_pos [4])
);

FILL FILL_0__1424_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1004_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__768_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _1193_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_bricks.regBricks [9]),
    .B(\u_ball.x_pos [3]),
    .C(_132_),
    .Y(_121_)
);

INVX1 _1249_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_bricks.regBricks [1]),
    .Y(_168_)
);

FILL FILL_0__1462_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1203_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1478_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_630_),
    .B(_632_),
    .C(_626_),
    .Y(_689_)
);

OAI21X1 _1058_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [1]),
    .B(\u_ball.x_paddle [2]),
    .C(\u_ball.x_paddle [3]),
    .Y(_291_)
);

FILL FILL_0__1518_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1271_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1287_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [6]),
    .Y(_352_)
);

NAND3X1 _830_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_497_),
    .B(_495_),
    .C(_492_),
    .Y(_564_)
);

INVX1 _1096_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_447_),
    .Y(_446_)
);

FILL FILL_0__921_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _924_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x2 ),
    .B(_231_),
    .C(_52_),
    .Y(_51_)
);

FILL FILL_1__1335_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1402_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_665_),
    .B(_570_),
    .C(\u_ctrl.State [1]),
    .Y(_569_)
);

BUFX2 _733_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_727_),
    .Y(p_tick)
);

INVX1 _1211_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_bricks.regBricks [4]),
    .Y(_137_)
);

INVX1 _962_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_200_),
    .Y(_199_)
);

OAI21X1 _1440_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_652_),
    .B(_656_),
    .C(\u_ctrl.State_3_bF$buf1 ),
    .Y(_596_)
);

OAI21X1 _1020_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(game_init),
    .B(_729_),
    .C(_254_),
    .Y(_253_)
);

INVX1 _771_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_13_),
    .Y(_16_)
);

FILL FILL_1__1182_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__824_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _827_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_508_),
    .B(_523_),
    .Y(_679_)
);

AND2X2 _1305_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_382_),
    .B(_378_),
    .Y(_370_)
);

FILL FILL_1__1467_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1047_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__840_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX2 _1114_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [5]),
    .Y(_464_)
);

FILL FILL_0__862_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _865_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_527_),
    .Y(_528_)
);

NAND3X1 _1343_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_406_),
    .B(_405_),
    .C(_407_),
    .Y(_404_)
);

NOR2X1 _1152_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_bricks.regBricks [13]),
    .B(\u_bricks.regBricks [12]),
    .Y(_81_)
);

INVX1 _1208_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_bricks.regBricks [3]),
    .Y(_135_)
);

AOI21X1 _959_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_197_),
    .B(\u_ball.y_ball [0]),
    .C(_202_),
    .Y(_196_)
);

DFFSR _1381_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_677__bF$buf1),
    .D(_690_),
    .CLK(clk_bF$buf4),
    .Q(\u_ball.y_pos [0])
);

NOR2X1 _1437_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_597_),
    .B(_641_),
    .Y(_520_)
);

OAI21X1 _1017_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_457_),
    .B(_314_),
    .C(_309_),
    .Y(_250_)
);

OAI21X1 _768_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_313_),
    .B(_234_),
    .C(_18_),
    .Y(_472_)
);

NAND3X1 _1190_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_134_),
    .B(_119_),
    .C(_125_),
    .Y(_118_)
);

FILL FILL_0__1230_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1246_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [5]),
    .B(_166_),
    .Y(_165_)
);

INVX1 _997_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_729_),
    .Y(_231_)
);

FILL FILL_1__1200_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1475_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [2]),
    .B(_629_),
    .Y(_623_)
);

INVX1 _1055_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_289_),
    .Y(_288_)
);

OAI21X1 _1284_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [5]),
    .B(_354_),
    .C(_350_),
    .Y(_349_)
);

FILL FILL_1_BUFX2_insert13 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1_BUFX2_insert17 (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1093_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(gnd),
    .B(_444_),
    .Y(_443_)
);

AND2X2 _1149_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_87_),
    .B(_79_),
    .Y(_0_)
);

FILL FILL_0__1362_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1378_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_677__bF$buf0),
    .D(_531_),
    .CLK(clk_bF$buf5),
    .Q(\u_ctrl.State [0])
);

FILL FILL_0__1171_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _921_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [0]),
    .B(_444_),
    .Y(_49_)
);

FILL FILL_1__1332_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _1187_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_117_),
    .B(_116_),
    .C(_132_),
    .Y(_115_)
);

FILL FILL_0__1227_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1456_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1036_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL77850x61350 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1265_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1494_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1074_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _824_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [3]),
    .B(_682_),
    .Y(_693_)
);

NAND3X1 _1302_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_382_),
    .B(_369_),
    .C(_368_),
    .Y(_367_)
);

FILL FILL_0__1359_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1531_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_677__bF$buf3),
    .S(vdd),
    .D(_668_),
    .CLK(clk_bF$buf7),
    .Q(\u_ctrl.cnt_v_sync [0])
);

NAND3X1 _1111_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [4]),
    .B(\u_ball.x_paddle [5]),
    .C(_462_),
    .Y(_461_)
);

AOI21X1 _862_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_523_),
    .B(_509_),
    .C(_530_),
    .Y(_532_)
);

NOR2X1 _918_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [1]),
    .B(_47_),
    .Y(_46_)
);

INVX1 _1340_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_422_),
    .Y(_401_)
);

INVX2 _1205_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [3]),
    .Y(_133_)
);

FILL FILL_0__953_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _956_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_203_),
    .B(_198_),
    .C(_200_),
    .Y(_194_)
);

FILL FILL78150x61350 (
    .gnd(gnd),
    .vdd(vdd)
);

INVX8 _1434_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(reset),
    .Y(_677_)
);

NAND2X1 _1014_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_277_),
    .B(_272_),
    .Y(_247_)
);

AOI21X1 _765_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_20_),
    .B(_203_),
    .C(_70_),
    .Y(_21_)
);

FILL FILL_0__818_ (
    .gnd(gnd),
    .vdd(vdd)
);

AND2X2 _1243_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_163_),
    .B(_164_),
    .Y(_162_)
);

FILL FILL_0__991_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI22X1 _994_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_236_),
    .B(_232_),
    .C(_229_),
    .D(_263_),
    .Y(_487_)
);

OAI21X1 _1472_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_625_),
    .B(_632_),
    .C(_621_),
    .Y(_688_)
);

INVX1 _1052_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_286_),
    .Y(_285_)
);

FILL FILL_0__1512_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1528_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_476__bF$buf2),
    .S(vdd),
    .D(_468_),
    .CLK(clk_bF$buf1),
    .Q(\u_ball.x_ball [4])
);

OAI21X1 _1108_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_460_),
    .B(_463_),
    .C(_459_),
    .Y(_458_)
);

FILL FILL_0__856_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI22X1 _859_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_456_),
    .B(\u_ball.x_pos [3]),
    .C(_534_),
    .D(_500_),
    .Y(_535_)
);

OR2X2 _1281_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [4]),
    .B(\u_ball.x_pos [4]),
    .Y(_346_)
);

FILL FILL_0__1321_ (
    .gnd(gnd),
    .vdd(vdd)
);

AND2X2 _1337_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_399_),
    .B(_417_),
    .Y(_398_)
);

FILL FILL_1__1079_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1090_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_451_),
    .B(_448_),
    .Y(_323_)
);

FILL FILL_1__872_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1146_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_149_),
    .Y(_77_)
);

FILL FILL_0__894_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _897_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_478_),
    .B(_32_),
    .C(_491_),
    .Y(_492_)
);

DFFSR _1375_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_677__bF$buf1),
    .D(_686_),
    .CLK(clk_bF$buf4),
    .Q(\u_ball.y_pos [3])
);

FILL FILL_0__1415_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__759_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1184_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [4]),
    .B(\u_ball.x_pos [5]),
    .Y(_112_)
);

FILL FILL_1__966_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__775_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1453_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1033_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1469_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_657_),
    .Y(_618_)
);

NAND2X1 _1049_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_291_),
    .B(_283_),
    .Y(_282_)
);

FILL FILL_0__797_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1278_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_345_),
    .B(_344_),
    .Y(_343_)
);

NAND3X1 _821_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [3]),
    .B(_695_),
    .C(_693_),
    .Y(_696_)
);

FILL FILL_1__1232_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1087_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [4]),
    .B(_462_),
    .Y(_320_)
);

FILL FILL_1__869_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__912_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _915_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [2]),
    .B(_193_),
    .Y(_43_)
);

FILL FILL_1__1135_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL77850x14550 (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1202_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_135_),
    .B(_133_),
    .C(_131_),
    .Y(_130_)
);

FILL FILL_0__950_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _953_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_193_),
    .B(_192_),
    .Y(_191_)
);

FILL FILL_1__1364_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1431_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State [1]),
    .B(\u_ctrl.cnt_v_sync [2]),
    .Y(_591_)
);

NOR2X1 _1011_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_313_),
    .B(_267_),
    .Y(_244_)
);

NAND3X1 _762_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_64_),
    .B(_59_),
    .C(_68_),
    .Y(_23_)
);

FILL FILL_0__815_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _818_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_698_),
    .B(_534_),
    .Y(_699_)
);

INVX1 _1240_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [5]),
    .Y(_160_)
);

INVX1 _991_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [1]),
    .Y(_226_)
);

INVX1 _1525_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(pixel_paddle),
    .Y(_721_)
);

INVX1 _1105_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [3]),
    .Y(_455_)
);

OAI21X1 _856_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_536_),
    .B(_535_),
    .C(_537_),
    .Y(_538_)
);

FILL FILL_1__1267_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1334_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_401_),
    .B(_396_),
    .C(\u_ball.x_paddle [6]),
    .Y(_395_)
);

FILL FILL_1__1496_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1076_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _1143_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_155_),
    .B(_165_),
    .C(_76_),
    .Y(_174_)
);

NAND3X1 _894_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_477_),
    .B(_490_),
    .C(_494_),
    .Y(_495_)
);

FILL FILL78150x14550 (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1372_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_729_),
    .Y(_433_)
);

NAND2X1 _1428_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.cnt_v_sync [2]),
    .B(_592_),
    .Y(_588_)
);

INVX1 _1008_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_253_),
    .Y(_241_)
);

OAI21X1 _759_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [5]),
    .B(_25_),
    .C(_52_),
    .Y(_26_)
);

NAND2X1 _1181_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_bricks.regBricks [15]),
    .B(\u_ball.x_pos [3]),
    .Y(_109_)
);

FILL FILL_0__1221_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1237_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_158_),
    .Y(_157_)
);

NAND2X1 _988_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_228_),
    .B(_224_),
    .Y(_223_)
);

FILL FILL_1__1399_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI22X1 _1466_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_620_),
    .B(_647_),
    .C(_616_),
    .D(\u_ctrl.State_3_bF$buf2 ),
    .Y(_687_)
);

AND2X2 _1046_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_280_),
    .B(_445_),
    .Y(_279_)
);

INVX1 _797_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(hit_brick),
    .Y(_719_)
);

FILL FILL_1__1420_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1000_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _1275_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_352_),
    .B(\u_ball.x_paddle [6]),
    .C(_341_),
    .Y(_340_)
);

AOI22X1 _1084_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [3]),
    .B(_321_),
    .C(_318_),
    .D(\u_ball.x_ball [4]),
    .Y(_317_)
);

FILL FILL_0__1353_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1514_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1369_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [6]),
    .B(\u_ball.x_paddle [4]),
    .Y(_430_)
);

FILL FILL_0__1162_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _912_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_43_),
    .B(_41_),
    .Y(_40_)
);

NAND3X1 _1178_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_bricks.regBricks [12]),
    .B(_133_),
    .C(_132_),
    .Y(_106_)
);

FILL FILL_0__1218_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1447_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1027_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _950_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_194_),
    .B(_189_),
    .Y(_188_)
);

FILL FILL_1__998_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1256_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1417_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1485_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1065_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _815_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_695_),
    .B(_693_),
    .Y(_702_)
);

FILL FILL_0__1294_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1522_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State [1]),
    .Y(_666_)
);

NAND3X1 _1102_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_456_),
    .B(_463_),
    .C(_453_),
    .Y(_452_)
);

NAND2X1 _853_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_540_),
    .B(_538_),
    .Y(_541_)
);

OAI22X1 _909_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [1]),
    .B(_201_),
    .C(_203_),
    .D(\u_ball.y_pos [0]),
    .Y(_37_)
);

OR2X2 _1331_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_399_),
    .B(_394_),
    .Y(_393_)
);

INVX1 _1140_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_74_),
    .Y(_173_)
);

NAND2X1 _891_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [2]),
    .B(_451_),
    .Y(_498_)
);

FILL FILL_0__944_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _947_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_231_),
    .B(\u_ball.y_ball [2]),
    .C(game_init),
    .Y(_71_)
);

FILL FILL_1__731_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1425_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_661_),
    .B(_587_),
    .Y(_586_)
);

OAI22X1 _1005_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_257_),
    .B(_239_),
    .C(_240_),
    .D(_248_),
    .Y(_238_)
);

OAI21X1 _756_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [4]),
    .B(_27_),
    .C(_719_),
    .Y(_28_)
);

FILL FILL_1__1167_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__809_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _1234_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_157_),
    .B(_155_),
    .C(_161_),
    .Y(_186_)
);

FILL FILL_0__982_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _985_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_222_),
    .B(_221_),
    .Y(_220_)
);

NAND2X1 _1463_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_614_),
    .B(_632_),
    .Y(_613_)
);

INVX1 _1043_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_282_),
    .Y(_276_)
);

FILL FILL_0__791_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _794_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(pixel_paddle),
    .B(_563_),
    .C(_718_),
    .Y(_724_)
);

FILL FILL_0__1503_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1519_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.cnt_v_sync [2]),
    .B(_664_),
    .Y(_663_)
);

FILL FILL_0__847_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _1272_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_338_),
    .B(_372_),
    .C(_374_),
    .Y(_337_)
);

FILL FILL_0__1312_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1328_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_419_),
    .B(_422_),
    .C(_391_),
    .Y(_441_)
);

AOI21X1 _1081_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_317_),
    .B(_322_),
    .C(_315_),
    .Y(_314_)
);

AOI21X1 _1137_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_155_),
    .B(_139_),
    .C(_82_),
    .Y(_171_)
);

FILL FILL_0__885_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__919_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _888_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [1]),
    .Y(_501_)
);

FILL FILL_1__1299_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1350_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _1366_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_430_),
    .B(_429_),
    .C(_428_),
    .Y(_427_)
);

FILL FILL_0__1406_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI22X1 _1175_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_104_),
    .B(_107_),
    .C(_115_),
    .D(_110_),
    .Y(_103_)
);

FILL FILL78450x43350 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1444_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__788_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _1269_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_337_),
    .B(_336_),
    .C(_335_),
    .Y(_334_)
);

FILL FILL_0__1482_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _812_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [4]),
    .B(\u_ball.x_ball [3]),
    .C(_694_),
    .Y(_705_)
);

NOR2X1 _1498_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_652_),
    .B(_656_),
    .Y(_642_)
);

AOI21X1 _1078_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_313_),
    .B(\u_ball.x_paddle [6]),
    .C(_312_),
    .Y(_311_)
);

AOI22X1 _850_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_60_),
    .B(\u_ball.y_pos [4]),
    .C(_543_),
    .D(\u_ball.y_pos [5]),
    .Y(_544_)
);

FILL FILL_0__903_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _906_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [1]),
    .B(_47_),
    .Y(_34_)
);

FILL FILL_1__1317_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL77850x21750 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1194_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__941_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _944_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_193_),
    .B(_192_),
    .C(_188_),
    .Y(_69_)
);

OAI21X1 _1422_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_661_),
    .B(_587_),
    .C(\u_ball.x_pos [1]),
    .Y(_584_)
);

INVX1 _1002_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x2 ),
    .Y(_236_)
);

OR2X2 _753_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_214_),
    .B(_211_),
    .Y(_30_)
);

FILL FILL_1__1164_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__806_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _809_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_703_),
    .B(_707_),
    .C(_700_),
    .Y(_708_)
);

NAND2X1 _1231_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_153_),
    .B(_167_),
    .Y(_152_)
);

NAND2X1 _982_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [3]),
    .B(_467_),
    .Y(_217_)
);

FILL FILL_1__1449_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1029_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1460_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [4]),
    .Y(_611_)
);

AND2X2 _1040_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_275_),
    .B(_274_),
    .Y(_273_)
);

FILL FILL_1__822_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _791_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_225_),
    .B(_228_),
    .C(_227_),
    .Y(_725_)
);

FILL FILL_0__1500_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1097_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1516_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [3]),
    .Y(_660_)
);

FILL FILL_0__844_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _847_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_546_),
    .Y(_547_)
);

OR2X2 _1325_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_397_),
    .B(_389_),
    .Y(_388_)
);

AOI21X1 _1134_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_155_),
    .B(_136_),
    .C(_72_),
    .Y(_169_)
);

FILL FILL78150x21750 (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _885_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_498_),
    .B(_500_),
    .C(_503_),
    .Y(_504_)
);

FILL FILL_1__1296_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _1363_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [6]),
    .B(\u_ball.x_paddle [4]),
    .C(\u_ball.x_paddle [5]),
    .Y(_424_)
);

AOI21X1 _1419_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_661_),
    .B(\u_ctrl.State [0]),
    .C(\u_ball.x_pos [2]),
    .Y(_582_)
);

INVX1 _1172_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [1]),
    .Y(_100_)
);

FILL FILL_0__1212_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1228_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [4]),
    .B(_153_),
    .Y(_150_)
);

FILL FILL78450x64950 (
    .gnd(gnd),
    .vdd(vdd)
);

OAI22X1 _979_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_467_),
    .B(_262_),
    .C(_215_),
    .D(_219_),
    .Y(_214_)
);

AND2X2 _1457_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_609_),
    .B(_652_),
    .Y(_608_)
);

OAI21X1 _1037_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_297_),
    .B(_273_),
    .C(_271_),
    .Y(_270_)
);

AOI21X1 _788_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_223_),
    .B(_220_),
    .C(_202_),
    .Y(_1_)
);

NOR3X1 _1266_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_339_),
    .B(_332_),
    .C(_355_),
    .Y(pixel_paddle)
);

OAI21X1 _1495_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State [0]),
    .B(\u_ctrl.State [2]),
    .C(_661_),
    .Y(_639_)
);

INVX1 _1075_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_457_),
    .Y(_308_)
);

FILL FILL_0__1115_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1344_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1153_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _903_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [0]),
    .B(_203_),
    .Y(_477_)
);

FILL FILL_1__1314_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1169_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [2]),
    .B(\u_ball.y_pos [0]),
    .Y(_97_)
);

FILL FILL_0__1209_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1398_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_592_),
    .B(_568_),
    .C(_567_),
    .Y(_668_)
);

FILL FILL_0__1438_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1018_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1191_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _941_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [3]),
    .B(\u_ball.sign_y ),
    .Y(_66_)
);

FILL FILL_0__1247_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _750_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_476__bF$buf3),
    .D(_483_),
    .CLK(clk_bF$buf5),
    .Q(\u_ball.y_ball [2])
);

FILL FILL_0__1476_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1056_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _806_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_258_),
    .B(_710_),
    .Y(_711_)
);

FILL FILL_0_BUFX2_insert1 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0_BUFX2_insert2 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1285_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1094_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR3X1 _1513_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_660_),
    .B(_659_),
    .C(_658_),
    .Y(_657_)
);

OAI21X1 _844_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_60_),
    .B(\u_ball.y_pos [4]),
    .C(_549_),
    .Y(_550_)
);

NAND2X1 _1322_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_386_),
    .B(_387_),
    .Y(_440_)
);

DFFSR _1131_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_176_),
    .D(_181_),
    .CLK(clk_bF$buf3),
    .Q(\u_bricks.regBricks [7])
);

NAND3X1 _882_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_506_),
    .B(_502_),
    .C(_505_),
    .Y(_507_)
);

FILL FILL_0__935_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _938_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_66_),
    .Y(_63_)
);

FILL FILL78150x3750 (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1360_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [5]),
    .Y(_421_)
);

OAI21X1 _1416_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State_3_bF$buf3 ),
    .B(_599_),
    .C(_660_),
    .Y(_580_)
);

DFFSR _747_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_476__bF$buf0),
    .S(vdd),
    .D(_475_),
    .CLK(clk_bF$buf2),
    .Q(\u_ball.x_ball [1])
);

INVX1 _1225_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_148_),
    .Y(_184_)
);

FILL FILL_0__973_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _976_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_212_),
    .B(_213_),
    .Y(_211_)
);

AOI21X1 _1454_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_642_),
    .B(_645_),
    .C(_729_),
    .Y(_606_)
);

OAI21X1 _1034_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_459_),
    .B(_275_),
    .C(_268_),
    .Y(_267_)
);

FILL FILL_0__782_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _785_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [3]),
    .B(_235_),
    .Y(_3_)
);

FILL FILL_1__1196_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__838_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1263_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_383_),
    .B(btn_left),
    .C(_331_),
    .Y(_330_)
);

FILL FILL_0__1303_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1319_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_385_),
    .B(_384_),
    .Y(_439_)
);

NAND2X1 _1492_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(game_new),
    .B(\u_ctrl.State [0]),
    .Y(_637_)
);

NAND2X1 _1072_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_454_),
    .B(_306_),
    .Y(_305_)
);

FILL FILL_1__854_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1112_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1128_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_176_),
    .D(_174_),
    .CLK(clk_bF$buf3),
    .Q(\u_bricks.regBricks [9])
);

FILL FILL_0__876_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _879_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [1]),
    .B(_201_),
    .Y(_510_)
);

FILL FILL_0__1341_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1357_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(btn_left),
    .B(_419_),
    .Y(_418_)
);

OAI21X1 _900_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_46_),
    .B(_44_),
    .C(_36_),
    .Y(_489_)
);

OAI21X1 _1166_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [1]),
    .B(_97_),
    .C(_95_),
    .Y(_94_)
);

FILL FILL_1__948_ (
    .gnd(gnd),
    .vdd(vdd)
);

CLKBUF1 CLKBUF1_insert4 (
    .gnd(gnd),
    .vdd(vdd),
    .A(clk),
    .Y(clk_bF$buf7)
);

CLKBUF1 CLKBUF1_insert5 (
    .gnd(gnd),
    .vdd(vdd),
    .A(clk),
    .Y(clk_bF$buf6)
);

CLKBUF1 CLKBUF1_insert6 (
    .gnd(gnd),
    .vdd(vdd),
    .A(clk),
    .Y(clk_bF$buf5)
);

CLKBUF1 CLKBUF1_insert7 (
    .gnd(gnd),
    .vdd(vdd),
    .A(clk),
    .Y(clk_bF$buf4)
);

CLKBUF1 CLKBUF1_insert8 (
    .gnd(gnd),
    .vdd(vdd),
    .A(clk),
    .Y(clk_bF$buf3)
);

CLKBUF1 CLKBUF1_insert9 (
    .gnd(gnd),
    .vdd(vdd),
    .A(clk),
    .Y(clk_bF$buf2)
);

DFFSR _1395_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_677__bF$buf1),
    .D(_685_),
    .CLK(clk_bF$buf4),
    .Q(\u_ball.y_pos [5])
);

FILL FILL_1__757_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1435_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1015_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__779_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__800_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _803_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_464_),
    .B(_705_),
    .C(_313_),
    .Y(_714_)
);

FILL FILL_1__1214_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _1489_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State [4]),
    .B(_637_),
    .C(_635_),
    .Y(_691_)
);

NOR2X1 _1069_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_460_),
    .B(_463_),
    .Y(_302_)
);

OAI21X1 _1298_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [0]),
    .B(_365_),
    .C(_364_),
    .Y(_363_)
);

NAND3X1 _1510_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [0]),
    .B(\u_ball.y_pos [1]),
    .C(\u_ball.y_pos [2]),
    .Y(_654_)
);

NAND3X1 _841_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_41_),
    .B(_546_),
    .C(_552_),
    .Y(_553_)
);

FILL FILL_1__1061_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1185_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__932_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _935_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_70_),
    .B(_234_),
    .C(_61_),
    .Y(_482_)
);

FILL FILL_1__1346_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1413_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_660_),
    .B(_658_),
    .C(_659_),
    .Y(_578_)
);

DFFSR _744_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_476__bF$buf3),
    .S(vdd),
    .D(_485_),
    .CLK(clk_bF$buf4),
    .Q(\u_ball.y_ball [0])
);

OAI21X1 _1222_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [5]),
    .B(_152_),
    .C(_164_),
    .Y(_145_)
);

FILL FILL_0__970_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _973_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.sign_x ),
    .B(\u_ball.x_ball [5]),
    .Y(_208_)
);

OAI21X1 _1451_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_655_),
    .B(_654_),
    .C(_611_),
    .Y(_604_)
);

OAI21X1 _1031_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_313_),
    .B(_265_),
    .C(_267_),
    .Y(_264_)
);

OAI21X1 _782_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_216_),
    .B(_4_),
    .C(_5_),
    .Y(_6_)
);

FILL FILL_0__1088_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR3X1 _1507_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_661_),
    .B(_652_),
    .C(_656_),
    .Y(_651_)
);

NOR2X1 _838_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [5]),
    .B(_543_),
    .Y(_556_)
);

NAND3X1 _1260_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_422_),
    .B(_328_),
    .C(_329_),
    .Y(_327_)
);

INVX1 _1316_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_382_),
    .Y(_381_)
);

FILL FILL_1__1478_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__1058_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_1__851_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1125_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_176_),
    .D(_187_),
    .CLK(clk_bF$buf6),
    .Q(\u_bricks.regBricks [1])
);

OAI21X1 _876_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_46_),
    .B(_37_),
    .C(_512_),
    .Y(_513_)
);

NOR2X1 _1354_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(btn_left),
    .B(_416_),
    .Y(_415_)
);

AND2X2 _1163_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_92_),
    .B(_118_),
    .Y(pixel_brick)
);

FILL FILL_0__1203_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1219_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_160_),
    .B(_163_),
    .Y(_142_)
);

DFFSR _1392_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_677__bF$buf1),
    .D(_675_),
    .CLK(clk_bF$buf4),
    .Q(\u_ball.x_pos [0])
);

NAND2X1 _1448_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_632_),
    .B(_602_),
    .Y(_601_)
);

NAND3X1 _1028_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_464_),
    .B(_313_),
    .C(_262_),
    .Y(_261_)
);

INVX1 _779_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_207_),
    .Y(_8_)
);

endmodule
