*SPICE netlist created from verilog structural netlist module bricks_out by vlog2Spice (qflow)
*This file may contain array delimiters, not for use in simulation.

** Start of included library /usr/local/share/qflow/tech/etri050/etri050_stdcells.sp
* NGSPICE file created from khu_etri050_stdcells.ext - technology: scmos

.subckt AOI22X1 A B C D Y vdd gnd
M1000 gnd C a_56_14# gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=1.8p ps=6.6u
M1001 vdd A a_7_146# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=25.2p ps=28.2u
M1002 Y D a_7_146# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1003 a_28_14# A gnd gnd nfet w=6u l=0.6u
+  ad=1.8p pd=6.6u as=12.6p ps=16.2u
M1004 Y B a_28_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=1.8p ps=6.6u
M1005 a_7_146# C Y vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=14.4p ps=14.4u
M1006 a_7_146# B vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1007 a_56_14# D Y gnd nfet w=6u l=0.6u
+  ad=1.8p pd=6.6u as=7.2p ps=8.4u
.ends

.subckt CLKBUF3 A Y vdd gnd
M1000 a_145_14# a_105_14# vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1001 a_65_14# a_25_14# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1002 a_105_14# a_65_14# vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1003 a_145_14# a_105_14# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1004 gnd a_145_14# a_185_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1005 a_25_14# A vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=25.2p ps=28.2u
M1006 a_65_14# a_25_14# vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1007 a_265_14# a_225_14# vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1008 a_265_14# a_225_14# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1009 a_225_14# a_185_14# vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1010 gnd a_265_14# Y gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1011 a_25_14# A gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
M1012 gnd a_25_14# a_65_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1013 a_105_14# a_65_14# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1014 Y a_265_14# vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1015 gnd a_105_14# a_145_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1016 vdd a_65_14# a_105_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1017 vdd a_105_14# a_145_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1018 a_225_14# a_185_14# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1019 gnd a_225_14# a_265_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1020 vdd a_25_14# a_65_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1021 gnd A a_25_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1022 vdd A a_25_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1023 vdd a_185_14# a_225_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1024 vdd a_225_14# a_265_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1025 vdd a_145_14# a_185_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1026 gnd a_65_14# a_105_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1027 a_185_14# a_145_14# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1028 gnd a_185_14# a_225_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1029 Y a_265_14# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1030 vdd a_265_14# Y vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=14.4p ps=14.4u
M1031 a_185_14# a_145_14# vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
.ends

.subckt INVX8 A Y vdd gnd
M1000 Y A gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1001 Y A vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=25.2p ps=28.2u
M1002 Y A vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1003 Y A gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
M1004 gnd A Y gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1005 vdd A Y vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=14.4p ps=14.4u
M1006 gnd A Y gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1007 vdd A Y vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
.ends

.subckt NOR3X1 A B C Y vdd gnd
M1000 gnd B Y gnd nfet w=3u l=0.6u
+  ad=3.6p pd=5.4u as=3.6p ps=5.4u
M1001 a_7_166# A vdd vdd pfet w=9u l=0.6u
+  ad=10.8p pd=11.4u as=10.8p ps=11.4u
M1002 a_7_166# B a_65_166# vdd pfet w=9u l=0.6u
+  ad=18.9p pd=22.2u as=10.8p ps=11.4u
M1003 a_65_166# C Y vdd pfet w=9u l=0.6u
+  ad=18.9p pd=22.2u as=10.8p ps=11.4u
M1004 Y C gnd gnd nfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=3.6p ps=5.4u
M1005 a_65_166# B a_7_166# vdd pfet w=9u l=0.6u
+  ad=10.8p pd=11.4u as=10.8p ps=11.4u
M1006 vdd A a_7_166# vdd pfet w=9u l=0.6u
+  ad=10.8p pd=11.4u as=18.9p ps=22.2u
M1007 Y C a_65_166# vdd pfet w=9u l=0.6u
+  ad=10.8p pd=11.4u as=18.9p ps=22.2u
M1008 Y A gnd gnd nfet w=3u l=0.6u
+  ad=3.6p pd=5.4u as=7.2p ps=10.8u
.ends

.subckt CLKBUF1 A Y vdd gnd
M1000 Y a_105_14# vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1001 a_65_14# a_25_14# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1002 a_105_14# a_65_14# vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1003 Y a_105_14# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1004 a_25_14# A vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=25.2p ps=28.2u
M1005 a_65_14# a_25_14# vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1006 a_25_14# A gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
M1007 gnd a_25_14# a_65_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1008 a_105_14# a_65_14# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1009 gnd a_105_14# Y gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1010 vdd a_65_14# a_105_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1011 vdd a_105_14# Y vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=14.4p ps=14.4u
M1012 vdd a_25_14# a_65_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1013 gnd A a_25_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1014 vdd A a_25_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1015 gnd a_65_14# a_105_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
.ends

.subckt MUX2X1 A B S Y vdd gnd
M1000 a_75_22# S Y gnd nfet w=6u l=0.6u
+  ad=2.7p pd=6.9u as=7.2p ps=8.4u
M1001 gnd S a_7_22# gnd nfet w=3u l=0.6u
+  ad=6.3p pd=8.4u as=6.3p ps=10.2u
M1002 Y S a_45_138# vdd pfet w=12u l=0.6u
+  ad=14.49p pd=15.6u as=5.4p ps=12.9u
M1003 gnd A a_75_22# gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=2.7p ps=6.9u
M1004 vdd A a_75_146# vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=5.4p ps=12.9u
M1005 a_45_138# B vdd vdd pfet w=12u l=0.6u
+  ad=5.4p pd=12.9u as=11.7p ps=14.4u
M1006 a_45_22# B gnd gnd nfet w=6u l=0.6u
+  ad=2.7p pd=6.9u as=6.3p ps=8.4u
M1007 Y a_7_22# a_45_22# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=2.7p ps=6.9u
M1008 a_75_146# a_7_22# Y vdd pfet w=12u l=0.6u
+  ad=5.4p pd=12.9u as=14.49p ps=15.6u
M1009 vdd S a_7_22# vdd pfet w=6u l=0.6u
+  ad=11.7p pd=14.4u as=12.6p ps=16.2u
.ends

.subckt NAND3X1 A B C Y vdd gnd
M1000 Y C a_34_14# gnd nfet w=9u l=0.6u
+  ad=18.9p pd=22.2u as=2.7p ps=9.6u
M1001 a_26_14# A gnd gnd nfet w=9u l=0.6u
+  ad=2.7p pd=9.6u as=18.9p ps=22.2u
M1002 vdd B Y vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1003 a_34_14# B a_26_14# gnd nfet w=9u l=0.6u
+  ad=2.7p pd=9.6u as=2.7p ps=9.6u
M1004 Y C vdd vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1005 Y A vdd vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
.ends

.subckt XOR2X1 A B Y vdd gnd
M1000 a_74_166# a_6_14# Y vdd pfet w=12u l=0.6u
+  ad=5.4p pd=12.9u as=14.4p ps=14.4u
M1001 a_28_58# B vdd vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=14.4p ps=14.4u
M1002 a_74_14# A Y gnd nfet w=6u l=0.6u
+  ad=2.7p pd=6.9u as=7.2p ps=8.4u
M1003 gnd A a_6_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
M1004 vdd A a_6_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=25.2p ps=28.2u
M1005 gnd B a_74_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=2.7p ps=6.9u
M1006 a_28_58# B gnd gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1007 Y A a_44_166# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=5.4p ps=12.9u
M1008 a_44_14# a_28_58# gnd gnd nfet w=6u l=0.6u
+  ad=2.7p pd=6.9u as=7.2p ps=8.4u
M1009 vdd B a_74_166# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=5.4p ps=12.9u
M1010 Y a_6_14# a_44_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=2.7p ps=6.9u
M1011 a_44_166# a_28_58# vdd vdd pfet w=12u l=0.6u
+  ad=5.4p pd=12.9u as=14.4p ps=14.4u
.ends

.subckt BUFX4 A Y vdd gnd
M1000 Y a_7_14# vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=15.3p ps=14.7u
M1001 gnd A a_7_14# gnd nfet w=4.5u l=0.6u
+  ad=7.65p pd=8.7u as=9.45p ps=13.2u
M1002 vdd a_7_14# Y vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=14.4p ps=14.4u
M1003 vdd A a_7_14# vdd pfet w=9u l=0.6u
+  ad=15.3p pd=14.7u as=18.9p ps=22.2u
M1004 Y a_7_14# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.65p ps=8.7u
M1005 gnd a_7_14# Y gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
.ends

.subckt INVX4 A Y vdd gnd
M1000 Y A vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=25.2p ps=28.2u
M1001 Y A gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
M1002 gnd A Y gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1003 vdd A Y vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=14.4p ps=14.4u
.ends

.subckt OAI21X1 A B C Y vdd gnd
M1000 Y C a_7_14# gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1001 a_30_146# A vdd vdd pfet w=12u l=0.6u
+  ad=3.6p pd=12.6u as=25.2p ps=28.2u
M1002 vdd C Y vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=14.4p ps=14.7u
M1003 gnd A a_7_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
M1004 Y B a_30_146# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.7u as=3.6p ps=12.6u
M1005 a_7_14# B gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
.ends

.subckt TBUFX2 A EN Y vdd gnd
M1000 vdd A a_44_166# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1001 Y a_22_14# a_44_166# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=25.2p ps=28.2u
M1002 a_22_14# EN vdd vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=25.2p ps=28.2u
M1003 gnd A a_44_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1004 a_44_14# A gnd gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1005 a_44_166# A vdd vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=14.4p ps=14.4u
M1006 a_44_166# a_22_14# Y vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1007 Y EN a_44_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
M1008 a_22_14# EN gnd gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=12.6p ps=16.2u
M1009 a_44_14# EN Y gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
.ends

.subckt DFFNEGX1 D CLK Q vdd gnd
M1000 a_163_14# a_7_14# a_153_14# gnd nfet w=3u l=0.6u
+  ad=3.6p pd=5.4u as=1.35p ps=3.9u
M1001 a_77_186# CLK a_57_14# vdd pfet w=6u l=0.6u
+  ad=3.6p pd=7.2u as=7.2p ps=8.4u
M1002 a_77_14# a_7_14# a_57_14# gnd nfet w=3u l=0.6u
+  ad=1.35p pd=3.9u as=3.6p ps=5.4u
M1003 vdd a_83_10# a_77_186# vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=3.6p ps=7.2u
M1004 vdd CLK a_7_14# vdd pfet w=12u l=0.6u
+  ad=12.15p pd=14.4u as=25.2p ps=28.2u
M1005 Q a_163_14# vdd vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=11.025p ps=14.4u
M1006 a_83_10# a_57_14# gnd gnd nfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=4.05p ps=5.7u
M1007 gnd CLK a_7_14# gnd nfet w=6u l=0.6u
+  ad=6.075p pd=8.4u as=12.6p ps=16.2u
M1008 gnd a_83_10# a_77_14# gnd nfet w=3u l=0.6u
+  ad=4.05p pd=5.7u as=1.35p ps=3.9u
M1009 vdd Q a_183_206# vdd pfet w=3u l=0.6u
+  ad=11.025p pd=14.4u as=1.35p ps=3.9u
M1010 a_154_186# a_83_10# vdd vdd pfet w=6u l=0.6u
+  ad=2.25p pd=6.75u as=12.6p ps=16.2u
M1011 a_183_14# CLK a_163_14# gnd nfet w=3u l=0.6u
+  ad=1.35p pd=3.9u as=3.6p ps=5.4u
M1012 a_45_186# D vdd vdd pfet w=6u l=0.6u
+  ad=3.6p pd=7.2u as=12.15p ps=14.4u
M1013 a_83_10# a_57_14# vdd vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1014 a_57_14# a_7_14# a_45_186# vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=3.6p ps=7.2u
M1015 gnd Q a_183_14# gnd nfet w=3u l=0.6u
+  ad=6.075p pd=8.4u as=1.35p ps=3.9u
M1016 a_183_206# a_7_14# a_163_14# vdd pfet w=3u l=0.6u
+  ad=1.35p pd=3.9u as=5.85p ps=8.4u
M1017 a_45_14# D gnd gnd nfet w=3u l=0.6u
+  ad=1.8p pd=4.2u as=6.075p ps=8.4u
M1018 a_57_14# CLK a_45_14# gnd nfet w=3u l=0.6u
+  ad=3.6p pd=5.4u as=1.8p ps=4.2u
M1019 a_153_14# a_83_10# gnd gnd nfet w=3u l=0.6u
+  ad=1.35p pd=3.9u as=6.3p ps=10.2u
M1020 Q a_163_14# gnd gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=6.075p ps=8.4u
M1021 a_163_14# CLK a_154_186# vdd pfet w=6u l=0.6u
+  ad=5.85p pd=8.4u as=2.25p ps=6.75u
.ends

.subckt AOI21X1 A B C Y vdd gnd
M1000 vdd A a_7_146# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=25.2p ps=28.2u
M1001 Y C a_7_146# vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=14.4p ps=14.4u
M1002 a_28_14# A gnd gnd nfet w=6u l=0.6u
+  ad=1.8p pd=6.6u as=12.6p ps=16.2u
M1003 Y B a_28_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.7u as=1.8p ps=6.6u
M1004 a_7_146# B vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1005 gnd C Y gnd nfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=7.2p ps=8.7u
.ends

.subckt BUFX2 A Y vdd gnd
M1000 Y a_7_14# vdd vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=14.4p ps=14.7u
M1001 gnd A a_7_14# gnd nfet w=3u l=0.6u
+  ad=7.2p pd=8.7u as=6.3p ps=10.2u
M1002 Y a_7_14# gnd gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.7u
M1003 vdd A a_7_14# vdd pfet w=6u l=0.6u
+  ad=14.4p pd=14.7u as=12.6p ps=16.2u
.ends

.subckt INVX2 A Y vdd gnd
M1000 Y A vdd vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=25.2p ps=28.2u
M1001 Y A gnd gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=12.6p ps=16.2u
.ends

.subckt FAX1 A B C YS YC vdd gnd
M1000 a_64_14# C a_6_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1001 YS a_174_14# vdd vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=14.13p ps=16.8u
M1002 a_206_14# B a_196_14# gnd nfet w=6u l=0.6u
+  ad=2.7p pd=6.9u as=2.7p ps=6.9u
M1003 gnd a_64_14# YC gnd nfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=6.3p ps=10.2u
M1004 gnd A a_206_14# gnd nfet w=6u l=0.6u
+  ad=5.85p pd=8.4u as=2.7p ps=6.9u
M1005 vdd A a_206_150# vdd pfet w=14.4u l=0.6u
+  ad=14.13p pd=16.8u as=6.48p ps=15.3u
M1006 gnd A a_6_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
M1007 a_114_14# C gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1008 a_64_14# C a_6_166# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1009 vdd A a_6_166# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=25.2p ps=28.2u
M1010 a_84_14# B a_64_14# gnd nfet w=6u l=0.6u
+  ad=2.7p pd=6.9u as=7.2p ps=8.4u
M1011 a_174_14# a_64_14# a_114_166# vdd pfet w=10.8u l=0.6u
+  ad=17.82p pd=17.1u as=12.96p ps=13.2u
M1012 vdd B a_114_166# vdd pfet w=10.8u l=0.6u
+  ad=12.96p pd=13.2u as=13.86p ps=14.4u
M1013 a_196_150# C a_174_14# vdd pfet w=14.4u l=0.6u
+  ad=6.48p pd=15.3u as=17.82p ps=17.1u
M1014 a_206_150# B a_196_150# vdd pfet w=14.4u l=0.6u
+  ad=6.48p pd=15.3u as=6.48p ps=15.3u
M1015 gnd A a_84_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=2.7p ps=6.9u
M1016 vdd A a_84_166# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=5.4p ps=12.9u
M1017 a_114_14# A gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1018 YS a_174_14# gnd gnd nfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=5.85p ps=8.4u
M1019 a_174_14# a_64_14# a_114_14# gnd nfet w=6u l=0.6u
+  ad=8.1p pd=8.7u as=7.2p ps=8.4u
M1020 a_6_14# B gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1021 YC a_64_14# vdd vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=12.6p ps=16.2u
M1022 a_84_166# B a_64_14# vdd pfet w=12u l=0.6u
+  ad=5.4p pd=12.9u as=14.4p ps=14.4u
M1023 a_6_166# B vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1024 a_114_166# A vdd vdd pfet w=12u l=0.6u
+  ad=13.86p pd=14.4u as=14.4p ps=14.4u
M1025 a_114_166# C vdd vdd pfet w=10.8u l=0.6u
+  ad=12.96p pd=13.2u as=12.96p ps=13.2u
M1026 gnd B a_114_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1027 a_196_14# C a_174_14# gnd nfet w=6u l=0.6u
+  ad=2.7p pd=6.9u as=8.1p ps=8.7u
.ends

.subckt NOR2X1 A B Y vdd gnd
M1000 a_25_146# A vdd vdd pfet w=12u l=0.6u
+  ad=3.6p pd=12.6u as=25.2p ps=28.2u
M1001 Y A gnd gnd nfet w=3u l=0.6u
+  ad=3.6p pd=5.4u as=6.3p ps=10.2u
M1002 Y B a_25_146# vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=3.6p ps=12.6u
M1003 gnd B Y gnd nfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=3.6p ps=5.4u
.ends

.subckt AND2X1 A B Y vdd gnd
M1000 gnd B a_25_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.7u as=1.8p ps=6.6u
M1001 a_25_14# A a_7_14# gnd nfet w=6u l=0.6u
+  ad=1.8p pd=6.6u as=12.6p ps=16.2u
M1002 vdd B a_7_14# vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1003 Y a_7_14# gnd gnd nfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=7.2p ps=8.7u
M1004 Y a_7_14# vdd vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1005 a_7_14# A vdd vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
.ends

.subckt DFFPOSX1 D CLK Q vdd gnd
M1000 vdd Q a_189_206# vdd pfet w=3u l=0.6u
+  ad=10.125p pd=14.7u as=0.9p ps=3.6u
M1001 a_83_186# a_11_14# a_59_14# vdd pfet w=6u l=0.6u
+  ad=3.6p pd=7.2u as=7.2p ps=8.4u
M1002 a_87_10# a_59_14# gnd gnd nfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=4.05p ps=5.7u
M1003 gnd CLK a_11_14# gnd nfet w=6u l=0.6u
+  ad=5.85p pd=8.4u as=12.6p ps=16.2u
M1004 gnd a_87_10# a_81_14# gnd nfet w=3u l=0.6u
+  ad=4.05p pd=5.7u as=1.35p ps=3.9u
M1005 a_159_14# a_87_10# gnd gnd nfet w=3u l=0.6u
+  ad=0.9p pd=3.6u as=6.3p ps=10.2u
M1006 a_49_186# D vdd vdd pfet w=6u l=0.6u
+  ad=4.5p pd=7.5u as=11.25p ps=14.4u
M1007 vdd a_87_10# a_83_186# vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=3.6p ps=7.2u
M1008 Q a_167_14# gnd gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=6.975p ps=8.7u
M1009 Q a_167_14# vdd vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=10.125p ps=14.7u
M1010 a_167_14# CLK a_159_14# gnd nfet w=3u l=0.6u
+  ad=3.6p pd=5.4u as=0.9p ps=3.6u
M1011 a_49_14# D gnd gnd nfet w=3u l=0.6u
+  ad=1.35p pd=3.9u as=5.85p ps=8.4u
M1012 a_87_10# a_59_14# vdd vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1013 a_59_14# CLK a_49_186# vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=4.5p ps=7.5u
M1014 a_161_186# a_87_10# vdd vdd pfet w=6u l=0.6u
+  ad=1.8p pd=6.6u as=12.6p ps=16.2u
M1015 a_189_206# CLK a_167_14# vdd pfet w=3u l=0.6u
+  ad=0.9p pd=3.6u as=6.075p ps=8.4u
M1016 a_59_14# a_11_14# a_49_14# gnd nfet w=3u l=0.6u
+  ad=4.05p pd=5.7u as=1.35p ps=3.9u
M1017 a_187_14# a_11_14# a_167_14# gnd nfet w=3u l=0.6u
+  ad=1.35p pd=3.9u as=3.6p ps=5.4u
M1018 vdd CLK a_11_14# vdd pfet w=12u l=0.6u
+  ad=11.25p pd=14.4u as=25.2p ps=28.2u
M1019 gnd Q a_187_14# gnd nfet w=3u l=0.6u
+  ad=6.975p pd=8.7u as=1.35p ps=3.9u
M1020 a_167_14# a_11_14# a_161_186# vdd pfet w=6u l=0.6u
+  ad=6.075p pd=8.4u as=1.8p ps=6.6u
M1021 a_81_14# CLK a_59_14# gnd nfet w=3u l=0.6u
+  ad=1.35p pd=3.9u as=4.05p ps=5.7u
.ends

.subckt NAND2X1 A B Y vdd gnd
M1000 a_27_14# A gnd gnd nfet w=6u l=0.6u
+  ad=2.7p pd=6.9u as=12.6p ps=16.2u
M1001 Y B a_27_14# gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=2.7p ps=6.9u
M1002 vdd B Y vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1003 Y A vdd vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
.ends

.subckt OR2X1 A B Y vdd gnd
M1000 Y a_7_146# gnd gnd nfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=3.6p ps=5.4u
M1001 a_25_146# A a_7_146# vdd pfet w=12u l=0.6u
+  ad=5.4p pd=12.9u as=25.2p ps=28.2u
M1002 a_7_146# A gnd gnd nfet w=3u l=0.6u
+  ad=3.6p pd=5.4u as=6.3p ps=10.2u
M1003 Y a_7_146# vdd vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=14.4p ps=14.7u
M1004 gnd B a_7_146# gnd nfet w=3u l=0.6u
+  ad=3.6p pd=5.4u as=3.6p ps=5.4u
M1005 vdd B a_25_146# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.7u as=5.4p ps=12.9u
.ends

.subckt CLKBUF2 A Y vdd gnd
M1000 a_145_14# a_105_14# vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1001 a_65_14# a_25_14# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1002 a_105_14# a_65_14# vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1003 a_145_14# a_105_14# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1004 gnd a_145_14# a_185_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1005 a_25_14# A vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=25.2p ps=28.2u
M1006 a_65_14# a_25_14# vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1007 Y a_185_14# vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1008 a_25_14# A gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
M1009 gnd a_25_14# a_65_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1010 a_105_14# a_65_14# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1011 gnd a_105_14# a_145_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1012 vdd a_65_14# a_105_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1013 vdd a_105_14# a_145_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1014 Y a_185_14# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1015 vdd a_25_14# a_65_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1016 gnd A a_25_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1017 vdd A a_25_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1018 vdd a_185_14# Y vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=14.4p ps=14.4u
M1019 vdd a_145_14# a_185_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1020 gnd a_65_14# a_105_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1021 a_185_14# a_145_14# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1022 gnd a_185_14# Y gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1023 a_185_14# a_145_14# vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
.ends

.subckt LATCH D CLK Q vdd gnd
M1000 a_48_206# D vdd vdd pfet w=6u l=0.6u
+  ad=2.7p pd=6.9u as=14.4p ps=14.7u
M1001 a_86_226# CLK a_58_14# vdd pfet w=3u l=0.6u
+  ad=1.35p pd=3.9u as=9.225p ps=9.6u
M1002 gnd CLK a_8_14# gnd nfet w=6u l=0.6u
+  ad=6.3p pd=8.4u as=12.6p ps=16.2u
M1003 a_86_14# a_8_14# a_58_14# gnd nfet w=3u l=0.6u
+  ad=1.35p pd=3.9u as=5.4p ps=6.6u
M1004 Q a_58_14# gnd gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.7u
M1005 gnd Q a_86_14# gnd nfet w=3u l=0.6u
+  ad=7.2p pd=8.7u as=1.35p ps=3.9u
M1006 a_46_14# D gnd gnd nfet w=3u l=0.6u
+  ad=1.8p pd=4.2u as=6.3p ps=8.4u
M1007 Q a_58_14# vdd vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=13.5p ps=14.7u
M1008 a_58_14# CLK a_46_14# gnd nfet w=3u l=0.6u
+  ad=5.4p pd=6.6u as=1.8p ps=4.2u
M1009 vdd CLK a_8_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.7u as=25.2p ps=28.2u
M1010 a_58_14# a_8_14# a_48_206# vdd pfet w=6u l=0.6u
+  ad=9.225p pd=9.6u as=2.7p ps=6.9u
M1011 vdd Q a_86_226# vdd pfet w=3u l=0.6u
+  ad=13.5p pd=14.7u as=1.35p ps=3.9u
.ends

.subckt HAX1 A B YS YC vdd gnd
M1000 a_6_206# B a_24_14# gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=1.8p ps=6.6u
M1001 vdd a_6_206# YC vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
M1002 gnd a_6_206# YC gnd nfet w=3u l=0.6u
+  ad=6.075p pd=8.4u as=6.21p ps=10.2u
M1003 a_24_14# A gnd gnd nfet w=6u l=0.6u
+  ad=1.8p pd=6.6u as=12.6p ps=16.2u
M1004 a_6_206# B vdd vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1005 a_128_166# B a_108_206# vdd pfet w=12u l=0.6u
+  ad=3.6p pd=12.6u as=13.5p ps=14.4u
M1006 a_108_206# a_6_206# vdd vdd pfet w=6u l=0.6u
+  ad=13.5p pd=14.4u as=7.2p ps=8.4u
M1007 YS a_108_206# gnd gnd nfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=6.3p ps=10.2u
M1008 a_96_14# a_6_206# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=6.075p ps=8.4u
M1009 a_108_206# B a_96_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1010 vdd A a_128_166# vdd pfet w=12u l=0.6u
+  ad=11.25p pd=14.4u as=3.6p ps=12.6u
M1011 YS a_108_206# vdd vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=11.25p ps=14.4u
M1012 a_96_14# A a_108_206# gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1013 vdd A a_6_206# vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
.ends

.subckt DFFSR R S D CLK Q vdd gnd
M1000 a_146_14# a_122_10# a_60_10# vdd pfet w=3u l=0.6u
+  ad=6.3p pd=8.4u as=3.6p ps=5.4u
M1001 a_64_14# a_60_10# gnd gnd nfet w=6u l=0.6u
+  ad=3.6p pd=7.2u as=9p ps=9u
M1002 vdd S a_301_14# vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1003 a_146_14# a_115_95# a_60_10# gnd nfet w=3u l=0.6u
+  ad=3.6p pd=5.4u as=3.6p ps=5.4u
M1004 a_36_10# a_60_10# vdd vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1005 a_391_14# a_334_14# gnd gnd nfet w=6u l=0.6u
+  ad=3.6p pd=7.2u as=9.45p ps=9.15u
M1006 a_8_14# R vdd vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
M1007 a_36_10# S a_64_14# gnd nfet w=6u l=0.6u
+  ad=14.4p pd=16.8u as=3.6p ps=7.2u
M1008 gnd a_334_14# Q gnd nfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=6.3p ps=10.2u
M1009 a_281_14# a_122_10# a_36_10# gnd nfet w=3u l=0.6u
+  ad=3.6p pd=5.4u as=6.3p ps=10.2u
M1010 a_28_14# R a_8_14# gnd nfet w=6u l=0.6u
+  ad=3.6p pd=7.2u as=14.4p ps=16.8u
M1011 a_301_14# S a_391_14# gnd nfet w=6u l=0.6u
+  ad=14.4p pd=16.8u as=3.6p ps=7.2u
M1012 gnd a_36_10# a_28_14# gnd nfet w=6u l=0.6u
+  ad=9p pd=9u as=3.6p ps=7.2u
M1013 gnd a_115_95# a_122_10# gnd nfet w=3u l=0.6u
+  ad=3.6p pd=5.4u as=6.3p ps=10.2u
M1014 a_301_14# a_334_14# vdd vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1015 vdd D a_146_14# vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=6.3p ps=8.4u
M1016 a_334_14# a_281_14# vdd vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
M1017 vdd a_115_95# a_122_10# vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
M1018 a_301_14# a_122_10# a_281_14# vdd pfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=3.6p ps=5.4u
M1019 gnd D a_146_14# gnd nfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=3.6p ps=5.4u
M1020 a_60_10# a_115_95# a_8_14# vdd pfet w=3u l=0.6u
+  ad=3.6p pd=5.4u as=6.3p ps=10.2u
M1021 a_301_14# a_115_95# a_281_14# gnd nfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=3.6p ps=5.4u
M1022 vdd S a_36_10# vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1023 vdd a_36_10# a_8_14# vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1024 a_115_95# CLK gnd gnd nfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=3.6p ps=5.4u
M1025 a_60_10# a_122_10# a_8_14# gnd nfet w=3u l=0.6u
+  ad=3.6p pd=5.4u as=6.3p ps=10.2u
M1026 a_354_14# a_281_14# a_334_14# gnd nfet w=6u l=0.6u
+  ad=3.6p pd=7.2u as=14.4p ps=16.8u
M1027 vdd R a_334_14# vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1028 a_115_95# CLK vdd vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1029 a_281_14# a_115_95# a_36_10# vdd pfet w=3u l=0.6u
+  ad=3.6p pd=5.4u as=6.3p ps=10.2u
M1030 gnd R a_354_14# gnd nfet w=6u l=0.6u
+  ad=9.45p pd=9.15u as=3.6p ps=7.2u
M1031 vdd a_334_14# Q vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=12.6p ps=16.2u
.ends

.subckt TBUFX1 A EN Y vdd gnd
M1000 a_68_166# a_26_14# Y vdd pfet w=12u l=0.6u
+  ad=5.4p pd=12.9u as=25.2p ps=28.2u
M1001 gnd A a_68_14# gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=2.7p ps=6.9u
M1002 a_26_14# EN gnd gnd nfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=6.3p ps=10.2u
M1003 a_26_14# EN vdd vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=12.6p ps=16.2u
M1004 vdd A a_68_166# vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=5.4p ps=12.9u
M1005 a_68_14# EN Y gnd nfet w=6u l=0.6u
+  ad=2.7p pd=6.9u as=12.6p ps=16.2u
.ends

.subckt XNOR2X1 A B Y vdd gnd
M1000 a_74_166# A Y vdd pfet w=12u l=0.6u
+  ad=3.6p pd=12.6u as=14.4p ps=14.4u
M1001 a_29_58# B vdd vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=16.2p ps=14.7u
M1002 gnd A a_6_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
M1003 vdd A a_6_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=25.2p ps=28.2u
M1004 Y A a_44_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=1.8p ps=6.6u
M1005 a_29_58# B gnd gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=8.1p ps=8.7u
M1006 vdd B a_74_166# vdd pfet w=12u l=0.6u
+  ad=16.2p pd=14.7u as=3.6p ps=12.6u
M1007 Y a_6_14# a_44_166# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=5.4p ps=12.9u
M1008 a_44_14# a_29_58# gnd gnd nfet w=6u l=0.6u
+  ad=1.8p pd=6.6u as=7.2p ps=8.4u
M1009 a_72_14# a_6_14# Y gnd nfet w=6u l=0.6u
+  ad=2.7p pd=6.9u as=7.2p ps=8.4u
M1010 a_44_166# a_29_58# vdd vdd pfet w=12u l=0.6u
+  ad=5.4p pd=12.9u as=14.4p ps=14.4u
M1011 gnd B a_72_14# gnd nfet w=6u l=0.6u
+  ad=8.1p pd=8.7u as=2.7p ps=6.9u
.ends

.subckt AND2X2 A B Y vdd gnd
M1000 a_25_14# A a_7_14# gnd nfet w=6u l=0.6u
+  ad=2.7p pd=6.9u as=12.6p ps=16.2u
M1001 gnd B a_25_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=2.7p ps=6.9u
M1002 vdd B a_7_14# vdd pfet w=6u l=0.6u
+  ad=14.4p pd=14.7u as=8.1p ps=8.7u
M1003 Y a_7_14# gnd gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1004 Y a_7_14# vdd vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=14.4p ps=14.7u
M1005 a_7_14# A vdd vdd pfet w=6u l=0.6u
+  ad=8.1p pd=8.7u as=12.6p ps=16.2u
.ends

.subckt INVX1 A Y vdd gnd
M1000 Y A gnd gnd nfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=6.3p ps=10.2u
M1001 Y A vdd vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=12.6p ps=16.2u
.ends

.subckt OAI22X1 A B C D Y vdd gnd
M1000 Y D a_7_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1001 a_25_146# A vdd vdd pfet w=12u l=0.6u
+  ad=5.4p pd=12.9u as=25.2p ps=28.2u
M1002 a_65_146# D Y vdd pfet w=12u l=0.6u
+  ad=5.4p pd=12.9u as=23.4p ps=15.9u
M1003 gnd A a_7_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
M1004 a_7_14# C Y gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1005 a_7_14# B gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1006 Y B a_25_146# vdd pfet w=12u l=0.6u
+  ad=23.4p pd=15.9u as=5.4p ps=12.9u
M1007 vdd C a_65_146# vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=5.4p ps=12.9u
.ends

.subckt OR2X2 A B Y vdd gnd
M1000 Y a_7_146# gnd gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=6.3p ps=8.4u
M1001 a_25_146# A a_7_146# vdd pfet w=12u l=0.6u
+  ad=5.4p pd=12.9u as=25.2p ps=28.2u
M1002 a_7_146# A gnd gnd nfet w=3u l=0.6u
+  ad=3.6p pd=5.4u as=6.3p ps=10.2u
M1003 Y a_7_146# vdd vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=14.4p ps=14.4u
M1004 gnd B a_7_146# gnd nfet w=3u l=0.6u
+  ad=6.3p pd=8.4u as=3.6p ps=5.4u
M1005 vdd B a_25_146# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=5.4p ps=12.9u
.ends

.subckt khu_etri050_stdcells vdd gnd
XAOI22X1_0 AOI22X1_0/A AOI22X1_0/B AOI22X1_0/C AOI22X1_0/D AOI22X1_0/Y vdd gnd AOI22X1
XCLKBUF3_0 CLKBUF3_0/A CLKBUF3_0/Y vdd gnd CLKBUF3
XINVX8_0 INVX8_0/A INVX8_0/Y vdd gnd INVX8
XNOR3X1_0 NOR3X1_0/A NOR3X1_0/B NOR3X1_0/C NOR3X1_0/Y vdd gnd NOR3X1
XCLKBUF1_0 CLKBUF1_0/A CLKBUF1_0/Y vdd gnd CLKBUF1
XMUX2X1_0 MUX2X1_0/A MUX2X1_0/B MUX2X1_0/S MUX2X1_0/Y vdd gnd MUX2X1
XNAND3X1_0 NAND3X1_0/A NAND3X1_0/B NAND3X1_0/C NAND3X1_0/Y vdd gnd NAND3X1
XXOR2X1_0 XOR2X1_0/A XOR2X1_0/B XOR2X1_0/Y vdd gnd XOR2X1
XBUFX4_0 BUFX4_0/A BUFX4_0/Y vdd gnd BUFX4
XINVX4_0 INVX4_0/A INVX4_0/Y vdd gnd INVX4
XOAI21X1_0 OAI21X1_0/A OAI21X1_0/B OAI21X1_0/C OAI21X1_0/Y vdd gnd OAI21X1
XTBUFX2_0 TBUFX2_0/A TBUFX2_0/EN TBUFX2_0/Y vdd gnd TBUFX2
XDFFNEGX1_0 DFFNEGX1_0/D DFFNEGX1_0/CLK DFFNEGX1_0/Q vdd gnd DFFNEGX1
XAOI21X1_0 AOI21X1_0/A AOI21X1_0/B AOI21X1_0/C AOI21X1_0/Y vdd gnd AOI21X1
XBUFX2_0 BUFX2_0/A BUFX2_0/Y vdd gnd BUFX2
XINVX2_0 INVX2_0/A INVX2_0/Y vdd gnd INVX2
XFAX1_0 FAX1_0/A FAX1_0/B FAX1_0/C FAX1_0/YS FAX1_0/YC vdd gnd FAX1
XNOR2X1_0 NOR2X1_0/A NOR2X1_0/B NOR2X1_0/Y vdd gnd NOR2X1
XAND2X1_0 AND2X1_0/A AND2X1_0/B AND2X1_0/Y vdd gnd AND2X1
XDFFPOSX1_0 DFFPOSX1_0/D DFFPOSX1_0/CLK DFFPOSX1_0/Q vdd gnd DFFPOSX1
XNAND2X1_0 NAND2X1_0/A NAND2X1_0/B NAND2X1_0/Y vdd gnd NAND2X1
XOR2X1_0 OR2X1_0/A OR2X1_0/B OR2X1_0/Y vdd gnd OR2X1
XCLKBUF2_0 CLKBUF2_0/A CLKBUF2_0/Y vdd gnd CLKBUF2
XLATCH_0 LATCH_0/D LATCH_0/CLK LATCH_0/Q vdd gnd LATCH
XHAX1_0 HAX1_0/A HAX1_0/B HAX1_0/YS HAX1_0/YC vdd gnd HAX1
XDFFSR_0 DFFSR_0/R DFFSR_0/S DFFSR_0/D DFFSR_0/CLK DFFSR_0/Q vdd gnd DFFSR
XTBUFX1_0 TBUFX1_0/A TBUFX1_0/EN TBUFX1_0/Y vdd gnd TBUFX1
XXNOR2X1_0 XNOR2X1_0/A XNOR2X1_0/B XNOR2X1_0/Y vdd gnd XNOR2X1
XAND2X2_0 AND2X2_0/A AND2X2_0/B AND2X2_0/Y vdd gnd AND2X2
XINVX1_0 INVX1_0/A INVX1_0/Y vdd gnd INVX1
XOAI22X1_0 OAI22X1_0/A OAI22X1_0/B OAI22X1_0/C OAI22X1_0/D OAI22X1_0/Y vdd gnd OAI22X1
XOR2X2_0 OR2X2_0/A OR2X2_0/B OR2X2_0/Y vdd gnd OR2X2
.ends

** End of included library /usr/local/share/qflow/tech/etri050/etri050_stdcells.sp

.subckt bricks_out vdd gnd clk reset v_sync pixel p_tick
+ btn_left btn_right game_over game_complete game_new 

XFILL_0__1241_ gnd vdd FILL
XFILL_1__1402_ gnd vdd FILL
X_1257_ _422_ _408_ _326_ _325_ vdd gnd NAND3X1
X_800_ _533_ _714_ _716_ _713_ _717_ vdd 
+ gnd
+ OAI22X1
X_1486_ _656_ _u_ctrl.State_3_bF$buf0_ _633_ _632_ vdd gnd AOI21X1
X_1066_ _u_ball.x_ball_[3] _321_ _299_ vdd gnd NAND2X1
XFILL_0__1106_ gnd vdd FILL
XFILL77850x3750 gnd vdd FILL
X_1295_ _u_ball.x_pos_[0] _360_ vdd gnd INVX1
XFILL_0__1335_ gnd vdd FILL
XFILL_0__1144_ gnd vdd FILL
XFILL_0__1373_ gnd vdd FILL
X_1389_ _677__bF$buf0 vdd _691_ clk_bF$buf7 game_init vdd 
+ gnd
+ DFFSR
XFILL_0__1429_ gnd vdd FILL
XFILL_0__1009_ gnd vdd FILL
XFILL_0__1182_ gnd vdd FILL
X_932_ _u_ball.sign_y_ _60_ _58_ vdd gnd NOR2X1
XFILL77550x61350 gnd vdd FILL
X_1198_ _127_ _168_ _u_ball.x_pos_[6] _126_ vdd gnd AOI21X1
X_1410_ _u_ctrl.State_3_bF$buf3_ _657_ _576_ vdd gnd NAND2X1
X_741_ _476__bF$buf2 vdd _472_ clk_bF$buf1 _u_ball.x_ball_[6] vdd 
+ gnd
+ DFFSR
XFILL_0__1467_ gnd vdd FILL
XFILL_0__1047_ gnd vdd FILL
X_970_ _209_ _206_ _205_ vdd gnd AND2X2
XFILL_0__1276_ gnd vdd FILL
XFILL_0__1085_ gnd vdd FILL
X_1504_ _649_ _648_ vdd gnd INVX1
X_835_ _556_ _558_ _559_ vdd gnd NOR2X1
X_1313_ _u_ball.x_paddle_[2] _379_ _378_ vdd gnd NAND2X1
X_1122_ vdd _176_ _171_ clk_bF$buf6 _u_bricks.regBricks_[10] vdd 
+ gnd
+ DFFSR
X_873_ _38_ _34_ _516_ _518_ vdd gnd AOI21X1
XFILL_0__926_ gnd vdd FILL
X_929_ _63_ _57_ _56_ _55_ vdd gnd NAND3X1
X_1351_ _u_ball.x_paddle_[2] _431_ _412_ vdd gnd NAND2X1
X_1407_ _u_ball.x_pos_[5] _576_ _574_ _670_ vdd gnd OAI21X1
XFILL_0__735_ gnd vdd FILL
X_738_ _476__bF$buf0 vdd _471_ clk_bF$buf2 _726_ vdd 
+ gnd
+ DFFSR
XFILL_1__1149_ gnd vdd FILL
X_1160_ _u_bricks.regBricks_[8] _u_bricks.regBricks_[14] _89_ vdd gnd NOR2X1
XFILL_0__1200_ gnd vdd FILL
X_1216_ _u_bricks.regBricks_[2] _140_ vdd gnd INVX1
XFILL_0__964_ gnd vdd FILL
X_967_ _u_ball.y_ball_[0] _203_ vdd gnd INVX2
X_1445_ _u_ctrl.State_[0] _599_ vdd gnd INVX1
X_1025_ _u_ball.x_ball_[5] _u_ball.x_ball_[4] _259_ _258_ vdd gnd NAND3X1
XFILL_0__773_ gnd vdd FILL
X_776_ _467_ _313_ _11_ vdd gnd NAND2X1
XFILL_1__980_ gnd vdd FILL
XFILL_0__829_ gnd vdd FILL
X_1254_ _437_ vdd _439_ clk_bF$buf0 _u_ball.x_paddle_[1] vdd 
+ gnd
+ DFFSR
X_1483_ _u_ball.y_pos_[1] _630_ vdd gnd INVX1
X_1063_ _297_ _319_ _320_ _296_ vdd gnd NAND3X1
XFILL_0__1523_ gnd vdd FILL
XFILL_0__1103_ gnd vdd FILL
X_1119_ vdd _176_ _182_ clk_bF$buf6 _u_bricks.regBricks_[2] vdd 
+ gnd
+ DFFSR
XFILL_0__867_ gnd vdd FILL
X_1292_ _366_ _358_ _365_ _357_ vdd gnd AOI21X1
XFILL_0__1332_ gnd vdd FILL
X_1348_ _426_ _416_ _415_ _409_ vdd gnd AOI21X1
XFILL_1__883_ gnd vdd FILL
X_1157_ _u_bricks.regBricks_[5] _86_ vdd gnd INVX1
X_1386_ vdd _677__bF$buf2 _672_ clk_bF$buf2 _u_ball.x_pos_[3] vdd 
+ gnd
+ DFFSR
XFILL_0__1426_ gnd vdd FILL
X_1195_ _u_bricks.regBricks_[11] _u_ball.x_pos_[3] _123_ vdd gnd NAND2X1
XFILL_1__977_ gnd vdd FILL
XFILL_1__786_ gnd vdd FILL
XFILL_0__1464_ gnd vdd FILL
X_1289_ _u_ball.x_pos_[5] _354_ vdd gnd INVX1
X_1501_ _647_ _648_ _646_ _645_ vdd gnd OAI21X1
X_832_ _561_ _542_ _562_ vdd gnd NAND2X1
XFILL_1__1243_ gnd vdd FILL
X_1098_ _449_ _450_ _448_ vdd gnd NOR2X1
X_1310_ _u_ball.x_pos_[3] _375_ vdd gnd INVX1
XFILL_1__1108_ gnd vdd FILL
XFILL_1__901_ gnd vdd FILL
XFILL77550x14550 gnd vdd FILL
X_870_ _522_ _514_ _523_ vdd gnd NAND2X1
XFILL_1__1281_ gnd vdd FILL
XFILL_0__1176_ gnd vdd FILL
XFILL_0__923_ gnd vdd FILL
X_926_ _60_ _235_ _53_ _55_ _481_ vdd 
+ gnd
+ AOI22X1
XFILL_1__1090_ gnd vdd FILL
X_1404_ _u_ctrl.cnt_v_sync_[0] _571_ vdd gnd INVX1
X_735_ _0_ game_complete vdd gnd BUFX2
XFILL_1__1146_ gnd vdd FILL
X_1213_ _u_bricks.regBricks_[7] _138_ vdd gnd INVX1
X_964_ _u_ball.y_ball_[1] _201_ vdd gnd INVX1
X_1442_ _636_ _600_ _598_ _517_ vdd gnd OAI21X1
X_1022_ _257_ _256_ _255_ vdd gnd AND2X2
XFILL_0__770_ gnd vdd FILL
XFILL_1__804_ gnd vdd FILL
X_773_ _13_ _10_ _14_ vdd gnd NAND2X1
XFILL_0__1079_ gnd vdd FILL
XFILL_0__826_ gnd vdd FILL
X_829_ _523_ _48_ _508_ _566_ vdd gnd AOI21X1
X_1251_ _437_ vdd _442_ clk_bF$buf1 _u_ball.x_paddle_[6] vdd 
+ gnd
+ DFFSR
X_1307_ _374_ _373_ _372_ vdd gnd NOR2X1
X_1480_ _628_ _629_ _u_ctrl.State_3_bF$buf2_ _627_ vdd gnd OAI21X1
X_1060_ _312_ _308_ _294_ _293_ vdd gnd NAND3X1
X_1116_ _u_ball.hit_paddle_ _466_ vdd gnd INVX1
X_867_ _u_ball.x_ball_[1] _501_ _526_ vdd gnd NAND2X1
XFILL_1__1278_ gnd vdd FILL
X_1345_ _421_ _431_ _406_ vdd gnd NOR2X1
X_1154_ _86_ _85_ _84_ _83_ vdd gnd NAND3X1
X_1383_ vdd _677__bF$buf2 _687_ clk_bF$buf5 _u_ball.x_pos_[6] vdd 
+ gnd
+ DFFSR
X_1439_ _u_ctrl.State_[1] _663_ _595_ vdd gnd NAND2X1
X_1019_ _263_ _465_ _253_ _252_ vdd gnd AOI21X1
X_1192_ _154_ _129_ _121_ _120_ vdd gnd OAI21X1
XFILL_0__1232_ gnd vdd FILL
X_1248_ _u_ball.x_ball_[4] _167_ vdd gnd INVX1
XFILL_0__996_ gnd vdd FILL
X_999_ game_init _u_ball.hit_paddle_ _234_ _233_ vdd gnd OAI21X1
X_1477_ _u_ball.y_pos_[2] _625_ vdd gnd INVX1
X_1057_ _460_ _459_ _291_ _290_ vdd gnd NOR3X1
XFILL78450x7350 gnd vdd FILL
XFILL_1__1431_ gnd vdd FILL
XFILL_1__1011_ gnd vdd FILL
XFILL78450x10950 gnd vdd FILL
X_1286_ _u_ball.x_paddle_[6] _352_ _351_ vdd gnd NOR2X1
XFILL_0__1326_ gnd vdd FILL
XFILL_0_CLKBUF1_insert10 gnd vdd FILL
X_1095_ _u_ball.x_ball_[1] _u_ball.x_paddle_[1] _445_ vdd gnd OR2X2
XFILL_0__1135_ gnd vdd FILL
XFILL_0__899_ gnd vdd FILL
XFILL_0__1364_ gnd vdd FILL
XFILL_1__1525_ gnd vdd FILL
XFILL_0__1173_ gnd vdd FILL
X_923_ _444_ _51_ _227_ _202_ _480_ vdd 
+ gnd
+ OAI22X1
X_1189_ _u_bricks.regBricks_[6] _133_ _117_ vdd gnd NAND2X1
XFILL_0__1229_ gnd vdd FILL
X_1401_ _572_ _569_ _592_ _573_ _669_ vdd 
+ gnd
+ AOI22X1
X_732_ _728_ pixel vdd gnd BUFX2
XFILL_0__1458_ gnd vdd FILL
XFILL_0__1038_ gnd vdd FILL
X_1210_ _160_ _152_ _136_ vdd gnd NOR2X1
X_961_ _u_ball.y_ball_[1] _u_ball.sign_y_ _198_ vdd gnd NOR2X1
XFILL_0__1267_ gnd vdd FILL
X_770_ _15_ _16_ _9_ _17_ vdd gnd NAND3X1
XFILL_0__1496_ gnd vdd FILL
XFILL_0__1076_ gnd vdd FILL
X_826_ _679_ _530_ _681_ vdd gnd AND2X2
X_1304_ _413_ _u_ball.x_pos_[1] _370_ _369_ vdd gnd OAI21X1
X_1113_ _u_ball.x_paddle_[1] _u_ball.x_paddle_[2] _u_ball.x_paddle_[3] _463_ vdd gnd NAND3X1
X_864_ _526_ _506_ _50_ _529_ vdd gnd AOI21X1
XFILL_0__917_ gnd vdd FILL
X_1342_ _420_ _407_ _404_ _403_ vdd gnd OAI21X1
XFILL_0__1399_ gnd vdd FILL
X_1151_ _135_ _82_ _81_ _80_ vdd gnd NAND3X1
X_1207_ _144_ _141_ _135_ _179_ vdd gnd AOI21X1
XFILL_0__955_ gnd vdd FILL
X_958_ _u_ball.y_ball_[0] _197_ _196_ _195_ vdd gnd OAI21X1
X_1380_ _677__bF$buf3 vdd _669_ clk_bF$buf2 _u_ctrl.cnt_v_sync_[1] vdd 
+ gnd
+ DFFSR
XFILL_0__1420_ gnd vdd FILL
XFILL_0__1000_ gnd vdd FILL
X_1436_ _u_ctrl.State_[1] _u_ctrl.State_[2] _597_ _594_ vdd gnd OAI21X1
X_1016_ _u_ball.x_ball_[6] _268_ _457_ _314_ _249_ vdd 
+ gnd
+ OAI22X1
XFILL_0__764_ gnd vdd FILL
X_767_ _726_ _19_ vdd gnd INVX1
XFILL_1__1178_ gnd vdd FILL
X_1245_ _u_ball.x_ball_[6] _164_ vdd gnd INVX1
XFILL_0__993_ gnd vdd FILL
X_996_ game_init _231_ _230_ vdd gnd NOR2X1
X_1474_ _624_ _623_ _u_ctrl.State_3_bF$buf2_ _622_ vdd gnd OAI21X1
X_1054_ _290_ _288_ _287_ vdd gnd NOR2X1
XFILL_1__836_ gnd vdd FILL
XFILL_0__1514_ gnd vdd FILL
XFILL_0__858_ gnd vdd FILL
X_1283_ _419_ _353_ _349_ _348_ vdd gnd AOI21X1
XFILL_0__1323_ gnd vdd FILL
X_1339_ _420_ _400_ vdd gnd INVX1
X_1092_ _443_ _445_ _446_ _438_ vdd gnd AOI21X1
X_1148_ reset _176_ vdd gnd INVX4
XFILL_0__896_ gnd vdd FILL
X_899_ _u_ball.y_ball_[1] _47_ _44_ _490_ vdd gnd OAI21X1
XFILL78150x43350 gnd vdd FILL
XFILL_0__1361_ gnd vdd FILL
X_1377_ _677__bF$buf3 vdd _520_ clk_bF$buf7 _u_ctrl.State_[1] vdd 
+ gnd
+ DFFSR
XFILL_0__1417_ gnd vdd FILL
X_920_ _49_ _50_ _48_ vdd gnd NAND2X1
X_1186_ _u_ball.x_pos_[6] _114_ vdd gnd INVX1
XFILL_0__820_ gnd vdd FILL
X_823_ _444_ _226_ _451_ _694_ vdd gnd NAND3X1
X_1089_ _452_ _323_ _324_ _322_ vdd gnd NAND3X1
X_1301_ _371_ _367_ _366_ vdd gnd NAND2X1
XFILL_1__1043_ gnd vdd FILL
X_1530_ _437_ vdd _435_ clk_bF$buf6 _u_ball.x_paddle_[3] vdd 
+ gnd
+ DFFSR
X_1110_ _u_ball.x_paddle_[4] _460_ vdd gnd INVX2
X_861_ _u_ball.x_pos_[6] _533_ vdd gnd INVX1
XFILL78450x18150 gnd vdd FILL
XFILL_0__1167_ gnd vdd FILL
XFILL_0__914_ gnd vdd FILL
X_917_ _u_ball.y_pos_[0] _45_ vdd gnd INVX1
XFILL_1__1328_ gnd vdd FILL
XFILL_1__930_ gnd vdd FILL
X_1204_ _u_ball.x_pos_[4] _132_ vdd gnd INVX2
XFILL_0__952_ gnd vdd FILL
X_955_ _u_ball.y_ball_[2] _193_ vdd gnd INVX1
X_1433_ _666_ _648_ _633_ _593_ vdd gnd OAI21X1
X_1013_ _270_ _246_ vdd gnd INVX1
XFILL_0__761_ gnd vdd FILL
X_764_ _u_ball.y_ball_[4] _u_ball.y_ball_[5] _21_ _22_ vdd gnd NAND3X1
X_1242_ _165_ _162_ _168_ _187_ vdd gnd AOI21X1
X_993_ _u_ball.sign_x_ _u_ball.x_ball_[1] _236_ _228_ vdd gnd NAND3X1
XFILL_0__1299_ gnd vdd FILL
X_1471_ _u_ball.x_pos_[6] _620_ vdd gnd INVX1
X_1051_ _u_ball.x_ball_[2] _448_ _284_ vdd gnd NAND2X1
XFILL_1__833_ gnd vdd FILL
X_1527_ _720_ _721_ _722_ _728_ vdd gnd NAND3X1
X_1107_ _461_ _458_ _464_ _457_ vdd gnd AOI21X1
X_858_ _u_ball.x_pos_[3] _456_ _297_ _u_ball.x_pos_[4] _536_ vdd 
+ gnd
+ OAI22X1
X_1280_ _421_ _u_ball.x_pos_[5] _351_ _345_ vdd gnd OAI21X1
X_1336_ _419_ _426_ _399_ _417_ _397_ vdd 
+ gnd
+ AOI22X1
X_1145_ _77_ _162_ _78_ _175_ vdd gnd AOI21X1
X_896_ _33_ _493_ vdd gnd INVX1
XFILL78150x64950 gnd vdd FILL
X_1374_ _476__bF$buf1 vdd _565_ clk_bF$buf1 _u_ball.hit_paddle_ vdd 
+ gnd
+ DFFSR
X_1183_ _u_bricks.regBricks_[5] _u_ball.x_pos_[3] _112_ _111_ vdd gnd NAND3X1
XFILL_0__1223_ gnd vdd FILL
X_1239_ _u_ball.x_ball_[3] _u_ball.x_ball_[4] _159_ vdd gnd NAND2X1
XFILL_0__987_ gnd vdd FILL
X_1468_ _619_ _618_ _620_ _617_ vdd gnd OAI21X1
X_1048_ _u_ball.x_ball_[3] _282_ _281_ vdd gnd NAND2X1
X_799_ _678_ _681_ _257_ _717_ _718_ vdd 
+ gnd
+ AOI22X1
X_1277_ _347_ _346_ _343_ _342_ vdd gnd AOI21X1
XFILL_0__1317_ gnd vdd FILL
XFILL_0__1070_ gnd vdd FILL
X_820_ _u_ball.x_ball_[0] _u_ball.x_ball_[1] _451_ _697_ vdd gnd OAI21X1
X_1086_ _455_ _454_ _460_ _319_ vdd gnd OAI21X1
XFILL_1__1460_ gnd vdd FILL
XFILL_1__1040_ gnd vdd FILL
XFILL_0__1355_ gnd vdd FILL
XFILL_0__1164_ gnd vdd FILL
X_914_ _u_ball.y_pos_[2] _42_ vdd gnd INVX1
XFILL78450x72150 gnd vdd FILL
XFILL78450x39750 gnd vdd FILL
XFILL_0__1449_ gnd vdd FILL
XFILL_0__1029_ gnd vdd FILL
X_1201_ _133_ _132_ _129_ vdd gnd NAND2X1
X_952_ _u_ball.y_ball_[2] _u_ball.sign_y_ _190_ vdd gnd NOR2X1
XFILL_0__1258_ gnd vdd FILL
X_1430_ _665_ _591_ _595_ _590_ vdd gnd OAI21X1
X_1010_ _244_ _245_ _264_ _243_ vdd gnd OAI21X1
X_761_ _63_ _58_ _56_ _24_ vdd gnd NAND3X1
XFILL_0__1487_ gnd vdd FILL
XFILL_0__1067_ gnd vdd FILL
X_817_ _696_ _699_ _700_ vdd gnd NAND2X1
X_990_ _u_ball.x2_ _467_ _226_ _225_ vdd gnd OAI21X1
XFILL_0__1296_ gnd vdd FILL
X_1524_ pixel_ball _720_ vdd gnd INVX1
X_1104_ _u_ball.x_paddle_[1] _u_ball.x_paddle_[2] _454_ vdd gnd NAND2X1
X_855_ _u_ball.x_pos_[5] _464_ _313_ _u_ball.x_pos_[6] _539_ vdd 
+ gnd
+ OAI22X1
XFILL_0__908_ gnd vdd FILL
X_1333_ _402_ _395_ _442_ vdd gnd NAND2X1
X_1142_ _166_ _160_ _75_ vdd gnd OR2X2
XFILL_0__890_ gnd vdd FILL
X_893_ _48_ _495_ _492_ _496_ vdd gnd NAND3X1
XFILL_0__946_ gnd vdd FILL
X_949_ _188_ _178_ vdd gnd INVX1
X_1371_ btn_right _432_ vdd gnd INVX1
XFILL_0__1411_ gnd vdd FILL
X_1427_ _592_ _589_ _588_ _676_ vdd gnd OAI21X1
X_1007_ _465_ _240_ vdd gnd INVX1
XFILL_0__755_ gnd vdd FILL
X_758_ _u_ball.y_ball_[5] _25_ _26_ _470_ vdd gnd AOI21X1
X_1180_ _u_bricks.regBricks_[14] _133_ _108_ vdd gnd NAND2X1
XFILL_1__962_ gnd vdd FILL
X_1236_ _u_ball.x_ball_[6] _163_ _156_ vdd gnd NAND2X1
XFILL_0__984_ gnd vdd FILL
X_987_ _u_ball.sign_x_ _451_ _222_ vdd gnd NAND2X1
X_1465_ _u_ball.y_pos_[3] _624_ _615_ vdd gnd NOR2X1
X_1045_ _u_ball.x_ball_[2] _448_ _279_ _278_ vdd gnd OAI21X1
XFILL_0__793_ gnd vdd FILL
X_796_ pixel_brick _563_ _718_ _723_ vdd gnd NAND3X1
XFILL_0__1505_ gnd vdd FILL
XFILL_0__849_ gnd vdd FILL
X_1274_ _348_ _342_ _340_ _339_ vdd gnd OAI21X1
XFILL_0__1314_ gnd vdd FILL
X_1083_ _464_ _458_ _461_ _316_ vdd gnd NAND3X1
XFILL_1__865_ gnd vdd FILL
X_1139_ _75_ _73_ vdd gnd INVX1
XFILL_0__887_ gnd vdd FILL
X_1368_ _u_ball.x_paddle_[5] _u_ball.x_paddle_[1] _429_ vdd gnd NOR2X1
XFILL_0__1408_ gnd vdd FILL
X_911_ _46_ _44_ _40_ _39_ vdd gnd OAI21X1
X_1177_ _u_bricks.regBricks_[13] _u_ball.x_pos_[3] _132_ _105_ vdd gnd NAND3X1
XFILL_1__959_ gnd vdd FILL
XFILL_1__768_ gnd vdd FILL
XFILL_0__1446_ gnd vdd FILL
XFILL_0__811_ gnd vdd FILL
X_814_ _701_ _702_ _703_ vdd gnd NAND2X1
XFILL_1__1225_ gnd vdd FILL
X_1521_ _u_ctrl.cnt_v_sync_[0] _u_ctrl.cnt_v_sync_[1] _665_ vdd gnd NOR2X1
X_1101_ _u_ball.x_ball_[2] _451_ vdd gnd INVX2
XFILL78450x25350 gnd vdd FILL
X_852_ _u_ball.x_ball_[6] _533_ _541_ _542_ vdd gnd OAI21X1
XFILL_1__1263_ gnd vdd FILL
XFILL_0__1158_ gnd vdd FILL
XFILL_0__905_ gnd vdd FILL
X_908_ _43_ _41_ _36_ vdd gnd AND2X2
X_1330_ _394_ _399_ _392_ vdd gnd NAND2X1
XFILL_1__1492_ gnd vdd FILL
XFILL_1__1072_ gnd vdd FILL
X_890_ _u_ball.x_pos_[2] _499_ vdd gnd INVX1
XFILL_0__1196_ gnd vdd FILL
X_946_ _177_ _178_ _71_ _483_ vdd gnd OAI21X1
XFILL_1__1357_ gnd vdd FILL
X_1424_ _587_ _647_ _586_ _675_ vdd gnd AOI21X1
X_1004_ _242_ _241_ _238_ _237_ vdd gnd NAND3X1
XFILL_0__752_ gnd vdd FILL
X_755_ _u_ball.sign_y_ _232_ _52_ _29_ vdd gnd OAI21X1
XFILL_0__808_ gnd vdd FILL
X_1233_ _u_bricks.regBricks_[8] _154_ vdd gnd INVX1
X_984_ _220_ _223_ _219_ vdd gnd NAND2X1
X_1462_ _655_ _632_ _613_ _686_ vdd gnd OAI21X1
X_1042_ _291_ _460_ _275_ vdd gnd OR2X2
XFILL_0__790_ gnd vdd FILL
X_793_ _724_ _466_ _234_ _565_ vdd gnd AOI21X1
XFILL_0__1099_ gnd vdd FILL
X_1518_ _666_ _663_ _662_ vdd gnd NOR2X1
X_849_ _u_ball.y_pos_[3] _70_ _545_ vdd gnd NAND2X1
X_1271_ _u_ball.x_pos_[4] _419_ _336_ vdd gnd NAND2X1
X_1327_ _400_ _406_ _397_ _390_ vdd gnd OAI21X1
XFILL_1__1489_ gnd vdd FILL
X_1080_ _u_ball.x_ball_[6] _313_ vdd gnd INVX2
X_1136_ _151_ _162_ _85_ _170_ vdd gnd AOI21X1
X_887_ _u_ball.x_pos_[0] _444_ _226_ _u_ball.x_pos_[1] _502_ vdd 
+ gnd
+ OAI22X1
XFILL_1__1510_ gnd vdd FILL
X_1365_ _431_ _427_ _426_ vdd gnd NAND2X1
X_1174_ _u_ball.y_pos_[3] _u_ball.y_pos_[5] _102_ vdd gnd OR2X2
XFILL_0__1214_ gnd vdd FILL
X_1459_ _653_ _610_ vdd gnd INVX1
X_1039_ _456_ _276_ _273_ _297_ _272_ vdd 
+ gnd
+ AOI22X1
XFILL_1__1413_ gnd vdd FILL
X_1268_ _u_ball.y_pos_[4] _u_ball.y_pos_[3] _333_ vdd gnd AND2X2
XFILL_0__1308_ gnd vdd FILL
XFILL_0__1061_ gnd vdd FILL
X_811_ _456_ _682_ _297_ _706_ vdd gnd OAI21X1
X_1497_ _642_ _u_ctrl.State_3_bF$buf0_ _662_ _641_ vdd gnd AOI21X1
X_1077_ _457_ _314_ _311_ _310_ vdd gnd OAI21X1
XFILL_0__1117_ gnd vdd FILL
XFILL_0__1290_ gnd vdd FILL
XFILL_0__1346_ gnd vdd FILL
XFILL_1__1507_ gnd vdd FILL
XFILL_1__1260_ gnd vdd FILL
XFILL_0__1155_ gnd vdd FILL
XFILL78450x46950 gnd vdd FILL
X_905_ _38_ _34_ _33_ vdd gnd NAND2X1
XFILL_0__1193_ gnd vdd FILL
X_943_ _69_ _68_ vdd gnd INVX1
X_1421_ _u_ball.x_pos_[1] _585_ _584_ _674_ vdd gnd OAI21X1
X_1001_ game_init _729_ _235_ vdd gnd NOR2X1
X_752_ _210_ _30_ _31_ vdd gnd NAND2X1
XFILL_0__1478_ gnd vdd FILL
XFILL_0__1058_ gnd vdd FILL
X_808_ _705_ _706_ _709_ vdd gnd NAND2X1
X_1230_ _u_ball.x_ball_[5] _152_ _151_ vdd gnd NOR2X1
X_981_ _218_ _217_ _216_ vdd gnd NAND2X1
XFILL_0__1287_ gnd vdd FILL
X_790_ _230_ _224_ _730_ vdd gnd NAND2X1
X_1515_ _u_ball.x_pos_[4] _659_ vdd gnd INVX1
X_846_ _70_ _u_ball.y_pos_[3] _41_ _548_ vdd gnd OAI21X1
X_1324_ _422_ _390_ _388_ _387_ vdd gnd NAND3X1
X_1133_ vdd _176_ _186_ clk_bF$buf3 _u_bricks.regBricks_[15] vdd 
+ gnd
+ DFFSR
XFILL_0__881_ gnd vdd FILL
X_884_ _498_ _500_ _505_ vdd gnd NAND2X1
XFILL_1_CLKBUF1_insert6 gnd vdd FILL
XFILL_0__937_ gnd vdd FILL
X_1362_ _432_ _424_ _425_ _423_ vdd gnd AOI21X1
XFILL_0__1402_ gnd vdd FILL
X_1418_ _582_ _u_ball.x_pos_[2] _583_ _673_ vdd gnd MUX2X1
X_749_ _476__bF$buf0 vdd _480_ clk_bF$buf2 _u_ball.x_ball_[0] vdd 
+ gnd
+ DFFSR
X_1171_ _u_ball.x_pos_[2] _u_ball.x_pos_[0] _99_ vdd gnd NOR2X1
XFILL_0__1211_ gnd vdd FILL
X_1227_ _150_ _160_ _149_ vdd gnd OR2X2
XFILL_0__975_ gnd vdd FILL
X_978_ _467_ _297_ _213_ vdd gnd NOR2X1
XFILL_0__1440_ gnd vdd FILL
XFILL_0__1020_ gnd vdd FILL
X_1456_ _661_ _608_ _632_ _607_ vdd gnd OAI21X1
X_1036_ _277_ _272_ _270_ _269_ vdd gnd AOI21X1
XFILL_0__784_ gnd vdd FILL
XFILL_1__818_ gnd vdd FILL
X_787_ _223_ _220_ _1_ _2_ vdd gnd OAI21X1
XFILL_1__991_ gnd vdd FILL
X_1265_ reset _437_ vdd gnd INVX2
XFILL_0__1305_ gnd vdd FILL
X_1494_ _640_ _639_ _641_ _638_ vdd gnd NAND3X1
X_1074_ _449_ _450_ _u_ball.x_ball_[2] _307_ vdd gnd OAI21X1
XFILL_0__878_ gnd vdd FILL
XBUFX2_insert0 _476_ _476__bF$buf3 vdd gnd BUFX2
XBUFX2_insert1 _476_ _476__bF$buf2 vdd gnd BUFX2
XBUFX2_insert2 _476_ _476__bF$buf1 vdd gnd BUFX2
XBUFX2_insert3 _476_ _476__bF$buf0 vdd gnd BUFX2
XFILL_0__1343_ gnd vdd FILL
X_1359_ _421_ _425_ _420_ vdd gnd NAND2X1
XFILL_1__894_ gnd vdd FILL
X_902_ _477_ _478_ vdd gnd INVX1
X_1168_ _u_ball.y_pos_[2] _u_ball.y_pos_[0] _96_ vdd gnd NAND2X1
X_1397_ _677__bF$buf3 vdd _515_ clk_bF$buf7 _u_ctrl.State_[4] vdd 
+ gnd
+ DFFSR
X_940_ _67_ _66_ _68_ _65_ vdd gnd OAI21X1
XFILL_1__1160_ gnd vdd FILL
XFILL_1__797_ gnd vdd FILL
XFILL_0__802_ gnd vdd FILL
X_805_ _u_ball.x_pos_[4] _709_ _711_ _u_ball.x_pos_[5] _712_ vdd 
+ gnd
+ AOI22X1
XFILL_1__1025_ gnd vdd FILL
XFILL78450x150 gnd vdd FILL
XFILL78450x32550 gnd vdd FILL
X_1512_ _u_ball.x_pos_[6] _u_ball.x_pos_[5] _657_ _656_ vdd gnd NAND3X1
XFILL_0__840_ gnd vdd FILL
X_843_ _u_ball.y_pos_[4] _60_ _551_ vdd gnd NOR2X1
XFILL_0__1149_ gnd vdd FILL
X_1321_ _433_ _423_ _u_ball.x_paddle_[1] _385_ vdd gnd OAI21X1
X_1130_ vdd _176_ _175_ clk_bF$buf3 _u_bricks.regBricks_[6] vdd 
+ gnd
+ DFFSR
XFILL_1__912_ gnd vdd FILL
X_881_ _507_ _504_ _508_ vdd gnd NAND2X1
XFILL_1__1292_ gnd vdd FILL
XFILL_0__1187_ gnd vdd FILL
XFILL_0__934_ gnd vdd FILL
X_937_ _64_ _63_ _69_ _62_ vdd gnd NAND3X1
X_1415_ _661_ _658_ _580_ _579_ vdd gnd OAI21X1
X_746_ _476__bF$buf3 vdd _482_ clk_bF$buf5 _u_ball.y_ball_[3] vdd 
+ gnd
+ DFFSR
X_1224_ _u_bricks.regBricks_[11] _147_ vdd gnd INVX1
X_975_ _211_ _214_ _210_ vdd gnd NAND2X1
X_1453_ _661_ _645_ _606_ _684_ vdd gnd AOI21X1
X_1033_ _313_ _267_ _285_ _269_ _266_ vdd 
+ gnd
+ OAI22X1
XFILL_1__815_ gnd vdd FILL
X_784_ _467_ _451_ _219_ _4_ vdd gnd OAI21X1
XFILL77850x10950 gnd vdd FILL
X_1509_ _655_ _654_ _653_ vdd gnd NOR2X1
X_1262_ _330_ _413_ _329_ vdd gnd OR2X2
X_1318_ _u_ball.x_paddle_[2] _383_ vdd gnd INVX1
X_1491_ game_new _636_ vdd gnd INVX1
X_1071_ _u_ball.x_ball_[2] _305_ _452_ _304_ vdd gnd OAI21X1
X_1127_ vdd _176_ _180_ clk_bF$buf3 _u_bricks.regBricks_[4] vdd 
+ gnd
+ DFFSR
X_878_ _u_ball.y_pos_[0] _203_ _511_ vdd gnd NOR2X1
X_1356_ _418_ _417_ vdd gnd INVX1
XFILL_1__1310_ gnd vdd FILL
X_1165_ _98_ _94_ _101_ _93_ vdd gnd NAND3X1
XFILL_0__1205_ gnd vdd FILL
X_1394_ _677__bF$buf2 vdd _676_ clk_bF$buf2 _u_ctrl.cnt_v_sync_[2] vdd 
+ gnd
+ DFFSR
XFILL_0__1243_ gnd vdd FILL
XFILL78150x10950 gnd vdd FILL
X_1259_ _383_ _422_ _327_ _436_ vdd gnd OAI21X1
XFILL_0__1052_ gnd vdd FILL
X_802_ _533_ _714_ _257_ _715_ vdd gnd NAND3X1
X_1488_ _u_ball.y_pos_[0] _634_ vdd gnd INVX1
X_1068_ _319_ _301_ vdd gnd INVX1
XFILL_0__1108_ gnd vdd FILL
XFILL_0__1281_ gnd vdd FILL
XFILL_1__1442_ gnd vdd FILL
XFILL_1__1022_ gnd vdd FILL
X_1297_ _363_ _376_ _362_ vdd gnd OR2X2
XFILL_0__1337_ gnd vdd FILL
XFILL_0__1090_ gnd vdd FILL
X_840_ _544_ _554_ vdd gnd INVX1
XFILL_0__1146_ gnd vdd FILL
X_934_ _u_ball.y_ball_[4] _60_ vdd gnd INVX2
X_1412_ _578_ _618_ _577_ vdd gnd NAND2X1
X_743_ _476__bF$buf1 vdd _473_ clk_bF$buf1 _u_ball.x_ball_[3] vdd 
+ gnd
+ DFFSR
XFILL_0__1469_ gnd vdd FILL
XFILL_0__1049_ gnd vdd FILL
X_1221_ _145_ _146_ _144_ vdd gnd NAND2X1
X_972_ _467_ _464_ _207_ vdd gnd NOR2X1
XFILL_0__1278_ gnd vdd FILL
X_1450_ _604_ _603_ vdd gnd INVX1
X_1030_ _266_ _264_ _292_ _310_ _263_ vdd 
+ gnd
+ AOI22X1
X_781_ _235_ _6_ _3_ _473_ vdd gnd OAI21X1
XFILL_0__1087_ gnd vdd FILL
X_1506_ _726_ _0_ _650_ vdd gnd NOR2X1
X_837_ _u_ball.y_pos_[5] _543_ _557_ vdd gnd NAND2X1
X_1315_ _u_ball.x_pos_[1] _380_ vdd gnd INVX1
X_1124_ vdd _176_ _172_ clk_bF$buf6 _u_bricks.regBricks_[5] vdd 
+ gnd
+ DFFSR
XFILL_0__872_ gnd vdd FILL
X_875_ _39_ _35_ _513_ _514_ vdd gnd NAND3X1
XFILL_0__928_ gnd vdd FILL
X_1353_ _415_ _414_ vdd gnd INVX1
X_1409_ _u_ctrl.State_3_bF$buf3_ _599_ _619_ _575_ vdd gnd OAI21X1
X_1162_ _u_bricks.regBricks_[11] _u_bricks.regBricks_[2] _91_ vdd gnd NOR2X1
XFILL_1__944_ gnd vdd FILL
X_1218_ _159_ _142_ _141_ vdd gnd NOR2X1
XFILL_0__966_ gnd vdd FILL
X_969_ _206_ _209_ _230_ _204_ vdd gnd OAI21X1
X_1391_ _677__bF$buf0 vdd _684_ clk_bF$buf7 _729_ vdd 
+ gnd
+ DFFSR
XFILL_0__1431_ gnd vdd FILL
XFILL_0__1011_ gnd vdd FILL
X_1447_ _611_ _632_ _601_ _683_ vdd gnd OAI21X1
X_1027_ _u_ball.x_ball_[0] _u_ball.x_ball_[1] _260_ vdd gnd NOR2X1
XFILL_0__775_ gnd vdd FILL
X_778_ _7_ _8_ _210_ _9_ vdd gnd NAND3X1
XFILL_1__1189_ gnd vdd FILL
X_1256_ _416_ _422_ _325_ _435_ vdd gnd OAI21X1
X_1485_ _634_ _661_ _632_ _631_ vdd gnd OAI21X1
X_1065_ _299_ _300_ _298_ vdd gnd NAND2X1
XFILL_1__847_ gnd vdd FILL
XFILL_0__1525_ gnd vdd FILL
XFILL_0__1105_ gnd vdd FILL
XFILL_0__869_ gnd vdd FILL
X_1294_ _u_ball.x_paddle_[1] _380_ _360_ _359_ vdd gnd OAI21X1
XFILL77850x18150 gnd vdd FILL
XFILL_0_BUFX2_insert13 gnd vdd FILL
X_1159_ _168_ _161_ _89_ _88_ vdd gnd NAND3X1
XFILL_0_BUFX2_insert15 gnd vdd FILL
XFILL_0_BUFX2_insert17 gnd vdd FILL
XFILL_0_BUFX2_insert19 gnd vdd FILL
X_1388_ vdd _677__bF$buf2 _673_ clk_bF$buf5 _u_ball.x_pos_[2] vdd 
+ gnd
+ DFFSR
XFILL_0__1428_ gnd vdd FILL
X_931_ _59_ _58_ _57_ vdd gnd NOR2X1
X_1197_ _130_ _128_ _126_ _125_ vdd gnd NAND3X1
X_740_ _476__bF$buf1 vdd _680_ clk_bF$buf0 hit_brick vdd 
+ gnd
+ DFFSR
XFILL_1__1207_ gnd vdd FILL
X_1503_ _u_ctrl.State_3_bF$buf3_ _u_ctrl.State_[0] _647_ vdd gnd NOR2X1
XFILL_0__831_ gnd vdd FILL
X_834_ _555_ _553_ _559_ _560_ vdd gnd NAND3X1
XFILL78150x18150 gnd vdd FILL
X_1312_ _382_ _378_ _377_ vdd gnd NAND2X1
XFILL_1__1474_ gnd vdd FILL
XFILL_1__1054_ gnd vdd FILL
X_1121_ vdd _176_ _185_ clk_bF$buf3 _u_bricks.regBricks_[8] vdd 
+ gnd
+ DFFSR
X_872_ _38_ _44_ _518_ _521_ vdd gnd AOI21X1
XFILL_0__1178_ gnd vdd FILL
X_928_ _56_ _63_ _57_ _54_ vdd gnd AOI21X1
XFILL_1__1339_ gnd vdd FILL
X_1350_ _427_ _431_ _u_ball.x_paddle_[2] _411_ vdd gnd AOI21X1
X_1406_ _u_ctrl.cnt_v_sync_[1] _573_ vdd gnd INVX1
X_737_ _476__bF$buf3 vdd _484_ clk_bF$buf4 _u_ball.y_ball_[1] vdd 
+ gnd
+ DFFSR
XFILL_1__941_ gnd vdd FILL
X_1215_ _u_ball.x_ball_[5] _150_ _139_ vdd gnd NOR2X1
X_966_ _230_ _202_ vdd gnd INVX2
X_1444_ _600_ _599_ game_new _515_ vdd gnd AOI21X1
X_1024_ _258_ _313_ _257_ vdd gnd OR2X2
XFILL_0__772_ gnd vdd FILL
X_775_ _u_ball.sign_x_ _u_ball.x_ball_[6] _12_ vdd gnd NAND2X1
X_1253_ _437_ vdd _441_ clk_bF$buf0 _u_ball.x_paddle_[4] vdd 
+ gnd
+ DFFSR
X_1309_ _u_ball.x_paddle_[3] _375_ _374_ vdd gnd NOR2X1
X_1482_ _634_ _630_ _629_ vdd gnd NOR2X1
X_1062_ _316_ _296_ _295_ vdd gnd AND2X2
X_1118_ _476__bF$buf1 vdd _469_ clk_bF$buf0 _u_ball.sign_y_ vdd 
+ gnd
+ DFFSR
X_869_ _523_ _497_ _509_ _524_ vdd gnd AOI21X1
X_1291_ _u_ball.y_pos_[1] _u_ball.y_pos_[2] _356_ vdd gnd OR2X2
X_1347_ _409_ _410_ _408_ vdd gnd NAND2X1
XFILL_0__1140_ gnd vdd FILL
X_1156_ _u_bricks.regBricks_[0] _85_ vdd gnd INVX1
X_1385_ _677__bF$buf3 vdd _692_ clk_bF$buf7 _727_ vdd 
+ gnd
+ DFFSR
X_1194_ _124_ _123_ _132_ _122_ vdd gnd AOI21X1
XFILL_0__1234_ gnd vdd FILL
XFILL_0__998_ gnd vdd FILL
XFILL_0__1043_ gnd vdd FILL
X_1479_ _627_ _632_ _626_ vdd gnd NAND2X1
X_1059_ _309_ _293_ _292_ vdd gnd NAND2X1
XFILL_0__1519_ gnd vdd FILL
XFILL_0__1272_ gnd vdd FILL
X_1288_ _u_ball.x_paddle_[5] _354_ _353_ vdd gnd NAND2X1
XFILL_0__1328_ gnd vdd FILL
XFILL_0__1081_ gnd vdd FILL
X_1500_ _666_ _650_ _645_ _644_ vdd gnd OAI21X1
X_831_ _525_ _532_ _562_ _563_ vdd gnd AOI21X1
X_1097_ _u_ball.x_ball_[1] _u_ball.x_paddle_[1] _447_ vdd gnd NAND2X1
XFILL_0__1137_ gnd vdd FILL
XFILL78150x72150 gnd vdd FILL
XFILL_1__1471_ gnd vdd FILL
XFILL78150x39750 gnd vdd FILL
XFILL_0__1366_ gnd vdd FILL
XFILL_0__1175_ gnd vdd FILL
X_925_ game_init _52_ vdd gnd INVX1
X_1403_ _571_ _573_ _570_ vdd gnd NOR2X1
XFILL_0__731_ gnd vdd FILL
X_734_ _726_ game_over vdd gnd BUFX2
X_1212_ _157_ _162_ _138_ _181_ vdd gnd AOI21X1
X_963_ _u_ball.y_ball_[1] _u_ball.sign_y_ _200_ vdd gnd NAND2X1
XFILL_0__1269_ gnd vdd FILL
X_1441_ _650_ _597_ vdd gnd INVX1
X_1021_ _u_ball.x_ball_[4] _261_ _255_ _254_ vdd gnd OAI21X1
X_772_ _208_ _15_ vdd gnd INVX1
XFILL_0__1498_ gnd vdd FILL
X_828_ _566_ _564_ _678_ vdd gnd NAND2X1
XFILL_1__1239_ gnd vdd FILL
X_1250_ _476__bF$buf2 vdd _486_ clk_bF$buf1 _u_ball.x_ball_[5] vdd 
+ gnd
+ DFFSR
X_1306_ _381_ _376_ _372_ _371_ vdd gnd OAI21X1
X_1115_ game_init _466_ _465_ vdd gnd NOR2X1
XFILL_0__863_ gnd vdd FILL
X_866_ _526_ _506_ _50_ _527_ vdd gnd NAND3X1
XFILL_0__919_ gnd vdd FILL
X_1344_ _419_ _426_ _405_ vdd gnd NAND2X1
X_1153_ _u_bricks.regBricks_[10] _82_ vdd gnd INVX1
X_1209_ _136_ _162_ _137_ _180_ vdd gnd AOI21X1
XFILL_0__957_ gnd vdd FILL
X_1382_ vdd _677__bF$buf2 _670_ clk_bF$buf2 _u_ball.x_pos_[5] vdd 
+ gnd
+ DFFSR
XFILL_0__1422_ gnd vdd FILL
XFILL_0__1002_ gnd vdd FILL
XFILL77850x150 gnd vdd FILL
X_1438_ _596_ _595_ _597_ _519_ vdd gnd AOI21X1
X_1018_ _309_ _251_ vdd gnd INVX1
XFILL_0__766_ gnd vdd FILL
X_769_ _230_ _17_ _14_ _18_ vdd gnd NAND3X1
X_1191_ _120_ _122_ _u_ball.x_pos_[6] _119_ vdd gnd OAI21X1
XFILL_1__973_ gnd vdd FILL
X_1247_ _u_ball.x_ball_[3] _167_ _166_ vdd gnd NAND2X1
XFILL_0__995_ gnd vdd FILL
X_998_ _233_ _232_ vdd gnd INVX1
XFILL_1__782_ gnd vdd FILL
XFILL_0__1460_ gnd vdd FILL
XFILL_0__1040_ gnd vdd FILL
X_1476_ _654_ _624_ vdd gnd INVX1
X_1056_ _460_ _291_ _459_ _289_ vdd gnd OAI21X1
XFILL_0__1516_ gnd vdd FILL
X_1285_ _351_ _350_ vdd gnd INVX1
XFILL_0__1325_ gnd vdd FILL
X_1094_ _u_ball.x_ball_[0] _444_ vdd gnd INVX2
XFILL_1__876_ gnd vdd FILL
XFILL_0__898_ gnd vdd FILL
X_1379_ _677__bF$buf0 vdd _517_ clk_bF$buf7 _u_ctrl.State_[3] vdd 
+ gnd
+ DFFSR
X_922_ _444_ _u_ball.x_pos_[0] _50_ vdd gnd OR2X2
X_1188_ _u_bricks.regBricks_[7] _u_ball.x_pos_[3] _116_ vdd gnd NAND2X1
X_1400_ _571_ _u_ctrl.State_[1] _u_ctrl.State_3_bF$buf0_ _568_ vdd gnd AOI21X1
X_731_ _729_ v_sync vdd gnd BUFX2
XFILL_1__1142_ gnd vdd FILL
XFILL_1__779_ gnd vdd FILL
X_960_ _198_ _199_ _197_ vdd gnd NOR2X1
XFILL_1__1371_ gnd vdd FILL
XFILL_1__1007_ gnd vdd FILL
XFILL_1__800_ gnd vdd FILL
XFILL_0__822_ gnd vdd FILL
X_825_ _u_ball.x_ball_[0] _u_ball.x_ball_[1] _u_ball.x_ball_[2] _682_ vdd gnd NOR3X1
XFILL_1__1236_ gnd vdd FILL
X_1303_ _372_ _368_ vdd gnd INVX1
X_1112_ _463_ _462_ vdd gnd INVX1
XFILL_0__860_ gnd vdd FILL
X_863_ _529_ _528_ _530_ vdd gnd NOR2X1
XFILL_1__1274_ gnd vdd FILL
XFILL_0__1169_ gnd vdd FILL
XFILL_0__916_ gnd vdd FILL
XFILL78450x68550 gnd vdd FILL
X_919_ _u_ball.y_pos_[1] _47_ vdd gnd INVX1
X_1341_ _434_ _422_ _403_ _402_ vdd gnd NAND3X1
XFILL_1__1083_ gnd vdd FILL
X_1150_ _83_ _80_ _79_ vdd gnd NOR2X1
X_1206_ _u_ball.x_pos_[5] _134_ vdd gnd INVX1
X_957_ _201_ _234_ _195_ _484_ vdd gnd OAI21X1
XFILL_1__1368_ gnd vdd FILL
X_1435_ _649_ _637_ _594_ _531_ vdd gnd NAND3X1
X_1015_ _250_ _312_ _251_ _249_ _248_ vdd 
+ gnd
+ AOI22X1
X_766_ _u_ball.y_ball_[1] _u_ball.y_ball_[2] _20_ vdd gnd NOR2X1
X_1244_ _729_ hit_brick _163_ vdd gnd AND2X2
X_995_ _u_ball.hit_paddle_ _230_ _229_ vdd gnd NAND2X1
X_1473_ _622_ _632_ _621_ vdd gnd NAND2X1
X_1053_ _464_ _287_ _286_ vdd gnd NAND2X1
X_1529_ vdd _176_ _169_ clk_bF$buf0 _u_bricks.regBricks_[12] vdd 
+ gnd
+ DFFSR
X_1109_ _u_ball.x_paddle_[5] _459_ vdd gnd INVX1
X_1282_ _u_ball.x_paddle_[3] _375_ _371_ _347_ vdd gnd OAI21X1
X_1338_ _u_ball.x_paddle_[3] _431_ _410_ _409_ _399_ vdd 
+ gnd
+ AOI22X1
X_1091_ _451_ _448_ _438_ _324_ vdd gnd OAI21X1
X_1147_ _u_bricks.regBricks_[6] _78_ vdd gnd INVX1
X_898_ _479_ _490_ _489_ _491_ vdd gnd NAND3X1
XFILL_1__1521_ gnd vdd FILL
XFILL_1__1101_ gnd vdd FILL
X_1376_ _677__bF$buf3 vdd _519_ clk_bF$buf7 _u_ctrl.State_[2] vdd 
+ gnd
+ DFFSR
X_1185_ _u_bricks.regBricks_[4] _133_ _132_ _113_ vdd gnd NAND3X1
XFILL_0__1225_ gnd vdd FILL
XFILL_0__989_ gnd vdd FILL
XFILL_0__1034_ gnd vdd FILL
XFILL_0__1263_ gnd vdd FILL
XFILL_1__1424_ gnd vdd FILL
XFILL_1__1004_ gnd vdd FILL
X_1279_ _419_ _u_ball.x_pos_[4] _349_ _344_ vdd gnd OAI21X1
XFILL_0__1319_ gnd vdd FILL
XFILL_0__1492_ gnd vdd FILL
XFILL_0__1072_ gnd vdd FILL
X_822_ _456_ _694_ _695_ vdd gnd NAND2X1
X_1088_ _463_ _453_ _321_ vdd gnd NAND2X1
XFILL78150x46950 gnd vdd FILL
XFILL78150x7350 gnd vdd FILL
X_1300_ _u_ball.y_pos_[0] _365_ vdd gnd INVX1
XFILL_0__1357_ gnd vdd FILL
X_860_ _498_ _506_ _502_ _534_ vdd gnd NAND3X1
X_916_ _47_ _u_ball.y_ball_[1] _u_ball.y_ball_[0] _45_ _44_ vdd 
+ gnd
+ AOI22X1
X_1203_ _133_ _u_bricks.regBricks_[2] _132_ _131_ vdd gnd AOI21X1
X_954_ _u_ball.sign_y_ _192_ vdd gnd INVX2
X_1432_ _661_ _642_ _593_ _592_ vdd gnd OAI21X1
X_1012_ _246_ _247_ _285_ _245_ vdd gnd AOI21X1
X_763_ _22_ _19_ game_init _471_ vdd gnd AOI21X1
XFILL_0__1489_ gnd vdd FILL
XFILL_0__1069_ gnd vdd FILL
X_819_ _451_ _499_ _697_ _698_ vdd gnd OAI21X1
X_1241_ _u_bricks.regBricks_[15] _161_ vdd gnd INVX1
X_992_ _236_ _444_ _227_ vdd gnd NAND2X1
X_1470_ _u_ball.x_pos_[5] _619_ vdd gnd INVX1
X_1050_ _455_ _449_ _283_ vdd gnd NAND2X1
XFILL_0__1510_ gnd vdd FILL
XFILL78450x54150 gnd vdd FILL
X_1526_ pixel_brick _722_ vdd gnd INVX1
X_1106_ _u_ball.x_ball_[3] _456_ vdd gnd INVX2
XFILL_0__854_ gnd vdd FILL
X_857_ _464_ _u_ball.x_pos_[5] _297_ _u_ball.x_pos_[4] _537_ vdd 
+ gnd
+ AOI22X1
X_1335_ _397_ _406_ _400_ _398_ _396_ vdd 
+ gnd
+ AOI22X1
XFILL78150x150 gnd vdd FILL
X_1144_ _u_bricks.regBricks_[9] _76_ vdd gnd INVX1
XFILL_0__892_ gnd vdd FILL
XFILL_1__926_ gnd vdd FILL
X_895_ _479_ _493_ _489_ _494_ vdd gnd NAND3X1
XFILL_0__948_ gnd vdd FILL
X_1373_ _u_ball.x_paddle_[6] _434_ vdd gnd INVX1
XFILL_1__735_ gnd vdd FILL
XFILL_0__1413_ gnd vdd FILL
X_1429_ _u_ctrl.State_3_bF$buf1_ _590_ _589_ vdd gnd NOR2X1
X_1009_ _465_ _243_ _248_ _242_ vdd gnd NAND3X1
XFILL_0__757_ gnd vdd FILL
X_1182_ _114_ _113_ _111_ _110_ vdd gnd NAND3X1
X_1238_ _159_ _160_ _158_ vdd gnd OR2X2
X_989_ _228_ _227_ _225_ _224_ vdd gnd NAND3X1
XFILL_0__1451_ gnd vdd FILL
XFILL_0__1031_ gnd vdd FILL
X_1467_ _656_ _617_ _616_ vdd gnd NAND2X1
X_1047_ gnd _444_ _447_ _280_ vdd gnd OAI21X1
XFILL_0__795_ gnd vdd FILL
XFILL_1__829_ gnd vdd FILL
X_798_ _718_ _563_ pixel_ball vdd gnd AND2X2
XFILL_0__1507_ gnd vdd FILL
XFILL_0__1260_ gnd vdd FILL
X_1276_ _u_ball.y_pos_[5] _341_ vdd gnd INVX1
X_1085_ _319_ _320_ _318_ vdd gnd NAND2X1
XFILL_0__910_ gnd vdd FILL
X_913_ _u_ball.y_ball_[2] _42_ _41_ vdd gnd NAND2X1
X_1179_ _108_ _109_ _132_ _107_ vdd gnd AOI21X1
X_1200_ _129_ _u_bricks.regBricks_[0] _128_ vdd gnd OR2X2
X_951_ _190_ _191_ _189_ vdd gnd NOR2X1
X_760_ _24_ _23_ _231_ _25_ vdd gnd AOI21X1
XFILL_1__1171_ gnd vdd FILL
XFILL78150x32550 gnd vdd FILL
XFILL_0__813_ gnd vdd FILL
X_816_ _u_ball.x_pos_[3] _701_ vdd gnd INVX1
XFILL_1__1456_ gnd vdd FILL
XFILL_1__1036_ gnd vdd FILL
X_1523_ _727_ _667_ vdd gnd INVX1
X_1103_ _455_ _454_ _453_ vdd gnd NAND2X1
XFILL_0__851_ gnd vdd FILL
X_854_ _539_ _540_ vdd gnd INVX1
X_1332_ _419_ btn_left _405_ _394_ vdd gnd OAI21X1
X_1141_ _156_ _75_ _u_bricks.regBricks_[13] _74_ vdd gnd OAI21X1
XFILL_1__923_ gnd vdd FILL
X_892_ _48_ _497_ vdd gnd INVX1
XFILL_0__1198_ gnd vdd FILL
X_948_ _194_ _189_ _729_ _177_ vdd gnd OAI21X1
X_1370_ btn_left _431_ vdd gnd INVX2
XFILL_0__1410_ gnd vdd FILL
X_1426_ _u_ball.x_pos_[0] _587_ vdd gnd INVX1
X_1006_ _256_ _239_ vdd gnd INVX1
XFILL_0__754_ gnd vdd FILL
X_757_ _70_ _543_ _20_ _27_ vdd gnd NAND3X1
XFILL77550x10950 gnd vdd FILL
X_1235_ _156_ _155_ vdd gnd INVX2
X_986_ _u_ball.x_ball_[2] _467_ _221_ vdd gnd NAND2X1
X_1464_ _653_ _615_ _u_ctrl.State_3_bF$buf2_ _614_ vdd gnd OAI21X1
X_1044_ _284_ _281_ _278_ _277_ vdd gnd NAND3X1
X_795_ _723_ _719_ _234_ _680_ vdd gnd AOI21X1
X_1273_ _u_ball.x_paddle_[2] _379_ _369_ _338_ vdd gnd OAI21X1
X_1329_ _422_ _392_ _393_ _391_ vdd gnd NAND3X1
X_1082_ _u_ball.x_ball_[4] _318_ _316_ _315_ vdd gnd OAI21X1
X_1138_ _73_ _162_ _86_ _172_ vdd gnd AOI21X1
X_889_ _u_ball.x_ball_[2] _499_ _500_ vdd gnd NAND2X1
X_1367_ _u_ball.x_paddle_[2] _u_ball.x_paddle_[3] _428_ vdd gnd NOR2X1
XFILL_0__1160_ gnd vdd FILL
X_910_ _u_ball.y_pos_[1] _201_ _38_ vdd gnd NAND2X1
XFILL_1__1321_ gnd vdd FILL
X_1176_ _u_ball.x_pos_[6] _105_ _106_ _104_ vdd gnd NAND3X1
XFILL_0__1216_ gnd vdd FILL
XFILL_0__1025_ gnd vdd FILL
XFILL_0__1483_ gnd vdd FILL
XFILL_0__1063_ gnd vdd FILL
X_813_ _u_ball.x_pos_[4] _704_ vdd gnd INVX1
X_1499_ _662_ _644_ _651_ _643_ vdd gnd NOR3X1
X_1079_ _461_ _312_ vdd gnd INVX1
XFILL_0__1292_ gnd vdd FILL
XFILL_1__1453_ gnd vdd FILL
XFILL_0__1348_ gnd vdd FILL
X_1520_ _665_ _664_ vdd gnd INVX1
X_1100_ _u_ball.x_paddle_[1] _u_ball.x_paddle_[2] _450_ vdd gnd AND2X2
X_851_ _u_ball.y_ball_[5] _543_ vdd gnd INVX1
XFILL78450x3750 gnd vdd FILL
XFILL_0__1157_ gnd vdd FILL
X_907_ _38_ _37_ _36_ _35_ vdd gnd NAND3X1
X_945_ _u_ball.y_ball_[3] _70_ vdd gnd INVX2
X_1423_ _661_ _u_ctrl.State_[0] _586_ _585_ vdd gnd AOI21X1
X_1003_ _467_ _252_ _237_ _488_ vdd gnd OAI21X1
X_754_ _729_ _28_ _29_ _469_ vdd gnd AOI21X1
X_1232_ _u_ball.x_ball_[3] _153_ vdd gnd INVX1
XFILL_0__980_ gnd vdd FILL
X_983_ _u_ball.sign_x_ _456_ _218_ vdd gnd NAND2X1
XFILL_0__1289_ gnd vdd FILL
XFILL78450x61350 gnd vdd FILL
X_1461_ _u_ball.y_pos_[5] _612_ vdd gnd INVX1
X_1041_ _455_ _449_ _460_ _274_ vdd gnd OAI21X1
X_792_ reset _476_ vdd gnd INVX8
XFILL_0__1501_ gnd vdd FILL
X_1517_ _u_ctrl.State_3_bF$buf1_ _661_ vdd gnd INVX4
XFILL_0__845_ gnd vdd FILL
X_848_ _38_ _43_ _37_ _546_ vdd gnd NAND3X1
X_1270_ _419_ _u_ball.x_pos_[4] _353_ _335_ vdd gnd OAI21X1
XFILL_0__1310_ gnd vdd FILL
X_1326_ _421_ _431_ _420_ _389_ vdd gnd OAI21X1
X_1135_ _u_bricks.regBricks_[12] _72_ vdd gnd INVX1
XFILL_0__883_ gnd vdd FILL
X_886_ _u_ball.x_ball_[1] _501_ _502_ _503_ vdd gnd OAI21X1
XFILL_0__939_ gnd vdd FILL
X_1364_ _426_ _425_ vdd gnd INVX1
XFILL_0__1404_ gnd vdd FILL
X_1173_ _u_ball.y_pos_[4] _102_ _101_ vdd gnd NOR2X1
XFILL_1__955_ gnd vdd FILL
X_1229_ _155_ _151_ _154_ _185_ vdd gnd AOI21X1
XFILL_0__977_ gnd vdd FILL
XFILL_1__764_ gnd vdd FILL
XFILL_0__1442_ gnd vdd FILL
XFILL_0__1022_ gnd vdd FILL
X_1458_ _611_ _610_ _612_ _609_ vdd gnd OAI21X1
X_1038_ _290_ _288_ _u_ball.x_ball_[5] _271_ vdd gnd OAI21X1
XFILL_0__786_ gnd vdd FILL
X_789_ _226_ _234_ _725_ _730_ _475_ vdd 
+ gnd
+ OAI22X1
X_1267_ _349_ _334_ _333_ _332_ vdd gnd OAI21X1
XFILL_0__1307_ gnd vdd FILL
XFILL_0__1480_ gnd vdd FILL
X_810_ _704_ _705_ _706_ _707_ vdd gnd NAND3X1
XFILL_1__1221_ gnd vdd FILL
X_1496_ _644_ _640_ vdd gnd INVX1
X_1076_ _u_ball.x_paddle_[6] _313_ _309_ vdd gnd NOR2X1
XFILL_1__858_ gnd vdd FILL
XFILL_0__901_ gnd vdd FILL
X_904_ _35_ _39_ _33_ _32_ vdd gnd AOI21X1
X_1399_ _u_ctrl.cnt_v_sync_[0] _592_ _567_ vdd gnd NAND2X1
X_942_ _70_ _192_ _67_ vdd gnd NOR2X1
XFILL_1__1353_ gnd vdd FILL
XFILL_0__1248_ gnd vdd FILL
XCLKBUF1_insert10 clk clk_bF$buf1 vdd gnd CLKBUF1
XCLKBUF1_insert11 clk clk_bF$buf0 vdd gnd CLKBUF1
X_1420_ _u_ball.x_pos_[1] _586_ _583_ vdd gnd NAND2X1
X_1000_ _235_ _234_ vdd gnd INVX4
X_751_ _297_ _234_ _202_ _31_ _468_ vdd 
+ gnd
+ OAI22X1
XFILL_0__804_ gnd vdd FILL
X_807_ _464_ _705_ _710_ vdd gnd NAND2X1
XFILL_1__1218_ gnd vdd FILL
X_980_ _216_ _215_ vdd gnd INVX1
X_1514_ _u_ball.x_pos_[1] _u_ball.x_pos_[0] _u_ball.x_pos_[2] _658_ vdd gnd NAND3X1
XFILL_0__842_ gnd vdd FILL
X_845_ _548_ _547_ _545_ _549_ vdd gnd OAI21X1
XFILL_1__1256_ gnd vdd FILL
X_1323_ _433_ _423_ _u_ball.x_paddle_[5] _386_ vdd gnd OAI21X1
XFILL_1__1485_ gnd vdd FILL
XFILL_1__1065_ gnd vdd FILL
X_1132_ vdd _176_ _179_ clk_bF$buf6 _u_bricks.regBricks_[3] vdd 
+ gnd
+ DFFSR
XFILL_0__880_ gnd vdd FILL
X_883_ _u_ball.x_pos_[1] _226_ _506_ vdd gnd NAND2X1
XFILL_0__1189_ gnd vdd FILL
X_939_ _67_ _64_ vdd gnd INVX1
X_1361_ _433_ _423_ _422_ vdd gnd NOR2X1
X_1417_ _658_ _661_ _581_ vdd gnd OR2X2
X_748_ _476__bF$buf0 vdd _487_ clk_bF$buf2 _u_ball.x2_ vdd 
+ gnd
+ DFFSR
X_1170_ _100_ _99_ _98_ vdd gnd NAND2X1
XFILL78450x14550 gnd vdd FILL
X_1226_ _156_ _149_ _u_bricks.regBricks_[14] _148_ vdd gnd OAI21X1
X_977_ _u_ball.sign_x_ _u_ball.x_ball_[4] _212_ vdd gnd NOR2X1
XFILL_1__761_ gnd vdd FILL
X_1455_ _612_ _632_ _607_ _685_ vdd gnd OAI21X1
X_1035_ _u_ball.x_paddle_[6] _268_ vdd gnd INVX1
X_786_ _451_ _234_ _2_ _474_ vdd gnd OAI21X1
X_1264_ _411_ _331_ vdd gnd INVX1
X_1493_ _667_ _643_ _638_ _692_ vdd gnd OAI21X1
X_1073_ _u_ball.x_paddle_[1] _u_ball.x_paddle_[2] _306_ vdd gnd OR2X2
X_1129_ vdd _176_ _184_ clk_bF$buf3 _u_bricks.regBricks_[14] vdd 
+ gnd
+ DFFSR
XFILL_1__1503_ gnd vdd FILL
X_1358_ _u_ball.x_paddle_[4] _419_ vdd gnd INVX2
XFILL_0__1151_ gnd vdd FILL
X_901_ _38_ _37_ _40_ _479_ vdd gnd NAND3X1
X_1167_ _u_ball.y_pos_[1] _96_ _95_ vdd gnd NAND2X1
XFILL_0__1207_ gnd vdd FILL
X_1396_ vdd _677__bF$buf1 _683_ clk_bF$buf4 _u_ball.y_pos_[4] vdd 
+ gnd
+ DFFSR
XFILL_0__1016_ gnd vdd FILL
XFILL_1__1350_ gnd vdd FILL
XFILL_1__987_ gnd vdd FILL
XFILL_0__1245_ gnd vdd FILL
XFILL_1__1406_ gnd vdd FILL
XFILL_0__1474_ gnd vdd FILL
XFILL_0__1054_ gnd vdd FILL
X_804_ _712_ _708_ _713_ vdd gnd AND2X2
XFILL_0__1283_ gnd vdd FILL
X_1299_ _u_ball.x_paddle_[1] _380_ _377_ _364_ vdd gnd OAI21X1
XFILL_0__1339_ gnd vdd FILL
XFILL_0__1092_ gnd vdd FILL
X_1511_ _u_ball.y_pos_[3] _655_ vdd gnd INVX1
X_842_ _545_ _551_ _544_ _552_ vdd gnd OAI21X1
X_1320_ _413_ _422_ _384_ vdd gnd NAND2X1
X_880_ _508_ _509_ vdd gnd INVX1
X_936_ _230_ _62_ _65_ _61_ vdd gnd NAND3X1
X_1414_ _u_ball.x_pos_[3] _581_ _579_ _672_ vdd gnd OAI21X1
X_745_ _476__bF$buf2 vdd _474_ clk_bF$buf1 _u_ball.x_ball_[2] vdd 
+ gnd
+ DFFSR
X_1223_ _u_ball.x_ball_[6] _151_ _146_ vdd gnd NAND2X1
XFILL_0__971_ gnd vdd FILL
X_974_ _467_ _297_ _210_ _209_ vdd gnd OAI21X1
X_1452_ _611_ _610_ _605_ vdd gnd NOR2X1
X_1032_ _290_ _u_ball.x_paddle_[6] _265_ vdd gnd AND2X2
XFILL_0_CLKBUF1_insert4 gnd vdd FILL
XFILL_0_CLKBUF1_insert6 gnd vdd FILL
XFILL_0_CLKBUF1_insert8 gnd vdd FILL
X_783_ _4_ _216_ game_init _5_ vdd gnd AOI21X1
X_1508_ _u_ball.y_pos_[5] _u_ball.y_pos_[4] _653_ _652_ vdd gnd NAND3X1
XFILL_0__836_ gnd vdd FILL
X_839_ _70_ _u_ball.y_pos_[3] _554_ _555_ vdd gnd OAI21X1
X_1261_ _413_ _330_ _328_ vdd gnd NAND2X1
XFILL_0__1301_ gnd vdd FILL
X_1317_ _u_ball.x_pos_[2] _383_ _382_ vdd gnd NAND2X1
X_1490_ _636_ _u_ctrl.State_[0] game_init _635_ vdd gnd AOI21X1
X_1070_ _307_ _438_ _304_ _303_ vdd gnd AOI21X1
XFILL_0__1110_ gnd vdd FILL
X_1126_ vdd _176_ _173_ clk_bF$buf6 _u_bricks.regBricks_[13] vdd 
+ gnd
+ DFFSR
XFILL_0__874_ gnd vdd FILL
XFILL_1__908_ gnd vdd FILL
X_877_ _46_ _510_ _511_ _512_ vdd gnd OAI21X1
X_1355_ _u_ball.x_paddle_[3] _416_ vdd gnd INVX1
XFILL_1__1097_ gnd vdd FILL
XFILL_1__890_ gnd vdd FILL
X_1164_ _103_ _u_ball.x_pos_[5] _93_ _92_ vdd gnd AOI21X1
XFILL_0__968_ gnd vdd FILL
X_1393_ vdd _677__bF$buf1 _689_ clk_bF$buf4 _u_ball.y_pos_[1] vdd 
+ gnd
+ DFFSR
XFILL_0__1433_ gnd vdd FILL
XFILL_0__1013_ gnd vdd FILL
X_1449_ _603_ _605_ _u_ctrl.State_3_bF$buf2_ _602_ vdd gnd OAI21X1
X_1029_ _u_ball.x_ball_[2] _u_ball.x_ball_[3] _262_ vdd gnd NOR2X1
XFILL_0__777_ gnd vdd FILL
XFILL_1__984_ gnd vdd FILL
X_1258_ _410_ _409_ _326_ vdd gnd OR2X2
XFILL_1__793_ gnd vdd FILL
XFILL_0__1471_ gnd vdd FILL
XFILL_0__1051_ gnd vdd FILL
X_801_ _u_ball.x_pos_[5] _711_ _715_ _716_ vdd gnd OAI21X1
X_1487_ _u_ctrl.State_3_bF$buf0_ _u_ctrl.State_[0] _649_ _633_ vdd gnd OAI21X1
X_1067_ _302_ _301_ _u_ball.x_ball_[4] _300_ vdd gnd OAI21X1
X_1296_ _362_ _366_ _361_ vdd gnd OR2X2
XFILL77850x68550 gnd vdd FILL
XFILL_1__887_ gnd vdd FILL
XFILL_1__1115_ gnd vdd FILL
XFILL_0__930_ gnd vdd FILL
X_933_ _u_ball.y_ball_[4] _192_ _59_ vdd gnd NOR2X1
X_1199_ _u_ball.x_pos_[4] _133_ _127_ vdd gnd NOR2X1
XFILL_0__1239_ gnd vdd FILL
X_1411_ _659_ _647_ _577_ _u_ctrl.State_3_bF$buf3_ _671_ vdd 
+ gnd
+ AOI22X1
X_742_ vdd _476__bF$buf1 _481_ clk_bF$buf0 _u_ball.y_ball_[4] vdd 
+ gnd
+ DFFSR
XFILL_1__1153_ gnd vdd FILL
X_1220_ _144_ _143_ vdd gnd INVX1
X_971_ _208_ _207_ _206_ vdd gnd NOR2X1
XFILL_1__1438_ gnd vdd FILL
XFILL_1__1018_ gnd vdd FILL
XFILL_1__811_ gnd vdd FILL
X_780_ _213_ _7_ vdd gnd INVX1
X_1505_ _726_ _0_ _u_ctrl.State_3_bF$buf1_ _649_ vdd gnd OAI21X1
XFILL_0__833_ gnd vdd FILL
X_836_ _557_ _551_ _558_ vdd gnd NOR2X1
XFILL78150x68550 gnd vdd FILL
X_1314_ _u_ball.x_pos_[2] _379_ vdd gnd INVX1
X_1123_ vdd _176_ _183_ clk_bF$buf6 _u_bricks.regBricks_[11] vdd 
+ gnd
+ DFFSR
XFILL_1__905_ gnd vdd FILL
X_874_ _u_ball.y_ball_[0] _45_ _516_ vdd gnd NAND2X1
XFILL_1__1285_ gnd vdd FILL
X_1352_ _u_ball.x_paddle_[1] _413_ vdd gnd INVX1
XFILL_1__1094_ gnd vdd FILL
X_1408_ _661_ _618_ _575_ _574_ vdd gnd OAI21X1
X_739_ _476__bF$buf2 vdd _488_ clk_bF$buf1 _u_ball.sign_x_ vdd 
+ gnd
+ DFFSR
X_1161_ _138_ _137_ _91_ _90_ vdd gnd NAND3X1
XFILL78450x21750 gnd vdd FILL
X_1217_ _143_ _141_ _147_ _183_ vdd gnd AOI21X1
X_968_ _464_ _234_ _204_ _205_ _486_ vdd 
+ gnd
+ OAI22X1
X_1390_ vdd _677__bF$buf0 _674_ clk_bF$buf5 _u_ball.x_pos_[1] vdd 
+ gnd
+ DFFSR
X_1446_ _u_ctrl.State_[4] _600_ vdd gnd INVX1
X_1026_ _260_ _451_ _456_ _259_ vdd gnd AOI21X1
X_777_ _u_ball.sign_x_ _u_ball.x_ball_[5] _9_ _10_ vdd gnd OAI21X1
X_1255_ _437_ vdd _440_ clk_bF$buf0 _u_ball.x_paddle_[5] vdd 
+ gnd
+ DFFSR
X_1484_ _634_ _632_ _631_ _690_ vdd gnd OAI21X1
X_1064_ _u_ball.x_ball_[4] _297_ vdd gnd INVX2
X_1293_ _359_ _369_ _358_ vdd gnd NOR2X1
X_1349_ _413_ _411_ _412_ _410_ vdd gnd OAI21X1
XFILL_0__1142_ gnd vdd FILL
XFILL_1__1303_ gnd vdd FILL
X_1158_ _90_ _88_ _87_ vdd gnd NOR2X1
XFILL_0__1371_ gnd vdd FILL
XFILL_1__1112_ gnd vdd FILL
X_1387_ vdd _677__bF$buf0 _688_ clk_bF$buf5 _u_ball.y_pos_[2] vdd 
+ gnd
+ DFFSR
XFILL_0__1007_ gnd vdd FILL
XFILL_0__1180_ gnd vdd FILL
X_930_ _70_ _192_ _68_ _56_ vdd gnd OAI21X1
X_1196_ _u_bricks.regBricks_[10] _133_ _124_ vdd gnd NAND2X1
XFILL_0__1236_ gnd vdd FILL
XBUFX2_insert12 _677_ _677__bF$buf3 vdd gnd BUFX2
XBUFX2_insert13 _677_ _677__bF$buf2 vdd gnd BUFX2
XBUFX2_insert14 _677_ _677__bF$buf1 vdd gnd BUFX2
XBUFX2_insert15 _677_ _677__bF$buf0 vdd gnd BUFX2
XBUFX2_insert16 _u_ctrl.State_[3] _u_ctrl.State_3_bF$buf3_ vdd gnd BUFX2
XBUFX2_insert17 _u_ctrl.State_[3] _u_ctrl.State_3_bF$buf2_ vdd gnd BUFX2
XBUFX2_insert18 _u_ctrl.State_[3] _u_ctrl.State_3_bF$buf1_ vdd gnd BUFX2
XBUFX2_insert19 _u_ctrl.State_[3] _u_ctrl.State_3_bF$buf0_ vdd gnd BUFX2
XFILL_0__1465_ gnd vdd FILL
XFILL_0__1045_ gnd vdd FILL
XFILL_0__1274_ gnd vdd FILL
XFILL_1__1435_ gnd vdd FILL
XFILL_0__1083_ gnd vdd FILL
X_1502_ _u_ctrl.State_[1] _u_ctrl.State_[2] _649_ _646_ vdd gnd OAI21X1
X_833_ _550_ _544_ _560_ _561_ vdd gnd AOI21X1
X_1099_ _u_ball.x_paddle_[1] _u_ball.x_paddle_[2] _449_ vdd gnd NOR2X1
XFILL_0__1139_ gnd vdd FILL
X_1311_ _u_ball.x_paddle_[1] _380_ _377_ _376_ vdd gnd AOI21X1
XFILL_0__1368_ gnd vdd FILL
X_1120_ vdd _176_ _170_ clk_bF$buf3 _u_bricks.regBricks_[0] vdd 
+ gnd
+ DFFSR
X_871_ _479_ _489_ _521_ _522_ vdd gnd NAND3X1
X_927_ _202_ _54_ _53_ vdd gnd NOR2X1
X_1405_ _666_ _599_ _u_ctrl.State_3_bF$buf1_ _572_ vdd gnd AOI21X1
XFILL_0__733_ gnd vdd FILL
X_736_ _476__bF$buf3 vdd _470_ clk_bF$buf5 _u_ball.y_ball_[5] vdd 
+ gnd
+ DFFSR
X_1214_ _139_ _162_ _140_ _182_ vdd gnd AOI21X1
XFILL_0__962_ gnd vdd FILL
X_965_ _202_ _234_ _203_ _485_ vdd gnd MUX2X1
X_1443_ _u_ctrl.State_[2] _650_ _598_ vdd gnd NAND2X1
X_1023_ game_init _u_ball.hit_paddle_ _256_ vdd gnd NOR2X1
X_774_ _12_ _11_ _13_ vdd gnd NAND2X1
XFILL_1__1185_ gnd vdd FILL
XFILL_0__827_ gnd vdd FILL
X_1252_ _437_ vdd _436_ clk_bF$buf0 _u_ball.x_paddle_[2] vdd 
+ gnd
+ DFFSR
X_1308_ _u_ball.x_pos_[3] _416_ _373_ vdd gnd NOR2X1
X_1481_ _u_ball.y_pos_[0] _u_ball.y_pos_[1] _628_ vdd gnd NOR2X1
X_1061_ _303_ _298_ _295_ _294_ vdd gnd OAI21X1
XFILL_0__1521_ gnd vdd FILL
XFILL_0__1101_ gnd vdd FILL
X_1117_ _u_ball.sign_x_ _467_ vdd gnd INVX2
XFILL_0__865_ gnd vdd FILL
X_868_ _524_ _496_ _525_ vdd gnd NAND2X1
X_1290_ _361_ _357_ _356_ _355_ vdd gnd AOI21X1
XFILL_0__1330_ gnd vdd FILL
X_1346_ _417_ _414_ _408_ _407_ vdd gnd NAND3X1
XFILL_1_CLKBUF1_insert10 gnd vdd FILL
X_1155_ _u_bricks.regBricks_[9] _u_bricks.regBricks_[6] _84_ vdd gnd NOR2X1
XFILL_1__937_ gnd vdd FILL
XFILL_0__959_ gnd vdd FILL
X_1384_ vdd _677__bF$buf2 _671_ clk_bF$buf7 _u_ball.x_pos_[4] vdd 
+ gnd
+ DFFSR
XFILL_0__1424_ gnd vdd FILL
XFILL_0__1004_ gnd vdd FILL
XFILL_0__768_ gnd vdd FILL
X_1193_ _u_bricks.regBricks_[9] _u_ball.x_pos_[3] _132_ _121_ vdd gnd NAND3X1
X_1249_ _u_bricks.regBricks_[1] _168_ vdd gnd INVX1
XFILL_0__1462_ gnd vdd FILL
XFILL_1__1203_ gnd vdd FILL
X_1478_ _630_ _632_ _626_ _689_ vdd gnd OAI21X1
X_1058_ _u_ball.x_paddle_[1] _u_ball.x_paddle_[2] _u_ball.x_paddle_[3] _291_ vdd gnd OAI21X1
XFILL_0__1518_ gnd vdd FILL
XFILL_0__1271_ gnd vdd FILL
X_1287_ _u_ball.x_pos_[6] _352_ vdd gnd INVX1
X_830_ _497_ _495_ _492_ _564_ vdd gnd NAND3X1
X_1096_ _447_ _446_ vdd gnd INVX1
XFILL_0__921_ gnd vdd FILL
X_924_ _u_ball.x2_ _231_ _52_ _51_ vdd gnd OAI21X1
XFILL_1__1335_ gnd vdd FILL
X_1402_ _665_ _570_ _u_ctrl.State_[1] _569_ vdd gnd OAI21X1
X_733_ _727_ p_tick vdd gnd BUFX2
X_1211_ _u_bricks.regBricks_[4] _137_ vdd gnd INVX1
X_962_ _200_ _199_ vdd gnd INVX1
X_1440_ _652_ _656_ _u_ctrl.State_3_bF$buf1_ _596_ vdd gnd OAI21X1
X_1020_ game_init _729_ _254_ _253_ vdd gnd OAI21X1
X_771_ _13_ _16_ vdd gnd INVX1
XFILL_1__1182_ gnd vdd FILL
XFILL_0__824_ gnd vdd FILL
X_827_ _508_ _523_ _679_ vdd gnd NAND2X1
X_1305_ _382_ _378_ _370_ vdd gnd AND2X2
XFILL_1__1467_ gnd vdd FILL
XFILL_1__1047_ gnd vdd FILL
XFILL_1__840_ gnd vdd FILL
X_1114_ _u_ball.x_ball_[5] _464_ vdd gnd INVX2
XFILL_0__862_ gnd vdd FILL
X_865_ _527_ _528_ vdd gnd INVX1
X_1343_ _406_ _405_ _407_ _404_ vdd gnd NAND3X1
X_1152_ _u_bricks.regBricks_[13] _u_bricks.regBricks_[12] _81_ vdd gnd NOR2X1
X_1208_ _u_bricks.regBricks_[3] _135_ vdd gnd INVX1
X_959_ _197_ _u_ball.y_ball_[0] _202_ _196_ vdd gnd AOI21X1
X_1381_ vdd _677__bF$buf1 _690_ clk_bF$buf4 _u_ball.y_pos_[0] vdd 
+ gnd
+ DFFSR
X_1437_ _597_ _641_ _520_ vdd gnd NOR2X1
X_1017_ _457_ _314_ _309_ _250_ vdd gnd OAI21X1
X_768_ _313_ _234_ _18_ _472_ vdd gnd OAI21X1
X_1190_ _134_ _119_ _125_ _118_ vdd gnd NAND3X1
XFILL_0__1230_ gnd vdd FILL
X_1246_ _u_ball.x_ball_[5] _166_ _165_ vdd gnd NOR2X1
X_997_ _729_ _231_ vdd gnd INVX1
XFILL_1__1200_ gnd vdd FILL
X_1475_ _u_ball.y_pos_[2] _629_ _623_ vdd gnd NOR2X1
X_1055_ _289_ _288_ vdd gnd INVX1
X_1284_ _u_ball.x_paddle_[5] _354_ _350_ _349_ vdd gnd OAI21X1
XFILL_1_BUFX2_insert13 gnd vdd FILL
XFILL_1_BUFX2_insert17 gnd vdd FILL
X_1093_ gnd _444_ _443_ vdd gnd NAND2X1
X_1149_ _87_ _79_ _0_ vdd gnd AND2X2
XFILL_0__1362_ gnd vdd FILL
X_1378_ vdd _677__bF$buf0 _531_ clk_bF$buf5 _u_ctrl.State_[0] vdd 
+ gnd
+ DFFSR
XFILL_0__1171_ gnd vdd FILL
X_921_ _u_ball.x_pos_[0] _444_ _49_ vdd gnd NAND2X1
XFILL_1__1332_ gnd vdd FILL
X_1187_ _117_ _116_ _132_ _115_ vdd gnd AOI21X1
XFILL_0__1227_ gnd vdd FILL
XFILL_0__1456_ gnd vdd FILL
XFILL_0__1036_ gnd vdd FILL
XFILL77850x61350 gnd vdd FILL
XFILL_0__1265_ gnd vdd FILL
XFILL_0__1494_ gnd vdd FILL
XFILL_0__1074_ gnd vdd FILL
X_824_ _u_ball.x_ball_[3] _682_ _693_ vdd gnd NAND2X1
X_1302_ _382_ _369_ _368_ _367_ vdd gnd NAND3X1
XFILL_0__1359_ gnd vdd FILL
X_1531_ _677__bF$buf3 vdd _668_ clk_bF$buf7 _u_ctrl.cnt_v_sync_[0] vdd 
+ gnd
+ DFFSR
X_1111_ _u_ball.x_paddle_[4] _u_ball.x_paddle_[5] _462_ _461_ vdd gnd NAND3X1
X_862_ _523_ _509_ _530_ _532_ vdd gnd AOI21X1
X_918_ _u_ball.y_ball_[1] _47_ _46_ vdd gnd NOR2X1
X_1340_ _422_ _401_ vdd gnd INVX1
X_1205_ _u_ball.x_pos_[3] _133_ vdd gnd INVX2
XFILL_0__953_ gnd vdd FILL
X_956_ _203_ _198_ _200_ _194_ vdd gnd OAI21X1
XFILL78150x61350 gnd vdd FILL
X_1434_ reset _677_ vdd gnd INVX8
X_1014_ _277_ _272_ _247_ vdd gnd NAND2X1
X_765_ _20_ _203_ _70_ _21_ vdd gnd AOI21X1
XFILL_0__818_ gnd vdd FILL
X_1243_ _163_ _164_ _162_ vdd gnd AND2X2
XFILL_0__991_ gnd vdd FILL
X_994_ _236_ _232_ _229_ _263_ _487_ vdd 
+ gnd
+ OAI22X1
X_1472_ _625_ _632_ _621_ _688_ vdd gnd OAI21X1
X_1052_ _286_ _285_ vdd gnd INVX1
XFILL_0__1512_ gnd vdd FILL
X_1528_ _476__bF$buf2 vdd _468_ clk_bF$buf1 _u_ball.x_ball_[4] vdd 
+ gnd
+ DFFSR
X_1108_ _460_ _463_ _459_ _458_ vdd gnd OAI21X1
XFILL_0__856_ gnd vdd FILL
X_859_ _456_ _u_ball.x_pos_[3] _534_ _500_ _535_ vdd 
+ gnd
+ AOI22X1
X_1281_ _u_ball.x_paddle_[4] _u_ball.x_pos_[4] _346_ vdd gnd OR2X2
XFILL_0__1321_ gnd vdd FILL
X_1337_ _399_ _417_ _398_ vdd gnd AND2X2
XFILL_1__1079_ gnd vdd FILL
X_1090_ _451_ _448_ _323_ vdd gnd NAND2X1
XFILL_1__872_ gnd vdd FILL
X_1146_ _149_ _77_ vdd gnd INVX1
XFILL_0__894_ gnd vdd FILL
X_897_ _478_ _32_ _491_ _492_ vdd gnd OAI21X1
X_1375_ vdd _677__bF$buf1 _686_ clk_bF$buf4 _u_ball.y_pos_[3] vdd 
+ gnd
+ DFFSR
XFILL_0__1415_ gnd vdd FILL
XFILL_0__759_ gnd vdd FILL
X_1184_ _u_ball.x_pos_[4] _u_ball.x_pos_[5] _112_ vdd gnd NAND2X1
XFILL_1__966_ gnd vdd FILL
XFILL_1__775_ gnd vdd FILL
XFILL_0__1453_ gnd vdd FILL
XFILL_0__1033_ gnd vdd FILL
X_1469_ _657_ _618_ vdd gnd INVX1
X_1049_ _291_ _283_ _282_ vdd gnd NAND2X1
XFILL_0__797_ gnd vdd FILL
X_1278_ _345_ _344_ _343_ vdd gnd NAND2X1
X_821_ _u_ball.x_pos_[3] _695_ _693_ _696_ vdd gnd NAND3X1
XFILL_1__1232_ gnd vdd FILL
X_1087_ _u_ball.x_paddle_[4] _462_ _320_ vdd gnd NAND2X1
XFILL_1__869_ gnd vdd FILL
XFILL_0__912_ gnd vdd FILL
X_915_ _u_ball.y_pos_[2] _193_ _43_ vdd gnd NAND2X1
XFILL_1__1135_ gnd vdd FILL
XFILL77850x14550 gnd vdd FILL
X_1202_ _135_ _133_ _131_ _130_ vdd gnd OAI21X1
XFILL_0__950_ gnd vdd FILL
X_953_ _193_ _192_ _191_ vdd gnd NOR2X1
XFILL_1__1364_ gnd vdd FILL
X_1431_ _u_ctrl.State_[1] _u_ctrl.cnt_v_sync_[2] _591_ vdd gnd NAND2X1
X_1011_ _313_ _267_ _244_ vdd gnd NOR2X1
X_762_ _64_ _59_ _68_ _23_ vdd gnd NAND3X1
XFILL_0__815_ gnd vdd FILL
X_818_ _698_ _534_ _699_ vdd gnd NAND2X1
X_1240_ _u_ball.x_ball_[5] _160_ vdd gnd INVX1
X_991_ _u_ball.x_ball_[1] _226_ vdd gnd INVX1
X_1525_ pixel_paddle _721_ vdd gnd INVX1
X_1105_ _u_ball.x_paddle_[3] _455_ vdd gnd INVX1
X_856_ _536_ _535_ _537_ _538_ vdd gnd OAI21X1
XFILL_1__1267_ gnd vdd FILL
X_1334_ _401_ _396_ _u_ball.x_paddle_[6] _395_ vdd gnd OAI21X1
XFILL_1__1496_ gnd vdd FILL
XFILL_1__1076_ gnd vdd FILL
X_1143_ _155_ _165_ _76_ _174_ vdd gnd AOI21X1
X_894_ _477_ _490_ _494_ _495_ vdd gnd NAND3X1
XFILL78150x14550 gnd vdd FILL
X_1372_ _729_ _433_ vdd gnd INVX1
X_1428_ _u_ctrl.cnt_v_sync_[2] _592_ _588_ vdd gnd NAND2X1
X_1008_ _253_ _241_ vdd gnd INVX1
X_759_ _u_ball.y_ball_[5] _25_ _52_ _26_ vdd gnd OAI21X1
X_1181_ _u_bricks.regBricks_[15] _u_ball.x_pos_[3] _109_ vdd gnd NAND2X1
XFILL_0__1221_ gnd vdd FILL
X_1237_ _158_ _157_ vdd gnd INVX1
X_988_ _228_ _224_ _223_ vdd gnd NAND2X1
XFILL_1__1399_ gnd vdd FILL
X_1466_ _620_ _647_ _616_ _u_ctrl.State_3_bF$buf2_ _687_ vdd 
+ gnd
+ AOI22X1
X_1046_ _280_ _445_ _279_ vdd gnd AND2X2
X_797_ hit_brick _719_ vdd gnd INVX1
XFILL_1__1420_ gnd vdd FILL
XFILL_1__1000_ gnd vdd FILL
X_1275_ _352_ _u_ball.x_paddle_[6] _341_ _340_ vdd gnd AOI21X1
X_1084_ _u_ball.x_ball_[3] _321_ _318_ _u_ball.x_ball_[4] _317_ vdd 
+ gnd
+ AOI22X1
XFILL_0__1353_ gnd vdd FILL
XFILL_1__1514_ gnd vdd FILL
X_1369_ _u_ball.x_paddle_[6] _u_ball.x_paddle_[4] _430_ vdd gnd NOR2X1
XFILL_0__1162_ gnd vdd FILL
X_912_ _43_ _41_ _40_ vdd gnd NAND2X1
X_1178_ _u_bricks.regBricks_[12] _133_ _132_ _106_ vdd gnd NAND3X1
XFILL_0__1218_ gnd vdd FILL
XFILL_0__1447_ gnd vdd FILL
XFILL_0__1027_ gnd vdd FILL
X_950_ _194_ _189_ _188_ vdd gnd NAND2X1
XFILL_1__998_ gnd vdd FILL
XFILL_0__1256_ gnd vdd FILL
XFILL_1__1417_ gnd vdd FILL
XFILL_0__1485_ gnd vdd FILL
XFILL_0__1065_ gnd vdd FILL
X_815_ _695_ _693_ _702_ vdd gnd NAND2X1
XFILL_0__1294_ gnd vdd FILL
X_1522_ _u_ctrl.State_[1] _666_ vdd gnd INVX1
X_1102_ _456_ _463_ _453_ _452_ vdd gnd NAND3X1
X_853_ _540_ _538_ _541_ vdd gnd NAND2X1
X_909_ _u_ball.y_pos_[1] _201_ _203_ _u_ball.y_pos_[0] _37_ vdd 
+ gnd
+ OAI22X1
X_1331_ _399_ _394_ _393_ vdd gnd OR2X2
X_1140_ _74_ _173_ vdd gnd INVX1
X_891_ _u_ball.x_pos_[2] _451_ _498_ vdd gnd NAND2X1
XFILL_0__944_ gnd vdd FILL
X_947_ _231_ _u_ball.y_ball_[2] game_init _71_ vdd gnd AOI21X1
XFILL_1__731_ gnd vdd FILL
X_1425_ _661_ _587_ _586_ vdd gnd NOR2X1
X_1005_ _257_ _239_ _240_ _248_ _238_ vdd 
+ gnd
+ OAI22X1
X_756_ _u_ball.y_ball_[4] _27_ _719_ _28_ vdd gnd OAI21X1
XFILL_1__1167_ gnd vdd FILL
XFILL_0__809_ gnd vdd FILL
X_1234_ _157_ _155_ _161_ _186_ vdd gnd AOI21X1
XFILL_0__982_ gnd vdd FILL
X_985_ _222_ _221_ _220_ vdd gnd NAND2X1
X_1463_ _614_ _632_ _613_ vdd gnd NAND2X1
X_1043_ _282_ _276_ vdd gnd INVX1
XFILL_0__791_ gnd vdd FILL
X_794_ pixel_paddle _563_ _718_ _724_ vdd gnd NAND3X1
XFILL_0__1503_ gnd vdd FILL
X_1519_ _u_ctrl.cnt_v_sync_[2] _664_ _663_ vdd gnd NOR2X1
XFILL_0__847_ gnd vdd FILL
X_1272_ _338_ _372_ _374_ _337_ vdd gnd AOI21X1
XFILL_0__1312_ gnd vdd FILL
X_1328_ _419_ _422_ _391_ _441_ vdd gnd OAI21X1
X_1081_ _317_ _322_ _315_ _314_ vdd gnd AOI21X1
X_1137_ _155_ _139_ _82_ _171_ vdd gnd AOI21X1
XFILL_0__885_ gnd vdd FILL
XFILL_1__919_ gnd vdd FILL
X_888_ _u_ball.x_pos_[1] _501_ vdd gnd INVX1
XFILL_1__1299_ gnd vdd FILL
XFILL_0__1350_ gnd vdd FILL
X_1366_ _430_ _429_ _428_ _427_ vdd gnd NAND3X1
XFILL_0__1406_ gnd vdd FILL
X_1175_ _104_ _107_ _115_ _110_ _103_ vdd 
+ gnd
+ OAI22X1
XFILL78450x43350 gnd vdd FILL
XFILL_0__1444_ gnd vdd FILL
XFILL_0__788_ gnd vdd FILL
X_1269_ _337_ _336_ _335_ _334_ vdd gnd AOI21X1
XFILL_0__1482_ gnd vdd FILL
X_812_ _u_ball.x_ball_[4] _u_ball.x_ball_[3] _694_ _705_ vdd gnd NAND3X1
X_1498_ _652_ _656_ _642_ vdd gnd NOR2X1
X_1078_ _313_ _u_ball.x_paddle_[6] _312_ _311_ vdd gnd AOI21X1
X_850_ _60_ _u_ball.y_pos_[4] _543_ _u_ball.y_pos_[5] _544_ vdd 
+ gnd
+ AOI22X1
XFILL_0__903_ gnd vdd FILL
X_906_ _u_ball.y_ball_[1] _47_ _34_ vdd gnd NAND2X1
XFILL_1__1317_ gnd vdd FILL
XFILL77850x21750 gnd vdd FILL
XFILL_0__1194_ gnd vdd FILL
XFILL_0__941_ gnd vdd FILL
X_944_ _193_ _192_ _188_ _69_ vdd gnd OAI21X1
X_1422_ _661_ _587_ _u_ball.x_pos_[1] _584_ vdd gnd OAI21X1
X_1002_ _u_ball.x2_ _236_ vdd gnd INVX1
X_753_ _214_ _211_ _30_ vdd gnd OR2X2
XFILL_1__1164_ gnd vdd FILL
XFILL_0__806_ gnd vdd FILL
X_809_ _703_ _707_ _700_ _708_ vdd gnd NAND3X1
X_1231_ _153_ _167_ _152_ vdd gnd NAND2X1
X_982_ _u_ball.x_ball_[3] _467_ _217_ vdd gnd NAND2X1
XFILL_1__1449_ gnd vdd FILL
XFILL_1__1029_ gnd vdd FILL
X_1460_ _u_ball.y_pos_[4] _611_ vdd gnd INVX1
X_1040_ _275_ _274_ _273_ vdd gnd AND2X2
XFILL_1__822_ gnd vdd FILL
X_791_ _225_ _228_ _227_ _725_ vdd gnd AOI21X1
XFILL_0__1500_ gnd vdd FILL
XFILL_0__1097_ gnd vdd FILL
X_1516_ _u_ball.x_pos_[3] _660_ vdd gnd INVX1
XFILL_0__844_ gnd vdd FILL
X_847_ _546_ _547_ vdd gnd INVX1
X_1325_ _397_ _389_ _388_ vdd gnd OR2X2
X_1134_ _155_ _136_ _72_ _169_ vdd gnd AOI21X1
XFILL78150x21750 gnd vdd FILL
X_885_ _498_ _500_ _503_ _504_ vdd gnd NAND3X1
XFILL_1__1296_ gnd vdd FILL
X_1363_ _u_ball.x_paddle_[6] _u_ball.x_paddle_[4] _u_ball.x_paddle_[5] _424_ vdd gnd NAND3X1
X_1419_ _661_ _u_ctrl.State_[0] _u_ball.x_pos_[2] _582_ vdd gnd AOI21X1
X_1172_ _u_ball.x_pos_[1] _100_ vdd gnd INVX1
XFILL_0__1212_ gnd vdd FILL
X_1228_ _u_ball.x_ball_[4] _153_ _150_ vdd gnd NAND2X1
XFILL78450x64950 gnd vdd FILL
X_979_ _467_ _262_ _215_ _219_ _214_ vdd 
+ gnd
+ OAI22X1
X_1457_ _609_ _652_ _608_ vdd gnd AND2X2
X_1037_ _297_ _273_ _271_ _270_ vdd gnd OAI21X1
X_788_ _223_ _220_ _202_ _1_ vdd gnd AOI21X1
X_1266_ _339_ _332_ _355_ pixel_paddle vdd gnd NOR3X1
X_1495_ _u_ctrl.State_[0] _u_ctrl.State_[2] _661_ _639_ vdd gnd OAI21X1
X_1075_ _457_ _308_ vdd gnd INVX1
XFILL_0__1115_ gnd vdd FILL
XFILL_0__1344_ gnd vdd FILL
XFILL_0__1153_ gnd vdd FILL
X_903_ _u_ball.y_pos_[0] _203_ _477_ vdd gnd NAND2X1
XFILL_1__1314_ gnd vdd FILL
X_1169_ _u_ball.y_pos_[2] _u_ball.y_pos_[0] _97_ vdd gnd NOR2X1
XFILL_0__1209_ gnd vdd FILL
X_1398_ _592_ _568_ _567_ _668_ vdd gnd OAI21X1
XFILL_0__1438_ gnd vdd FILL
XFILL_0__1018_ gnd vdd FILL
XFILL_0__1191_ gnd vdd FILL
X_941_ _u_ball.y_ball_[3] _u_ball.sign_y_ _66_ vdd gnd NOR2X1
XFILL_0__1247_ gnd vdd FILL
X_750_ vdd _476__bF$buf3 _483_ clk_bF$buf5 _u_ball.y_ball_[2] vdd 
+ gnd
+ DFFSR
XFILL_0__1476_ gnd vdd FILL
XFILL_0__1056_ gnd vdd FILL
X_806_ _258_ _710_ _711_ vdd gnd NAND2X1
XFILL_0_BUFX2_insert1 gnd vdd FILL
XFILL_0_BUFX2_insert2 gnd vdd FILL
XFILL_0__1285_ gnd vdd FILL
XFILL_0__1094_ gnd vdd FILL
X_1513_ _660_ _659_ _658_ _657_ vdd gnd NOR3X1
X_844_ _60_ _u_ball.y_pos_[4] _549_ _550_ vdd gnd OAI21X1
X_1322_ _386_ _387_ _440_ vdd gnd NAND2X1
X_1131_ vdd _176_ _181_ clk_bF$buf3 _u_bricks.regBricks_[7] vdd 
+ gnd
+ DFFSR
X_882_ _506_ _502_ _505_ _507_ vdd gnd NAND3X1
XFILL_0__935_ gnd vdd FILL
X_938_ _66_ _63_ vdd gnd INVX1
XFILL78150x3750 gnd vdd FILL
X_1360_ _u_ball.x_paddle_[5] _421_ vdd gnd INVX1
X_1416_ _u_ctrl.State_3_bF$buf3_ _599_ _660_ _580_ vdd gnd OAI21X1
X_747_ _476__bF$buf0 vdd _475_ clk_bF$buf2 _u_ball.x_ball_[1] vdd 
+ gnd
+ DFFSR
X_1225_ _148_ _184_ vdd gnd INVX1
XFILL_0__973_ gnd vdd FILL
X_976_ _212_ _213_ _211_ vdd gnd NOR2X1
X_1454_ _642_ _645_ _729_ _606_ vdd gnd AOI21X1
X_1034_ _459_ _275_ _268_ _267_ vdd gnd OAI21X1
XFILL_0__782_ gnd vdd FILL
X_785_ _u_ball.x_ball_[3] _235_ _3_ vdd gnd NAND2X1
XFILL_1__1196_ gnd vdd FILL
XFILL_0__838_ gnd vdd FILL
X_1263_ _383_ btn_left _331_ _330_ vdd gnd OAI21X1
XFILL_0__1303_ gnd vdd FILL
X_1319_ _385_ _384_ _439_ vdd gnd NAND2X1
X_1492_ game_new _u_ctrl.State_[0] _637_ vdd gnd NAND2X1
X_1072_ _454_ _306_ _305_ vdd gnd NAND2X1
XFILL_1__854_ gnd vdd FILL
XFILL_0__1112_ gnd vdd FILL
X_1128_ vdd _176_ _174_ clk_bF$buf3 _u_bricks.regBricks_[9] vdd 
+ gnd
+ DFFSR
XFILL_0__876_ gnd vdd FILL
X_879_ _u_ball.y_pos_[1] _201_ _510_ vdd gnd NOR2X1
XFILL_0__1341_ gnd vdd FILL
X_1357_ btn_left _419_ _418_ vdd gnd NOR2X1
X_900_ _46_ _44_ _36_ _489_ vdd gnd OAI21X1
X_1166_ _u_ball.y_pos_[1] _97_ _95_ _94_ vdd gnd OAI21X1
XFILL_1__948_ gnd vdd FILL
XCLKBUF1_insert4 clk clk_bF$buf7 vdd gnd CLKBUF1
XCLKBUF1_insert5 clk clk_bF$buf6 vdd gnd CLKBUF1
XCLKBUF1_insert6 clk clk_bF$buf5 vdd gnd CLKBUF1
XCLKBUF1_insert7 clk clk_bF$buf4 vdd gnd CLKBUF1
XCLKBUF1_insert8 clk clk_bF$buf3 vdd gnd CLKBUF1
XCLKBUF1_insert9 clk clk_bF$buf2 vdd gnd CLKBUF1
X_1395_ vdd _677__bF$buf1 _685_ clk_bF$buf4 _u_ball.y_pos_[5] vdd 
+ gnd
+ DFFSR
XFILL_1__757_ gnd vdd FILL
XFILL_0__1435_ gnd vdd FILL
XFILL_0__1015_ gnd vdd FILL
XFILL_0__779_ gnd vdd FILL
XFILL_0__800_ gnd vdd FILL
X_803_ _464_ _705_ _313_ _714_ vdd gnd OAI21X1
XFILL_1__1214_ gnd vdd FILL
X_1489_ _u_ctrl.State_[4] _637_ _635_ _691_ vdd gnd AOI21X1
X_1069_ _460_ _463_ _302_ vdd gnd NOR2X1
X_1298_ _u_ball.x_pos_[0] _365_ _364_ _363_ vdd gnd OAI21X1
X_1510_ _u_ball.y_pos_[0] _u_ball.y_pos_[1] _u_ball.y_pos_[2] _654_ vdd gnd NAND3X1
X_841_ _41_ _546_ _552_ _553_ vdd gnd NAND3X1
XFILL_1__1061_ gnd vdd FILL
XFILL_0__1185_ gnd vdd FILL
XFILL_0__932_ gnd vdd FILL
X_935_ _70_ _234_ _61_ _482_ vdd gnd OAI21X1
XFILL_1__1346_ gnd vdd FILL
X_1413_ _660_ _658_ _659_ _578_ vdd gnd OAI21X1
X_744_ _476__bF$buf3 vdd _485_ clk_bF$buf4 _u_ball.y_ball_[0] vdd 
+ gnd
+ DFFSR
X_1222_ _u_ball.x_ball_[5] _152_ _164_ _145_ vdd gnd OAI21X1
XFILL_0__970_ gnd vdd FILL
X_973_ _u_ball.sign_x_ _u_ball.x_ball_[5] _208_ vdd gnd NOR2X1
X_1451_ _655_ _654_ _611_ _604_ vdd gnd OAI21X1
X_1031_ _313_ _265_ _267_ _264_ vdd gnd OAI21X1
X_782_ _216_ _4_ _5_ _6_ vdd gnd OAI21X1
XFILL_0__1088_ gnd vdd FILL
X_1507_ _661_ _652_ _656_ _651_ vdd gnd NOR3X1
X_838_ _u_ball.y_pos_[5] _543_ _556_ vdd gnd NOR2X1
X_1260_ _422_ _328_ _329_ _327_ vdd gnd NAND3X1
X_1316_ _382_ _381_ vdd gnd INVX1
XFILL_1__1478_ gnd vdd FILL
XFILL_1__1058_ gnd vdd FILL
XFILL_1__851_ gnd vdd FILL
X_1125_ vdd _176_ _187_ clk_bF$buf6 _u_bricks.regBricks_[1] vdd 
+ gnd
+ DFFSR
X_876_ _46_ _37_ _512_ _513_ vdd gnd OAI21X1
X_1354_ btn_left _416_ _415_ vdd gnd NOR2X1
X_1163_ _92_ _118_ pixel_brick vdd gnd AND2X2
XFILL_0__1203_ gnd vdd FILL
X_1219_ _160_ _163_ _142_ vdd gnd NAND2X1
X_1392_ vdd _677__bF$buf1 _675_ clk_bF$buf4 _u_ball.x_pos_[0] vdd 
+ gnd
+ DFFSR
X_1448_ _632_ _602_ _601_ vdd gnd NAND2X1
X_1028_ _464_ _313_ _262_ _261_ vdd gnd NAND3X1
X_779_ _207_ _8_ vdd gnd INVX1

.ends
.end
