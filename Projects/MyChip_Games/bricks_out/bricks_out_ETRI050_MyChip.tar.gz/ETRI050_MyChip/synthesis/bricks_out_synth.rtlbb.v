/* Verilog module written by vlog2Verilog (qflow) */
/* With bit-blasted vectors */
/* With power connections converted to binary 1, 0 */

module bricks_out(
    input clk,
    input reset,
    output v_sync,
    output pixel,
    output p_tick,
    input btn_left,
    input btn_right,
    output game_over,
    output game_complete,
    input game_new
);

wire _588_ ;
wire _168_ ;
wire _60_ ;
wire _397_ ;
wire \u_ball.sign_x  ;
wire _703_ ;
wire _19_ ;
wire _512_ ;
wire _321_ ;
wire _57_ ;
wire _550_ ;
wire _130_ ;
wire _606_ ;
wire _415_ ;
wire _95_ ;
wire _644_ ;
wire _224_ ;
wire pixel_brick ;
wire _453_ ;
wire _509_ ;
wire _682_ ;
wire _262_ ;
wire _318_ ;
wire _491_ ;
wire _547_ ;
wire _127_ ;
wire _356_ ;
wire btn_right ;
wire _585_ ;
wire _165_ ;
wire _394_ ;
wire _679_ ;
wire _259_ ;
wire _488_ ;
wire _700_ ;
wire _297_ ;
wire _16_ ;
wire _54_ ;
wire _603_ ;
wire _412_ ;
wire _92_ ;
wire _641_ ;
wire _221_ ;
wire _450_ ;
wire _506_ ;
wire _315_ ;
wire _544_ ;
wire _124_ ;
wire _353_ ;
wire _409_ ;
wire _89_ ;
wire _582_ ;
wire _162_ ;
wire _638_ ;
wire _218_ ;
wire _391_ ;
wire _447_ ;
wire _676_ ;
wire _256_ ;
wire _485_ ;
wire _294_ ;
wire _13_ ;
wire _579_ ;
wire _159_ ;
wire _51_ ;
wire _388_ ;
wire _600_ ;
wire _197_ ;
wire _7_ ;
wire _503_ ;
wire _312_ ;
wire _48_ ;
wire _541_ ;
wire _121_ ;
wire _350_ ;
wire _406_ ;
wire _86_ ;
wire _635_ ;
wire _215_ ;
wire _444_ ;
wire _673_ ;
wire _253_ ;
wire _729_ ;
wire _309_ ;
wire _482_ ;
wire _538_ ;
wire _118_ ;
wire _291_ ;
wire _10_ ;
wire _347_ ;
wire _576_ ;
wire _156_ ;
wire _385_ ;
wire pixel ;
wire _194_ ;
wire _479_ ;
wire _288_ ;
wire _4_ ;
wire _500_ ;
wire hit_brick ;
wire _45_ ;
wire _403_ ;
wire _83_ ;
wire _632_ ;
wire _212_ ;
wire _441_ ;
wire _670_ ;
wire _250_ ;
wire _726_ ;
wire _306_ ;
wire _535_ ;
wire _115_ ;
wire _344_ ;
wire _573_ ;
wire _153_ ;
wire _629_ ;
wire _209_ ;
wire _382_ ;
wire _438_ ;
wire _191_ ;
wire _667_ ;
wire _247_ ;
wire _476_ ;
wire clk_bF$buf0 ;
wire clk_bF$buf1 ;
wire clk_bF$buf2 ;
wire clk_bF$buf3 ;
wire clk_bF$buf4 ;
wire clk_bF$buf5 ;
wire clk_bF$buf6 ;
wire clk_bF$buf7 ;
wire _285_ ;
wire _1_ ;
wire _677__bF$buf0 ;
wire _677__bF$buf1 ;
wire _677__bF$buf2 ;
wire _677__bF$buf3 ;
wire _42_ ;
wire _379_ ;
wire _188_ ;
wire _400_ ;
wire _80_ ;
wire _723_ ;
wire _303_ ;
wire [6:0] \u_ball.x_ball  ;
wire _39_ ;
wire _532_ ;
wire _112_ ;
wire _341_ ;
wire clk ;
wire _77_ ;
wire _570_ ;
wire _150_ ;
wire _626_ ;
wire _206_ ;
wire _435_ ;
wire _664_ ;
wire _244_ ;
wire _473_ ;
wire _529_ ;
wire _109_ ;
wire _282_ ;
wire _338_ ;
wire _567_ ;
wire _147_ ;
wire _376_ ;
wire _185_ ;
wire _699_ ;
wire _279_ ;
wire _720_ ;
wire _300_ ;
wire _36_ ;
wire _74_ ;
wire _623_ ;
wire _203_ ;
wire _432_ ;
wire pixel_paddle ;
wire _661_ ;
wire _241_ ;
wire _717_ ;
wire _470_ ;
wire _526_ ;
wire _106_ ;
wire _335_ ;
wire _564_ ;
wire _144_ ;
wire [2:0] \u_ctrl.cnt_v_sync  ;
wire _373_ ;
wire _429_ ;
wire _182_ ;
wire _658_ ;
wire _238_ ;
wire _467_ ;
wire _696_ ;
wire _276_ ;
wire _33_ ;
wire \u_ball.hit_paddle  ;
wire _599_ ;
wire _179_ ;
wire _71_ ;
wire _620_ ;
wire _200_ ;
wire _714_ ;
wire _523_ ;
wire _103_ ;
wire \u_ctrl.State_3_bF$buf3  ;
wire _332_ ;
wire _68_ ;
wire _561_ ;
wire _141_ ;
wire _617_ ;
wire _370_ ;
wire _426_ ;
wire _655_ ;
wire _235_ ;
wire _464_ ;
wire _693_ ;
wire _273_ ;
wire _329_ ;
wire _558_ ;
wire _138_ ;
wire _30_ ;
wire _367_ ;
wire _596_ ;
wire _176_ ;
wire _499_ ;
wire _711_ ;
wire _27_ ;
wire _520_ ;
wire _100_ ;
wire \u_ctrl.State_3_bF$buf0  ;
wire _65_ ;
wire _614_ ;
wire _423_ ;
wire _652_ ;
wire _232_ ;
wire _708_ ;
wire _461_ ;
wire _517_ ;
wire _690_ ;
wire _270_ ;
wire _326_ ;
wire _555_ ;
wire _135_ ;
wire _364_ ;
wire _593_ ;
wire _173_ ;
wire _649_ ;
wire _229_ ;
wire _458_ ;
wire _687_ ;
wire _267_ ;
wire _496_ ;
wire _24_ ;
wire _62_ ;
wire _399_ ;
wire _611_ ;
wire _420_ ;
wire _705_ ;
wire _514_ ;
wire _323_ ;
wire _59_ ;
wire _552_ ;
wire _132_ ;
wire _608_ ;
wire _361_ ;
wire _417_ ;
wire _97_ ;
wire _590_ ;
wire _170_ ;
wire _646_ ;
wire _226_ ;
wire _455_ ;
wire _684_ ;
wire _264_ ;
wire _493_ ;
wire _549_ ;
wire _129_ ;
wire _21_ ;
wire _358_ ;
wire _587_ ;
wire _167_ ;
wire _396_ ;
wire \u_ball.x2  ;
wire _702_ ;
wire _299_ ;
wire _18_ ;
wire _511_ ;
wire _320_ ;
wire _56_ ;
wire _605_ ;
wire _414_ ;
wire _94_ ;
wire _643_ ;
wire _223_ ;
wire _452_ ;
wire _508_ ;
wire _681_ ;
wire _261_ ;
wire _317_ ;
wire _490_ ;
wire _546_ ;
wire _126_ ;
wire _355_ ;
wire game_over ;
wire _584_ ;
wire _164_ ;
wire _393_ ;
wire _449_ ;
wire _678_ ;
wire _258_ ;
wire _487_ ;
wire _296_ ;
wire _15_ ;
wire _53_ ;
wire _602_ ;
wire _199_ ;
wire _411_ ;
wire _91_ ;
wire _640_ ;
wire _220_ ;
wire _9_ ;
wire _505_ ;
wire _314_ ;
wire _543_ ;
wire _123_ ;
wire _352_ ;
wire _408_ ;
wire _88_ ;
wire _581_ ;
wire _161_ ;
wire _637_ ;
wire _217_ ;
wire _390_ ;
wire _446_ ;
wire _675_ ;
wire _255_ ;
wire _484_ ;
wire _293_ ;
wire _12_ ;
wire _349_ ;
wire _578_ ;
wire _158_ ;
wire _50_ ;
wire _387_ ;
wire _196_ ;
wire _6_ ;
wire _502_ ;
wire _311_ ;
wire _47_ ;
wire _540_ ;
wire _120_ ;
wire [6:0] \u_ball.x_paddle  ;
wire _405_ ;
wire _85_ ;
wire _634_ ;
wire _214_ ;
wire _443_ ;
wire _672_ ;
wire _252_ ;
wire _728_ ;
wire _308_ ;
wire _481_ ;
wire _537_ ;
wire _117_ ;
wire _290_ ;
wire _346_ ;
wire _575_ ;
wire _155_ ;
wire _384_ ;
wire _193_ ;
wire _669_ ;
wire _249_ ;
wire _478_ ;
wire _287_ ;
wire _3_ ;
wire game_complete ;
wire _44_ ;
wire _402_ ;
wire _82_ ;
wire _631_ ;
wire _211_ ;
wire _440_ ;
wire _725_ ;
wire _305_ ;
wire _534_ ;
wire _114_ ;
wire _343_ ;
wire _79_ ;
wire _572_ ;
wire _152_ ;
wire _628_ ;
wire _208_ ;
wire _381_ ;
wire [5:0] \u_ball.y_pos  ;
wire _437_ ;
wire _190_ ;
wire _666_ ;
wire _246_ ;
wire pixel_ball ;
wire _475_ ;
wire _284_ ;
wire _0_ ;
wire v_sync ;
wire _569_ ;
wire _149_ ;
wire _41_ ;
wire _378_ ;
wire _187_ ;
wire _722_ ;
wire _302_ ;
wire _38_ ;
wire _531_ ;
wire _111_ ;
wire _340_ ;
wire _76_ ;
wire _625_ ;
wire _205_ ;
wire _434_ ;
wire _663_ ;
wire _243_ ;
wire _719_ ;
wire _472_ ;
wire _528_ ;
wire _108_ ;
wire _281_ ;
wire _337_ ;
wire _566_ ;
wire _146_ ;
wire _375_ ;
wire _184_ ;
wire _469_ ;
wire _698_ ;
wire _278_ ;
wire _35_ ;
wire _73_ ;
wire _622_ ;
wire _202_ ;
wire _431_ ;
wire _660_ ;
wire _240_ ;
wire _716_ ;
wire _525_ ;
wire _105_ ;
wire _334_ ;
wire _563_ ;
wire _143_ ;
wire _619_ ;
wire _372_ ;
wire _428_ ;
wire _181_ ;
wire _657_ ;
wire _237_ ;
wire _466_ ;
wire _695_ ;
wire _275_ ;
wire _32_ ;
wire _369_ ;
wire _598_ ;
wire _178_ ;
wire _70_ ;
wire _713_ ;
wire _29_ ;
wire _522_ ;
wire _102_ ;
wire \u_ctrl.State_3_bF$buf2  ;
wire _331_ ;
wire _67_ ;
wire _560_ ;
wire _140_ ;
wire _616_ ;
wire _425_ ;
wire _654_ ;
wire _234_ ;
wire _463_ ;
wire _519_ ;
wire _692_ ;
wire _272_ ;
wire game_init ;
wire _328_ ;
wire _557_ ;
wire _137_ ;
wire [4:0] \u_ctrl.State  ;
wire _366_ ;
wire _595_ ;
wire _175_ ;
wire _689_ ;
wire _269_ ;
wire _498_ ;
wire _710_ ;
wire _26_ ;
wire _64_ ;
wire _613_ ;
wire _422_ ;
wire _651_ ;
wire _231_ ;
wire _707_ ;
wire _460_ ;
wire _516_ ;
wire [5:0] \u_ball.y_ball  ;
wire _325_ ;
wire _554_ ;
wire _134_ ;
wire _363_ ;
wire _419_ ;
wire _99_ ;
wire _592_ ;
wire _172_ ;
wire _648_ ;
wire _228_ ;
wire _457_ ;
wire _686_ ;
wire _266_ ;
wire _495_ ;
wire _23_ ;
wire _589_ ;
wire _169_ ;
wire _61_ ;
wire _398_ ;
wire _610_ ;
wire \u_ball.sign_y  ;
wire _704_ ;
wire _513_ ;
wire _322_ ;
wire _58_ ;
wire _551_ ;
wire _131_ ;
wire _607_ ;
wire _360_ ;
wire _416_ ;
wire _96_ ;
wire _645_ ;
wire _225_ ;
wire game_new ;
wire _454_ ;
wire _683_ ;
wire _263_ ;
wire _319_ ;
wire _492_ ;
wire _548_ ;
wire _128_ ;
wire _20_ ;
wire _357_ ;
wire _586_ ;
wire _166_ ;
wire _395_ ;
wire _489_ ;
wire _701_ ;
wire _298_ ;
wire _17_ ;
wire _510_ ;
wire _55_ ;
wire _604_ ;
wire _413_ ;
wire _93_ ;
wire _642_ ;
wire _222_ ;
wire _451_ ;
wire _507_ ;
wire _680_ ;
wire _260_ ;
wire _316_ ;
wire _545_ ;
wire _125_ ;
wire _354_ ;
wire _583_ ;
wire _163_ ;
wire _639_ ;
wire _219_ ;
wire _392_ ;
wire _448_ ;
wire _677_ ;
wire _257_ ;
wire _486_ ;
wire _295_ ;
wire _14_ ;
wire _52_ ;
wire _389_ ;
wire _601_ ;
wire _198_ ;
wire _410_ ;
wire _90_ ;
wire _8_ ;
wire _504_ ;
wire _313_ ;
wire _49_ ;
wire _542_ ;
wire _122_ ;
wire _351_ ;
wire _407_ ;
wire _87_ ;
wire _580_ ;
wire _160_ ;
wire _636_ ;
wire _216_ ;
wire _445_ ;
wire btn_left ;
wire _674_ ;
wire _254_ ;
wire _483_ ;
wire _539_ ;
wire _119_ ;
wire _292_ ;
wire _11_ ;
wire _348_ ;
wire _577_ ;
wire _157_ ;
wire _386_ ;
wire _195_ ;
wire _289_ ;
wire _5_ ;
wire _501_ ;
wire _730_ ;
wire _310_ ;
wire _46_ ;
wire _404_ ;
wire _84_ ;
wire _633_ ;
wire _213_ ;
wire _442_ ;
wire _671_ ;
wire _251_ ;
wire _727_ ;
wire _307_ ;
wire _480_ ;
wire _536_ ;
wire _116_ ;
wire _345_ ;
wire _574_ ;
wire _154_ ;
wire _383_ ;
wire _439_ ;
wire _192_ ;
wire _668_ ;
wire _248_ ;
wire _477_ ;
wire _286_ ;
wire _2_ ;
wire _43_ ;
wire _189_ ;
wire _401_ ;
wire _81_ ;
wire _630_ ;
wire _210_ ;
wire _724_ ;
wire _304_ ;
wire _533_ ;
wire _113_ ;
wire _342_ ;
wire _476__bF$buf0 ;
wire _476__bF$buf1 ;
wire _476__bF$buf2 ;
wire _78_ ;
wire _476__bF$buf3 ;
wire _571_ ;
wire _151_ ;
wire [6:0] \u_ball.x_pos  ;
wire _627_ ;
wire _207_ ;
wire _380_ ;
wire _436_ ;
wire _665_ ;
wire _245_ ;
wire _474_ ;
wire _283_ ;
wire _339_ ;
wire _568_ ;
wire _148_ ;
wire _40_ ;
wire _377_ ;
wire _186_ ;
wire _721_ ;
wire _301_ ;
wire _37_ ;
wire _530_ ;
wire _110_ ;
wire _75_ ;
wire _624_ ;
wire _204_ ;
wire _433_ ;
wire _662_ ;
wire _242_ ;
wire _718_ ;
wire _471_ ;
wire _527_ ;
wire _107_ ;
wire _280_ ;
wire _336_ ;
wire _565_ ;
wire _145_ ;
wire _374_ ;
wire _183_ ;
wire _659_ ;
wire _239_ ;
wire _468_ ;
wire _697_ ;
wire _277_ ;
wire _34_ ;
wire _72_ ;
wire _621_ ;
wire _201_ ;
wire _430_ ;
wire _715_ ;
wire _524_ ;
wire _104_ ;
wire _333_ ;
wire _69_ ;
wire _562_ ;
wire _142_ ;
wire _618_ ;
wire _371_ ;
wire _427_ ;
wire _180_ ;
wire _656_ ;
wire _236_ ;
wire _465_ ;
wire _694_ ;
wire _274_ ;
wire _559_ ;
wire _139_ ;
wire _31_ ;
wire _368_ ;
wire _597_ ;
wire _177_ ;
wire _712_ ;
wire _28_ ;
wire _521_ ;
wire _101_ ;
wire \u_ctrl.State_3_bF$buf1  ;
wire _330_ ;
wire _66_ ;
wire _615_ ;
wire _424_ ;
wire _653_ ;
wire _233_ ;
wire _709_ ;
wire _462_ ;
wire _518_ ;
wire _691_ ;
wire _271_ ;
wire p_tick ;
wire _327_ ;
wire _556_ ;
wire _136_ ;
wire _365_ ;
wire _594_ ;
wire _174_ ;
wire _459_ ;
wire _688_ ;
wire _268_ ;
wire _497_ ;
wire _25_ ;
wire _63_ ;
wire [15:0] \u_bricks.regBricks  ;
wire _612_ ;
wire reset ;
wire _421_ ;
wire _650_ ;
wire _230_ ;
wire _706_ ;
wire _515_ ;
wire _324_ ;
wire _553_ ;
wire _133_ ;
wire _609_ ;
wire _362_ ;
wire _418_ ;
wire _98_ ;
wire _591_ ;
wire _171_ ;
wire _647_ ;
wire _227_ ;
wire _456_ ;
wire _685_ ;
wire _265_ ;
wire _494_ ;
wire _22_ ;
wire _359_ ;

BUFX2 BUFX2_insert19 (
    .A(\u_ctrl.State [3]),
    .Y(\u_ctrl.State_3_bF$buf0 )
);

BUFX2 BUFX2_insert18 (
    .A(\u_ctrl.State [3]),
    .Y(\u_ctrl.State_3_bF$buf1 )
);

BUFX2 BUFX2_insert17 (
    .A(\u_ctrl.State [3]),
    .Y(\u_ctrl.State_3_bF$buf2 )
);

BUFX2 BUFX2_insert16 (
    .A(\u_ctrl.State [3]),
    .Y(\u_ctrl.State_3_bF$buf3 )
);

BUFX2 BUFX2_insert15 (
    .A(_677_),
    .Y(_677__bF$buf0)
);

BUFX2 BUFX2_insert14 (
    .A(_677_),
    .Y(_677__bF$buf1)
);

BUFX2 BUFX2_insert13 (
    .A(_677_),
    .Y(_677__bF$buf2)
);

BUFX2 BUFX2_insert12 (
    .A(_677_),
    .Y(_677__bF$buf3)
);

CLKBUF1 CLKBUF1_insert11 (
    .A(clk),
    .Y(clk_bF$buf0)
);

CLKBUF1 CLKBUF1_insert10 (
    .A(clk),
    .Y(clk_bF$buf1)
);

CLKBUF1 CLKBUF1_insert9 (
    .A(clk),
    .Y(clk_bF$buf2)
);

CLKBUF1 CLKBUF1_insert8 (
    .A(clk),
    .Y(clk_bF$buf3)
);

CLKBUF1 CLKBUF1_insert7 (
    .A(clk),
    .Y(clk_bF$buf4)
);

CLKBUF1 CLKBUF1_insert6 (
    .A(clk),
    .Y(clk_bF$buf5)
);

CLKBUF1 CLKBUF1_insert5 (
    .A(clk),
    .Y(clk_bF$buf6)
);

CLKBUF1 CLKBUF1_insert4 (
    .A(clk),
    .Y(clk_bF$buf7)
);

BUFX2 BUFX2_insert3 (
    .A(_476_),
    .Y(_476__bF$buf0)
);

BUFX2 BUFX2_insert2 (
    .A(_476_),
    .Y(_476__bF$buf1)
);

BUFX2 BUFX2_insert1 (
    .A(_476_),
    .Y(_476__bF$buf2)
);

BUFX2 BUFX2_insert0 (
    .A(_476_),
    .Y(_476__bF$buf3)
);

INVX4 _1000_ (
    .A(_235_),
    .Y(_234_)
);

NOR2X1 _1001_ (
    .A(game_init),
    .B(_729_),
    .Y(_235_)
);

INVX1 _1002_ (
    .A(\u_ball.x2 ),
    .Y(_236_)
);

OAI21X1 _1003_ (
    .A(_467_),
    .B(_252_),
    .C(_237_),
    .Y(_488_)
);

NAND3X1 _1004_ (
    .A(_242_),
    .B(_241_),
    .C(_238_),
    .Y(_237_)
);

OAI22X1 _1005_ (
    .A(_257_),
    .B(_239_),
    .C(_240_),
    .D(_248_),
    .Y(_238_)
);

INVX1 _1006_ (
    .A(_256_),
    .Y(_239_)
);

INVX1 _1007_ (
    .A(_465_),
    .Y(_240_)
);

INVX1 _1008_ (
    .A(_253_),
    .Y(_241_)
);

NAND3X1 _1009_ (
    .A(_465_),
    .B(_243_),
    .C(_248_),
    .Y(_242_)
);

OAI21X1 _1010_ (
    .A(_244_),
    .B(_245_),
    .C(_264_),
    .Y(_243_)
);

NOR2X1 _1011_ (
    .A(_313_),
    .B(_267_),
    .Y(_244_)
);

AOI21X1 _1012_ (
    .A(_246_),
    .B(_247_),
    .C(_285_),
    .Y(_245_)
);

INVX1 _1013_ (
    .A(_270_),
    .Y(_246_)
);

NAND2X1 _1014_ (
    .A(_277_),
    .B(_272_),
    .Y(_247_)
);

AOI22X1 _1015_ (
    .A(_250_),
    .B(_312_),
    .C(_251_),
    .D(_249_),
    .Y(_248_)
);

OAI22X1 _1016_ (
    .A(\u_ball.x_ball [6]),
    .B(_268_),
    .C(_457_),
    .D(_314_),
    .Y(_249_)
);

OAI21X1 _1017_ (
    .A(_457_),
    .B(_314_),
    .C(_309_),
    .Y(_250_)
);

INVX1 _1018_ (
    .A(_309_),
    .Y(_251_)
);

AOI21X1 _1019_ (
    .A(_263_),
    .B(_465_),
    .C(_253_),
    .Y(_252_)
);

OAI21X1 _1020_ (
    .A(game_init),
    .B(_729_),
    .C(_254_),
    .Y(_253_)
);

OAI21X1 _1021_ (
    .A(\u_ball.x_ball [4]),
    .B(_261_),
    .C(_255_),
    .Y(_254_)
);

AND2X2 _1022_ (
    .A(_257_),
    .B(_256_),
    .Y(_255_)
);

NOR2X1 _1023_ (
    .A(game_init),
    .B(\u_ball.hit_paddle ),
    .Y(_256_)
);

OR2X2 _1024_ (
    .A(_258_),
    .B(_313_),
    .Y(_257_)
);

NAND3X1 _1025_ (
    .A(\u_ball.x_ball [5]),
    .B(\u_ball.x_ball [4]),
    .C(_259_),
    .Y(_258_)
);

AOI21X1 _1026_ (
    .A(_260_),
    .B(_451_),
    .C(_456_),
    .Y(_259_)
);

NOR2X1 _1027_ (
    .A(\u_ball.x_ball [0]),
    .B(\u_ball.x_ball [1]),
    .Y(_260_)
);

NAND3X1 _1028_ (
    .A(_464_),
    .B(_313_),
    .C(_262_),
    .Y(_261_)
);

NOR2X1 _1029_ (
    .A(\u_ball.x_ball [2]),
    .B(\u_ball.x_ball [3]),
    .Y(_262_)
);

AOI22X1 _1030_ (
    .A(_266_),
    .B(_264_),
    .C(_292_),
    .D(_310_),
    .Y(_263_)
);

OAI21X1 _1031_ (
    .A(_313_),
    .B(_265_),
    .C(_267_),
    .Y(_264_)
);

AND2X2 _1032_ (
    .A(_290_),
    .B(\u_ball.x_paddle [6]),
    .Y(_265_)
);

OAI22X1 _1033_ (
    .A(_313_),
    .B(_267_),
    .C(_285_),
    .D(_269_),
    .Y(_266_)
);

OAI21X1 _1034_ (
    .A(_459_),
    .B(_275_),
    .C(_268_),
    .Y(_267_)
);

INVX1 _1035_ (
    .A(\u_ball.x_paddle [6]),
    .Y(_268_)
);

AOI21X1 _1036_ (
    .A(_277_),
    .B(_272_),
    .C(_270_),
    .Y(_269_)
);

OAI21X1 _1037_ (
    .A(_297_),
    .B(_273_),
    .C(_271_),
    .Y(_270_)
);

OAI21X1 _1038_ (
    .A(_290_),
    .B(_288_),
    .C(\u_ball.x_ball [5]),
    .Y(_271_)
);

AOI22X1 _1039_ (
    .A(_456_),
    .B(_276_),
    .C(_273_),
    .D(_297_),
    .Y(_272_)
);

AND2X2 _1040_ (
    .A(_275_),
    .B(_274_),
    .Y(_273_)
);

OAI21X1 _1041_ (
    .A(_455_),
    .B(_449_),
    .C(_460_),
    .Y(_274_)
);

OR2X2 _1042_ (
    .A(_291_),
    .B(_460_),
    .Y(_275_)
);

INVX1 _1043_ (
    .A(_282_),
    .Y(_276_)
);

NAND3X1 _1044_ (
    .A(_284_),
    .B(_281_),
    .C(_278_),
    .Y(_277_)
);

OAI21X1 _1045_ (
    .A(\u_ball.x_ball [2]),
    .B(_448_),
    .C(_279_),
    .Y(_278_)
);

AND2X2 _1046_ (
    .A(_280_),
    .B(_445_),
    .Y(_279_)
);

OAI21X1 _1047_ (
    .A(gnd),
    .B(_444_),
    .C(_447_),
    .Y(_280_)
);

NAND2X1 _1048_ (
    .A(\u_ball.x_ball [3]),
    .B(_282_),
    .Y(_281_)
);

NAND2X1 _1049_ (
    .A(_291_),
    .B(_283_),
    .Y(_282_)
);

NAND2X1 _1050_ (
    .A(_455_),
    .B(_449_),
    .Y(_283_)
);

NAND2X1 _1051_ (
    .A(\u_ball.x_ball [2]),
    .B(_448_),
    .Y(_284_)
);

INVX1 _1052_ (
    .A(_286_),
    .Y(_285_)
);

NAND2X1 _1053_ (
    .A(_464_),
    .B(_287_),
    .Y(_286_)
);

NOR2X1 _1054_ (
    .A(_290_),
    .B(_288_),
    .Y(_287_)
);

INVX1 _1055_ (
    .A(_289_),
    .Y(_288_)
);

OAI21X1 _1056_ (
    .A(_460_),
    .B(_291_),
    .C(_459_),
    .Y(_289_)
);

NOR3X1 _1057_ (
    .A(_460_),
    .B(_459_),
    .C(_291_),
    .Y(_290_)
);

OAI21X1 _1058_ (
    .A(\u_ball.x_paddle [1]),
    .B(\u_ball.x_paddle [2]),
    .C(\u_ball.x_paddle [3]),
    .Y(_291_)
);

NAND2X1 _1059_ (
    .A(_309_),
    .B(_293_),
    .Y(_292_)
);

NAND3X1 _1060_ (
    .A(_312_),
    .B(_308_),
    .C(_294_),
    .Y(_293_)
);

OAI21X1 _1061_ (
    .A(_303_),
    .B(_298_),
    .C(_295_),
    .Y(_294_)
);

AND2X2 _1062_ (
    .A(_316_),
    .B(_296_),
    .Y(_295_)
);

NAND3X1 _1063_ (
    .A(_297_),
    .B(_319_),
    .C(_320_),
    .Y(_296_)
);

INVX2 _1064_ (
    .A(\u_ball.x_ball [4]),
    .Y(_297_)
);

NAND2X1 _1065_ (
    .A(_299_),
    .B(_300_),
    .Y(_298_)
);

NAND2X1 _1066_ (
    .A(\u_ball.x_ball [3]),
    .B(_321_),
    .Y(_299_)
);

OAI21X1 _1067_ (
    .A(_302_),
    .B(_301_),
    .C(\u_ball.x_ball [4]),
    .Y(_300_)
);

INVX1 _1068_ (
    .A(_319_),
    .Y(_301_)
);

NOR2X1 _1069_ (
    .A(_460_),
    .B(_463_),
    .Y(_302_)
);

AOI21X1 _1070_ (
    .A(_307_),
    .B(_438_),
    .C(_304_),
    .Y(_303_)
);

OAI21X1 _1071_ (
    .A(\u_ball.x_ball [2]),
    .B(_305_),
    .C(_452_),
    .Y(_304_)
);

NAND2X1 _1072_ (
    .A(_454_),
    .B(_306_),
    .Y(_305_)
);

OR2X2 _1073_ (
    .A(\u_ball.x_paddle [1]),
    .B(\u_ball.x_paddle [2]),
    .Y(_306_)
);

OAI21X1 _1074_ (
    .A(_449_),
    .B(_450_),
    .C(\u_ball.x_ball [2]),
    .Y(_307_)
);

INVX1 _1075_ (
    .A(_457_),
    .Y(_308_)
);

NOR2X1 _1076_ (
    .A(\u_ball.x_paddle [6]),
    .B(_313_),
    .Y(_309_)
);

OAI21X1 _1077_ (
    .A(_457_),
    .B(_314_),
    .C(_311_),
    .Y(_310_)
);

AOI21X1 _1078_ (
    .A(_313_),
    .B(\u_ball.x_paddle [6]),
    .C(_312_),
    .Y(_311_)
);

INVX1 _1079_ (
    .A(_461_),
    .Y(_312_)
);

INVX2 _1080_ (
    .A(\u_ball.x_ball [6]),
    .Y(_313_)
);

AOI21X1 _1081_ (
    .A(_317_),
    .B(_322_),
    .C(_315_),
    .Y(_314_)
);

OAI21X1 _1082_ (
    .A(\u_ball.x_ball [4]),
    .B(_318_),
    .C(_316_),
    .Y(_315_)
);

NAND3X1 _1083_ (
    .A(_464_),
    .B(_458_),
    .C(_461_),
    .Y(_316_)
);

AOI22X1 _1084_ (
    .A(\u_ball.x_ball [3]),
    .B(_321_),
    .C(_318_),
    .D(\u_ball.x_ball [4]),
    .Y(_317_)
);

NAND2X1 _1085_ (
    .A(_319_),
    .B(_320_),
    .Y(_318_)
);

OAI21X1 _1086_ (
    .A(_455_),
    .B(_454_),
    .C(_460_),
    .Y(_319_)
);

NAND2X1 _1087_ (
    .A(\u_ball.x_paddle [4]),
    .B(_462_),
    .Y(_320_)
);

NAND2X1 _1088_ (
    .A(_463_),
    .B(_453_),
    .Y(_321_)
);

NAND3X1 _1089_ (
    .A(_452_),
    .B(_323_),
    .C(_324_),
    .Y(_322_)
);

NAND2X1 _1090_ (
    .A(_451_),
    .B(_448_),
    .Y(_323_)
);

OAI21X1 _1091_ (
    .A(_451_),
    .B(_448_),
    .C(_438_),
    .Y(_324_)
);

AOI21X1 _1092_ (
    .A(_443_),
    .B(_445_),
    .C(_446_),
    .Y(_438_)
);

NAND2X1 _1093_ (
    .A(gnd),
    .B(_444_),
    .Y(_443_)
);

INVX2 _1094_ (
    .A(\u_ball.x_ball [0]),
    .Y(_444_)
);

OR2X2 _1095_ (
    .A(\u_ball.x_ball [1]),
    .B(\u_ball.x_paddle [1]),
    .Y(_445_)
);

INVX1 _1096_ (
    .A(_447_),
    .Y(_446_)
);

NAND2X1 _1097_ (
    .A(\u_ball.x_ball [1]),
    .B(\u_ball.x_paddle [1]),
    .Y(_447_)
);

NOR2X1 _1098_ (
    .A(_449_),
    .B(_450_),
    .Y(_448_)
);

NOR2X1 _1099_ (
    .A(\u_ball.x_paddle [1]),
    .B(\u_ball.x_paddle [2]),
    .Y(_449_)
);

AND2X2 _1100_ (
    .A(\u_ball.x_paddle [1]),
    .B(\u_ball.x_paddle [2]),
    .Y(_450_)
);

INVX2 _1101_ (
    .A(\u_ball.x_ball [2]),
    .Y(_451_)
);

NAND3X1 _1102_ (
    .A(_456_),
    .B(_463_),
    .C(_453_),
    .Y(_452_)
);

NAND2X1 _1103_ (
    .A(_455_),
    .B(_454_),
    .Y(_453_)
);

NAND2X1 _1104_ (
    .A(\u_ball.x_paddle [1]),
    .B(\u_ball.x_paddle [2]),
    .Y(_454_)
);

INVX1 _1105_ (
    .A(\u_ball.x_paddle [3]),
    .Y(_455_)
);

INVX2 _1106_ (
    .A(\u_ball.x_ball [3]),
    .Y(_456_)
);

AOI21X1 _1107_ (
    .A(_461_),
    .B(_458_),
    .C(_464_),
    .Y(_457_)
);

OAI21X1 _1108_ (
    .A(_460_),
    .B(_463_),
    .C(_459_),
    .Y(_458_)
);

INVX1 _1109_ (
    .A(\u_ball.x_paddle [5]),
    .Y(_459_)
);

INVX2 _1110_ (
    .A(\u_ball.x_paddle [4]),
    .Y(_460_)
);

NAND3X1 _1111_ (
    .A(\u_ball.x_paddle [4]),
    .B(\u_ball.x_paddle [5]),
    .C(_462_),
    .Y(_461_)
);

INVX1 _1112_ (
    .A(_463_),
    .Y(_462_)
);

NAND3X1 _1113_ (
    .A(\u_ball.x_paddle [1]),
    .B(\u_ball.x_paddle [2]),
    .C(\u_ball.x_paddle [3]),
    .Y(_463_)
);

INVX2 _1114_ (
    .A(\u_ball.x_ball [5]),
    .Y(_464_)
);

NOR2X1 _1115_ (
    .A(game_init),
    .B(_466_),
    .Y(_465_)
);

INVX1 _1116_ (
    .A(\u_ball.hit_paddle ),
    .Y(_466_)
);

INVX2 _1117_ (
    .A(\u_ball.sign_x ),
    .Y(_467_)
);

DFFSR _1118_ (
    .CLK(clk_bF$buf7),
    .D(_469_),
    .Q(\u_ball.sign_y ),
    .R(_476__bF$buf3),
    .S(vdd)
);

DFFSR _1119_ (
    .CLK(clk_bF$buf6),
    .D(_182_),
    .Q(\u_bricks.regBricks [2]),
    .R(vdd),
    .S(_176_)
);

DFFSR _1120_ (
    .CLK(clk_bF$buf5),
    .D(_170_),
    .Q(\u_bricks.regBricks [0]),
    .R(vdd),
    .S(_176_)
);

DFFSR _1121_ (
    .CLK(clk_bF$buf4),
    .D(_185_),
    .Q(\u_bricks.regBricks [8]),
    .R(vdd),
    .S(_176_)
);

DFFSR _1122_ (
    .CLK(clk_bF$buf3),
    .D(_171_),
    .Q(\u_bricks.regBricks [10]),
    .R(vdd),
    .S(_176_)
);

DFFSR _1123_ (
    .CLK(clk_bF$buf2),
    .D(_183_),
    .Q(\u_bricks.regBricks [11]),
    .R(vdd),
    .S(_176_)
);

DFFSR _1124_ (
    .CLK(clk_bF$buf1),
    .D(_172_),
    .Q(\u_bricks.regBricks [5]),
    .R(vdd),
    .S(_176_)
);

DFFSR _1125_ (
    .CLK(clk_bF$buf0),
    .D(_187_),
    .Q(\u_bricks.regBricks [1]),
    .R(vdd),
    .S(_176_)
);

DFFSR _1126_ (
    .CLK(clk_bF$buf7),
    .D(_173_),
    .Q(\u_bricks.regBricks [13]),
    .R(vdd),
    .S(_176_)
);

DFFSR _1127_ (
    .CLK(clk_bF$buf6),
    .D(_180_),
    .Q(\u_bricks.regBricks [4]),
    .R(vdd),
    .S(_176_)
);

DFFSR _1128_ (
    .CLK(clk_bF$buf5),
    .D(_174_),
    .Q(\u_bricks.regBricks [9]),
    .R(vdd),
    .S(_176_)
);

DFFSR _1129_ (
    .CLK(clk_bF$buf4),
    .D(_184_),
    .Q(\u_bricks.regBricks [14]),
    .R(vdd),
    .S(_176_)
);

DFFSR _1130_ (
    .CLK(clk_bF$buf3),
    .D(_175_),
    .Q(\u_bricks.regBricks [6]),
    .R(vdd),
    .S(_176_)
);

DFFSR _1131_ (
    .CLK(clk_bF$buf2),
    .D(_181_),
    .Q(\u_bricks.regBricks [7]),
    .R(vdd),
    .S(_176_)
);

DFFSR _1132_ (
    .CLK(clk_bF$buf1),
    .D(_179_),
    .Q(\u_bricks.regBricks [3]),
    .R(vdd),
    .S(_176_)
);

DFFSR _1133_ (
    .CLK(clk_bF$buf0),
    .D(_186_),
    .Q(\u_bricks.regBricks [15]),
    .R(vdd),
    .S(_176_)
);

AOI21X1 _1134_ (
    .A(_155_),
    .B(_136_),
    .C(_72_),
    .Y(_169_)
);

INVX1 _1135_ (
    .A(\u_bricks.regBricks [12]),
    .Y(_72_)
);

AOI21X1 _1136_ (
    .A(_151_),
    .B(_162_),
    .C(_85_),
    .Y(_170_)
);

AOI21X1 _1137_ (
    .A(_155_),
    .B(_139_),
    .C(_82_),
    .Y(_171_)
);

AOI21X1 _1138_ (
    .A(_73_),
    .B(_162_),
    .C(_86_),
    .Y(_172_)
);

INVX1 _1139_ (
    .A(_75_),
    .Y(_73_)
);

INVX1 _1140_ (
    .A(_74_),
    .Y(_173_)
);

OAI21X1 _1141_ (
    .A(_156_),
    .B(_75_),
    .C(\u_bricks.regBricks [13]),
    .Y(_74_)
);

OR2X2 _1142_ (
    .A(_166_),
    .B(_160_),
    .Y(_75_)
);

AOI21X1 _1143_ (
    .A(_155_),
    .B(_165_),
    .C(_76_),
    .Y(_174_)
);

INVX1 _1144_ (
    .A(\u_bricks.regBricks [9]),
    .Y(_76_)
);

AOI21X1 _1145_ (
    .A(_77_),
    .B(_162_),
    .C(_78_),
    .Y(_175_)
);

INVX1 _1146_ (
    .A(_149_),
    .Y(_77_)
);

INVX1 _1147_ (
    .A(\u_bricks.regBricks [6]),
    .Y(_78_)
);

INVX4 _1148_ (
    .A(reset),
    .Y(_176_)
);

AND2X2 _1149_ (
    .A(_87_),
    .B(_79_),
    .Y(_0_)
);

NOR2X1 _1150_ (
    .A(_83_),
    .B(_80_),
    .Y(_79_)
);

NAND3X1 _1151_ (
    .A(_135_),
    .B(_82_),
    .C(_81_),
    .Y(_80_)
);

NOR2X1 _1152_ (
    .A(\u_bricks.regBricks [13]),
    .B(\u_bricks.regBricks [12]),
    .Y(_81_)
);

INVX1 _1153_ (
    .A(\u_bricks.regBricks [10]),
    .Y(_82_)
);

NAND3X1 _1154_ (
    .A(_86_),
    .B(_85_),
    .C(_84_),
    .Y(_83_)
);

NOR2X1 _1155_ (
    .A(\u_bricks.regBricks [9]),
    .B(\u_bricks.regBricks [6]),
    .Y(_84_)
);

INVX1 _1156_ (
    .A(\u_bricks.regBricks [0]),
    .Y(_85_)
);

INVX1 _1157_ (
    .A(\u_bricks.regBricks [5]),
    .Y(_86_)
);

NOR2X1 _1158_ (
    .A(_90_),
    .B(_88_),
    .Y(_87_)
);

NAND3X1 _1159_ (
    .A(_168_),
    .B(_161_),
    .C(_89_),
    .Y(_88_)
);

NOR2X1 _1160_ (
    .A(\u_bricks.regBricks [8]),
    .B(\u_bricks.regBricks [14]),
    .Y(_89_)
);

NAND3X1 _1161_ (
    .A(_138_),
    .B(_137_),
    .C(_91_),
    .Y(_90_)
);

NOR2X1 _1162_ (
    .A(\u_bricks.regBricks [11]),
    .B(\u_bricks.regBricks [2]),
    .Y(_91_)
);

AND2X2 _1163_ (
    .A(_92_),
    .B(_118_),
    .Y(pixel_brick)
);

AOI21X1 _1164_ (
    .A(_103_),
    .B(\u_ball.x_pos [5]),
    .C(_93_),
    .Y(_92_)
);

NAND3X1 _1165_ (
    .A(_98_),
    .B(_94_),
    .C(_101_),
    .Y(_93_)
);

OAI21X1 _1166_ (
    .A(\u_ball.y_pos [1]),
    .B(_97_),
    .C(_95_),
    .Y(_94_)
);

NAND2X1 _1167_ (
    .A(\u_ball.y_pos [1]),
    .B(_96_),
    .Y(_95_)
);

NAND2X1 _1168_ (
    .A(\u_ball.y_pos [2]),
    .B(\u_ball.y_pos [0]),
    .Y(_96_)
);

NOR2X1 _1169_ (
    .A(\u_ball.y_pos [2]),
    .B(\u_ball.y_pos [0]),
    .Y(_97_)
);

NAND2X1 _1170_ (
    .A(_100_),
    .B(_99_),
    .Y(_98_)
);

NOR2X1 _1171_ (
    .A(\u_ball.x_pos [2]),
    .B(\u_ball.x_pos [0]),
    .Y(_99_)
);

INVX1 _1172_ (
    .A(\u_ball.x_pos [1]),
    .Y(_100_)
);

NOR2X1 _1173_ (
    .A(\u_ball.y_pos [4]),
    .B(_102_),
    .Y(_101_)
);

OR2X2 _1174_ (
    .A(\u_ball.y_pos [3]),
    .B(\u_ball.y_pos [5]),
    .Y(_102_)
);

OAI22X1 _1175_ (
    .A(_104_),
    .B(_107_),
    .C(_115_),
    .D(_110_),
    .Y(_103_)
);

NAND3X1 _1176_ (
    .A(\u_ball.x_pos [6]),
    .B(_105_),
    .C(_106_),
    .Y(_104_)
);

NAND3X1 _1177_ (
    .A(\u_bricks.regBricks [13]),
    .B(\u_ball.x_pos [3]),
    .C(_132_),
    .Y(_105_)
);

NAND3X1 _1178_ (
    .A(\u_bricks.regBricks [12]),
    .B(_133_),
    .C(_132_),
    .Y(_106_)
);

AOI21X1 _1179_ (
    .A(_108_),
    .B(_109_),
    .C(_132_),
    .Y(_107_)
);

NAND2X1 _1180_ (
    .A(\u_bricks.regBricks [14]),
    .B(_133_),
    .Y(_108_)
);

NAND2X1 _1181_ (
    .A(\u_bricks.regBricks [15]),
    .B(\u_ball.x_pos [3]),
    .Y(_109_)
);

NAND3X1 _1182_ (
    .A(_114_),
    .B(_113_),
    .C(_111_),
    .Y(_110_)
);

NAND3X1 _1183_ (
    .A(\u_bricks.regBricks [5]),
    .B(\u_ball.x_pos [3]),
    .C(_112_),
    .Y(_111_)
);

NAND2X1 _1184_ (
    .A(\u_ball.x_pos [4]),
    .B(\u_ball.x_pos [5]),
    .Y(_112_)
);

NAND3X1 _1185_ (
    .A(\u_bricks.regBricks [4]),
    .B(_133_),
    .C(_132_),
    .Y(_113_)
);

INVX1 _1186_ (
    .A(\u_ball.x_pos [6]),
    .Y(_114_)
);

AOI21X1 _1187_ (
    .A(_117_),
    .B(_116_),
    .C(_132_),
    .Y(_115_)
);

NAND2X1 _1188_ (
    .A(\u_bricks.regBricks [7]),
    .B(\u_ball.x_pos [3]),
    .Y(_116_)
);

NAND2X1 _1189_ (
    .A(\u_bricks.regBricks [6]),
    .B(_133_),
    .Y(_117_)
);

NAND3X1 _1190_ (
    .A(_134_),
    .B(_119_),
    .C(_125_),
    .Y(_118_)
);

OAI21X1 _1191_ (
    .A(_120_),
    .B(_122_),
    .C(\u_ball.x_pos [6]),
    .Y(_119_)
);

OAI21X1 _1192_ (
    .A(_154_),
    .B(_129_),
    .C(_121_),
    .Y(_120_)
);

NAND3X1 _1193_ (
    .A(\u_bricks.regBricks [9]),
    .B(\u_ball.x_pos [3]),
    .C(_132_),
    .Y(_121_)
);

AOI21X1 _1194_ (
    .A(_124_),
    .B(_123_),
    .C(_132_),
    .Y(_122_)
);

NAND2X1 _1195_ (
    .A(\u_bricks.regBricks [11]),
    .B(\u_ball.x_pos [3]),
    .Y(_123_)
);

NAND2X1 _1196_ (
    .A(\u_bricks.regBricks [10]),
    .B(_133_),
    .Y(_124_)
);

NAND3X1 _1197_ (
    .A(_130_),
    .B(_128_),
    .C(_126_),
    .Y(_125_)
);

AOI21X1 _1198_ (
    .A(_127_),
    .B(_168_),
    .C(\u_ball.x_pos [6]),
    .Y(_126_)
);

NOR2X1 _1199_ (
    .A(\u_ball.x_pos [4]),
    .B(_133_),
    .Y(_127_)
);

OR2X2 _1200_ (
    .A(_129_),
    .B(\u_bricks.regBricks [0]),
    .Y(_128_)
);

NAND2X1 _1201_ (
    .A(_133_),
    .B(_132_),
    .Y(_129_)
);

OAI21X1 _1202_ (
    .A(_135_),
    .B(_133_),
    .C(_131_),
    .Y(_130_)
);

AOI21X1 _1203_ (
    .A(_133_),
    .B(\u_bricks.regBricks [2]),
    .C(_132_),
    .Y(_131_)
);

INVX2 _1204_ (
    .A(\u_ball.x_pos [4]),
    .Y(_132_)
);

INVX2 _1205_ (
    .A(\u_ball.x_pos [3]),
    .Y(_133_)
);

INVX1 _1206_ (
    .A(\u_ball.x_pos [5]),
    .Y(_134_)
);

AOI21X1 _1207_ (
    .A(_144_),
    .B(_141_),
    .C(_135_),
    .Y(_179_)
);

INVX1 _1208_ (
    .A(\u_bricks.regBricks [3]),
    .Y(_135_)
);

AOI21X1 _1209_ (
    .A(_136_),
    .B(_162_),
    .C(_137_),
    .Y(_180_)
);

NOR2X1 _1210_ (
    .A(_160_),
    .B(_152_),
    .Y(_136_)
);

INVX1 _1211_ (
    .A(\u_bricks.regBricks [4]),
    .Y(_137_)
);

AOI21X1 _1212_ (
    .A(_157_),
    .B(_162_),
    .C(_138_),
    .Y(_181_)
);

INVX1 _1213_ (
    .A(\u_bricks.regBricks [7]),
    .Y(_138_)
);

AOI21X1 _1214_ (
    .A(_139_),
    .B(_162_),
    .C(_140_),
    .Y(_182_)
);

NOR2X1 _1215_ (
    .A(\u_ball.x_ball [5]),
    .B(_150_),
    .Y(_139_)
);

INVX1 _1216_ (
    .A(\u_bricks.regBricks [2]),
    .Y(_140_)
);

AOI21X1 _1217_ (
    .A(_143_),
    .B(_141_),
    .C(_147_),
    .Y(_183_)
);

NOR2X1 _1218_ (
    .A(_159_),
    .B(_142_),
    .Y(_141_)
);

NAND2X1 _1219_ (
    .A(_160_),
    .B(_163_),
    .Y(_142_)
);

INVX1 _1220_ (
    .A(_144_),
    .Y(_143_)
);

NAND2X1 _1221_ (
    .A(_145_),
    .B(_146_),
    .Y(_144_)
);

OAI21X1 _1222_ (
    .A(\u_ball.x_ball [5]),
    .B(_152_),
    .C(_164_),
    .Y(_145_)
);

NAND2X1 _1223_ (
    .A(\u_ball.x_ball [6]),
    .B(_151_),
    .Y(_146_)
);

INVX1 _1224_ (
    .A(\u_bricks.regBricks [11]),
    .Y(_147_)
);

INVX1 _1225_ (
    .A(_148_),
    .Y(_184_)
);

OAI21X1 _1226_ (
    .A(_156_),
    .B(_149_),
    .C(\u_bricks.regBricks [14]),
    .Y(_148_)
);

OR2X2 _1227_ (
    .A(_150_),
    .B(_160_),
    .Y(_149_)
);

NAND2X1 _1228_ (
    .A(\u_ball.x_ball [4]),
    .B(_153_),
    .Y(_150_)
);

AOI21X1 _1229_ (
    .A(_155_),
    .B(_151_),
    .C(_154_),
    .Y(_185_)
);

NOR2X1 _1230_ (
    .A(\u_ball.x_ball [5]),
    .B(_152_),
    .Y(_151_)
);

NAND2X1 _1231_ (
    .A(_153_),
    .B(_167_),
    .Y(_152_)
);

INVX1 _1232_ (
    .A(\u_ball.x_ball [3]),
    .Y(_153_)
);

INVX1 _1233_ (
    .A(\u_bricks.regBricks [8]),
    .Y(_154_)
);

AOI21X1 _1234_ (
    .A(_157_),
    .B(_155_),
    .C(_161_),
    .Y(_186_)
);

INVX2 _1235_ (
    .A(_156_),
    .Y(_155_)
);

NAND2X1 _1236_ (
    .A(\u_ball.x_ball [6]),
    .B(_163_),
    .Y(_156_)
);

INVX1 _1237_ (
    .A(_158_),
    .Y(_157_)
);

OR2X2 _1238_ (
    .A(_159_),
    .B(_160_),
    .Y(_158_)
);

NAND2X1 _1239_ (
    .A(\u_ball.x_ball [3]),
    .B(\u_ball.x_ball [4]),
    .Y(_159_)
);

INVX1 _1240_ (
    .A(\u_ball.x_ball [5]),
    .Y(_160_)
);

INVX1 _1241_ (
    .A(\u_bricks.regBricks [15]),
    .Y(_161_)
);

AOI21X1 _1242_ (
    .A(_165_),
    .B(_162_),
    .C(_168_),
    .Y(_187_)
);

AND2X2 _1243_ (
    .A(_163_),
    .B(_164_),
    .Y(_162_)
);

AND2X2 _1244_ (
    .A(_729_),
    .B(hit_brick),
    .Y(_163_)
);

INVX1 _1245_ (
    .A(\u_ball.x_ball [6]),
    .Y(_164_)
);

NOR2X1 _1246_ (
    .A(\u_ball.x_ball [5]),
    .B(_166_),
    .Y(_165_)
);

NAND2X1 _1247_ (
    .A(\u_ball.x_ball [3]),
    .B(_167_),
    .Y(_166_)
);

INVX1 _1248_ (
    .A(\u_ball.x_ball [4]),
    .Y(_167_)
);

INVX1 _1249_ (
    .A(\u_bricks.regBricks [1]),
    .Y(_168_)
);

DFFSR _1250_ (
    .CLK(clk_bF$buf7),
    .D(_486_),
    .Q(\u_ball.x_ball [5]),
    .R(_476__bF$buf2),
    .S(vdd)
);

DFFSR _1251_ (
    .CLK(clk_bF$buf6),
    .D(_442_),
    .Q(\u_ball.x_paddle [6]),
    .R(_437_),
    .S(vdd)
);

DFFSR _1252_ (
    .CLK(clk_bF$buf5),
    .D(_436_),
    .Q(\u_ball.x_paddle [2]),
    .R(_437_),
    .S(vdd)
);

DFFSR _1253_ (
    .CLK(clk_bF$buf4),
    .D(_441_),
    .Q(\u_ball.x_paddle [4]),
    .R(_437_),
    .S(vdd)
);

DFFSR _1254_ (
    .CLK(clk_bF$buf3),
    .D(_439_),
    .Q(\u_ball.x_paddle [1]),
    .R(_437_),
    .S(vdd)
);

DFFSR _1255_ (
    .CLK(clk_bF$buf2),
    .D(_440_),
    .Q(\u_ball.x_paddle [5]),
    .R(_437_),
    .S(vdd)
);

OAI21X1 _1256_ (
    .A(_416_),
    .B(_422_),
    .C(_325_),
    .Y(_435_)
);

NAND3X1 _1257_ (
    .A(_422_),
    .B(_408_),
    .C(_326_),
    .Y(_325_)
);

OR2X2 _1258_ (
    .A(_410_),
    .B(_409_),
    .Y(_326_)
);

OAI21X1 _1259_ (
    .A(_383_),
    .B(_422_),
    .C(_327_),
    .Y(_436_)
);

NAND3X1 _1260_ (
    .A(_422_),
    .B(_328_),
    .C(_329_),
    .Y(_327_)
);

NAND2X1 _1261_ (
    .A(_413_),
    .B(_330_),
    .Y(_328_)
);

OR2X2 _1262_ (
    .A(_330_),
    .B(_413_),
    .Y(_329_)
);

OAI21X1 _1263_ (
    .A(_383_),
    .B(btn_left),
    .C(_331_),
    .Y(_330_)
);

INVX1 _1264_ (
    .A(_411_),
    .Y(_331_)
);

INVX2 _1265_ (
    .A(reset),
    .Y(_437_)
);

NOR3X1 _1266_ (
    .A(_339_),
    .B(_332_),
    .C(_355_),
    .Y(pixel_paddle)
);

OAI21X1 _1267_ (
    .A(_349_),
    .B(_334_),
    .C(_333_),
    .Y(_332_)
);

AND2X2 _1268_ (
    .A(\u_ball.y_pos [4]),
    .B(\u_ball.y_pos [3]),
    .Y(_333_)
);

AOI21X1 _1269_ (
    .A(_337_),
    .B(_336_),
    .C(_335_),
    .Y(_334_)
);

OAI21X1 _1270_ (
    .A(_419_),
    .B(\u_ball.x_pos [4]),
    .C(_353_),
    .Y(_335_)
);

NAND2X1 _1271_ (
    .A(\u_ball.x_pos [4]),
    .B(_419_),
    .Y(_336_)
);

AOI21X1 _1272_ (
    .A(_338_),
    .B(_372_),
    .C(_374_),
    .Y(_337_)
);

OAI21X1 _1273_ (
    .A(\u_ball.x_paddle [2]),
    .B(_379_),
    .C(_369_),
    .Y(_338_)
);

OAI21X1 _1274_ (
    .A(_348_),
    .B(_342_),
    .C(_340_),
    .Y(_339_)
);

AOI21X1 _1275_ (
    .A(_352_),
    .B(\u_ball.x_paddle [6]),
    .C(_341_),
    .Y(_340_)
);

INVX1 _1276_ (
    .A(\u_ball.y_pos [5]),
    .Y(_341_)
);

AOI21X1 _1277_ (
    .A(_347_),
    .B(_346_),
    .C(_343_),
    .Y(_342_)
);

NAND2X1 _1278_ (
    .A(_345_),
    .B(_344_),
    .Y(_343_)
);

OAI21X1 _1279_ (
    .A(_419_),
    .B(\u_ball.x_pos [4]),
    .C(_349_),
    .Y(_344_)
);

OAI21X1 _1280_ (
    .A(_421_),
    .B(\u_ball.x_pos [5]),
    .C(_351_),
    .Y(_345_)
);

OR2X2 _1281_ (
    .A(\u_ball.x_paddle [4]),
    .B(\u_ball.x_pos [4]),
    .Y(_346_)
);

OAI21X1 _1282_ (
    .A(\u_ball.x_paddle [3]),
    .B(_375_),
    .C(_371_),
    .Y(_347_)
);

AOI21X1 _1283_ (
    .A(_419_),
    .B(_353_),
    .C(_349_),
    .Y(_348_)
);

OAI21X1 _1284_ (
    .A(\u_ball.x_paddle [5]),
    .B(_354_),
    .C(_350_),
    .Y(_349_)
);

INVX1 _1285_ (
    .A(_351_),
    .Y(_350_)
);

NOR2X1 _1286_ (
    .A(\u_ball.x_paddle [6]),
    .B(_352_),
    .Y(_351_)
);

INVX1 _1287_ (
    .A(\u_ball.x_pos [6]),
    .Y(_352_)
);

NAND2X1 _1288_ (
    .A(\u_ball.x_paddle [5]),
    .B(_354_),
    .Y(_353_)
);

INVX1 _1289_ (
    .A(\u_ball.x_pos [5]),
    .Y(_354_)
);

AOI21X1 _1290_ (
    .A(_361_),
    .B(_357_),
    .C(_356_),
    .Y(_355_)
);

OR2X2 _1291_ (
    .A(\u_ball.y_pos [1]),
    .B(\u_ball.y_pos [2]),
    .Y(_356_)
);

AOI21X1 _1292_ (
    .A(_366_),
    .B(_358_),
    .C(_365_),
    .Y(_357_)
);

NOR2X1 _1293_ (
    .A(_359_),
    .B(_369_),
    .Y(_358_)
);

OAI21X1 _1294_ (
    .A(\u_ball.x_paddle [1]),
    .B(_380_),
    .C(_360_),
    .Y(_359_)
);

INVX1 _1295_ (
    .A(\u_ball.x_pos [0]),
    .Y(_360_)
);

OR2X2 _1296_ (
    .A(_362_),
    .B(_366_),
    .Y(_361_)
);

OR2X2 _1297_ (
    .A(_363_),
    .B(_376_),
    .Y(_362_)
);

OAI21X1 _1298_ (
    .A(\u_ball.x_pos [0]),
    .B(_365_),
    .C(_364_),
    .Y(_363_)
);

OAI21X1 _1299_ (
    .A(\u_ball.x_paddle [1]),
    .B(_380_),
    .C(_377_),
    .Y(_364_)
);

INVX1 _1300_ (
    .A(\u_ball.y_pos [0]),
    .Y(_365_)
);

NAND2X1 _1301_ (
    .A(_371_),
    .B(_367_),
    .Y(_366_)
);

NAND3X1 _1302_ (
    .A(_382_),
    .B(_369_),
    .C(_368_),
    .Y(_367_)
);

INVX1 _1303_ (
    .A(_372_),
    .Y(_368_)
);

OAI21X1 _1304_ (
    .A(_413_),
    .B(\u_ball.x_pos [1]),
    .C(_370_),
    .Y(_369_)
);

AND2X2 _1305_ (
    .A(_382_),
    .B(_378_),
    .Y(_370_)
);

OAI21X1 _1306_ (
    .A(_381_),
    .B(_376_),
    .C(_372_),
    .Y(_371_)
);

NOR2X1 _1307_ (
    .A(_374_),
    .B(_373_),
    .Y(_372_)
);

NOR2X1 _1308_ (
    .A(\u_ball.x_pos [3]),
    .B(_416_),
    .Y(_373_)
);

NOR2X1 _1309_ (
    .A(\u_ball.x_paddle [3]),
    .B(_375_),
    .Y(_374_)
);

INVX1 _1310_ (
    .A(\u_ball.x_pos [3]),
    .Y(_375_)
);

AOI21X1 _1311_ (
    .A(\u_ball.x_paddle [1]),
    .B(_380_),
    .C(_377_),
    .Y(_376_)
);

NAND2X1 _1312_ (
    .A(_382_),
    .B(_378_),
    .Y(_377_)
);

NAND2X1 _1313_ (
    .A(\u_ball.x_paddle [2]),
    .B(_379_),
    .Y(_378_)
);

INVX1 _1314_ (
    .A(\u_ball.x_pos [2]),
    .Y(_379_)
);

INVX1 _1315_ (
    .A(\u_ball.x_pos [1]),
    .Y(_380_)
);

INVX1 _1316_ (
    .A(_382_),
    .Y(_381_)
);

NAND2X1 _1317_ (
    .A(\u_ball.x_pos [2]),
    .B(_383_),
    .Y(_382_)
);

INVX1 _1318_ (
    .A(\u_ball.x_paddle [2]),
    .Y(_383_)
);

NAND2X1 _1319_ (
    .A(_385_),
    .B(_384_),
    .Y(_439_)
);

NAND2X1 _1320_ (
    .A(_413_),
    .B(_422_),
    .Y(_384_)
);

OAI21X1 _1321_ (
    .A(_433_),
    .B(_423_),
    .C(\u_ball.x_paddle [1]),
    .Y(_385_)
);

NAND2X1 _1322_ (
    .A(_386_),
    .B(_387_),
    .Y(_440_)
);

OAI21X1 _1323_ (
    .A(_433_),
    .B(_423_),
    .C(\u_ball.x_paddle [5]),
    .Y(_386_)
);

NAND3X1 _1324_ (
    .A(_422_),
    .B(_390_),
    .C(_388_),
    .Y(_387_)
);

OR2X2 _1325_ (
    .A(_397_),
    .B(_389_),
    .Y(_388_)
);

OAI21X1 _1326_ (
    .A(_421_),
    .B(_431_),
    .C(_420_),
    .Y(_389_)
);

OAI21X1 _1327_ (
    .A(_400_),
    .B(_406_),
    .C(_397_),
    .Y(_390_)
);

OAI21X1 _1328_ (
    .A(_419_),
    .B(_422_),
    .C(_391_),
    .Y(_441_)
);

NAND3X1 _1329_ (
    .A(_422_),
    .B(_392_),
    .C(_393_),
    .Y(_391_)
);

NAND2X1 _1330_ (
    .A(_394_),
    .B(_399_),
    .Y(_392_)
);

OR2X2 _1331_ (
    .A(_399_),
    .B(_394_),
    .Y(_393_)
);

OAI21X1 _1332_ (
    .A(_419_),
    .B(btn_left),
    .C(_405_),
    .Y(_394_)
);

NAND2X1 _1333_ (
    .A(_402_),
    .B(_395_),
    .Y(_442_)
);

OAI21X1 _1334_ (
    .A(_401_),
    .B(_396_),
    .C(\u_ball.x_paddle [6]),
    .Y(_395_)
);

AOI22X1 _1335_ (
    .A(_397_),
    .B(_406_),
    .C(_400_),
    .D(_398_),
    .Y(_396_)
);

AOI22X1 _1336_ (
    .A(_419_),
    .B(_426_),
    .C(_399_),
    .D(_417_),
    .Y(_397_)
);

AND2X2 _1337_ (
    .A(_399_),
    .B(_417_),
    .Y(_398_)
);

AOI22X1 _1338_ (
    .A(\u_ball.x_paddle [3]),
    .B(_431_),
    .C(_410_),
    .D(_409_),
    .Y(_399_)
);

INVX1 _1339_ (
    .A(_420_),
    .Y(_400_)
);

INVX1 _1340_ (
    .A(_422_),
    .Y(_401_)
);

NAND3X1 _1341_ (
    .A(_434_),
    .B(_422_),
    .C(_403_),
    .Y(_402_)
);

OAI21X1 _1342_ (
    .A(_420_),
    .B(_407_),
    .C(_404_),
    .Y(_403_)
);

NAND3X1 _1343_ (
    .A(_406_),
    .B(_405_),
    .C(_407_),
    .Y(_404_)
);

NAND2X1 _1344_ (
    .A(_419_),
    .B(_426_),
    .Y(_405_)
);

NOR2X1 _1345_ (
    .A(_421_),
    .B(_431_),
    .Y(_406_)
);

NAND3X1 _1346_ (
    .A(_417_),
    .B(_414_),
    .C(_408_),
    .Y(_407_)
);

NAND2X1 _1347_ (
    .A(_409_),
    .B(_410_),
    .Y(_408_)
);

AOI21X1 _1348_ (
    .A(_426_),
    .B(_416_),
    .C(_415_),
    .Y(_409_)
);

OAI21X1 _1349_ (
    .A(_413_),
    .B(_411_),
    .C(_412_),
    .Y(_410_)
);

AOI21X1 _1350_ (
    .A(_427_),
    .B(_431_),
    .C(\u_ball.x_paddle [2]),
    .Y(_411_)
);

NAND2X1 _1351_ (
    .A(\u_ball.x_paddle [2]),
    .B(_431_),
    .Y(_412_)
);

INVX1 _1352_ (
    .A(\u_ball.x_paddle [1]),
    .Y(_413_)
);

INVX1 _1353_ (
    .A(_415_),
    .Y(_414_)
);

NOR2X1 _1354_ (
    .A(btn_left),
    .B(_416_),
    .Y(_415_)
);

INVX1 _1355_ (
    .A(\u_ball.x_paddle [3]),
    .Y(_416_)
);

INVX1 _1356_ (
    .A(_418_),
    .Y(_417_)
);

NOR2X1 _1357_ (
    .A(btn_left),
    .B(_419_),
    .Y(_418_)
);

INVX2 _1358_ (
    .A(\u_ball.x_paddle [4]),
    .Y(_419_)
);

NAND2X1 _1359_ (
    .A(_421_),
    .B(_425_),
    .Y(_420_)
);

INVX1 _1360_ (
    .A(\u_ball.x_paddle [5]),
    .Y(_421_)
);

NOR2X1 _1361_ (
    .A(_433_),
    .B(_423_),
    .Y(_422_)
);

AOI21X1 _1362_ (
    .A(_432_),
    .B(_424_),
    .C(_425_),
    .Y(_423_)
);

NAND3X1 _1363_ (
    .A(\u_ball.x_paddle [6]),
    .B(\u_ball.x_paddle [4]),
    .C(\u_ball.x_paddle [5]),
    .Y(_424_)
);

INVX1 _1364_ (
    .A(_426_),
    .Y(_425_)
);

NAND2X1 _1365_ (
    .A(_431_),
    .B(_427_),
    .Y(_426_)
);

NAND3X1 _1366_ (
    .A(_430_),
    .B(_429_),
    .C(_428_),
    .Y(_427_)
);

NOR2X1 _1367_ (
    .A(\u_ball.x_paddle [2]),
    .B(\u_ball.x_paddle [3]),
    .Y(_428_)
);

NOR2X1 _1368_ (
    .A(\u_ball.x_paddle [5]),
    .B(\u_ball.x_paddle [1]),
    .Y(_429_)
);

NOR2X1 _1369_ (
    .A(\u_ball.x_paddle [6]),
    .B(\u_ball.x_paddle [4]),
    .Y(_430_)
);

INVX2 _1370_ (
    .A(btn_left),
    .Y(_431_)
);

INVX1 _1371_ (
    .A(btn_right),
    .Y(_432_)
);

INVX1 _1372_ (
    .A(_729_),
    .Y(_433_)
);

INVX1 _1373_ (
    .A(\u_ball.x_paddle [6]),
    .Y(_434_)
);

DFFSR _1374_ (
    .CLK(clk_bF$buf1),
    .D(_565_),
    .Q(\u_ball.hit_paddle ),
    .R(_476__bF$buf1),
    .S(vdd)
);

DFFSR _1375_ (
    .CLK(clk_bF$buf0),
    .D(_686_),
    .Q(\u_ball.y_pos [3]),
    .R(vdd),
    .S(_677__bF$buf3)
);

DFFSR _1376_ (
    .CLK(clk_bF$buf7),
    .D(_519_),
    .Q(\u_ctrl.State [2]),
    .R(_677__bF$buf2),
    .S(vdd)
);

DFFSR _1377_ (
    .CLK(clk_bF$buf6),
    .D(_520_),
    .Q(\u_ctrl.State [1]),
    .R(_677__bF$buf1),
    .S(vdd)
);

DFFSR _1378_ (
    .CLK(clk_bF$buf5),
    .D(_531_),
    .Q(\u_ctrl.State [0]),
    .R(vdd),
    .S(_677__bF$buf0)
);

DFFSR _1379_ (
    .CLK(clk_bF$buf4),
    .D(_517_),
    .Q(\u_ctrl.State [3]),
    .R(_677__bF$buf3),
    .S(vdd)
);

DFFSR _1380_ (
    .CLK(clk_bF$buf3),
    .D(_669_),
    .Q(\u_ctrl.cnt_v_sync [1]),
    .R(_677__bF$buf2),
    .S(vdd)
);

DFFSR _1381_ (
    .CLK(clk_bF$buf2),
    .D(_690_),
    .Q(\u_ball.y_pos [0]),
    .R(vdd),
    .S(_677__bF$buf1)
);

DFFSR _1382_ (
    .CLK(clk_bF$buf1),
    .D(_670_),
    .Q(\u_ball.x_pos [5]),
    .R(vdd),
    .S(_677__bF$buf0)
);

DFFSR _1383_ (
    .CLK(clk_bF$buf0),
    .D(_687_),
    .Q(\u_ball.x_pos [6]),
    .R(vdd),
    .S(_677__bF$buf3)
);

DFFSR _1384_ (
    .CLK(clk_bF$buf7),
    .D(_671_),
    .Q(\u_ball.x_pos [4]),
    .R(vdd),
    .S(_677__bF$buf2)
);

DFFSR _1385_ (
    .CLK(clk_bF$buf6),
    .D(_692_),
    .Q(_727_),
    .R(_677__bF$buf1),
    .S(vdd)
);

DFFSR _1386_ (
    .CLK(clk_bF$buf5),
    .D(_672_),
    .Q(\u_ball.x_pos [3]),
    .R(vdd),
    .S(_677__bF$buf0)
);

DFFSR _1387_ (
    .CLK(clk_bF$buf4),
    .D(_688_),
    .Q(\u_ball.y_pos [2]),
    .R(vdd),
    .S(_677__bF$buf3)
);

DFFSR _1388_ (
    .CLK(clk_bF$buf3),
    .D(_673_),
    .Q(\u_ball.x_pos [2]),
    .R(vdd),
    .S(_677__bF$buf2)
);

DFFSR _1389_ (
    .CLK(clk_bF$buf2),
    .D(_691_),
    .Q(game_init),
    .R(_677__bF$buf1),
    .S(vdd)
);

DFFSR _1390_ (
    .CLK(clk_bF$buf1),
    .D(_674_),
    .Q(\u_ball.x_pos [1]),
    .R(vdd),
    .S(_677__bF$buf0)
);

DFFSR _1391_ (
    .CLK(clk_bF$buf0),
    .D(_684_),
    .Q(_729_),
    .R(_677__bF$buf3),
    .S(vdd)
);

DFFSR _1392_ (
    .CLK(clk_bF$buf7),
    .D(_675_),
    .Q(\u_ball.x_pos [0]),
    .R(vdd),
    .S(_677__bF$buf2)
);

DFFSR _1393_ (
    .CLK(clk_bF$buf6),
    .D(_689_),
    .Q(\u_ball.y_pos [1]),
    .R(vdd),
    .S(_677__bF$buf1)
);

DFFSR _1394_ (
    .CLK(clk_bF$buf5),
    .D(_676_),
    .Q(\u_ctrl.cnt_v_sync [2]),
    .R(_677__bF$buf0),
    .S(vdd)
);

DFFSR _1395_ (
    .CLK(clk_bF$buf4),
    .D(_685_),
    .Q(\u_ball.y_pos [5]),
    .R(vdd),
    .S(_677__bF$buf3)
);

DFFSR _1396_ (
    .CLK(clk_bF$buf3),
    .D(_683_),
    .Q(\u_ball.y_pos [4]),
    .R(vdd),
    .S(_677__bF$buf2)
);

DFFSR _1397_ (
    .CLK(clk_bF$buf2),
    .D(_515_),
    .Q(\u_ctrl.State [4]),
    .R(_677__bF$buf1),
    .S(vdd)
);

OAI21X1 _1398_ (
    .A(_592_),
    .B(_568_),
    .C(_567_),
    .Y(_668_)
);

NAND2X1 _1399_ (
    .A(\u_ctrl.cnt_v_sync [0]),
    .B(_592_),
    .Y(_567_)
);

AOI21X1 _1400_ (
    .A(_571_),
    .B(\u_ctrl.State [1]),
    .C(\u_ctrl.State_3_bF$buf3 ),
    .Y(_568_)
);

AOI22X1 _1401_ (
    .A(_572_),
    .B(_569_),
    .C(_592_),
    .D(_573_),
    .Y(_669_)
);

OAI21X1 _1402_ (
    .A(_665_),
    .B(_570_),
    .C(\u_ctrl.State [1]),
    .Y(_569_)
);

NOR2X1 _1403_ (
    .A(_571_),
    .B(_573_),
    .Y(_570_)
);

INVX1 _1404_ (
    .A(\u_ctrl.cnt_v_sync [0]),
    .Y(_571_)
);

AOI21X1 _1405_ (
    .A(_666_),
    .B(_599_),
    .C(\u_ctrl.State_3_bF$buf2 ),
    .Y(_572_)
);

INVX1 _1406_ (
    .A(\u_ctrl.cnt_v_sync [1]),
    .Y(_573_)
);

OAI21X1 _1407_ (
    .A(\u_ball.x_pos [5]),
    .B(_576_),
    .C(_574_),
    .Y(_670_)
);

OAI21X1 _1408_ (
    .A(_661_),
    .B(_618_),
    .C(_575_),
    .Y(_574_)
);

OAI21X1 _1409_ (
    .A(\u_ctrl.State_3_bF$buf1 ),
    .B(_599_),
    .C(_619_),
    .Y(_575_)
);

NAND2X1 _1410_ (
    .A(\u_ctrl.State_3_bF$buf0 ),
    .B(_657_),
    .Y(_576_)
);

AOI22X1 _1411_ (
    .A(_659_),
    .B(_647_),
    .C(_577_),
    .D(\u_ctrl.State_3_bF$buf3 ),
    .Y(_671_)
);

NAND2X1 _1412_ (
    .A(_578_),
    .B(_618_),
    .Y(_577_)
);

OAI21X1 _1413_ (
    .A(_660_),
    .B(_658_),
    .C(_659_),
    .Y(_578_)
);

OAI21X1 _1414_ (
    .A(\u_ball.x_pos [3]),
    .B(_581_),
    .C(_579_),
    .Y(_672_)
);

OAI21X1 _1415_ (
    .A(_661_),
    .B(_658_),
    .C(_580_),
    .Y(_579_)
);

OAI21X1 _1416_ (
    .A(\u_ctrl.State_3_bF$buf2 ),
    .B(_599_),
    .C(_660_),
    .Y(_580_)
);

OR2X2 _1417_ (
    .A(_658_),
    .B(_661_),
    .Y(_581_)
);

MUX2X1 _1418_ (
    .A(_582_),
    .B(\u_ball.x_pos [2]),
    .S(_583_),
    .Y(_673_)
);

AOI21X1 _1419_ (
    .A(_661_),
    .B(\u_ctrl.State [0]),
    .C(\u_ball.x_pos [2]),
    .Y(_582_)
);

NAND2X1 _1420_ (
    .A(\u_ball.x_pos [1]),
    .B(_586_),
    .Y(_583_)
);

OAI21X1 _1421_ (
    .A(\u_ball.x_pos [1]),
    .B(_585_),
    .C(_584_),
    .Y(_674_)
);

OAI21X1 _1422_ (
    .A(_661_),
    .B(_587_),
    .C(\u_ball.x_pos [1]),
    .Y(_584_)
);

AOI21X1 _1423_ (
    .A(_661_),
    .B(\u_ctrl.State [0]),
    .C(_586_),
    .Y(_585_)
);

AOI21X1 _1424_ (
    .A(_587_),
    .B(_647_),
    .C(_586_),
    .Y(_675_)
);

NOR2X1 _1425_ (
    .A(_661_),
    .B(_587_),
    .Y(_586_)
);

INVX1 _1426_ (
    .A(\u_ball.x_pos [0]),
    .Y(_587_)
);

OAI21X1 _1427_ (
    .A(_592_),
    .B(_589_),
    .C(_588_),
    .Y(_676_)
);

NAND2X1 _1428_ (
    .A(\u_ctrl.cnt_v_sync [2]),
    .B(_592_),
    .Y(_588_)
);

NOR2X1 _1429_ (
    .A(\u_ctrl.State_3_bF$buf1 ),
    .B(_590_),
    .Y(_589_)
);

OAI21X1 _1430_ (
    .A(_665_),
    .B(_591_),
    .C(_595_),
    .Y(_590_)
);

NAND2X1 _1431_ (
    .A(\u_ctrl.State [1]),
    .B(\u_ctrl.cnt_v_sync [2]),
    .Y(_591_)
);

OAI21X1 _1432_ (
    .A(_661_),
    .B(_642_),
    .C(_593_),
    .Y(_592_)
);

OAI21X1 _1433_ (
    .A(_666_),
    .B(_648_),
    .C(_633_),
    .Y(_593_)
);

INVX8 _1434_ (
    .A(reset),
    .Y(_677_)
);

NAND3X1 _1435_ (
    .A(_649_),
    .B(_637_),
    .C(_594_),
    .Y(_531_)
);

OAI21X1 _1436_ (
    .A(\u_ctrl.State [1]),
    .B(\u_ctrl.State [2]),
    .C(_597_),
    .Y(_594_)
);

NOR2X1 _1437_ (
    .A(_597_),
    .B(_641_),
    .Y(_520_)
);

AOI21X1 _1438_ (
    .A(_596_),
    .B(_595_),
    .C(_597_),
    .Y(_519_)
);

NAND2X1 _1439_ (
    .A(\u_ctrl.State [1]),
    .B(_663_),
    .Y(_595_)
);

OAI21X1 _1440_ (
    .A(_652_),
    .B(_656_),
    .C(\u_ctrl.State_3_bF$buf0 ),
    .Y(_596_)
);

INVX1 _1441_ (
    .A(_650_),
    .Y(_597_)
);

OAI21X1 _1442_ (
    .A(_636_),
    .B(_600_),
    .C(_598_),
    .Y(_517_)
);

NAND2X1 _1443_ (
    .A(\u_ctrl.State [2]),
    .B(_650_),
    .Y(_598_)
);

AOI21X1 _1444_ (
    .A(_600_),
    .B(_599_),
    .C(game_new),
    .Y(_515_)
);

INVX1 _1445_ (
    .A(\u_ctrl.State [0]),
    .Y(_599_)
);

INVX1 _1446_ (
    .A(\u_ctrl.State [4]),
    .Y(_600_)
);

OAI21X1 _1447_ (
    .A(_611_),
    .B(_632_),
    .C(_601_),
    .Y(_683_)
);

NAND2X1 _1448_ (
    .A(_632_),
    .B(_602_),
    .Y(_601_)
);

OAI21X1 _1449_ (
    .A(_603_),
    .B(_605_),
    .C(\u_ctrl.State_3_bF$buf3 ),
    .Y(_602_)
);

INVX1 _1450_ (
    .A(_604_),
    .Y(_603_)
);

OAI21X1 _1451_ (
    .A(_655_),
    .B(_654_),
    .C(_611_),
    .Y(_604_)
);

NOR2X1 _1452_ (
    .A(_611_),
    .B(_610_),
    .Y(_605_)
);

AOI21X1 _1453_ (
    .A(_661_),
    .B(_645_),
    .C(_606_),
    .Y(_684_)
);

AOI21X1 _1454_ (
    .A(_642_),
    .B(_645_),
    .C(_729_),
    .Y(_606_)
);

OAI21X1 _1455_ (
    .A(_612_),
    .B(_632_),
    .C(_607_),
    .Y(_685_)
);

OAI21X1 _1456_ (
    .A(_661_),
    .B(_608_),
    .C(_632_),
    .Y(_607_)
);

AND2X2 _1457_ (
    .A(_609_),
    .B(_652_),
    .Y(_608_)
);

OAI21X1 _1458_ (
    .A(_611_),
    .B(_610_),
    .C(_612_),
    .Y(_609_)
);

INVX1 _1459_ (
    .A(_653_),
    .Y(_610_)
);

INVX1 _1460_ (
    .A(\u_ball.y_pos [4]),
    .Y(_611_)
);

INVX1 _1461_ (
    .A(\u_ball.y_pos [5]),
    .Y(_612_)
);

OAI21X1 _1462_ (
    .A(_655_),
    .B(_632_),
    .C(_613_),
    .Y(_686_)
);

NAND2X1 _1463_ (
    .A(_614_),
    .B(_632_),
    .Y(_613_)
);

OAI21X1 _1464_ (
    .A(_653_),
    .B(_615_),
    .C(\u_ctrl.State_3_bF$buf2 ),
    .Y(_614_)
);

NOR2X1 _1465_ (
    .A(\u_ball.y_pos [3]),
    .B(_624_),
    .Y(_615_)
);

AOI22X1 _1466_ (
    .A(_620_),
    .B(_647_),
    .C(_616_),
    .D(\u_ctrl.State_3_bF$buf1 ),
    .Y(_687_)
);

NAND2X1 _1467_ (
    .A(_656_),
    .B(_617_),
    .Y(_616_)
);

OAI21X1 _1468_ (
    .A(_619_),
    .B(_618_),
    .C(_620_),
    .Y(_617_)
);

INVX1 _1469_ (
    .A(_657_),
    .Y(_618_)
);

INVX1 _1470_ (
    .A(\u_ball.x_pos [5]),
    .Y(_619_)
);

INVX1 _1471_ (
    .A(\u_ball.x_pos [6]),
    .Y(_620_)
);

OAI21X1 _1472_ (
    .A(_625_),
    .B(_632_),
    .C(_621_),
    .Y(_688_)
);

NAND2X1 _1473_ (
    .A(_622_),
    .B(_632_),
    .Y(_621_)
);

OAI21X1 _1474_ (
    .A(_624_),
    .B(_623_),
    .C(\u_ctrl.State_3_bF$buf0 ),
    .Y(_622_)
);

NOR2X1 _1475_ (
    .A(\u_ball.y_pos [2]),
    .B(_629_),
    .Y(_623_)
);

INVX1 _1476_ (
    .A(_654_),
    .Y(_624_)
);

INVX1 _1477_ (
    .A(\u_ball.y_pos [2]),
    .Y(_625_)
);

OAI21X1 _1478_ (
    .A(_630_),
    .B(_632_),
    .C(_626_),
    .Y(_689_)
);

NAND2X1 _1479_ (
    .A(_627_),
    .B(_632_),
    .Y(_626_)
);

OAI21X1 _1480_ (
    .A(_628_),
    .B(_629_),
    .C(\u_ctrl.State_3_bF$buf3 ),
    .Y(_627_)
);

NOR2X1 _1481_ (
    .A(\u_ball.y_pos [0]),
    .B(\u_ball.y_pos [1]),
    .Y(_628_)
);

NOR2X1 _1482_ (
    .A(_634_),
    .B(_630_),
    .Y(_629_)
);

INVX1 _1483_ (
    .A(\u_ball.y_pos [1]),
    .Y(_630_)
);

OAI21X1 _1484_ (
    .A(_634_),
    .B(_632_),
    .C(_631_),
    .Y(_690_)
);

OAI21X1 _1485_ (
    .A(_634_),
    .B(_661_),
    .C(_632_),
    .Y(_631_)
);

AOI21X1 _1486_ (
    .A(_656_),
    .B(\u_ctrl.State_3_bF$buf2 ),
    .C(_633_),
    .Y(_632_)
);

OAI21X1 _1487_ (
    .A(\u_ctrl.State_3_bF$buf1 ),
    .B(\u_ctrl.State [0]),
    .C(_649_),
    .Y(_633_)
);

INVX1 _1488_ (
    .A(\u_ball.y_pos [0]),
    .Y(_634_)
);

AOI21X1 _1489_ (
    .A(\u_ctrl.State [4]),
    .B(_637_),
    .C(_635_),
    .Y(_691_)
);

AOI21X1 _1490_ (
    .A(_636_),
    .B(\u_ctrl.State [0]),
    .C(game_init),
    .Y(_635_)
);

INVX1 _1491_ (
    .A(game_new),
    .Y(_636_)
);

NAND2X1 _1492_ (
    .A(game_new),
    .B(\u_ctrl.State [0]),
    .Y(_637_)
);

OAI21X1 _1493_ (
    .A(_667_),
    .B(_643_),
    .C(_638_),
    .Y(_692_)
);

NAND3X1 _1494_ (
    .A(_640_),
    .B(_639_),
    .C(_641_),
    .Y(_638_)
);

OAI21X1 _1495_ (
    .A(\u_ctrl.State [0]),
    .B(\u_ctrl.State [2]),
    .C(_661_),
    .Y(_639_)
);

INVX1 _1496_ (
    .A(_644_),
    .Y(_640_)
);

AOI21X1 _1497_ (
    .A(_642_),
    .B(\u_ctrl.State_3_bF$buf0 ),
    .C(_662_),
    .Y(_641_)
);

NOR2X1 _1498_ (
    .A(_652_),
    .B(_656_),
    .Y(_642_)
);

NOR3X1 _1499_ (
    .A(_662_),
    .B(_644_),
    .C(_651_),
    .Y(_643_)
);

OAI21X1 _1500_ (
    .A(_666_),
    .B(_650_),
    .C(_645_),
    .Y(_644_)
);

OAI21X1 _1501_ (
    .A(_647_),
    .B(_648_),
    .C(_646_),
    .Y(_645_)
);

OAI21X1 _1502_ (
    .A(\u_ctrl.State [1]),
    .B(\u_ctrl.State [2]),
    .C(_649_),
    .Y(_646_)
);

NOR2X1 _1503_ (
    .A(\u_ctrl.State_3_bF$buf3 ),
    .B(\u_ctrl.State [0]),
    .Y(_647_)
);

INVX1 _1504_ (
    .A(_649_),
    .Y(_648_)
);

OAI21X1 _1505_ (
    .A(_726_),
    .B(_0_),
    .C(\u_ctrl.State_3_bF$buf2 ),
    .Y(_649_)
);

NOR2X1 _1506_ (
    .A(_726_),
    .B(_0_),
    .Y(_650_)
);

NOR3X1 _1507_ (
    .A(_661_),
    .B(_652_),
    .C(_656_),
    .Y(_651_)
);

NAND3X1 _1508_ (
    .A(\u_ball.y_pos [5]),
    .B(\u_ball.y_pos [4]),
    .C(_653_),
    .Y(_652_)
);

NOR2X1 _1509_ (
    .A(_655_),
    .B(_654_),
    .Y(_653_)
);

NAND3X1 _1510_ (
    .A(\u_ball.y_pos [0]),
    .B(\u_ball.y_pos [1]),
    .C(\u_ball.y_pos [2]),
    .Y(_654_)
);

INVX1 _1511_ (
    .A(\u_ball.y_pos [3]),
    .Y(_655_)
);

NAND3X1 _1512_ (
    .A(\u_ball.x_pos [6]),
    .B(\u_ball.x_pos [5]),
    .C(_657_),
    .Y(_656_)
);

NOR3X1 _1513_ (
    .A(_660_),
    .B(_659_),
    .C(_658_),
    .Y(_657_)
);

NAND3X1 _1514_ (
    .A(\u_ball.x_pos [1]),
    .B(\u_ball.x_pos [0]),
    .C(\u_ball.x_pos [2]),
    .Y(_658_)
);

INVX1 _1515_ (
    .A(\u_ball.x_pos [4]),
    .Y(_659_)
);

INVX1 _1516_ (
    .A(\u_ball.x_pos [3]),
    .Y(_660_)
);

INVX4 _1517_ (
    .A(\u_ctrl.State_3_bF$buf1 ),
    .Y(_661_)
);

NOR2X1 _1518_ (
    .A(_666_),
    .B(_663_),
    .Y(_662_)
);

NOR2X1 _1519_ (
    .A(\u_ctrl.cnt_v_sync [2]),
    .B(_664_),
    .Y(_663_)
);

INVX1 _1520_ (
    .A(_665_),
    .Y(_664_)
);

NOR2X1 _1521_ (
    .A(\u_ctrl.cnt_v_sync [0]),
    .B(\u_ctrl.cnt_v_sync [1]),
    .Y(_665_)
);

INVX1 _1522_ (
    .A(\u_ctrl.State [1]),
    .Y(_666_)
);

INVX1 _1523_ (
    .A(_727_),
    .Y(_667_)
);

INVX1 _1524_ (
    .A(pixel_ball),
    .Y(_720_)
);

INVX1 _1525_ (
    .A(pixel_paddle),
    .Y(_721_)
);

INVX1 _1526_ (
    .A(pixel_brick),
    .Y(_722_)
);

NAND3X1 _1527_ (
    .A(_720_),
    .B(_721_),
    .C(_722_),
    .Y(_728_)
);

DFFSR _1528_ (
    .CLK(clk_bF$buf1),
    .D(_468_),
    .Q(\u_ball.x_ball [4]),
    .R(_476__bF$buf0),
    .S(vdd)
);

DFFSR _1529_ (
    .CLK(clk_bF$buf0),
    .D(_169_),
    .Q(\u_bricks.regBricks [12]),
    .R(vdd),
    .S(_176_)
);

DFFSR _1530_ (
    .CLK(clk_bF$buf7),
    .D(_435_),
    .Q(\u_ball.x_paddle [3]),
    .R(_437_),
    .S(vdd)
);

DFFSR _1531_ (
    .CLK(clk_bF$buf6),
    .D(_668_),
    .Q(\u_ctrl.cnt_v_sync [0]),
    .R(_677__bF$buf0),
    .S(vdd)
);

BUFX2 _731_ (
    .A(_729_),
    .Y(v_sync)
);

BUFX2 _732_ (
    .A(_728_),
    .Y(pixel)
);

BUFX2 _733_ (
    .A(_727_),
    .Y(p_tick)
);

BUFX2 _734_ (
    .A(_726_),
    .Y(game_over)
);

BUFX2 _735_ (
    .A(_0_),
    .Y(game_complete)
);

DFFSR _736_ (
    .CLK(clk_bF$buf5),
    .D(_470_),
    .Q(\u_ball.y_ball [5]),
    .R(_476__bF$buf3),
    .S(vdd)
);

DFFSR _737_ (
    .CLK(clk_bF$buf4),
    .D(_484_),
    .Q(\u_ball.y_ball [1]),
    .R(_476__bF$buf2),
    .S(vdd)
);

DFFSR _738_ (
    .CLK(clk_bF$buf3),
    .D(_471_),
    .Q(_726_),
    .R(_476__bF$buf1),
    .S(vdd)
);

DFFSR _739_ (
    .CLK(clk_bF$buf2),
    .D(_488_),
    .Q(\u_ball.sign_x ),
    .R(_476__bF$buf0),
    .S(vdd)
);

DFFSR _740_ (
    .CLK(clk_bF$buf1),
    .D(_680_),
    .Q(hit_brick),
    .R(_476__bF$buf3),
    .S(vdd)
);

DFFSR _741_ (
    .CLK(clk_bF$buf0),
    .D(_472_),
    .Q(\u_ball.x_ball [6]),
    .R(_476__bF$buf2),
    .S(vdd)
);

DFFSR _742_ (
    .CLK(clk_bF$buf7),
    .D(_481_),
    .Q(\u_ball.y_ball [4]),
    .R(vdd),
    .S(_476__bF$buf1)
);

DFFSR _743_ (
    .CLK(clk_bF$buf6),
    .D(_473_),
    .Q(\u_ball.x_ball [3]),
    .R(_476__bF$buf0),
    .S(vdd)
);

DFFSR _744_ (
    .CLK(clk_bF$buf5),
    .D(_485_),
    .Q(\u_ball.y_ball [0]),
    .R(_476__bF$buf3),
    .S(vdd)
);

DFFSR _745_ (
    .CLK(clk_bF$buf4),
    .D(_474_),
    .Q(\u_ball.x_ball [2]),
    .R(_476__bF$buf2),
    .S(vdd)
);

DFFSR _746_ (
    .CLK(clk_bF$buf3),
    .D(_482_),
    .Q(\u_ball.y_ball [3]),
    .R(_476__bF$buf1),
    .S(vdd)
);

DFFSR _747_ (
    .CLK(clk_bF$buf2),
    .D(_475_),
    .Q(\u_ball.x_ball [1]),
    .R(_476__bF$buf0),
    .S(vdd)
);

DFFSR _748_ (
    .CLK(clk_bF$buf1),
    .D(_487_),
    .Q(\u_ball.x2 ),
    .R(_476__bF$buf3),
    .S(vdd)
);

DFFSR _749_ (
    .CLK(clk_bF$buf0),
    .D(_480_),
    .Q(\u_ball.x_ball [0]),
    .R(_476__bF$buf2),
    .S(vdd)
);

DFFSR _750_ (
    .CLK(clk_bF$buf7),
    .D(_483_),
    .Q(\u_ball.y_ball [2]),
    .R(vdd),
    .S(_476__bF$buf1)
);

OAI22X1 _751_ (
    .A(_297_),
    .B(_234_),
    .C(_202_),
    .D(_31_),
    .Y(_468_)
);

NAND2X1 _752_ (
    .A(_210_),
    .B(_30_),
    .Y(_31_)
);

OR2X2 _753_ (
    .A(_214_),
    .B(_211_),
    .Y(_30_)
);

AOI21X1 _754_ (
    .A(_729_),
    .B(_28_),
    .C(_29_),
    .Y(_469_)
);

OAI21X1 _755_ (
    .A(\u_ball.sign_y ),
    .B(_232_),
    .C(_52_),
    .Y(_29_)
);

OAI21X1 _756_ (
    .A(\u_ball.y_ball [4]),
    .B(_27_),
    .C(_719_),
    .Y(_28_)
);

NAND3X1 _757_ (
    .A(_70_),
    .B(_543_),
    .C(_20_),
    .Y(_27_)
);

AOI21X1 _758_ (
    .A(\u_ball.y_ball [5]),
    .B(_25_),
    .C(_26_),
    .Y(_470_)
);

OAI21X1 _759_ (
    .A(\u_ball.y_ball [5]),
    .B(_25_),
    .C(_52_),
    .Y(_26_)
);

AOI21X1 _760_ (
    .A(_24_),
    .B(_23_),
    .C(_231_),
    .Y(_25_)
);

NAND3X1 _761_ (
    .A(_63_),
    .B(_58_),
    .C(_56_),
    .Y(_24_)
);

NAND3X1 _762_ (
    .A(_64_),
    .B(_59_),
    .C(_68_),
    .Y(_23_)
);

AOI21X1 _763_ (
    .A(_22_),
    .B(_19_),
    .C(game_init),
    .Y(_471_)
);

NAND3X1 _764_ (
    .A(\u_ball.y_ball [4]),
    .B(\u_ball.y_ball [5]),
    .C(_21_),
    .Y(_22_)
);

AOI21X1 _765_ (
    .A(_20_),
    .B(_203_),
    .C(_70_),
    .Y(_21_)
);

NOR2X1 _766_ (
    .A(\u_ball.y_ball [1]),
    .B(\u_ball.y_ball [2]),
    .Y(_20_)
);

INVX1 _767_ (
    .A(_726_),
    .Y(_19_)
);

OAI21X1 _768_ (
    .A(_313_),
    .B(_234_),
    .C(_18_),
    .Y(_472_)
);

NAND3X1 _769_ (
    .A(_230_),
    .B(_17_),
    .C(_14_),
    .Y(_18_)
);

NAND3X1 _770_ (
    .A(_15_),
    .B(_16_),
    .C(_9_),
    .Y(_17_)
);

INVX1 _771_ (
    .A(_13_),
    .Y(_16_)
);

INVX1 _772_ (
    .A(_208_),
    .Y(_15_)
);

NAND2X1 _773_ (
    .A(_13_),
    .B(_10_),
    .Y(_14_)
);

NAND2X1 _774_ (
    .A(_12_),
    .B(_11_),
    .Y(_13_)
);

NAND2X1 _775_ (
    .A(\u_ball.sign_x ),
    .B(\u_ball.x_ball [6]),
    .Y(_12_)
);

NAND2X1 _776_ (
    .A(_467_),
    .B(_313_),
    .Y(_11_)
);

OAI21X1 _777_ (
    .A(\u_ball.sign_x ),
    .B(\u_ball.x_ball [5]),
    .C(_9_),
    .Y(_10_)
);

NAND3X1 _778_ (
    .A(_7_),
    .B(_8_),
    .C(_210_),
    .Y(_9_)
);

INVX1 _779_ (
    .A(_207_),
    .Y(_8_)
);

INVX1 _780_ (
    .A(_213_),
    .Y(_7_)
);

OAI21X1 _781_ (
    .A(_235_),
    .B(_6_),
    .C(_3_),
    .Y(_473_)
);

OAI21X1 _782_ (
    .A(_216_),
    .B(_4_),
    .C(_5_),
    .Y(_6_)
);

AOI21X1 _783_ (
    .A(_4_),
    .B(_216_),
    .C(game_init),
    .Y(_5_)
);

OAI21X1 _784_ (
    .A(_467_),
    .B(_451_),
    .C(_219_),
    .Y(_4_)
);

NAND2X1 _785_ (
    .A(\u_ball.x_ball [3]),
    .B(_235_),
    .Y(_3_)
);

OAI21X1 _786_ (
    .A(_451_),
    .B(_234_),
    .C(_2_),
    .Y(_474_)
);

OAI21X1 _787_ (
    .A(_223_),
    .B(_220_),
    .C(_1_),
    .Y(_2_)
);

AOI21X1 _788_ (
    .A(_223_),
    .B(_220_),
    .C(_202_),
    .Y(_1_)
);

OAI22X1 _789_ (
    .A(_226_),
    .B(_234_),
    .C(_725_),
    .D(_730_),
    .Y(_475_)
);

NAND2X1 _790_ (
    .A(_230_),
    .B(_224_),
    .Y(_730_)
);

AOI21X1 _791_ (
    .A(_225_),
    .B(_228_),
    .C(_227_),
    .Y(_725_)
);

INVX8 _792_ (
    .A(reset),
    .Y(_476_)
);

AOI21X1 _793_ (
    .A(_724_),
    .B(_466_),
    .C(_234_),
    .Y(_565_)
);

NAND3X1 _794_ (
    .A(pixel_paddle),
    .B(_563_),
    .C(_718_),
    .Y(_724_)
);

AOI21X1 _795_ (
    .A(_723_),
    .B(_719_),
    .C(_234_),
    .Y(_680_)
);

NAND3X1 _796_ (
    .A(pixel_brick),
    .B(_563_),
    .C(_718_),
    .Y(_723_)
);

INVX1 _797_ (
    .A(hit_brick),
    .Y(_719_)
);

AND2X2 _798_ (
    .A(_718_),
    .B(_563_),
    .Y(pixel_ball)
);

AOI22X1 _799_ (
    .A(_678_),
    .B(_681_),
    .C(_257_),
    .D(_717_),
    .Y(_718_)
);

OAI22X1 _800_ (
    .A(_533_),
    .B(_714_),
    .C(_716_),
    .D(_713_),
    .Y(_717_)
);

OAI21X1 _801_ (
    .A(\u_ball.x_pos [5]),
    .B(_711_),
    .C(_715_),
    .Y(_716_)
);

NAND3X1 _802_ (
    .A(_533_),
    .B(_714_),
    .C(_257_),
    .Y(_715_)
);

OAI21X1 _803_ (
    .A(_464_),
    .B(_705_),
    .C(_313_),
    .Y(_714_)
);

AND2X2 _804_ (
    .A(_712_),
    .B(_708_),
    .Y(_713_)
);

AOI22X1 _805_ (
    .A(\u_ball.x_pos [4]),
    .B(_709_),
    .C(_711_),
    .D(\u_ball.x_pos [5]),
    .Y(_712_)
);

NAND2X1 _806_ (
    .A(_258_),
    .B(_710_),
    .Y(_711_)
);

NAND2X1 _807_ (
    .A(_464_),
    .B(_705_),
    .Y(_710_)
);

NAND2X1 _808_ (
    .A(_705_),
    .B(_706_),
    .Y(_709_)
);

NAND3X1 _809_ (
    .A(_703_),
    .B(_707_),
    .C(_700_),
    .Y(_708_)
);

NAND3X1 _810_ (
    .A(_704_),
    .B(_705_),
    .C(_706_),
    .Y(_707_)
);

OAI21X1 _811_ (
    .A(_456_),
    .B(_682_),
    .C(_297_),
    .Y(_706_)
);

NAND3X1 _812_ (
    .A(\u_ball.x_ball [4]),
    .B(\u_ball.x_ball [3]),
    .C(_694_),
    .Y(_705_)
);

INVX1 _813_ (
    .A(\u_ball.x_pos [4]),
    .Y(_704_)
);

NAND2X1 _814_ (
    .A(_701_),
    .B(_702_),
    .Y(_703_)
);

NAND2X1 _815_ (
    .A(_695_),
    .B(_693_),
    .Y(_702_)
);

INVX1 _816_ (
    .A(\u_ball.x_pos [3]),
    .Y(_701_)
);

NAND2X1 _817_ (
    .A(_696_),
    .B(_699_),
    .Y(_700_)
);

NAND2X1 _818_ (
    .A(_698_),
    .B(_534_),
    .Y(_699_)
);

OAI21X1 _819_ (
    .A(_451_),
    .B(_499_),
    .C(_697_),
    .Y(_698_)
);

OAI21X1 _820_ (
    .A(\u_ball.x_ball [0]),
    .B(\u_ball.x_ball [1]),
    .C(_451_),
    .Y(_697_)
);

NAND3X1 _821_ (
    .A(\u_ball.x_pos [3]),
    .B(_695_),
    .C(_693_),
    .Y(_696_)
);

NAND2X1 _822_ (
    .A(_456_),
    .B(_694_),
    .Y(_695_)
);

NAND3X1 _823_ (
    .A(_444_),
    .B(_226_),
    .C(_451_),
    .Y(_694_)
);

NAND2X1 _824_ (
    .A(\u_ball.x_ball [3]),
    .B(_682_),
    .Y(_693_)
);

NOR3X1 _825_ (
    .A(\u_ball.x_ball [0]),
    .B(\u_ball.x_ball [1]),
    .C(\u_ball.x_ball [2]),
    .Y(_682_)
);

AND2X2 _826_ (
    .A(_679_),
    .B(_530_),
    .Y(_681_)
);

NAND2X1 _827_ (
    .A(_508_),
    .B(_523_),
    .Y(_679_)
);

NAND2X1 _828_ (
    .A(_566_),
    .B(_564_),
    .Y(_678_)
);

AOI21X1 _829_ (
    .A(_523_),
    .B(_48_),
    .C(_508_),
    .Y(_566_)
);

NAND3X1 _830_ (
    .A(_497_),
    .B(_495_),
    .C(_492_),
    .Y(_564_)
);

AOI21X1 _831_ (
    .A(_525_),
    .B(_532_),
    .C(_562_),
    .Y(_563_)
);

NAND2X1 _832_ (
    .A(_561_),
    .B(_542_),
    .Y(_562_)
);

AOI21X1 _833_ (
    .A(_550_),
    .B(_544_),
    .C(_560_),
    .Y(_561_)
);

NAND3X1 _834_ (
    .A(_555_),
    .B(_553_),
    .C(_559_),
    .Y(_560_)
);

NOR2X1 _835_ (
    .A(_556_),
    .B(_558_),
    .Y(_559_)
);

NOR2X1 _836_ (
    .A(_557_),
    .B(_551_),
    .Y(_558_)
);

NAND2X1 _837_ (
    .A(\u_ball.y_pos [5]),
    .B(_543_),
    .Y(_557_)
);

NOR2X1 _838_ (
    .A(\u_ball.y_pos [5]),
    .B(_543_),
    .Y(_556_)
);

OAI21X1 _839_ (
    .A(_70_),
    .B(\u_ball.y_pos [3]),
    .C(_554_),
    .Y(_555_)
);

INVX1 _840_ (
    .A(_544_),
    .Y(_554_)
);

NAND3X1 _841_ (
    .A(_41_),
    .B(_546_),
    .C(_552_),
    .Y(_553_)
);

OAI21X1 _842_ (
    .A(_545_),
    .B(_551_),
    .C(_544_),
    .Y(_552_)
);

NOR2X1 _843_ (
    .A(\u_ball.y_pos [4]),
    .B(_60_),
    .Y(_551_)
);

OAI21X1 _844_ (
    .A(_60_),
    .B(\u_ball.y_pos [4]),
    .C(_549_),
    .Y(_550_)
);

OAI21X1 _845_ (
    .A(_548_),
    .B(_547_),
    .C(_545_),
    .Y(_549_)
);

OAI21X1 _846_ (
    .A(_70_),
    .B(\u_ball.y_pos [3]),
    .C(_41_),
    .Y(_548_)
);

INVX1 _847_ (
    .A(_546_),
    .Y(_547_)
);

NAND3X1 _848_ (
    .A(_38_),
    .B(_43_),
    .C(_37_),
    .Y(_546_)
);

NAND2X1 _849_ (
    .A(\u_ball.y_pos [3]),
    .B(_70_),
    .Y(_545_)
);

AOI22X1 _850_ (
    .A(_60_),
    .B(\u_ball.y_pos [4]),
    .C(_543_),
    .D(\u_ball.y_pos [5]),
    .Y(_544_)
);

INVX1 _851_ (
    .A(\u_ball.y_ball [5]),
    .Y(_543_)
);

OAI21X1 _852_ (
    .A(\u_ball.x_ball [6]),
    .B(_533_),
    .C(_541_),
    .Y(_542_)
);

NAND2X1 _853_ (
    .A(_540_),
    .B(_538_),
    .Y(_541_)
);

INVX1 _854_ (
    .A(_539_),
    .Y(_540_)
);

OAI22X1 _855_ (
    .A(\u_ball.x_pos [5]),
    .B(_464_),
    .C(_313_),
    .D(\u_ball.x_pos [6]),
    .Y(_539_)
);

OAI21X1 _856_ (
    .A(_536_),
    .B(_535_),
    .C(_537_),
    .Y(_538_)
);

AOI22X1 _857_ (
    .A(_464_),
    .B(\u_ball.x_pos [5]),
    .C(_297_),
    .D(\u_ball.x_pos [4]),
    .Y(_537_)
);

OAI22X1 _858_ (
    .A(\u_ball.x_pos [3]),
    .B(_456_),
    .C(_297_),
    .D(\u_ball.x_pos [4]),
    .Y(_536_)
);

AOI22X1 _859_ (
    .A(_456_),
    .B(\u_ball.x_pos [3]),
    .C(_534_),
    .D(_500_),
    .Y(_535_)
);

NAND3X1 _860_ (
    .A(_498_),
    .B(_506_),
    .C(_502_),
    .Y(_534_)
);

INVX1 _861_ (
    .A(\u_ball.x_pos [6]),
    .Y(_533_)
);

AOI21X1 _862_ (
    .A(_523_),
    .B(_509_),
    .C(_530_),
    .Y(_532_)
);

NOR2X1 _863_ (
    .A(_529_),
    .B(_528_),
    .Y(_530_)
);

AOI21X1 _864_ (
    .A(_526_),
    .B(_506_),
    .C(_50_),
    .Y(_529_)
);

INVX1 _865_ (
    .A(_527_),
    .Y(_528_)
);

NAND3X1 _866_ (
    .A(_526_),
    .B(_506_),
    .C(_50_),
    .Y(_527_)
);

NAND2X1 _867_ (
    .A(\u_ball.x_ball [1]),
    .B(_501_),
    .Y(_526_)
);

NAND2X1 _868_ (
    .A(_524_),
    .B(_496_),
    .Y(_525_)
);

AOI21X1 _869_ (
    .A(_523_),
    .B(_497_),
    .C(_509_),
    .Y(_524_)
);

NAND2X1 _870_ (
    .A(_522_),
    .B(_514_),
    .Y(_523_)
);

NAND3X1 _871_ (
    .A(_479_),
    .B(_489_),
    .C(_521_),
    .Y(_522_)
);

AOI21X1 _872_ (
    .A(_38_),
    .B(_44_),
    .C(_518_),
    .Y(_521_)
);

AOI21X1 _873_ (
    .A(_38_),
    .B(_34_),
    .C(_516_),
    .Y(_518_)
);

NAND2X1 _874_ (
    .A(\u_ball.y_ball [0]),
    .B(_45_),
    .Y(_516_)
);

NAND3X1 _875_ (
    .A(_39_),
    .B(_35_),
    .C(_513_),
    .Y(_514_)
);

OAI21X1 _876_ (
    .A(_46_),
    .B(_37_),
    .C(_512_),
    .Y(_513_)
);

OAI21X1 _877_ (
    .A(_46_),
    .B(_510_),
    .C(_511_),
    .Y(_512_)
);

NOR2X1 _878_ (
    .A(\u_ball.y_pos [0]),
    .B(_203_),
    .Y(_511_)
);

NOR2X1 _879_ (
    .A(\u_ball.y_pos [1]),
    .B(_201_),
    .Y(_510_)
);

INVX1 _880_ (
    .A(_508_),
    .Y(_509_)
);

NAND2X1 _881_ (
    .A(_507_),
    .B(_504_),
    .Y(_508_)
);

NAND3X1 _882_ (
    .A(_506_),
    .B(_502_),
    .C(_505_),
    .Y(_507_)
);

NAND2X1 _883_ (
    .A(\u_ball.x_pos [1]),
    .B(_226_),
    .Y(_506_)
);

NAND2X1 _884_ (
    .A(_498_),
    .B(_500_),
    .Y(_505_)
);

NAND3X1 _885_ (
    .A(_498_),
    .B(_500_),
    .C(_503_),
    .Y(_504_)
);

OAI21X1 _886_ (
    .A(\u_ball.x_ball [1]),
    .B(_501_),
    .C(_502_),
    .Y(_503_)
);

OAI22X1 _887_ (
    .A(\u_ball.x_pos [0]),
    .B(_444_),
    .C(_226_),
    .D(\u_ball.x_pos [1]),
    .Y(_502_)
);

INVX1 _888_ (
    .A(\u_ball.x_pos [1]),
    .Y(_501_)
);

NAND2X1 _889_ (
    .A(\u_ball.x_ball [2]),
    .B(_499_),
    .Y(_500_)
);

INVX1 _890_ (
    .A(\u_ball.x_pos [2]),
    .Y(_499_)
);

NAND2X1 _891_ (
    .A(\u_ball.x_pos [2]),
    .B(_451_),
    .Y(_498_)
);

INVX1 _892_ (
    .A(_48_),
    .Y(_497_)
);

NAND3X1 _893_ (
    .A(_48_),
    .B(_495_),
    .C(_492_),
    .Y(_496_)
);

NAND3X1 _894_ (
    .A(_477_),
    .B(_490_),
    .C(_494_),
    .Y(_495_)
);

NAND3X1 _895_ (
    .A(_479_),
    .B(_493_),
    .C(_489_),
    .Y(_494_)
);

INVX1 _896_ (
    .A(_33_),
    .Y(_493_)
);

OAI21X1 _897_ (
    .A(_478_),
    .B(_32_),
    .C(_491_),
    .Y(_492_)
);

NAND3X1 _898_ (
    .A(_479_),
    .B(_490_),
    .C(_489_),
    .Y(_491_)
);

OAI21X1 _899_ (
    .A(\u_ball.y_ball [1]),
    .B(_47_),
    .C(_44_),
    .Y(_490_)
);

OAI21X1 _900_ (
    .A(_46_),
    .B(_44_),
    .C(_36_),
    .Y(_489_)
);

NAND3X1 _901_ (
    .A(_38_),
    .B(_37_),
    .C(_40_),
    .Y(_479_)
);

INVX1 _902_ (
    .A(_477_),
    .Y(_478_)
);

NAND2X1 _903_ (
    .A(\u_ball.y_pos [0]),
    .B(_203_),
    .Y(_477_)
);

AOI21X1 _904_ (
    .A(_35_),
    .B(_39_),
    .C(_33_),
    .Y(_32_)
);

NAND2X1 _905_ (
    .A(_38_),
    .B(_34_),
    .Y(_33_)
);

NAND2X1 _906_ (
    .A(\u_ball.y_ball [1]),
    .B(_47_),
    .Y(_34_)
);

NAND3X1 _907_ (
    .A(_38_),
    .B(_37_),
    .C(_36_),
    .Y(_35_)
);

AND2X2 _908_ (
    .A(_43_),
    .B(_41_),
    .Y(_36_)
);

OAI22X1 _909_ (
    .A(\u_ball.y_pos [1]),
    .B(_201_),
    .C(_203_),
    .D(\u_ball.y_pos [0]),
    .Y(_37_)
);

NAND2X1 _910_ (
    .A(\u_ball.y_pos [1]),
    .B(_201_),
    .Y(_38_)
);

OAI21X1 _911_ (
    .A(_46_),
    .B(_44_),
    .C(_40_),
    .Y(_39_)
);

NAND2X1 _912_ (
    .A(_43_),
    .B(_41_),
    .Y(_40_)
);

NAND2X1 _913_ (
    .A(\u_ball.y_ball [2]),
    .B(_42_),
    .Y(_41_)
);

INVX1 _914_ (
    .A(\u_ball.y_pos [2]),
    .Y(_42_)
);

NAND2X1 _915_ (
    .A(\u_ball.y_pos [2]),
    .B(_193_),
    .Y(_43_)
);

AOI22X1 _916_ (
    .A(_47_),
    .B(\u_ball.y_ball [1]),
    .C(\u_ball.y_ball [0]),
    .D(_45_),
    .Y(_44_)
);

INVX1 _917_ (
    .A(\u_ball.y_pos [0]),
    .Y(_45_)
);

NOR2X1 _918_ (
    .A(\u_ball.y_ball [1]),
    .B(_47_),
    .Y(_46_)
);

INVX1 _919_ (
    .A(\u_ball.y_pos [1]),
    .Y(_47_)
);

NAND2X1 _920_ (
    .A(_49_),
    .B(_50_),
    .Y(_48_)
);

NAND2X1 _921_ (
    .A(\u_ball.x_pos [0]),
    .B(_444_),
    .Y(_49_)
);

OR2X2 _922_ (
    .A(_444_),
    .B(\u_ball.x_pos [0]),
    .Y(_50_)
);

OAI22X1 _923_ (
    .A(_444_),
    .B(_51_),
    .C(_227_),
    .D(_202_),
    .Y(_480_)
);

OAI21X1 _924_ (
    .A(\u_ball.x2 ),
    .B(_231_),
    .C(_52_),
    .Y(_51_)
);

INVX1 _925_ (
    .A(game_init),
    .Y(_52_)
);

AOI22X1 _926_ (
    .A(_60_),
    .B(_235_),
    .C(_53_),
    .D(_55_),
    .Y(_481_)
);

NOR2X1 _927_ (
    .A(_202_),
    .B(_54_),
    .Y(_53_)
);

AOI21X1 _928_ (
    .A(_56_),
    .B(_63_),
    .C(_57_),
    .Y(_54_)
);

NAND3X1 _929_ (
    .A(_63_),
    .B(_57_),
    .C(_56_),
    .Y(_55_)
);

OAI21X1 _930_ (
    .A(_70_),
    .B(_192_),
    .C(_68_),
    .Y(_56_)
);

NOR2X1 _931_ (
    .A(_59_),
    .B(_58_),
    .Y(_57_)
);

NOR2X1 _932_ (
    .A(\u_ball.sign_y ),
    .B(_60_),
    .Y(_58_)
);

NOR2X1 _933_ (
    .A(\u_ball.y_ball [4]),
    .B(_192_),
    .Y(_59_)
);

INVX2 _934_ (
    .A(\u_ball.y_ball [4]),
    .Y(_60_)
);

OAI21X1 _935_ (
    .A(_70_),
    .B(_234_),
    .C(_61_),
    .Y(_482_)
);

NAND3X1 _936_ (
    .A(_230_),
    .B(_62_),
    .C(_65_),
    .Y(_61_)
);

NAND3X1 _937_ (
    .A(_64_),
    .B(_63_),
    .C(_69_),
    .Y(_62_)
);

INVX1 _938_ (
    .A(_66_),
    .Y(_63_)
);

INVX1 _939_ (
    .A(_67_),
    .Y(_64_)
);

OAI21X1 _940_ (
    .A(_67_),
    .B(_66_),
    .C(_68_),
    .Y(_65_)
);

NOR2X1 _941_ (
    .A(\u_ball.y_ball [3]),
    .B(\u_ball.sign_y ),
    .Y(_66_)
);

NOR2X1 _942_ (
    .A(_70_),
    .B(_192_),
    .Y(_67_)
);

INVX1 _943_ (
    .A(_69_),
    .Y(_68_)
);

OAI21X1 _944_ (
    .A(_193_),
    .B(_192_),
    .C(_188_),
    .Y(_69_)
);

INVX2 _945_ (
    .A(\u_ball.y_ball [3]),
    .Y(_70_)
);

OAI21X1 _946_ (
    .A(_177_),
    .B(_178_),
    .C(_71_),
    .Y(_483_)
);

AOI21X1 _947_ (
    .A(_231_),
    .B(\u_ball.y_ball [2]),
    .C(game_init),
    .Y(_71_)
);

OAI21X1 _948_ (
    .A(_194_),
    .B(_189_),
    .C(_729_),
    .Y(_177_)
);

INVX1 _949_ (
    .A(_188_),
    .Y(_178_)
);

NAND2X1 _950_ (
    .A(_194_),
    .B(_189_),
    .Y(_188_)
);

NOR2X1 _951_ (
    .A(_190_),
    .B(_191_),
    .Y(_189_)
);

NOR2X1 _952_ (
    .A(\u_ball.y_ball [2]),
    .B(\u_ball.sign_y ),
    .Y(_190_)
);

NOR2X1 _953_ (
    .A(_193_),
    .B(_192_),
    .Y(_191_)
);

INVX2 _954_ (
    .A(\u_ball.sign_y ),
    .Y(_192_)
);

INVX1 _955_ (
    .A(\u_ball.y_ball [2]),
    .Y(_193_)
);

OAI21X1 _956_ (
    .A(_203_),
    .B(_198_),
    .C(_200_),
    .Y(_194_)
);

OAI21X1 _957_ (
    .A(_201_),
    .B(_234_),
    .C(_195_),
    .Y(_484_)
);

OAI21X1 _958_ (
    .A(\u_ball.y_ball [0]),
    .B(_197_),
    .C(_196_),
    .Y(_195_)
);

AOI21X1 _959_ (
    .A(_197_),
    .B(\u_ball.y_ball [0]),
    .C(_202_),
    .Y(_196_)
);

NOR2X1 _960_ (
    .A(_198_),
    .B(_199_),
    .Y(_197_)
);

NOR2X1 _961_ (
    .A(\u_ball.y_ball [1]),
    .B(\u_ball.sign_y ),
    .Y(_198_)
);

INVX1 _962_ (
    .A(_200_),
    .Y(_199_)
);

NAND2X1 _963_ (
    .A(\u_ball.y_ball [1]),
    .B(\u_ball.sign_y ),
    .Y(_200_)
);

INVX1 _964_ (
    .A(\u_ball.y_ball [1]),
    .Y(_201_)
);

MUX2X1 _965_ (
    .A(_202_),
    .B(_234_),
    .S(_203_),
    .Y(_485_)
);

INVX2 _966_ (
    .A(_230_),
    .Y(_202_)
);

INVX2 _967_ (
    .A(\u_ball.y_ball [0]),
    .Y(_203_)
);

OAI22X1 _968_ (
    .A(_464_),
    .B(_234_),
    .C(_204_),
    .D(_205_),
    .Y(_486_)
);

OAI21X1 _969_ (
    .A(_206_),
    .B(_209_),
    .C(_230_),
    .Y(_204_)
);

AND2X2 _970_ (
    .A(_209_),
    .B(_206_),
    .Y(_205_)
);

NOR2X1 _971_ (
    .A(_208_),
    .B(_207_),
    .Y(_206_)
);

NOR2X1 _972_ (
    .A(_467_),
    .B(_464_),
    .Y(_207_)
);

NOR2X1 _973_ (
    .A(\u_ball.sign_x ),
    .B(\u_ball.x_ball [5]),
    .Y(_208_)
);

OAI21X1 _974_ (
    .A(_467_),
    .B(_297_),
    .C(_210_),
    .Y(_209_)
);

NAND2X1 _975_ (
    .A(_211_),
    .B(_214_),
    .Y(_210_)
);

NOR2X1 _976_ (
    .A(_212_),
    .B(_213_),
    .Y(_211_)
);

NOR2X1 _977_ (
    .A(\u_ball.sign_x ),
    .B(\u_ball.x_ball [4]),
    .Y(_212_)
);

NOR2X1 _978_ (
    .A(_467_),
    .B(_297_),
    .Y(_213_)
);

OAI22X1 _979_ (
    .A(_467_),
    .B(_262_),
    .C(_215_),
    .D(_219_),
    .Y(_214_)
);

INVX1 _980_ (
    .A(_216_),
    .Y(_215_)
);

NAND2X1 _981_ (
    .A(_218_),
    .B(_217_),
    .Y(_216_)
);

NAND2X1 _982_ (
    .A(\u_ball.x_ball [3]),
    .B(_467_),
    .Y(_217_)
);

NAND2X1 _983_ (
    .A(\u_ball.sign_x ),
    .B(_456_),
    .Y(_218_)
);

NAND2X1 _984_ (
    .A(_220_),
    .B(_223_),
    .Y(_219_)
);

NAND2X1 _985_ (
    .A(_222_),
    .B(_221_),
    .Y(_220_)
);

NAND2X1 _986_ (
    .A(\u_ball.x_ball [2]),
    .B(_467_),
    .Y(_221_)
);

NAND2X1 _987_ (
    .A(\u_ball.sign_x ),
    .B(_451_),
    .Y(_222_)
);

NAND2X1 _988_ (
    .A(_228_),
    .B(_224_),
    .Y(_223_)
);

NAND3X1 _989_ (
    .A(_228_),
    .B(_227_),
    .C(_225_),
    .Y(_224_)
);

OAI21X1 _990_ (
    .A(\u_ball.x2 ),
    .B(_467_),
    .C(_226_),
    .Y(_225_)
);

INVX1 _991_ (
    .A(\u_ball.x_ball [1]),
    .Y(_226_)
);

NAND2X1 _992_ (
    .A(_236_),
    .B(_444_),
    .Y(_227_)
);

NAND3X1 _993_ (
    .A(\u_ball.sign_x ),
    .B(\u_ball.x_ball [1]),
    .C(_236_),
    .Y(_228_)
);

OAI22X1 _994_ (
    .A(_236_),
    .B(_232_),
    .C(_229_),
    .D(_263_),
    .Y(_487_)
);

NAND2X1 _995_ (
    .A(\u_ball.hit_paddle ),
    .B(_230_),
    .Y(_229_)
);

NOR2X1 _996_ (
    .A(game_init),
    .B(_231_),
    .Y(_230_)
);

INVX1 _997_ (
    .A(_729_),
    .Y(_231_)
);

INVX1 _998_ (
    .A(_233_),
    .Y(_232_)
);

OAI21X1 _999_ (
    .A(game_init),
    .B(\u_ball.hit_paddle ),
    .C(_234_),
    .Y(_233_)
);

endmodule
