*SPICE netlist created from verilog structural netlist module bricks_out by vlog2Spice (qflow)
*This file may contain array delimiters, not for use in simulation.

** Start of included library /usr/local/share/qflow/tech/etri050/etri050_stdcells.sp
* NGSPICE file created from khu_etri050_stdcells.ext - technology: scmos

.subckt AOI22X1 A B C D Y vdd gnd
M1000 gnd C a_56_14# gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=1.8p ps=6.6u
M1001 vdd A a_7_146# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=25.2p ps=28.2u
M1002 Y D a_7_146# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1003 a_28_14# A gnd gnd nfet w=6u l=0.6u
+  ad=1.8p pd=6.6u as=12.6p ps=16.2u
M1004 Y B a_28_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=1.8p ps=6.6u
M1005 a_7_146# C Y vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=14.4p ps=14.4u
M1006 a_7_146# B vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1007 a_56_14# D Y gnd nfet w=6u l=0.6u
+  ad=1.8p pd=6.6u as=7.2p ps=8.4u
.ends

.subckt CLKBUF3 A Y vdd gnd
M1000 a_145_14# a_105_14# vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1001 a_65_14# a_25_14# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1002 a_105_14# a_65_14# vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1003 a_145_14# a_105_14# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1004 gnd a_145_14# a_185_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1005 a_25_14# A vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=25.2p ps=28.2u
M1006 a_65_14# a_25_14# vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1007 a_265_14# a_225_14# vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1008 a_265_14# a_225_14# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1009 a_225_14# a_185_14# vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1010 gnd a_265_14# Y gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1011 a_25_14# A gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
M1012 gnd a_25_14# a_65_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1013 a_105_14# a_65_14# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1014 Y a_265_14# vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1015 gnd a_105_14# a_145_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1016 vdd a_65_14# a_105_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1017 vdd a_105_14# a_145_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1018 a_225_14# a_185_14# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1019 gnd a_225_14# a_265_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1020 vdd a_25_14# a_65_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1021 gnd A a_25_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1022 vdd A a_25_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1023 vdd a_185_14# a_225_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1024 vdd a_225_14# a_265_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1025 vdd a_145_14# a_185_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1026 gnd a_65_14# a_105_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1027 a_185_14# a_145_14# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1028 gnd a_185_14# a_225_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1029 Y a_265_14# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1030 vdd a_265_14# Y vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=14.4p ps=14.4u
M1031 a_185_14# a_145_14# vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
.ends

.subckt INVX8 A Y vdd gnd
M1000 Y A gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1001 Y A vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=25.2p ps=28.2u
M1002 Y A vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1003 Y A gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
M1004 gnd A Y gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1005 vdd A Y vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=14.4p ps=14.4u
M1006 gnd A Y gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1007 vdd A Y vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
.ends

.subckt NOR3X1 A B C Y vdd gnd
M1000 gnd B Y gnd nfet w=3u l=0.6u
+  ad=3.6p pd=5.4u as=3.6p ps=5.4u
M1001 a_7_166# A vdd vdd pfet w=9u l=0.6u
+  ad=10.8p pd=11.4u as=10.8p ps=11.4u
M1002 a_7_166# B a_65_166# vdd pfet w=9u l=0.6u
+  ad=18.9p pd=22.2u as=10.8p ps=11.4u
M1003 a_65_166# C Y vdd pfet w=9u l=0.6u
+  ad=18.9p pd=22.2u as=10.8p ps=11.4u
M1004 Y C gnd gnd nfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=3.6p ps=5.4u
M1005 a_65_166# B a_7_166# vdd pfet w=9u l=0.6u
+  ad=10.8p pd=11.4u as=10.8p ps=11.4u
M1006 vdd A a_7_166# vdd pfet w=9u l=0.6u
+  ad=10.8p pd=11.4u as=18.9p ps=22.2u
M1007 Y C a_65_166# vdd pfet w=9u l=0.6u
+  ad=10.8p pd=11.4u as=18.9p ps=22.2u
M1008 Y A gnd gnd nfet w=3u l=0.6u
+  ad=3.6p pd=5.4u as=7.2p ps=10.8u
.ends

.subckt CLKBUF1 A Y vdd gnd
M1000 Y a_105_14# vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1001 a_65_14# a_25_14# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1002 a_105_14# a_65_14# vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1003 Y a_105_14# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1004 a_25_14# A vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=25.2p ps=28.2u
M1005 a_65_14# a_25_14# vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1006 a_25_14# A gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
M1007 gnd a_25_14# a_65_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1008 a_105_14# a_65_14# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1009 gnd a_105_14# Y gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1010 vdd a_65_14# a_105_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1011 vdd a_105_14# Y vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=14.4p ps=14.4u
M1012 vdd a_25_14# a_65_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1013 gnd A a_25_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1014 vdd A a_25_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1015 gnd a_65_14# a_105_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
.ends

.subckt MUX2X1 A B S Y vdd gnd
M1000 a_75_22# S Y gnd nfet w=6u l=0.6u
+  ad=2.7p pd=6.9u as=7.2p ps=8.4u
M1001 gnd S a_7_22# gnd nfet w=3u l=0.6u
+  ad=6.3p pd=8.4u as=6.3p ps=10.2u
M1002 Y S a_45_138# vdd pfet w=12u l=0.6u
+  ad=14.49p pd=15.6u as=5.4p ps=12.9u
M1003 gnd A a_75_22# gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=2.7p ps=6.9u
M1004 vdd A a_75_146# vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=5.4p ps=12.9u
M1005 a_45_138# B vdd vdd pfet w=12u l=0.6u
+  ad=5.4p pd=12.9u as=11.7p ps=14.4u
M1006 a_45_22# B gnd gnd nfet w=6u l=0.6u
+  ad=2.7p pd=6.9u as=6.3p ps=8.4u
M1007 Y a_7_22# a_45_22# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=2.7p ps=6.9u
M1008 a_75_146# a_7_22# Y vdd pfet w=12u l=0.6u
+  ad=5.4p pd=12.9u as=14.49p ps=15.6u
M1009 vdd S a_7_22# vdd pfet w=6u l=0.6u
+  ad=11.7p pd=14.4u as=12.6p ps=16.2u
.ends

.subckt NAND3X1 A B C Y vdd gnd
M1000 Y C a_34_14# gnd nfet w=9u l=0.6u
+  ad=18.9p pd=22.2u as=2.7p ps=9.6u
M1001 a_26_14# A gnd gnd nfet w=9u l=0.6u
+  ad=2.7p pd=9.6u as=18.9p ps=22.2u
M1002 vdd B Y vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1003 a_34_14# B a_26_14# gnd nfet w=9u l=0.6u
+  ad=2.7p pd=9.6u as=2.7p ps=9.6u
M1004 Y C vdd vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1005 Y A vdd vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
.ends

.subckt XOR2X1 A B Y vdd gnd
M1000 a_74_166# a_6_14# Y vdd pfet w=12u l=0.6u
+  ad=5.4p pd=12.9u as=14.4p ps=14.4u
M1001 a_28_58# B vdd vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=14.4p ps=14.4u
M1002 a_74_14# A Y gnd nfet w=6u l=0.6u
+  ad=2.7p pd=6.9u as=7.2p ps=8.4u
M1003 gnd A a_6_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
M1004 vdd A a_6_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=25.2p ps=28.2u
M1005 gnd B a_74_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=2.7p ps=6.9u
M1006 a_28_58# B gnd gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1007 Y A a_44_166# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=5.4p ps=12.9u
M1008 a_44_14# a_28_58# gnd gnd nfet w=6u l=0.6u
+  ad=2.7p pd=6.9u as=7.2p ps=8.4u
M1009 vdd B a_74_166# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=5.4p ps=12.9u
M1010 Y a_6_14# a_44_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=2.7p ps=6.9u
M1011 a_44_166# a_28_58# vdd vdd pfet w=12u l=0.6u
+  ad=5.4p pd=12.9u as=14.4p ps=14.4u
.ends

.subckt BUFX4 A Y vdd gnd
M1000 Y a_7_14# vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=15.3p ps=14.7u
M1001 gnd A a_7_14# gnd nfet w=4.5u l=0.6u
+  ad=7.65p pd=8.7u as=9.45p ps=13.2u
M1002 vdd a_7_14# Y vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=14.4p ps=14.4u
M1003 vdd A a_7_14# vdd pfet w=9u l=0.6u
+  ad=15.3p pd=14.7u as=18.9p ps=22.2u
M1004 Y a_7_14# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.65p ps=8.7u
M1005 gnd a_7_14# Y gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
.ends

.subckt INVX4 A Y vdd gnd
M1000 Y A vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=25.2p ps=28.2u
M1001 Y A gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
M1002 gnd A Y gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1003 vdd A Y vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=14.4p ps=14.4u
.ends

.subckt OAI21X1 A B C Y vdd gnd
M1000 Y C a_7_14# gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1001 a_30_146# A vdd vdd pfet w=12u l=0.6u
+  ad=3.6p pd=12.6u as=25.2p ps=28.2u
M1002 vdd C Y vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=14.4p ps=14.7u
M1003 gnd A a_7_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
M1004 Y B a_30_146# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.7u as=3.6p ps=12.6u
M1005 a_7_14# B gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
.ends

.subckt TBUFX2 A EN Y vdd gnd
M1000 vdd A a_44_166# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1001 Y a_22_14# a_44_166# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=25.2p ps=28.2u
M1002 a_22_14# EN vdd vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=25.2p ps=28.2u
M1003 gnd A a_44_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1004 a_44_14# A gnd gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1005 a_44_166# A vdd vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=14.4p ps=14.4u
M1006 a_44_166# a_22_14# Y vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1007 Y EN a_44_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
M1008 a_22_14# EN gnd gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=12.6p ps=16.2u
M1009 a_44_14# EN Y gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
.ends

.subckt DFFNEGX1 D CLK Q vdd gnd
M1000 a_163_14# a_7_14# a_153_14# gnd nfet w=3u l=0.6u
+  ad=3.6p pd=5.4u as=1.35p ps=3.9u
M1001 a_77_186# CLK a_57_14# vdd pfet w=6u l=0.6u
+  ad=3.6p pd=7.2u as=7.2p ps=8.4u
M1002 a_77_14# a_7_14# a_57_14# gnd nfet w=3u l=0.6u
+  ad=1.35p pd=3.9u as=3.6p ps=5.4u
M1003 vdd a_83_10# a_77_186# vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=3.6p ps=7.2u
M1004 vdd CLK a_7_14# vdd pfet w=12u l=0.6u
+  ad=12.15p pd=14.4u as=25.2p ps=28.2u
M1005 Q a_163_14# vdd vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=11.025p ps=14.4u
M1006 a_83_10# a_57_14# gnd gnd nfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=4.05p ps=5.7u
M1007 gnd CLK a_7_14# gnd nfet w=6u l=0.6u
+  ad=6.075p pd=8.4u as=12.6p ps=16.2u
M1008 gnd a_83_10# a_77_14# gnd nfet w=3u l=0.6u
+  ad=4.05p pd=5.7u as=1.35p ps=3.9u
M1009 vdd Q a_183_206# vdd pfet w=3u l=0.6u
+  ad=11.025p pd=14.4u as=1.35p ps=3.9u
M1010 a_154_186# a_83_10# vdd vdd pfet w=6u l=0.6u
+  ad=2.25p pd=6.75u as=12.6p ps=16.2u
M1011 a_183_14# CLK a_163_14# gnd nfet w=3u l=0.6u
+  ad=1.35p pd=3.9u as=3.6p ps=5.4u
M1012 a_45_186# D vdd vdd pfet w=6u l=0.6u
+  ad=3.6p pd=7.2u as=12.15p ps=14.4u
M1013 a_83_10# a_57_14# vdd vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1014 a_57_14# a_7_14# a_45_186# vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=3.6p ps=7.2u
M1015 gnd Q a_183_14# gnd nfet w=3u l=0.6u
+  ad=6.075p pd=8.4u as=1.35p ps=3.9u
M1016 a_183_206# a_7_14# a_163_14# vdd pfet w=3u l=0.6u
+  ad=1.35p pd=3.9u as=5.85p ps=8.4u
M1017 a_45_14# D gnd gnd nfet w=3u l=0.6u
+  ad=1.8p pd=4.2u as=6.075p ps=8.4u
M1018 a_57_14# CLK a_45_14# gnd nfet w=3u l=0.6u
+  ad=3.6p pd=5.4u as=1.8p ps=4.2u
M1019 a_153_14# a_83_10# gnd gnd nfet w=3u l=0.6u
+  ad=1.35p pd=3.9u as=6.3p ps=10.2u
M1020 Q a_163_14# gnd gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=6.075p ps=8.4u
M1021 a_163_14# CLK a_154_186# vdd pfet w=6u l=0.6u
+  ad=5.85p pd=8.4u as=2.25p ps=6.75u
.ends

.subckt AOI21X1 A B C Y vdd gnd
M1000 vdd A a_7_146# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=25.2p ps=28.2u
M1001 Y C a_7_146# vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=14.4p ps=14.4u
M1002 a_28_14# A gnd gnd nfet w=6u l=0.6u
+  ad=1.8p pd=6.6u as=12.6p ps=16.2u
M1003 Y B a_28_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.7u as=1.8p ps=6.6u
M1004 a_7_146# B vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1005 gnd C Y gnd nfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=7.2p ps=8.7u
.ends

.subckt BUFX2 A Y vdd gnd
M1000 Y a_7_14# vdd vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=14.4p ps=14.7u
M1001 gnd A a_7_14# gnd nfet w=3u l=0.6u
+  ad=7.2p pd=8.7u as=6.3p ps=10.2u
M1002 Y a_7_14# gnd gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.7u
M1003 vdd A a_7_14# vdd pfet w=6u l=0.6u
+  ad=14.4p pd=14.7u as=12.6p ps=16.2u
.ends

.subckt INVX2 A Y vdd gnd
M1000 Y A vdd vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=25.2p ps=28.2u
M1001 Y A gnd gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=12.6p ps=16.2u
.ends

.subckt FAX1 A B C YS YC vdd gnd
M1000 a_64_14# C a_6_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1001 YS a_174_14# vdd vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=14.13p ps=16.8u
M1002 a_206_14# B a_196_14# gnd nfet w=6u l=0.6u
+  ad=2.7p pd=6.9u as=2.7p ps=6.9u
M1003 gnd a_64_14# YC gnd nfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=6.3p ps=10.2u
M1004 gnd A a_206_14# gnd nfet w=6u l=0.6u
+  ad=5.85p pd=8.4u as=2.7p ps=6.9u
M1005 vdd A a_206_150# vdd pfet w=14.4u l=0.6u
+  ad=14.13p pd=16.8u as=6.48p ps=15.3u
M1006 gnd A a_6_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
M1007 a_114_14# C gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1008 a_64_14# C a_6_166# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1009 vdd A a_6_166# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=25.2p ps=28.2u
M1010 a_84_14# B a_64_14# gnd nfet w=6u l=0.6u
+  ad=2.7p pd=6.9u as=7.2p ps=8.4u
M1011 a_174_14# a_64_14# a_114_166# vdd pfet w=10.8u l=0.6u
+  ad=17.82p pd=17.1u as=12.96p ps=13.2u
M1012 vdd B a_114_166# vdd pfet w=10.8u l=0.6u
+  ad=12.96p pd=13.2u as=13.86p ps=14.4u
M1013 a_196_150# C a_174_14# vdd pfet w=14.4u l=0.6u
+  ad=6.48p pd=15.3u as=17.82p ps=17.1u
M1014 a_206_150# B a_196_150# vdd pfet w=14.4u l=0.6u
+  ad=6.48p pd=15.3u as=6.48p ps=15.3u
M1015 gnd A a_84_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=2.7p ps=6.9u
M1016 vdd A a_84_166# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=5.4p ps=12.9u
M1017 a_114_14# A gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1018 YS a_174_14# gnd gnd nfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=5.85p ps=8.4u
M1019 a_174_14# a_64_14# a_114_14# gnd nfet w=6u l=0.6u
+  ad=8.1p pd=8.7u as=7.2p ps=8.4u
M1020 a_6_14# B gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1021 YC a_64_14# vdd vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=12.6p ps=16.2u
M1022 a_84_166# B a_64_14# vdd pfet w=12u l=0.6u
+  ad=5.4p pd=12.9u as=14.4p ps=14.4u
M1023 a_6_166# B vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1024 a_114_166# A vdd vdd pfet w=12u l=0.6u
+  ad=13.86p pd=14.4u as=14.4p ps=14.4u
M1025 a_114_166# C vdd vdd pfet w=10.8u l=0.6u
+  ad=12.96p pd=13.2u as=12.96p ps=13.2u
M1026 gnd B a_114_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1027 a_196_14# C a_174_14# gnd nfet w=6u l=0.6u
+  ad=2.7p pd=6.9u as=8.1p ps=8.7u
.ends

.subckt NOR2X1 A B Y vdd gnd
M1000 a_25_146# A vdd vdd pfet w=12u l=0.6u
+  ad=3.6p pd=12.6u as=25.2p ps=28.2u
M1001 Y A gnd gnd nfet w=3u l=0.6u
+  ad=3.6p pd=5.4u as=6.3p ps=10.2u
M1002 Y B a_25_146# vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=3.6p ps=12.6u
M1003 gnd B Y gnd nfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=3.6p ps=5.4u
.ends

.subckt AND2X1 A B Y vdd gnd
M1000 gnd B a_25_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.7u as=1.8p ps=6.6u
M1001 a_25_14# A a_7_14# gnd nfet w=6u l=0.6u
+  ad=1.8p pd=6.6u as=12.6p ps=16.2u
M1002 vdd B a_7_14# vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1003 Y a_7_14# gnd gnd nfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=7.2p ps=8.7u
M1004 Y a_7_14# vdd vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1005 a_7_14# A vdd vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
.ends

.subckt DFFPOSX1 D CLK Q vdd gnd
M1000 vdd Q a_189_206# vdd pfet w=3u l=0.6u
+  ad=10.125p pd=14.7u as=0.9p ps=3.6u
M1001 a_83_186# a_11_14# a_59_14# vdd pfet w=6u l=0.6u
+  ad=3.6p pd=7.2u as=7.2p ps=8.4u
M1002 a_87_10# a_59_14# gnd gnd nfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=4.05p ps=5.7u
M1003 gnd CLK a_11_14# gnd nfet w=6u l=0.6u
+  ad=5.85p pd=8.4u as=12.6p ps=16.2u
M1004 gnd a_87_10# a_81_14# gnd nfet w=3u l=0.6u
+  ad=4.05p pd=5.7u as=1.35p ps=3.9u
M1005 a_159_14# a_87_10# gnd gnd nfet w=3u l=0.6u
+  ad=0.9p pd=3.6u as=6.3p ps=10.2u
M1006 a_49_186# D vdd vdd pfet w=6u l=0.6u
+  ad=4.5p pd=7.5u as=11.25p ps=14.4u
M1007 vdd a_87_10# a_83_186# vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=3.6p ps=7.2u
M1008 Q a_167_14# gnd gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=6.975p ps=8.7u
M1009 Q a_167_14# vdd vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=10.125p ps=14.7u
M1010 a_167_14# CLK a_159_14# gnd nfet w=3u l=0.6u
+  ad=3.6p pd=5.4u as=0.9p ps=3.6u
M1011 a_49_14# D gnd gnd nfet w=3u l=0.6u
+  ad=1.35p pd=3.9u as=5.85p ps=8.4u
M1012 a_87_10# a_59_14# vdd vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1013 a_59_14# CLK a_49_186# vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=4.5p ps=7.5u
M1014 a_161_186# a_87_10# vdd vdd pfet w=6u l=0.6u
+  ad=1.8p pd=6.6u as=12.6p ps=16.2u
M1015 a_189_206# CLK a_167_14# vdd pfet w=3u l=0.6u
+  ad=0.9p pd=3.6u as=6.075p ps=8.4u
M1016 a_59_14# a_11_14# a_49_14# gnd nfet w=3u l=0.6u
+  ad=4.05p pd=5.7u as=1.35p ps=3.9u
M1017 a_187_14# a_11_14# a_167_14# gnd nfet w=3u l=0.6u
+  ad=1.35p pd=3.9u as=3.6p ps=5.4u
M1018 vdd CLK a_11_14# vdd pfet w=12u l=0.6u
+  ad=11.25p pd=14.4u as=25.2p ps=28.2u
M1019 gnd Q a_187_14# gnd nfet w=3u l=0.6u
+  ad=6.975p pd=8.7u as=1.35p ps=3.9u
M1020 a_167_14# a_11_14# a_161_186# vdd pfet w=6u l=0.6u
+  ad=6.075p pd=8.4u as=1.8p ps=6.6u
M1021 a_81_14# CLK a_59_14# gnd nfet w=3u l=0.6u
+  ad=1.35p pd=3.9u as=4.05p ps=5.7u
.ends

.subckt NAND2X1 A B Y vdd gnd
M1000 a_27_14# A gnd gnd nfet w=6u l=0.6u
+  ad=2.7p pd=6.9u as=12.6p ps=16.2u
M1001 Y B a_27_14# gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=2.7p ps=6.9u
M1002 vdd B Y vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1003 Y A vdd vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
.ends

.subckt OR2X1 A B Y vdd gnd
M1000 Y a_7_146# gnd gnd nfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=3.6p ps=5.4u
M1001 a_25_146# A a_7_146# vdd pfet w=12u l=0.6u
+  ad=5.4p pd=12.9u as=25.2p ps=28.2u
M1002 a_7_146# A gnd gnd nfet w=3u l=0.6u
+  ad=3.6p pd=5.4u as=6.3p ps=10.2u
M1003 Y a_7_146# vdd vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=14.4p ps=14.7u
M1004 gnd B a_7_146# gnd nfet w=3u l=0.6u
+  ad=3.6p pd=5.4u as=3.6p ps=5.4u
M1005 vdd B a_25_146# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.7u as=5.4p ps=12.9u
.ends

.subckt CLKBUF2 A Y vdd gnd
M1000 a_145_14# a_105_14# vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1001 a_65_14# a_25_14# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1002 a_105_14# a_65_14# vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1003 a_145_14# a_105_14# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1004 gnd a_145_14# a_185_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1005 a_25_14# A vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=25.2p ps=28.2u
M1006 a_65_14# a_25_14# vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1007 Y a_185_14# vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1008 a_25_14# A gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
M1009 gnd a_25_14# a_65_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1010 a_105_14# a_65_14# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1011 gnd a_105_14# a_145_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1012 vdd a_65_14# a_105_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1013 vdd a_105_14# a_145_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1014 Y a_185_14# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1015 vdd a_25_14# a_65_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1016 gnd A a_25_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1017 vdd A a_25_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1018 vdd a_185_14# Y vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=14.4p ps=14.4u
M1019 vdd a_145_14# a_185_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1020 gnd a_65_14# a_105_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1021 a_185_14# a_145_14# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1022 gnd a_185_14# Y gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1023 a_185_14# a_145_14# vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
.ends

.subckt LATCH D CLK Q vdd gnd
M1000 a_48_206# D vdd vdd pfet w=6u l=0.6u
+  ad=2.7p pd=6.9u as=14.4p ps=14.7u
M1001 a_86_226# CLK a_58_14# vdd pfet w=3u l=0.6u
+  ad=1.35p pd=3.9u as=9.225p ps=9.6u
M1002 gnd CLK a_8_14# gnd nfet w=6u l=0.6u
+  ad=6.3p pd=8.4u as=12.6p ps=16.2u
M1003 a_86_14# a_8_14# a_58_14# gnd nfet w=3u l=0.6u
+  ad=1.35p pd=3.9u as=5.4p ps=6.6u
M1004 Q a_58_14# gnd gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.7u
M1005 gnd Q a_86_14# gnd nfet w=3u l=0.6u
+  ad=7.2p pd=8.7u as=1.35p ps=3.9u
M1006 a_46_14# D gnd gnd nfet w=3u l=0.6u
+  ad=1.8p pd=4.2u as=6.3p ps=8.4u
M1007 Q a_58_14# vdd vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=13.5p ps=14.7u
M1008 a_58_14# CLK a_46_14# gnd nfet w=3u l=0.6u
+  ad=5.4p pd=6.6u as=1.8p ps=4.2u
M1009 vdd CLK a_8_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.7u as=25.2p ps=28.2u
M1010 a_58_14# a_8_14# a_48_206# vdd pfet w=6u l=0.6u
+  ad=9.225p pd=9.6u as=2.7p ps=6.9u
M1011 vdd Q a_86_226# vdd pfet w=3u l=0.6u
+  ad=13.5p pd=14.7u as=1.35p ps=3.9u
.ends

.subckt HAX1 A B YS YC vdd gnd
M1000 a_6_206# B a_24_14# gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=1.8p ps=6.6u
M1001 vdd a_6_206# YC vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
M1002 gnd a_6_206# YC gnd nfet w=3u l=0.6u
+  ad=6.075p pd=8.4u as=6.21p ps=10.2u
M1003 a_24_14# A gnd gnd nfet w=6u l=0.6u
+  ad=1.8p pd=6.6u as=12.6p ps=16.2u
M1004 a_6_206# B vdd vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1005 a_128_166# B a_108_206# vdd pfet w=12u l=0.6u
+  ad=3.6p pd=12.6u as=13.5p ps=14.4u
M1006 a_108_206# a_6_206# vdd vdd pfet w=6u l=0.6u
+  ad=13.5p pd=14.4u as=7.2p ps=8.4u
M1007 YS a_108_206# gnd gnd nfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=6.3p ps=10.2u
M1008 a_96_14# a_6_206# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=6.075p ps=8.4u
M1009 a_108_206# B a_96_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1010 vdd A a_128_166# vdd pfet w=12u l=0.6u
+  ad=11.25p pd=14.4u as=3.6p ps=12.6u
M1011 YS a_108_206# vdd vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=11.25p ps=14.4u
M1012 a_96_14# A a_108_206# gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1013 vdd A a_6_206# vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
.ends

.subckt DFFSR R S D CLK Q vdd gnd
M1000 a_146_14# a_122_10# a_60_10# vdd pfet w=3u l=0.6u
+  ad=6.3p pd=8.4u as=3.6p ps=5.4u
M1001 a_64_14# a_60_10# gnd gnd nfet w=6u l=0.6u
+  ad=3.6p pd=7.2u as=9p ps=9u
M1002 vdd S a_301_14# vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1003 a_146_14# a_115_95# a_60_10# gnd nfet w=3u l=0.6u
+  ad=3.6p pd=5.4u as=3.6p ps=5.4u
M1004 a_36_10# a_60_10# vdd vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1005 a_391_14# a_334_14# gnd gnd nfet w=6u l=0.6u
+  ad=3.6p pd=7.2u as=9.45p ps=9.15u
M1006 a_8_14# R vdd vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
M1007 a_36_10# S a_64_14# gnd nfet w=6u l=0.6u
+  ad=14.4p pd=16.8u as=3.6p ps=7.2u
M1008 gnd a_334_14# Q gnd nfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=6.3p ps=10.2u
M1009 a_281_14# a_122_10# a_36_10# gnd nfet w=3u l=0.6u
+  ad=3.6p pd=5.4u as=6.3p ps=10.2u
M1010 a_28_14# R a_8_14# gnd nfet w=6u l=0.6u
+  ad=3.6p pd=7.2u as=14.4p ps=16.8u
M1011 a_301_14# S a_391_14# gnd nfet w=6u l=0.6u
+  ad=14.4p pd=16.8u as=3.6p ps=7.2u
M1012 gnd a_36_10# a_28_14# gnd nfet w=6u l=0.6u
+  ad=9p pd=9u as=3.6p ps=7.2u
M1013 gnd a_115_95# a_122_10# gnd nfet w=3u l=0.6u
+  ad=3.6p pd=5.4u as=6.3p ps=10.2u
M1014 a_301_14# a_334_14# vdd vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1015 vdd D a_146_14# vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=6.3p ps=8.4u
M1016 a_334_14# a_281_14# vdd vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
M1017 vdd a_115_95# a_122_10# vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
M1018 a_301_14# a_122_10# a_281_14# vdd pfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=3.6p ps=5.4u
M1019 gnd D a_146_14# gnd nfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=3.6p ps=5.4u
M1020 a_60_10# a_115_95# a_8_14# vdd pfet w=3u l=0.6u
+  ad=3.6p pd=5.4u as=6.3p ps=10.2u
M1021 a_301_14# a_115_95# a_281_14# gnd nfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=3.6p ps=5.4u
M1022 vdd S a_36_10# vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1023 vdd a_36_10# a_8_14# vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1024 a_115_95# CLK gnd gnd nfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=3.6p ps=5.4u
M1025 a_60_10# a_122_10# a_8_14# gnd nfet w=3u l=0.6u
+  ad=3.6p pd=5.4u as=6.3p ps=10.2u
M1026 a_354_14# a_281_14# a_334_14# gnd nfet w=6u l=0.6u
+  ad=3.6p pd=7.2u as=14.4p ps=16.8u
M1027 vdd R a_334_14# vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1028 a_115_95# CLK vdd vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1029 a_281_14# a_115_95# a_36_10# vdd pfet w=3u l=0.6u
+  ad=3.6p pd=5.4u as=6.3p ps=10.2u
M1030 gnd R a_354_14# gnd nfet w=6u l=0.6u
+  ad=9.45p pd=9.15u as=3.6p ps=7.2u
M1031 vdd a_334_14# Q vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=12.6p ps=16.2u
.ends

.subckt TBUFX1 A EN Y vdd gnd
M1000 a_68_166# a_26_14# Y vdd pfet w=12u l=0.6u
+  ad=5.4p pd=12.9u as=25.2p ps=28.2u
M1001 gnd A a_68_14# gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=2.7p ps=6.9u
M1002 a_26_14# EN gnd gnd nfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=6.3p ps=10.2u
M1003 a_26_14# EN vdd vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=12.6p ps=16.2u
M1004 vdd A a_68_166# vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=5.4p ps=12.9u
M1005 a_68_14# EN Y gnd nfet w=6u l=0.6u
+  ad=2.7p pd=6.9u as=12.6p ps=16.2u
.ends

.subckt XNOR2X1 A B Y vdd gnd
M1000 a_74_166# A Y vdd pfet w=12u l=0.6u
+  ad=3.6p pd=12.6u as=14.4p ps=14.4u
M1001 a_29_58# B vdd vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=16.2p ps=14.7u
M1002 gnd A a_6_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
M1003 vdd A a_6_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=25.2p ps=28.2u
M1004 Y A a_44_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=1.8p ps=6.6u
M1005 a_29_58# B gnd gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=8.1p ps=8.7u
M1006 vdd B a_74_166# vdd pfet w=12u l=0.6u
+  ad=16.2p pd=14.7u as=3.6p ps=12.6u
M1007 Y a_6_14# a_44_166# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=5.4p ps=12.9u
M1008 a_44_14# a_29_58# gnd gnd nfet w=6u l=0.6u
+  ad=1.8p pd=6.6u as=7.2p ps=8.4u
M1009 a_72_14# a_6_14# Y gnd nfet w=6u l=0.6u
+  ad=2.7p pd=6.9u as=7.2p ps=8.4u
M1010 a_44_166# a_29_58# vdd vdd pfet w=12u l=0.6u
+  ad=5.4p pd=12.9u as=14.4p ps=14.4u
M1011 gnd B a_72_14# gnd nfet w=6u l=0.6u
+  ad=8.1p pd=8.7u as=2.7p ps=6.9u
.ends

.subckt AND2X2 A B Y vdd gnd
M1000 a_25_14# A a_7_14# gnd nfet w=6u l=0.6u
+  ad=2.7p pd=6.9u as=12.6p ps=16.2u
M1001 gnd B a_25_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=2.7p ps=6.9u
M1002 vdd B a_7_14# vdd pfet w=6u l=0.6u
+  ad=14.4p pd=14.7u as=8.1p ps=8.7u
M1003 Y a_7_14# gnd gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1004 Y a_7_14# vdd vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=14.4p ps=14.7u
M1005 a_7_14# A vdd vdd pfet w=6u l=0.6u
+  ad=8.1p pd=8.7u as=12.6p ps=16.2u
.ends

.subckt INVX1 A Y vdd gnd
M1000 Y A gnd gnd nfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=6.3p ps=10.2u
M1001 Y A vdd vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=12.6p ps=16.2u
.ends

.subckt OAI22X1 A B C D Y vdd gnd
M1000 Y D a_7_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1001 a_25_146# A vdd vdd pfet w=12u l=0.6u
+  ad=5.4p pd=12.9u as=25.2p ps=28.2u
M1002 a_65_146# D Y vdd pfet w=12u l=0.6u
+  ad=5.4p pd=12.9u as=23.4p ps=15.9u
M1003 gnd A a_7_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
M1004 a_7_14# C Y gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1005 a_7_14# B gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1006 Y B a_25_146# vdd pfet w=12u l=0.6u
+  ad=23.4p pd=15.9u as=5.4p ps=12.9u
M1007 vdd C a_65_146# vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=5.4p ps=12.9u
.ends

.subckt OR2X2 A B Y vdd gnd
M1000 Y a_7_146# gnd gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=6.3p ps=8.4u
M1001 a_25_146# A a_7_146# vdd pfet w=12u l=0.6u
+  ad=5.4p pd=12.9u as=25.2p ps=28.2u
M1002 a_7_146# A gnd gnd nfet w=3u l=0.6u
+  ad=3.6p pd=5.4u as=6.3p ps=10.2u
M1003 Y a_7_146# vdd vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=14.4p ps=14.4u
M1004 gnd B a_7_146# gnd nfet w=3u l=0.6u
+  ad=6.3p pd=8.4u as=3.6p ps=5.4u
M1005 vdd B a_25_146# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=5.4p ps=12.9u
.ends

.subckt khu_etri050_stdcells vdd gnd
XAOI22X1_0 AOI22X1_0/A AOI22X1_0/B AOI22X1_0/C AOI22X1_0/D AOI22X1_0/Y vdd gnd AOI22X1
XCLKBUF3_0 CLKBUF3_0/A CLKBUF3_0/Y vdd gnd CLKBUF3
XINVX8_0 INVX8_0/A INVX8_0/Y vdd gnd INVX8
XNOR3X1_0 NOR3X1_0/A NOR3X1_0/B NOR3X1_0/C NOR3X1_0/Y vdd gnd NOR3X1
XCLKBUF1_0 CLKBUF1_0/A CLKBUF1_0/Y vdd gnd CLKBUF1
XMUX2X1_0 MUX2X1_0/A MUX2X1_0/B MUX2X1_0/S MUX2X1_0/Y vdd gnd MUX2X1
XNAND3X1_0 NAND3X1_0/A NAND3X1_0/B NAND3X1_0/C NAND3X1_0/Y vdd gnd NAND3X1
XXOR2X1_0 XOR2X1_0/A XOR2X1_0/B XOR2X1_0/Y vdd gnd XOR2X1
XBUFX4_0 BUFX4_0/A BUFX4_0/Y vdd gnd BUFX4
XINVX4_0 INVX4_0/A INVX4_0/Y vdd gnd INVX4
XOAI21X1_0 OAI21X1_0/A OAI21X1_0/B OAI21X1_0/C OAI21X1_0/Y vdd gnd OAI21X1
XTBUFX2_0 TBUFX2_0/A TBUFX2_0/EN TBUFX2_0/Y vdd gnd TBUFX2
XDFFNEGX1_0 DFFNEGX1_0/D DFFNEGX1_0/CLK DFFNEGX1_0/Q vdd gnd DFFNEGX1
XAOI21X1_0 AOI21X1_0/A AOI21X1_0/B AOI21X1_0/C AOI21X1_0/Y vdd gnd AOI21X1
XBUFX2_0 BUFX2_0/A BUFX2_0/Y vdd gnd BUFX2
XINVX2_0 INVX2_0/A INVX2_0/Y vdd gnd INVX2
XFAX1_0 FAX1_0/A FAX1_0/B FAX1_0/C FAX1_0/YS FAX1_0/YC vdd gnd FAX1
XNOR2X1_0 NOR2X1_0/A NOR2X1_0/B NOR2X1_0/Y vdd gnd NOR2X1
XAND2X1_0 AND2X1_0/A AND2X1_0/B AND2X1_0/Y vdd gnd AND2X1
XDFFPOSX1_0 DFFPOSX1_0/D DFFPOSX1_0/CLK DFFPOSX1_0/Q vdd gnd DFFPOSX1
XNAND2X1_0 NAND2X1_0/A NAND2X1_0/B NAND2X1_0/Y vdd gnd NAND2X1
XOR2X1_0 OR2X1_0/A OR2X1_0/B OR2X1_0/Y vdd gnd OR2X1
XCLKBUF2_0 CLKBUF2_0/A CLKBUF2_0/Y vdd gnd CLKBUF2
XLATCH_0 LATCH_0/D LATCH_0/CLK LATCH_0/Q vdd gnd LATCH
XHAX1_0 HAX1_0/A HAX1_0/B HAX1_0/YS HAX1_0/YC vdd gnd HAX1
XDFFSR_0 DFFSR_0/R DFFSR_0/S DFFSR_0/D DFFSR_0/CLK DFFSR_0/Q vdd gnd DFFSR
XTBUFX1_0 TBUFX1_0/A TBUFX1_0/EN TBUFX1_0/Y vdd gnd TBUFX1
XXNOR2X1_0 XNOR2X1_0/A XNOR2X1_0/B XNOR2X1_0/Y vdd gnd XNOR2X1
XAND2X2_0 AND2X2_0/A AND2X2_0/B AND2X2_0/Y vdd gnd AND2X2
XINVX1_0 INVX1_0/A INVX1_0/Y vdd gnd INVX1
XOAI22X1_0 OAI22X1_0/A OAI22X1_0/B OAI22X1_0/C OAI22X1_0/D OAI22X1_0/Y vdd gnd OAI22X1
XOR2X2_0 OR2X2_0/A OR2X2_0/B OR2X2_0/Y vdd gnd OR2X2
.ends

** End of included library /usr/local/share/qflow/tech/etri050/etri050_stdcells.sp

.subckt bricks_out vdd gnd clk reset v_sync pixel p_tick
+ btn_left btn_right game_over game_complete game_new 

XFILL_0__1241_ gnd vdd FILL
X_1257_ reset _434_ vdd gnd INVX2
X_800_ \u_ball.y_pos\[3] _702_ vdd gnd INVX1
X_1486_ _636_ _635_ _637_ _634_ vdd gnd NAND3X1
X_1066_ _445_ _456_ _300_ vdd gnd AND2X2
XFILL_0__1106_ gnd vdd FILL
X_1295_ _369_ _365_ vdd gnd INVX1
X_1389_ vdd _673__bF$buf3 _682_ clk_bF$buf3 \u_ball.y_pos\[3] vdd 
+ gnd
+ DFFSR
X_932_ _62_ _174_ _58_ vdd gnd NAND2X1
X_1198_ \u_ball.x_pos\[5] _131_ vdd gnd INVX1
XFILL_0__1238_ gnd vdd FILL
X_1410_ _578_ \u_ball.x_pos\[2] _579_ _669_ vdd gnd MUX2X1
X_741_ _469__bF$buf1 vdd _467_ clk_bF$buf5 \u_ball.x_ball\[2] vdd 
+ gnd
+ DFFSR
X_970_ _210_ _207_ _213_ _206_ vdd gnd NAND3X1
XFILL_0__1276_ gnd vdd FILL
X_1504_ \u_ball.x_pos\[6] \u_ball.x_pos\[5] _653_ _652_ vdd gnd NAND3X1
X_835_ _251_ _306_ _544_ vdd gnd AND2X2
X_1313_ _430_ _420_ \u_ball.x_paddle\[1] _382_ vdd gnd OAI21X1
X_1122_ vdd _173_ _172_ clk_bF$buf0 \u_bricks.regBricks\[6] vdd 
+ gnd
+ DFFSR
X_873_ _500_ _42_ _501_ vdd gnd OR2X2
XFILL_0__926_ gnd vdd FILL
X_929_ _57_ _61_ _221_ _55_ vdd gnd OAI21X1
X_1351_ _418_ _422_ _417_ vdd gnd NAND2X1
X_1407_ _657_ _654_ _576_ _575_ vdd gnd OAI21X1
X_738_ _469__bF$buf2 vdd _561_ clk_bF$buf5 \u_ball.hit_paddle\ vdd 
+ gnd
+ DFFSR
X_1160_ \u_ball.y_pos\[2] \u_ball.y_pos\[0] _93_ vdd gnd NAND2X1
XFILL_0__1200_ gnd vdd FILL
X_1216_ _157_ _164_ _143_ vdd gnd NOR2X1
XFILL_0__964_ gnd vdd FILL
X_967_ _219_ _204_ _203_ vdd gnd NAND2X1
X_1445_ _657_ _641_ _602_ _680_ vdd gnd AOI21X1
X_1025_ \u_ball.x_paddle\[6] _284_ _306_ _259_ vdd gnd OAI21X1
X_776_ _726_ _207_ game_init _1_ vdd gnd AOI21X1
X_1254_ _327_ _410_ _326_ vdd gnd OR2X2
X_1483_ game_new _632_ vdd gnd INVX1
X_1063_ _440_ _298_ _297_ vdd gnd NAND2X1
XFILL_0__1103_ gnd vdd FILL
X_1119_ vdd _173_ _177_ clk_bF$buf7 \u_bricks.regBricks\[4] vdd 
+ gnd
+ DFFSR
X_1292_ \u_ball.y_pos\[0] _362_ vdd gnd INVX1
XFILL_0__1332_ gnd vdd FILL
X_1348_ _415_ _414_ vdd gnd INVX1
X_1157_ _95_ _91_ _98_ _90_ vdd gnd NAND3X1
X_1386_ _673__bF$buf2 vdd _672_ clk_bF$buf6 \u_ctrl.cnt_v_sync\[2] vdd 
+ gnd
+ DFFSR
X_1195_ _130_ \u_bricks.regBricks\[2] _129_ _128_ vdd gnd AOI21X1
XFILL_0__1235_ gnd vdd FILL
XFILL_0__999_ gnd vdd FILL
XFILL_0__1273_ gnd vdd FILL
X_1289_ _360_ _373_ _359_ vdd gnd OR2X2
XFILL_0__1329_ gnd vdd FILL
X_1501_ _651_ _650_ _649_ vdd gnd NOR2X1
X_832_ \u_ball.x_pos\[5] _541_ _546_ _544_ _547_ vdd 
+ gnd
+ OAI22X1
X_1098_ \u_ball.x_ball\[3] _449_ vdd gnd INVX2
X_1310_ \u_ball.x_paddle\[2] _380_ vdd gnd INVX1
X_870_ _494_ _496_ _503_ _504_ vdd gnd NAND3X1
X_926_ \u_ball.y_ball\[4] _174_ _53_ vdd gnd NOR2X1
X_1404_ _574_ _614_ _573_ vdd gnd NAND2X1
X_735_ _469__bF$buf1 vdd _479_ clk_bF$buf7 \u_ball.x_ball\[5] vdd 
+ gnd
+ DFFSR
X_1213_ _144_ _141_ _148_ _181_ vdd gnd AOI21X1
XFILL_0__961_ gnd vdd FILL
X_964_ \u_ball.sign_x\ \u_ball.x_ball\[5] _200_ vdd gnd NOR2X1
X_1442_ _600_ _599_ vdd gnd INVX1
X_1022_ _257_ _283_ _286_ _303_ _256_ vdd 
+ gnd
+ AOI22X1
X_773_ _218_ _202_ _457_ _3_ vdd gnd OAI21X1
X_829_ _549_ _249_ _550_ vdd gnd AND2X2
X_1251_ _380_ _419_ _324_ _433_ vdd gnd OAI21X1
X_1307_ \u_ball.x_pos\[1] _377_ vdd gnd INVX1
X_1480_ \u_ball.y_pos\[0] _630_ vdd gnd INVX1
X_1060_ _456_ _453_ _294_ vdd gnd AND2X2
XFILL_0__1100_ gnd vdd FILL
X_1116_ vdd _173_ _169_ clk_bF$buf7 \u_bricks.regBricks\[5] vdd 
+ gnd
+ DFFSR
X_867_ _502_ _501_ _507_ vdd gnd NAND2X1
X_1345_ _412_ _411_ vdd gnd INVX1
X_1154_ \u_bricks.regBricks\[15] \u_bricks.regBricks\[2] _88_ vdd gnd NOR2X1
XFILL_0__958_ gnd vdd FILL
X_1383_ vdd _673__bF$buf0 _685_ clk_bF$buf2 \u_ball.y_pos\[1] vdd 
+ gnd
+ DFFSR
X_1439_ _607_ _628_ _597_ _679_ vdd gnd OAI21X1
X_1019_ \u_ball.x_ball\[0] \u_ball.x_ball\[2] _253_ vdd gnd NOR2X1
XFILL_0__767_ gnd vdd FILL
X_1192_ _126_ \u_bricks.regBricks\[0] _125_ vdd gnd OR2X2
XFILL_0__1232_ gnd vdd FILL
X_1248_ _413_ _419_ _322_ _432_ vdd gnd OAI21X1
XFILL_0__996_ gnd vdd FILL
X_999_ _236_ _234_ _258_ _233_ vdd gnd AOI21X1
XFILL73950x3750 gnd vdd FILL
X_1477_ _630_ _657_ _628_ _627_ vdd gnd OAI21X1
X_1057_ \u_ball.x_ball\[4] _291_ vdd gnd INVX2
XFILL_0__1270_ gnd vdd FILL
X_1286_ \u_ball.x_paddle\[1] _377_ _357_ _356_ vdd gnd OAI21X1
XFILL_0__1326_ gnd vdd FILL
X_1095_ \u_ball.x_paddle\[3] _446_ vdd gnd INVX1
XFILL74250x68550 gnd vdd FILL
X_923_ _62_ _174_ _61_ _50_ vdd gnd OAI21X1
X_1189_ _127_ _125_ _123_ _122_ vdd gnd NAND3X1
X_1401_ \u_ctrl.State_3_bF$buf3\ _595_ _615_ _571_ vdd gnd OAI21X1
X_732_ _469__bF$buf3 vdd _463_ clk_bF$buf4 \u_ball.y_ball\[5] vdd 
+ gnd
+ DFFSR
X_1210_ _139_ _138_ vdd gnd INVX1
X_961_ _198_ _197_ vdd gnd INVX1
X_770_ _222_ _199_ _6_ vdd gnd NOR2X1
X_826_ _552_ _551_ _507_ _553_ vdd gnd OAI21X1
X_1304_ _379_ _375_ _374_ vdd gnd NAND2X1
X_1113_ vdd _173_ _182_ clk_bF$buf0 \u_bricks.regBricks\[8] vdd 
+ gnd
+ DFFSR
X_864_ \u_ball.x_ball\[1] _497_ _510_ vdd gnd NOR2X1
X_1342_ _424_ _428_ \u_ball.x_paddle\[2] _408_ vdd gnd AOI21X1
XFILL_0__1399_ gnd vdd FILL
X_729_ _723_ p_tick vdd gnd BUFX2
X_1151_ _152_ _148_ _86_ _85_ vdd gnd NAND3X1
X_1207_ \u_ball.x_ball\[5] _156_ _136_ vdd gnd NOR2X1
X_958_ _201_ _197_ _195_ _194_ vdd gnd OAI21X1
X_1380_ vdd _673__bF$buf0 _669_ clk_bF$buf3 \u_ball.x_pos\[2] vdd 
+ gnd
+ DFFSR
X_1436_ _596_ _595_ game_new _512_ vdd gnd AOI21X1
X_1016_ _306_ _251_ _250_ vdd gnd NOR2X1
XFILL_0__764_ gnd vdd FILL
X_767_ _306_ _7_ _8_ _465_ vdd gnd AOI21X1
X_1245_ _434_ vdd _438_ clk_bF$buf1 \u_ball.x_paddle\[4] vdd 
+ gnd
+ DFFSR
XFILL_0__993_ gnd vdd FILL
X_996_ _458_ _231_ _237_ _230_ vdd gnd NAND3X1
X_1474_ _630_ _626_ _625_ vdd gnd NOR2X1
X_1054_ _292_ _296_ _289_ _288_ vdd gnd OAI21X1
X_1283_ \u_ball.y_pos\[1] \u_ball.y_pos\[2] _353_ vdd gnd OR2X2
XFILL_0__1323_ gnd vdd FILL
X_1339_ _406_ _407_ _405_ vdd gnd NAND2X1
X_1092_ \u_ball.x_ball\[2] _443_ vdd gnd INVX2
XFILL73650x28950 gnd vdd FILL
X_1148_ \u_bricks.regBricks\[0] _82_ vdd gnd INVX1
X_899_ \u_ball.y_pos\[2] _28_ vdd gnd INVX1
XFILL_0__1361_ gnd vdd FILL
X_1377_ vdd _673__bF$buf3 _684_ clk_bF$buf1 \u_ball.y_pos\[2] vdd 
+ gnd
+ DFFSR
XFILL_0__1417_ gnd vdd FILL
X_920_ _196_ _48_ _47_ vdd gnd NOR2X1
X_1186_ _121_ _120_ _129_ _119_ vdd gnd AOI21X1
X_823_ \u_ball.x_pos\[5] _457_ _556_ vdd gnd NOR2X1
X_1089_ _443_ _442_ _441_ _440_ vdd gnd NAND3X1
XFILL74250x54150 gnd vdd FILL
X_1301_ \u_ball.x_paddle\[3] _372_ _371_ vdd gnd NOR2X1
XFILL_0__1358_ gnd vdd FILL
X_1110_ _469__bF$buf0 vdd _462_ clk_bF$buf4 \u_ball.sign_y\ vdd 
+ gnd
+ DFFSR
X_861_ _443_ \u_ball.x_pos\[2] _515_ vdd gnd OR2X2
X_917_ _216_ _45_ vdd gnd INVX1
XFILL_0__1396_ gnd vdd FILL
X_1204_ _138_ _159_ _135_ _178_ vdd gnd AOI21X1
X_955_ _196_ _254_ _193_ _478_ vdd gnd MUX2X1
X_1433_ _646_ _593_ vdd gnd INVX1
X_1013_ \u_ball.x_ball\[5] \u_ball.x_ball\[4] _247_ vdd gnd NOR2X1
XFILL_0__761_ gnd vdd FILL
X_764_ \u_ball.y_ball\[3] \u_ball.y_ball\[4] \u_ball.y_ball\[5] _11_ vdd gnd NAND3X1
X_1242_ _469__bF$buf2 vdd _475_ clk_bF$buf4 \u_ball.y_ball\[3] vdd 
+ gnd
+ DFFSR
XFILL_0__990_ gnd vdd FILL
X_993_ _229_ _237_ _228_ _227_ vdd gnd OAI21X1
X_1471_ _623_ _628_ _622_ vdd gnd NAND2X1
X_1051_ \u_ball.x_paddle\[1] \u_ball.x_paddle\[2] \u_ball.x_paddle\[3] _285_ vdd gnd OAI21X1
X_1107_ game_init _459_ _458_ vdd gnd NOR2X1
X_858_ _510_ _513_ _519_ _520_ vdd gnd OAI21X1
X_1280_ \u_ball.x_paddle\[5] _351_ _350_ vdd gnd NAND2X1
XFILL_0__1320_ gnd vdd FILL
X_1336_ _416_ _423_ _402_ vdd gnd NAND2X1
X_1145_ \u_bricks.regBricks\[10] _79_ vdd gnd INVX1
X_896_ _29_ _27_ _26_ _34_ _25_ vdd 
+ gnd
+ AOI22X1
X_1374_ vdd _673__bF$buf2 _666_ clk_bF$buf2 \u_ball.x_pos\[5] vdd 
+ gnd
+ DFFSR
XFILL_0__1414_ gnd vdd FILL
XFILL_0__758_ gnd vdd FILL
X_1183_ _117_ _119_ \u_ball.x_pos\[6] _116_ vdd gnd OAI21X1
X_1239_ \u_ball.x_ball\[3] _164_ _163_ vdd gnd NAND2X1
XFILL_0__987_ gnd vdd FILL
X_1468_ _650_ _620_ vdd gnd INVX1
X_1048_ \u_ball.x_paddle\[6] _282_ vdd gnd INVX1
XFILL_0__796_ gnd vdd FILL
X_799_ \u_ball.y_ball\[3] _702_ _690_ _703_ vdd gnd OAI21X1
X_1277_ _348_ _347_ vdd gnd INVX1
XFILL_0__1317_ gnd vdd FILL
X_820_ \u_ball.x_pos\[4] _559_ vdd gnd INVX1
X_1086_ _321_ _435_ \u_ball.x_ball\[2] _320_ vdd gnd OAI21X1
XFILL_0__1355_ gnd vdd FILL
X_914_ _46_ _43_ _45_ _196_ _473_ vdd 
+ gnd
+ OAI22X1
XFILL_0__1393_ gnd vdd FILL
XFILL_0__1449_ gnd vdd FILL
X_1201_ _133_ _159_ _134_ _177_ vdd gnd AOI21X1
X_952_ _191_ _190_ vdd gnd INVX1
X_1430_ _592_ _591_ _593_ _516_ vdd gnd AOI21X1
X_1010_ _246_ _245_ _249_ _244_ vdd gnd NAND3X1
X_761_ _13_ _9_ game_init _464_ vdd gnd AOI21X1
X_817_ _457_ \u_ball.x_pos\[5] _306_ \u_ball.x_pos\[6] _674_ vdd 
+ gnd
+ AOI22X1
X_990_ \u_ball.x2\ _225_ vdd gnd INVX1
X_1104_ _456_ _455_ vdd gnd INVX1
X_855_ _520_ _522_ _523_ vdd gnd NAND2X1
X_1333_ _431_ _419_ _400_ _399_ vdd gnd NAND3X1
X_1142_ _80_ _77_ _76_ vdd gnd NOR2X1
X_893_ _471_ _35_ _470_ _472_ vdd gnd AOI21X1
X_949_ _188_ \u_ball.y_ball\[0] _196_ _187_ vdd gnd AOI21X1
X_1371_ _673__bF$buf1 vdd _514_ clk_bF$buf3 \u_ctrl.State\[3] vdd 
+ gnd
+ DFFSR
XFILL_0__1411_ gnd vdd FILL
X_1427_ _645_ _633_ _590_ _528_ vdd gnd NAND3X1
X_1007_ _256_ _458_ _242_ _241_ vdd gnd AOI21X1
XFILL_0__755_ gnd vdd FILL
X_758_ _15_ _14_ _222_ _16_ vdd gnd AOI21X1
X_1180_ \u_bricks.regBricks\[7] \u_ball.x_pos\[3] _113_ vdd gnd NAND2X1
X_1236_ _725_ hit_brick _160_ vdd gnd AND2X2
X_987_ _725_ _222_ vdd gnd INVX2
X_1465_ _618_ _628_ _617_ vdd gnd NAND2X1
X_1045_ _446_ _321_ _279_ vdd gnd NAND2X1
XFILL_0__793_ gnd vdd FILL
X_796_ _675_ _705_ _555_ _706_ vdd gnd NAND3X1
X_1274_ \u_ball.x_paddle\[3] _372_ _368_ _344_ vdd gnd OAI21X1
XFILL_0__1314_ gnd vdd FILL
X_1083_ \u_ball.x_ball\[1] \u_ball.x_paddle\[1] \u_ball.x_ball\[0] _318_ _317_ vdd 
+ gnd
+ OAI22X1
X_1139_ \u_bricks.regBricks\[6] _75_ vdd gnd INVX1
XFILL_0__1352_ gnd vdd FILL
X_1368_ _673__bF$buf2 vdd _516_ clk_bF$buf6 \u_ctrl.State\[2] vdd 
+ gnd
+ DFFSR
XFILL_0__1408_ gnd vdd FILL
X_911_ \u_ball.x_pos\[0] _46_ _40_ vdd gnd NAND2X1
X_1177_ \u_bricks.regBricks\[4] _130_ _129_ _110_ vdd gnd NAND3X1
XFILL_0__1390_ gnd vdd FILL
XFILL_0__1446_ gnd vdd FILL
XFILL74250x61350 gnd vdd FILL
X_814_ \u_ball.y_pos\[5] _678_ vdd gnd INVX1
XFILL74250x28950 gnd vdd FILL
XFILL73950x43350 gnd vdd FILL
XFILL_0__1349_ gnd vdd FILL
X_1521_ vdd _173_ _166_ clk_bF$buf0 \u_bricks.regBricks\[12] vdd 
+ gnd
+ DFFSR
X_1101_ \u_ball.x_paddle\[5] _452_ vdd gnd INVX1
X_852_ _46_ _299_ _443_ _526_ vdd gnd NAND3X1
X_908_ \u_ball.y_pos\[0] _193_ _37_ vdd gnd NOR2X1
X_1330_ \u_ball.x_paddle\[3] _428_ _407_ _406_ _396_ vdd 
+ gnd
+ AOI22X1
X_890_ _470_ _484_ vdd gnd INVX1
X_946_ _193_ _189_ _191_ _185_ vdd gnd OAI21X1
X_1424_ _657_ _638_ _589_ _588_ vdd gnd OAI21X1
X_1004_ _282_ \u_ball.x_ball\[6] _450_ _307_ _238_ vdd 
+ gnd
+ OAI22X1
XFILL_0__752_ gnd vdd FILL
X_755_ \u_ball.y_ball\[5] _18_ vdd gnd INVX1
X_1233_ \u_ball.x_ball\[5] _158_ vdd gnd INVX1
X_984_ _225_ _223_ _220_ _256_ _480_ vdd 
+ gnd
+ OAI22X1
X_1462_ \u_ball.x_pos\[5] _615_ vdd gnd INVX1
X_1042_ _321_ _435_ _276_ vdd gnd NOR2X1
XFILL_0__790_ gnd vdd FILL
X_793_ _694_ _675_ _704_ _708_ vdd gnd NAND3X1
X_1518_ pixel_brick _718_ vdd gnd INVX1
X_849_ _449_ _529_ _291_ _530_ vdd gnd OAI21X1
X_1271_ _416_ \u_ball.x_pos\[4] _346_ _341_ vdd gnd OAI21X1
XFILL_0__1311_ gnd vdd FILL
X_1327_ _394_ _403_ _397_ _395_ _393_ vdd 
+ gnd
+ AOI22X1
X_1080_ _456_ _445_ _314_ vdd gnd NAND2X1
X_1136_ \u_bricks.regBricks\[9] _73_ vdd gnd INVX1
X_887_ _486_ _35_ _34_ _487_ vdd gnd NAND3X1
X_1365_ \u_ball.x_paddle\[6] _431_ vdd gnd INVX1
XFILL_0__1405_ gnd vdd FILL
XFILL_0__749_ gnd vdd FILL
X_1174_ _111_ _110_ _108_ _107_ vdd gnd NAND3X1
XFILL_0__1443_ gnd vdd FILL
X_1459_ _652_ _613_ _612_ vdd gnd NAND2X1
X_1039_ \u_ball.x_ball\[0] _318_ _273_ vdd gnd NAND2X1
XFILL_0__787_ gnd vdd FILL
X_1268_ \u_ball.y_pos\[5] _338_ vdd gnd INVX1
XFILL_0__1308_ gnd vdd FILL
XFILL_0__1481_ gnd vdd FILL
X_811_ _34_ _29_ _26_ _691_ vdd gnd NAND3X1
X_1497_ _722_ _0_ \u_ctrl.State_3_bF$buf0\ _645_ vdd gnd OAI21X1
X_1077_ _312_ _313_ _311_ vdd gnd NAND2X1
XFILL_0__1346_ gnd vdd FILL
X_905_ \u_ball.y_pos\[1] _192_ _34_ vdd gnd NAND2X1
X_943_ _175_ _174_ _68_ vdd gnd NOR2X1
XFILL74250x14550 gnd vdd FILL
X_1421_ \u_ctrl.State_3_bF$buf1\ _586_ _585_ vdd gnd NOR2X1
X_1001_ _268_ _281_ _235_ vdd gnd NAND2X1
X_752_ \u_ball.sign_y\ _223_ _44_ _21_ vdd gnd OAI21X1
XFILL_0__1478_ gnd vdd FILL
X_808_ _693_ _692_ _690_ _694_ vdd gnd OAI21X1
X_1230_ _156_ _158_ _155_ vdd gnd OR2X2
X_981_ \u_ball.sign_x\ \u_ball.x_ball\[1] _225_ _217_ vdd gnd NAND3X1
X_790_ pixel_brick _709_ _710_ _711_ vdd gnd NAND3X1
X_1515_ _723_ _663_ vdd gnd INVX1
X_846_ \u_ball.x_ball\[3] _526_ _533_ vdd gnd NAND2X1
X_1324_ _416_ btn_left _402_ _391_ vdd gnd OAI21X1
X_1133_ _154_ _72_ \u_bricks.regBricks\[13] _71_ vdd gnd OAI21X1
X_884_ _485_ _489_ _483_ _490_ vdd gnd NAND3X1
X_1362_ btn_left _428_ vdd gnd INVX2
XFILL_0__1402_ gnd vdd FILL
X_1418_ \u_ball.x_pos\[0] _583_ vdd gnd INVX1
X_749_ _22_ _23_ vdd gnd INVX1
X_1171_ _105_ _106_ _129_ _104_ vdd gnd AOI21X1
X_1227_ _153_ _183_ vdd gnd INVX1
X_978_ _217_ _215_ _214_ vdd gnd NAND2X1
XFILL_0__1440_ gnd vdd FILL
X_1456_ _649_ _611_ \u_ctrl.State_3_bF$buf2\ _610_ vdd gnd OAI21X1
X_1036_ _275_ _271_ _277_ _270_ vdd gnd NAND3X1
XFILL_0__784_ gnd vdd FILL
X_787_ _712_ _459_ _254_ _561_ vdd gnd AOI21X1
X_1265_ \u_ball.x_paddle\[2] _376_ _366_ _335_ vdd gnd OAI21X1
XFILL_0__1305_ gnd vdd FILL
X_1494_ \u_ctrl.State\[1] \u_ctrl.State\[2] _645_ _642_ vdd gnd OAI21X1
X_1074_ \u_ball.x_ball\[4] _311_ _309_ _308_ vdd gnd OAI21X1
XBUFX2_insert0 _673_ _673__bF$buf3 vdd gnd BUFX2
XBUFX2_insert1 _673_ _673__bF$buf2 vdd gnd BUFX2
XBUFX2_insert2 _673_ _673__bF$buf1 vdd gnd BUFX2
XBUFX2_insert3 _673_ _673__bF$buf0 vdd gnd BUFX2
XFILL_0__1343_ gnd vdd FILL
X_1359_ \u_ball.x_paddle\[2] \u_ball.x_paddle\[3] _425_ vdd gnd NOR2X1
X_902_ \u_ball.y_ball\[0] _32_ _33_ _31_ vdd gnd OAI21X1
X_1168_ \u_ball.x_pos\[6] _102_ _103_ _101_ vdd gnd NAND3X1
X_1397_ _662_ _595_ \u_ctrl.State_3_bF$buf1\ _568_ vdd gnd AOI21X1
XFILL_0__1437_ gnd vdd FILL
X_940_ _66_ _185_ _65_ vdd gnd AND2X2
XFILL_0__1475_ gnd vdd FILL
X_805_ _175_ \u_ball.y_pos\[2] _691_ _697_ vdd gnd OAI21X1
XFILL73950x50550 gnd vdd FILL
X_1512_ _661_ _660_ vdd gnd INVX1
X_843_ _510_ _513_ _515_ _536_ vdd gnd OAI21X1
X_1321_ _419_ _389_ _390_ _388_ vdd gnd NAND3X1
X_1130_ _70_ _159_ _83_ _169_ vdd gnd AOI21X1
X_881_ _487_ _492_ _493_ vdd gnd NAND2X1
X_937_ _64_ _65_ _63_ _476_ vdd gnd OAI21X1
X_1415_ _657_ \u_ctrl.State\[0] _582_ _581_ vdd gnd AOI21X1
X_746_ _469__bF$buf3 vdd _478_ clk_bF$buf1 \u_ball.y_ball\[0] vdd 
+ gnd
+ DFFSR
X_1224_ _157_ _164_ _150_ vdd gnd NAND2X1
X_975_ \u_ball.x_ball\[2] _460_ _211_ vdd gnd NAND2X1
X_1453_ \u_ball.y_pos\[5] _608_ vdd gnd INVX1
X_1033_ _281_ _268_ _267_ vdd gnd AND2X2
XFILL_0__781_ gnd vdd FILL
X_784_ _216_ _214_ _221_ _714_ vdd gnd OAI21X1
X_1509_ \u_ctrl.State_3_bF$buf2\ _657_ vdd gnd INVX4
X_1262_ _416_ \u_ball.x_pos\[4] _350_ _332_ vdd gnd OAI21X1
XFILL_0__1302_ gnd vdd FILL
X_1318_ _418_ _428_ _417_ _386_ vdd gnd OAI21X1
X_1491_ _658_ _640_ _647_ _639_ vdd gnd NOR3X1
X_1071_ _454_ _305_ vdd gnd INVX1
X_1127_ \u_bricks.regBricks\[12] _69_ vdd gnd INVX1
X_878_ _485_ _483_ _495_ _496_ vdd gnd NAND3X1
XFILL_0__1340_ gnd vdd FILL
X_1356_ _423_ _422_ vdd gnd INVX1
X_1165_ \u_ball.y_pos\[4] _99_ _98_ vdd gnd NOR2X1
X_1394_ _661_ _566_ \u_ctrl.State\[1] _565_ vdd gnd OAI21X1
XFILL_0__1434_ gnd vdd FILL
XFILL_0__778_ gnd vdd FILL
X_1259_ _346_ _331_ _330_ _329_ vdd gnd OAI21X1
XFILL_0__1472_ gnd vdd FILL
X_802_ _54_ \u_ball.y_pos\[4] _699_ _700_ vdd gnd OAI21X1
X_1488_ _640_ _636_ vdd gnd INVX1
X_1068_ \u_ball.x_paddle\[6] _306_ _302_ vdd gnd NOR2X1
X_1297_ _379_ _375_ _367_ vdd gnd AND2X2
XFILL_0__1337_ gnd vdd FILL
X_840_ \u_ball.x_pos\[4] _531_ _535_ _538_ _539_ vdd 
+ gnd
+ OAI22X1
X_934_ _62_ _174_ _60_ vdd gnd NOR2X1
XFILL74250x21750 gnd vdd FILL
X_1412_ \u_ball.x_pos\[1] _582_ _579_ vdd gnd NAND2X1
X_743_ _469__bF$buf0 vdd _468_ clk_bF$buf4 \u_ball.x_ball\[1] vdd 
+ gnd
+ DFFSR
XFILL_0__1469_ gnd vdd FILL
X_1221_ \u_bricks.regBricks\[11] _148_ vdd gnd INVX1
X_972_ \u_ball.x_ball\[3] _460_ _208_ vdd gnd NAND2X1
XFILL74250x3750 gnd vdd FILL
X_1450_ _607_ _606_ _608_ _605_ vdd gnd OAI21X1
X_1030_ _265_ _264_ vdd gnd INVX1
X_781_ _213_ _210_ _715_ _719_ vdd gnd OAI21X1
X_1506_ \u_ball.x_pos\[1] \u_ball.x_pos\[0] \u_ball.x_pos\[2] _654_ vdd gnd NAND3X1
X_837_ \u_ball.x_pos\[4] _531_ _541_ \u_ball.x_pos\[5] _542_ vdd 
+ gnd
+ AOI22X1
X_1315_ _430_ _420_ \u_ball.x_paddle\[5] _383_ vdd gnd OAI21X1
X_1124_ vdd _173_ _176_ clk_bF$buf0 \u_bricks.regBricks\[3] vdd 
+ gnd
+ DFFSR
X_875_ \u_ball.x_pos\[1] _299_ _499_ vdd gnd NAND2X1
X_1353_ _430_ _420_ _419_ vdd gnd NOR2X1
X_1409_ _654_ _657_ _577_ vdd gnd OR2X2
X_1162_ _97_ _96_ _95_ vdd gnd NAND2X1
X_1218_ _146_ _147_ _145_ vdd gnd NAND2X1
X_969_ \u_ball.x_ball\[2] \u_ball.x_ball\[3] \u_ball.sign_x\ _205_ vdd gnd OAI21X1
X_1391_ \u_ctrl.cnt_v_sync\[0] _588_ _563_ vdd gnd NAND2X1
XFILL_0__1431_ gnd vdd FILL
X_1447_ _608_ _628_ _603_ _681_ vdd gnd OAI21X1
X_1027_ _270_ _266_ _262_ _261_ vdd gnd AOI21X1
XFILL_0__775_ gnd vdd FILL
X_778_ _210_ _213_ _721_ vdd gnd NAND2X1
X_1256_ _408_ _328_ vdd gnd INVX1
X_1485_ _663_ _639_ _634_ _688_ vdd gnd OAI21X1
X_1065_ \u_ball.x_ball\[1] _299_ vdd gnd INVX2
XFILL73350x28950 gnd vdd FILL
X_1294_ _379_ _366_ _365_ _364_ vdd gnd NAND3X1
XFILL_0__1334_ gnd vdd FILL
XFILL_0_BUFX2_insert12 gnd vdd FILL
X_1159_ \u_ball.y_pos\[1] _93_ _92_ vdd gnd NAND2X1
XFILL_0_BUFX2_insert15 gnd vdd FILL
XFILL_0_BUFX2_insert18 gnd vdd FILL
X_1388_ vdd _673__bF$buf0 _679_ clk_bF$buf2 \u_ball.y_pos\[4] vdd 
+ gnd
+ DFFSR
XFILL_0__1428_ gnd vdd FILL
X_931_ _58_ _59_ _57_ vdd gnd NAND2X1
X_1197_ \u_ball.x_pos\[3] _130_ vdd gnd INVX2
X_740_ _469__bF$buf3 vdd _477_ clk_bF$buf4 \u_ball.y_ball\[1] vdd 
+ gnd
+ DFFSR
XFILL_0__1466_ gnd vdd FILL
X_1503_ \u_ball.y_pos\[3] _651_ vdd gnd INVX1
X_834_ \u_ball.x_pos\[6] _545_ vdd gnd INVX1
X_1312_ _410_ _419_ _381_ vdd gnd NAND2X1
X_1121_ vdd _173_ _181_ clk_bF$buf7 \u_bricks.regBricks\[11] vdd 
+ gnd
+ DFFSR
X_872_ _42_ _500_ _502_ vdd gnd NAND2X1
X_928_ _62_ _254_ _55_ _56_ _475_ vdd 
+ gnd
+ OAI22X1
X_1350_ \u_ball.x_paddle\[4] _416_ vdd gnd INVX2
X_1406_ \u_ball.x_pos\[3] _577_ _575_ _668_ vdd gnd OAI21X1
X_737_ _469__bF$buf1 vdd _465_ clk_bF$buf5 \u_ball.x_ball\[6] vdd 
+ gnd
+ DFFSR
X_1215_ _160_ _143_ _142_ vdd gnd NAND2X1
X_966_ _206_ _205_ _203_ _202_ vdd gnd AOI21X1
X_1444_ _607_ _606_ _601_ vdd gnd NOR2X1
X_1024_ \u_ball.x_ball\[5] _260_ _259_ _258_ vdd gnd OAI21X1
XFILL_0__772_ gnd vdd FILL
X_775_ _207_ _726_ _1_ _2_ vdd gnd OAI21X1
XFILL_0__828_ gnd vdd FILL
X_1253_ _410_ _327_ _325_ vdd gnd NAND2X1
X_1309_ \u_ball.x_pos\[2] _380_ _379_ vdd gnd NAND2X1
X_1482_ _632_ \u_ctrl.State\[0] game_init _631_ vdd gnd AOI21X1
X_1062_ _449_ _300_ _297_ _320_ _296_ vdd 
+ gnd
+ AOI22X1
X_1118_ vdd _173_ _170_ clk_bF$buf0 \u_bricks.regBricks\[13] vdd 
+ gnd
+ DFFSR
X_869_ _485_ _493_ _483_ _505_ vdd gnd NAND3X1
X_1291_ \u_ball.x_paddle\[1] _377_ _374_ _361_ vdd gnd OAI21X1
X_1347_ \u_ball.x_paddle\[3] _413_ vdd gnd INVX1
X_1156_ _100_ \u_ball.x_pos\[5] _90_ _89_ vdd gnd AOI21X1
X_1385_ vdd _673__bF$buf3 _681_ clk_bF$buf3 \u_ball.y_pos\[5] vdd 
+ gnd
+ DFFSR
XFILL_0__1425_ gnd vdd FILL
XFILL_0__769_ gnd vdd FILL
X_1194_ _132_ _130_ _128_ _127_ vdd gnd OAI21X1
XFILL_0__1463_ gnd vdd FILL
X_1479_ \u_ctrl.State_3_bF$buf3\ \u_ctrl.State\[0] _645_ _629_ vdd gnd OAI21X1
X_1059_ _295_ _294_ \u_ball.x_ball\[4] _293_ vdd gnd OAI21X1
X_1288_ _359_ _363_ _358_ vdd gnd OR2X2
X_1500_ \u_ball.y_pos\[5] \u_ball.y_pos\[4] _649_ _648_ vdd gnd NAND3X1
X_831_ \u_ball.x_pos\[6] _544_ _548_ vdd gnd NAND2X1
X_1097_ \u_ball.x_paddle\[1] _448_ vdd gnd INVX1
XFILL_0__1137_ gnd vdd FILL
X_925_ \u_ball.sign_y\ _54_ _52_ vdd gnd NOR2X1
XFILL73950x10950 gnd vdd FILL
X_1403_ _655_ _643_ _573_ \u_ctrl.State_3_bF$buf0\ _667_ vdd 
+ gnd
+ AOI22X1
XFILL_0__731_ gnd vdd FILL
X_734_ _469__bF$buf2 vdd _464_ clk_bF$buf4 _722_ vdd 
+ gnd
+ DFFSR
X_1212_ \u_bricks.regBricks\[15] _140_ vdd gnd INVX1
X_963_ _460_ _457_ _199_ vdd gnd NOR2X1
X_1441_ _599_ _601_ \u_ctrl.State_3_bF$buf2\ _598_ vdd gnd OAI21X1
X_1021_ game_init _725_ _255_ vdd gnd NOR2X1
X_772_ _206_ _205_ _4_ vdd gnd AND2X2
XFILL_0__1498_ gnd vdd FILL
XFILL_0__825_ gnd vdd FILL
X_828_ _496_ _494_ _38_ _551_ vdd gnd AOI21X1
X_1250_ _407_ _406_ _323_ vdd gnd OR2X2
X_1306_ \u_ball.x_pos\[2] _376_ vdd gnd INVX1
X_1115_ vdd _173_ _180_ clk_bF$buf7 \u_bricks.regBricks\[15] vdd 
+ gnd
+ DFFSR
X_866_ _507_ _505_ _506_ _508_ vdd gnd NAND3X1
X_1344_ \u_ball.x_paddle\[1] _410_ vdd gnd INVX1
XFILL_0__728_ gnd vdd FILL
X_1153_ _135_ _134_ _88_ _87_ vdd gnd NAND3X1
X_1209_ _138_ _151_ _140_ _180_ vdd gnd AOI21X1
X_1382_ vdd _673__bF$buf3 _670_ clk_bF$buf1 \u_ball.x_pos\[1] vdd 
+ gnd
+ DFFSR
XFILL_0__1422_ gnd vdd FILL
X_1438_ \u_ctrl.State\[4] _596_ vdd gnd INVX1
X_1018_ _253_ _299_ _449_ _252_ vdd gnd AOI21X1
X_769_ _6_ _3_ _5_ _7_ vdd gnd NAND3X1
X_1191_ \u_ball.x_pos\[4] _130_ _124_ vdd gnd NOR2X1
X_1247_ _434_ vdd _437_ clk_bF$buf1 \u_ball.x_paddle\[5] vdd 
+ gnd
+ DFFSR
X_998_ _306_ _280_ _232_ vdd gnd NOR2X1
XFILL_0__1460_ gnd vdd FILL
X_1476_ _630_ _628_ _627_ _686_ vdd gnd OAI21X1
X_1056_ _291_ _312_ _313_ _290_ vdd gnd NAND3X1
X_1285_ _356_ _366_ _355_ vdd gnd NOR2X1
X_1094_ _448_ _447_ _446_ _445_ vdd gnd OAI21X1
XFILL_0__1134_ gnd vdd FILL
XFILL_0__1363_ gnd vdd FILL
X_1379_ _673__bF$buf1 vdd _687_ clk_bF$buf3 game_init vdd 
+ gnd
+ DFFSR
XFILL_0__1419_ gnd vdd FILL
X_922_ _58_ _51_ _50_ _49_ vdd gnd NAND3X1
X_1188_ \u_bricks.regBricks\[10] _130_ _121_ vdd gnd NAND2X1
X_1400_ _657_ _614_ _571_ _570_ vdd gnd OAI21X1
X_731_ _0_ game_complete vdd gnd BUFX2
XFILL_0__1457_ gnd vdd FILL
X_960_ _221_ _196_ vdd gnd INVX2
XFILL73650x43350 gnd vdd FILL
XFILL_0__1495_ gnd vdd FILL
XFILL_0__822_ gnd vdd FILL
X_825_ _504_ _523_ _554_ vdd gnd AND2X2
X_1303_ \u_ball.x_paddle\[1] _377_ _374_ _373_ vdd gnd AOI21X1
X_1112_ vdd _173_ _167_ clk_bF$buf0 \u_bricks.regBricks\[0] vdd 
+ gnd
+ DFFSR
XFILL_0__860_ gnd vdd FILL
X_863_ \u_ball.x_pos\[0] _511_ vdd gnd INVX1
XFILL_0__1169_ gnd vdd FILL
X_919_ _54_ _255_ _47_ _49_ _474_ vdd 
+ gnd
+ AOI22X1
X_1341_ _410_ _408_ _409_ _407_ vdd gnd OAI21X1
X_728_ _724_ pixel vdd gnd BUFX2
X_1150_ _87_ _85_ _84_ vdd gnd NOR2X1
X_1206_ _136_ _159_ _137_ _179_ vdd gnd AOI21X1
X_957_ _457_ _254_ _194_ _479_ vdd gnd OAI21X1
X_1435_ \u_ctrl.State\[2] _646_ _594_ vdd gnd NAND2X1
X_1015_ _250_ _249_ vdd gnd INVX1
X_766_ _722_ _9_ vdd gnd INVX1
XFILL_0__819_ gnd vdd FILL
X_1244_ _434_ vdd _433_ clk_bF$buf1 \u_ball.x_paddle\[2] vdd 
+ gnd
+ DFFSR
X_995_ _458_ _229_ vdd gnd INVX1
X_1473_ \u_ball.y_pos\[0] \u_ball.y_pos\[1] _624_ vdd gnd NOR2X1
X_1053_ _305_ _301_ _288_ _287_ vdd gnd NAND3X1
XFILL_0__1513_ gnd vdd FILL
X_1109_ \u_ball.sign_x\ _460_ vdd gnd INVX2
XFILL_0__857_ gnd vdd FILL
X_1282_ _358_ _354_ _353_ _352_ vdd gnd AOI21X1
X_1338_ _414_ _411_ _405_ _404_ vdd gnd NAND3X1
X_1091_ \u_ball.x_paddle\[1] \u_ball.x_paddle\[2] _442_ vdd gnd NAND2X1
XFILL_0__1131_ gnd vdd FILL
X_1147_ \u_bricks.regBricks\[9] \u_bricks.regBricks\[6] _81_ vdd gnd NOR2X1
X_898_ \u_ball.y_ball\[2] _28_ _27_ vdd gnd NAND2X1
X_1376_ vdd _673__bF$buf1 _667_ clk_bF$buf6 \u_ball.x_pos\[4] vdd 
+ gnd
+ DFFSR
X_1185_ \u_bricks.regBricks\[9] \u_ball.x_pos\[3] _129_ _118_ vdd gnd NAND3X1
XFILL_0__1454_ gnd vdd FILL
XFILL_0__798_ gnd vdd FILL
X_1279_ \u_ball.x_pos\[6] _349_ vdd gnd INVX1
XFILL_0__1492_ gnd vdd FILL
X_822_ \u_ball.x_pos\[3] _449_ _557_ vdd gnd NAND2X1
X_1088_ \u_ball.x_paddle\[1] \u_ball.x_paddle\[2] _435_ vdd gnd AND2X2
XFILL_0__1128_ gnd vdd FILL
X_1300_ \u_ball.x_pos\[3] _413_ _370_ vdd gnd NOR2X1
X_860_ \u_ball.x_pos\[2] _443_ _518_ vdd gnd NAND2X1
XFILL_0__1166_ gnd vdd FILL
X_916_ game_init _44_ vdd gnd INVX1
X_1203_ \u_bricks.regBricks\[4] _134_ vdd gnd INVX1
X_954_ \u_ball.y_ball\[1] _192_ vdd gnd INVX1
X_1432_ _648_ _652_ \u_ctrl.State_3_bF$buf3\ _592_ vdd gnd OAI21X1
X_1012_ _306_ _248_ _247_ _246_ vdd gnd NAND3X1
X_763_ _11_ _12_ vdd gnd INVX1
XFILL_0__1489_ gnd vdd FILL
XFILL_0__816_ gnd vdd FILL
X_819_ _559_ \u_ball.x_ball\[4] \u_ball.x_ball\[3] _532_ _560_ vdd 
+ gnd
+ AOI22X1
X_1241_ \u_bricks.regBricks\[1] _165_ vdd gnd INVX1
X_992_ _230_ _243_ _227_ _226_ vdd gnd NAND3X1
XFILL73950x72150 gnd vdd FILL
X_1470_ _626_ _628_ _622_ _685_ vdd gnd OAI21X1
X_1050_ _453_ _452_ _285_ _284_ vdd gnd NOR3X1
XFILL_0__1510_ gnd vdd FILL
X_1106_ \u_ball.x_ball\[5] _457_ vdd gnd INVX2
XFILL_0__854_ gnd vdd FILL
X_857_ _510_ _41_ _498_ _521_ vdd gnd OAI21X1
X_1335_ _403_ _402_ _404_ _401_ vdd gnd NAND3X1
X_1144_ \u_bricks.regBricks\[13] \u_bricks.regBricks\[12] _78_ vdd gnd NOR2X1
XFILL_0__892_ gnd vdd FILL
X_895_ _29_ _27_ _470_ vdd gnd NAND2X1
X_1373_ vdd _673__bF$buf0 _683_ clk_bF$buf2 \u_ball.x_pos\[6] vdd 
+ gnd
+ DFFSR
X_1429_ _593_ _637_ _517_ vdd gnd NOR2X1
X_1009_ _244_ _254_ _243_ vdd gnd AND2X2
X_1182_ _131_ _116_ _122_ _115_ vdd gnd NAND3X1
X_1238_ \u_ball.x_ball\[5] _163_ _162_ vdd gnd NOR2X1
X_989_ game_init \u_ball.hit_paddle\ _254_ _224_ vdd gnd OAI21X1
XFILL_0__1451_ gnd vdd FILL
X_1467_ \u_ball.y_pos\[2] _625_ _619_ vdd gnd NOR2X1
X_1047_ _285_ _453_ _281_ vdd gnd OR2X2
X_798_ _701_ _703_ _696_ _704_ vdd gnd AOI21X1
XFILL_0__1507_ gnd vdd FILL
X_1276_ \u_ball.x_paddle\[5] _351_ _347_ _346_ vdd gnd OAI21X1
X_1085_ \u_ball.x_ball\[1] \u_ball.x_paddle\[1] _319_ vdd gnd NAND2X1
XFILL_0__889_ gnd vdd FILL
XFILL_0__1163_ gnd vdd FILL
X_913_ \u_ball.x_pos\[0] _46_ _42_ vdd gnd NOR2X1
X_1179_ _114_ _113_ _129_ _112_ vdd gnd AOI21X1
X_1200_ \u_bricks.regBricks\[3] _132_ vdd gnd INVX1
XFILL73650x50550 gnd vdd FILL
X_951_ \u_ball.y_ball\[1] \u_ball.sign_y\ _189_ vdd gnd NOR2X1
X_760_ _59_ _53_ _61_ _14_ vdd gnd NAND3X1
XFILL_0__1486_ gnd vdd FILL
XFILL_0__813_ gnd vdd FILL
X_816_ _556_ _562_ _674_ _675_ vdd gnd OAI21X1
X_1523_ _673__bF$buf2 vdd _664_ clk_bF$buf6 \u_ctrl.cnt_v_sync\[0] vdd 
+ gnd
+ DFFSR
X_1103_ \u_ball.x_paddle\[4] \u_ball.x_paddle\[5] _455_ _454_ vdd gnd NAND3X1
XFILL_0__851_ gnd vdd FILL
X_854_ _523_ _524_ vdd gnd INVX1
X_1332_ _419_ _398_ vdd gnd INVX1
X_1141_ _84_ _76_ _0_ vdd gnd AND2X2
X_892_ _25_ _472_ _30_ _482_ vdd gnd OAI21X1
XFILL_0__1198_ gnd vdd FILL
X_948_ \u_ball.y_ball\[0] _188_ _187_ _186_ vdd gnd OAI21X1
X_1370_ vdd _673__bF$buf1 _528_ clk_bF$buf0 \u_ctrl.State\[0] vdd 
+ gnd
+ DFFSR
XFILL74250x43350 gnd vdd FILL
X_1426_ reset _673_ vdd gnd INVX8
X_1006_ _302_ _240_ vdd gnd INVX1
X_757_ \u_ball.y_ball\[5] _16_ _44_ _17_ vdd gnd OAI21X1
X_1235_ _160_ _161_ _159_ vdd gnd AND2X2
X_986_ game_init _222_ _221_ vdd gnd NOR2X1
X_1464_ _621_ _628_ _617_ _684_ vdd gnd OAI21X1
X_1044_ _285_ _279_ _278_ vdd gnd NAND2X1
X_795_ _525_ _550_ _706_ pixel_ball vdd gnd NOR3X1
XFILL_0__1504_ gnd vdd FILL
XFILL_0__848_ gnd vdd FILL
X_1273_ \u_ball.x_paddle\[4] \u_ball.x_pos\[4] _343_ vdd gnd OR2X2
X_1329_ _396_ _414_ _395_ vdd gnd AND2X2
X_1082_ _319_ _317_ _320_ _316_ vdd gnd NAND3X1
X_1138_ _155_ _74_ vdd gnd INVX1
XFILL_0__886_ gnd vdd FILL
X_889_ _34_ _26_ _484_ _485_ vdd gnd NAND3X1
X_1367_ vdd _673__bF$buf3 _686_ clk_bF$buf1 \u_ball.y_pos\[0] vdd 
+ gnd
+ DFFSR
XFILL_0__1160_ gnd vdd FILL
X_910_ _40_ _41_ _39_ vdd gnd NAND2X1
X_1176_ \u_ball.x_pos\[4] \u_ball.x_pos\[5] _109_ vdd gnd NAND2X1
XFILL_0__1025_ gnd vdd FILL
XFILL_0__1483_ gnd vdd FILL
XFILL_0__810_ gnd vdd FILL
X_813_ \u_ball.y_ball\[4] _677_ \u_ball.y_ball\[5] _678_ _689_ vdd 
+ gnd
+ OAI22X1
X_1499_ _657_ _648_ _652_ _647_ vdd gnd NOR3X1
X_1079_ _456_ _453_ _313_ vdd gnd OR2X2
X_1520_ _469__bF$buf1 vdd _461_ clk_bF$buf5 \u_ball.x_ball\[4] vdd 
+ gnd
+ DFFSR
X_1100_ _453_ _456_ _452_ _451_ vdd gnd OAI21X1
X_851_ \u_ball.x_ball\[4] \u_ball.x_ball\[3] _526_ _527_ vdd gnd NAND3X1
XFILL_0__1157_ gnd vdd FILL
X_907_ \u_ball.y_pos\[1] _36_ vdd gnd INVX1
XFILL_0__1195_ gnd vdd FILL
X_945_ \u_ball.y_ball\[2] _175_ vdd gnd INVX1
X_1423_ \u_ctrl.State\[1] \u_ctrl.cnt_v_sync\[2] _587_ vdd gnd NAND2X1
X_1003_ _239_ _305_ _240_ _238_ _237_ vdd 
+ gnd
+ AOI22X1
X_754_ _62_ _54_ _18_ _19_ vdd gnd NAND3X1
XFILL_0__807_ gnd vdd FILL
XFILL73950x46950 gnd vdd FILL
X_1232_ \u_ball.x_ball\[3] _157_ vdd gnd INVX1
X_983_ \u_ball.sign_x\ \u_ball.x_ball\[4] _219_ vdd gnd NAND2X1
X_1461_ _653_ _614_ vdd gnd INVX1
X_1041_ \u_ball.x_ball\[2] _276_ _275_ vdd gnd NAND2X1
X_792_ _553_ _554_ _708_ _709_ vdd gnd AOI21X1
XFILL_0__1501_ gnd vdd FILL
X_1517_ pixel_paddle _717_ vdd gnd INVX1
XFILL_0__845_ gnd vdd FILL
X_848_ _527_ _530_ _531_ vdd gnd NAND2X1
X_1270_ _342_ _341_ _340_ vdd gnd NAND2X1
X_1326_ _398_ _393_ \u_ball.x_paddle\[6] _392_ vdd gnd OAI21X1
X_1135_ _151_ _162_ _73_ _171_ vdd gnd AOI21X1
XFILL_0__883_ gnd vdd FILL
X_886_ _487_ _488_ vdd gnd INVX1
X_1364_ _725_ _430_ vdd gnd INVX1
X_1173_ \u_bricks.regBricks\[15] \u_ball.x_pos\[3] _106_ vdd gnd NAND2X1
X_1229_ \u_ball.x_ball\[6] _160_ _154_ vdd gnd NAND2X1
XFILL_0__1022_ gnd vdd FILL
X_1458_ _616_ _643_ _612_ \u_ctrl.State_3_bF$buf1\ _683_ vdd 
+ gnd
+ AOI22X1
X_1038_ _273_ _319_ _274_ _272_ vdd gnd AOI21X1
X_789_ _711_ _707_ _254_ _676_ vdd gnd AOI21X1
X_1267_ _349_ \u_ball.x_paddle\[6] _338_ _337_ vdd gnd AOI21X1
X_810_ _62_ \u_ball.y_pos\[3] _691_ _27_ _692_ vdd 
+ gnd
+ AOI22X1
X_1496_ _645_ _644_ vdd gnd INVX1
X_1076_ \u_ball.x_ball\[3] _314_ _311_ \u_ball.x_ball\[4] _310_ vdd 
+ gnd
+ AOI22X1
XFILL_0__1154_ gnd vdd FILL
X_904_ _35_ _34_ _33_ vdd gnd NAND2X1
X_1399_ \u_ball.x_pos\[5] _572_ _570_ _666_ vdd gnd OAI21X1
XFILL_0__1019_ gnd vdd FILL
XFILL_0__1192_ gnd vdd FILL
X_942_ \u_ball.y_ball\[2] \u_ball.sign_y\ _67_ vdd gnd NOR2X1
XCLKBUF1_insert10 clk clk_bF$buf1 vdd gnd CLKBUF1
XCLKBUF1_insert11 clk clk_bF$buf0 vdd gnd CLKBUF1
X_1420_ \u_ctrl.cnt_v_sync\[2] _588_ _584_ vdd gnd NAND2X1
X_1000_ \u_ball.x_ball\[4] _235_ _260_ \u_ball.x_ball\[5] _234_ vdd 
+ gnd
+ AOI22X1
X_751_ _725_ _20_ _21_ _462_ vdd gnd AOI21X1
XFILL_0__1057_ gnd vdd FILL
XFILL_0__804_ gnd vdd FILL
X_807_ _545_ \u_ball.x_ball\[6] \u_ball.y_ball\[5] _678_ _695_ vdd 
+ gnd
+ AOI22X1
X_980_ \u_ball.x2\ \u_ball.x_ball\[0] _216_ vdd gnd NOR2X1
X_1514_ \u_ctrl.State\[1] _662_ vdd gnd INVX1
XFILL_0__842_ gnd vdd FILL
X_845_ _449_ _529_ _534_ vdd gnd NAND2X1
X_1323_ _396_ _391_ _390_ vdd gnd OR2X2
X_1132_ _71_ _170_ vdd gnd INVX1
XFILL_0__880_ gnd vdd FILL
X_883_ _490_ _482_ _38_ _491_ vdd gnd AOI21X1
XFILL74250x50550 gnd vdd FILL
XFILL_0__1189_ gnd vdd FILL
X_939_ _185_ _66_ _725_ _64_ vdd gnd OAI21X1
X_1361_ \u_ball.x_paddle\[6] \u_ball.x_paddle\[4] _427_ vdd gnd NOR2X1
XFILL73950x7350 gnd vdd FILL
XFILL73950x32550 gnd vdd FILL
X_1417_ _657_ _583_ _582_ vdd gnd NOR2X1
X_748_ _203_ _4_ _221_ _24_ vdd gnd OAI21X1
X_1170_ \u_bricks.regBricks\[12] _130_ _129_ _103_ vdd gnd NAND3X1
X_1226_ \u_bricks.regBricks\[8] _152_ vdd gnd INVX1
X_977_ _216_ _214_ _217_ _213_ vdd gnd OAI21X1
X_1455_ _610_ _628_ _609_ vdd gnd NAND2X1
X_1035_ _278_ _269_ vdd gnd INVX1
X_786_ reset _469_ vdd gnd INVX8
XFILL_0__839_ gnd vdd FILL
X_1264_ _335_ _369_ _371_ _334_ vdd gnd AOI21X1
X_1493_ _643_ _644_ _642_ _641_ vdd gnd OAI21X1
X_1073_ _315_ _310_ _308_ _307_ vdd gnd AOI21X1
X_1129_ _151_ _136_ _79_ _168_ vdd gnd AOI21X1
XFILL_0__877_ gnd vdd FILL
X_1358_ _427_ _426_ _425_ _424_ vdd gnd NAND3X1
XFILL_0__1151_ gnd vdd FILL
X_901_ _37_ _33_ _31_ _30_ vdd gnd OAI21X1
X_1167_ _101_ _104_ _112_ _107_ _100_ vdd 
+ gnd
+ OAI22X1
X_1396_ \u_ctrl.cnt_v_sync\[0] _567_ vdd gnd INVX1
XFILL_0__1016_ gnd vdd FILL
XFILL_0__1054_ gnd vdd FILL
XFILL_0__801_ gnd vdd FILL
X_804_ _62_ \u_ball.y_pos\[3] _689_ _698_ vdd gnd OAI21X1
X_1299_ _371_ _370_ _369_ vdd gnd NOR2X1
X_1511_ \u_ctrl.cnt_v_sync\[2] _660_ _659_ vdd gnd NOR2X1
X_842_ \u_ball.x_ball\[3] \u_ball.x_pos\[3] _526_ _537_ vdd gnd OAI21X1
XFILL_0__1148_ gnd vdd FILL
X_1320_ _416_ _419_ _388_ _438_ vdd gnd OAI21X1
XFILL73650x10950 gnd vdd FILL
X_880_ _25_ _472_ _493_ _494_ vdd gnd OAI21X1
XFILL_0__1186_ gnd vdd FILL
X_936_ \u_ball.y_ball\[3] _62_ vdd gnd INVX2
X_1414_ _657_ _583_ \u_ball.x_pos\[1] _580_ vdd gnd OAI21X1
X_745_ _469__bF$buf3 vdd _473_ clk_bF$buf5 \u_ball.x_ball\[0] vdd 
+ gnd
+ DFFSR
X_1223_ \u_ball.x_ball\[5] _150_ _149_ vdd gnd NOR2X1
X_974_ _212_ _211_ _210_ vdd gnd NAND2X1
X_1452_ \u_ball.y_pos\[4] _607_ vdd gnd INVX1
X_1032_ _449_ _269_ _267_ _291_ _266_ vdd 
+ gnd
+ AOI22X1
XFILL_0_CLKBUF1_insert4 gnd vdd FILL
XFILL_0_CLKBUF1_insert6 gnd vdd FILL
XFILL_0_CLKBUF1_insert9 gnd vdd FILL
X_783_ _299_ _254_ _713_ _714_ _468_ vdd 
+ gnd
+ OAI22X1
XFILL_0__1089_ gnd vdd FILL
X_1508_ \u_ball.x_pos\[3] _656_ vdd gnd INVX1
XFILL_0__836_ gnd vdd FILL
X_839_ _457_ _527_ _540_ vdd gnd NAND2X1
X_1261_ _334_ _333_ _332_ _331_ vdd gnd AOI21X1
X_1317_ _394_ _386_ _385_ vdd gnd OR2X2
X_1490_ _648_ _652_ _638_ vdd gnd NOR2X1
X_1070_ \u_ball.x_paddle\[6] _306_ _305_ _304_ vdd gnd AOI21X1
X_1126_ _151_ _133_ _69_ _166_ vdd gnd AOI21X1
XFILL_0__874_ gnd vdd FILL
X_877_ \u_ball.x_pos\[1] _497_ vdd gnd INVX1
X_1355_ \u_ball.x_paddle\[6] \u_ball.x_paddle\[4] \u_ball.x_paddle\[5] _421_ vdd gnd NAND3X1
X_1164_ \u_ball.x_pos\[1] _97_ vdd gnd INVX1
X_1393_ _568_ _565_ _588_ _569_ _665_ vdd 
+ gnd
+ AOI22X1
XFILL_0__1013_ gnd vdd FILL
X_1449_ _605_ _648_ _604_ vdd gnd AND2X2
X_1029_ _284_ _264_ \u_ball.x_ball\[5] _263_ vdd gnd OAI21X1
X_1258_ _336_ _329_ _352_ pixel_paddle vdd gnd NOR3X1
XFILL_0__1051_ gnd vdd FILL
X_801_ _698_ _700_ _697_ _701_ vdd gnd NAND3X1
X_1487_ \u_ctrl.State\[0] \u_ctrl.State\[2] _635_ vdd gnd NOR2X1
X_1067_ _450_ _301_ vdd gnd INVX1
X_1296_ _410_ \u_ball.x_pos\[1] _367_ _366_ vdd gnd OAI21X1
XFILL_0__1145_ gnd vdd FILL
XFILL_0__1183_ gnd vdd FILL
X_933_ _60_ _59_ vdd gnd INVX1
X_1199_ _145_ _141_ _132_ _176_ vdd gnd AOI21X1
X_1411_ _657_ \u_ctrl.State\[0] \u_ball.x_pos\[2] _578_ vdd gnd AOI21X1
X_742_ _469__bF$buf2 vdd _481_ clk_bF$buf5 \u_ball.sign_x\ vdd 
+ gnd
+ DFFSR
XFILL_0__1048_ gnd vdd FILL
X_1220_ \u_ball.x_ball\[6] _149_ _147_ vdd gnd NAND2X1
X_971_ _209_ _208_ _207_ vdd gnd NAND2X1
X_780_ _443_ _254_ _719_ _467_ vdd gnd OAI21X1
XFILL_0__1086_ gnd vdd FILL
X_1505_ _656_ _655_ _654_ _653_ vdd gnd NOR3X1
XFILL_0__833_ gnd vdd FILL
X_836_ _542_ _539_ _543_ vdd gnd AND2X2
X_1314_ _383_ _384_ _437_ vdd gnd NAND2X1
X_1123_ vdd _173_ _178_ clk_bF$buf7 \u_bricks.regBricks\[7] vdd 
+ gnd
+ DFFSR
XFILL_0__871_ gnd vdd FILL
X_874_ _498_ _499_ _500_ vdd gnd AND2X2
X_1352_ \u_ball.x_paddle\[5] _418_ vdd gnd INVX1
X_1408_ \u_ctrl.State_3_bF$buf0\ _595_ _656_ _576_ vdd gnd OAI21X1
X_739_ _469__bF$buf2 vdd _466_ clk_bF$buf5 \u_ball.x_ball\[3] vdd 
+ gnd
+ DFFSR
X_1161_ \u_ball.y_pos\[2] \u_ball.y_pos\[0] _94_ vdd gnd NOR2X1
X_1217_ _145_ _144_ vdd gnd INVX1
X_968_ _460_ _291_ _204_ vdd gnd NAND2X1
X_1390_ _588_ _564_ _563_ _664_ vdd gnd OAI21X1
XFILL_0__1010_ gnd vdd FILL
X_1446_ _638_ _641_ _725_ _602_ vdd gnd AOI21X1
X_1026_ _264_ _284_ _260_ vdd gnd OR2X2
X_777_ _460_ _443_ _721_ _726_ vdd gnd OAI21X1
X_1255_ _380_ btn_left _328_ _327_ vdd gnd OAI21X1
X_1484_ game_new \u_ctrl.State\[0] _633_ vdd gnd NAND2X1
X_1064_ _299_ _448_ _317_ _298_ vdd gnd OAI21X1
XFILL_0__868_ gnd vdd FILL
X_1293_ _368_ _364_ _363_ vdd gnd NAND2X1
X_1349_ btn_left _416_ _415_ vdd gnd NOR2X1
XFILL_0__1142_ gnd vdd FILL
X_1158_ \u_ball.y_pos\[1] _94_ _92_ _91_ vdd gnd OAI21X1
X_1387_ _673__bF$buf0 vdd _512_ clk_bF$buf2 \u_ctrl.State\[4] vdd 
+ gnd
+ DFFSR
XFILL_0__1007_ gnd vdd FILL
XFILL_0__1180_ gnd vdd FILL
X_930_ _61_ _57_ _56_ vdd gnd AND2X2
X_1196_ \u_ball.x_pos\[4] _129_ vdd gnd INVX2
XBUFX2_insert12 _469_ _469__bF$buf3 vdd gnd BUFX2
XBUFX2_insert13 _469_ _469__bF$buf2 vdd gnd BUFX2
XBUFX2_insert14 _469_ _469__bF$buf1 vdd gnd BUFX2
XBUFX2_insert15 _469_ _469__bF$buf0 vdd gnd BUFX2
XBUFX2_insert16 \u_ctrl.State\[3] \u_ctrl.State_3_bF$buf3\ vdd gnd BUFX2
XBUFX2_insert17 \u_ctrl.State\[3] \u_ctrl.State_3_bF$buf2\ vdd gnd BUFX2
XBUFX2_insert18 \u_ctrl.State\[3] \u_ctrl.State_3_bF$buf1\ vdd gnd BUFX2
XBUFX2_insert19 \u_ctrl.State\[3] \u_ctrl.State_3_bF$buf0\ vdd gnd BUFX2
XFILL_0__1045_ gnd vdd FILL
XFILL_0__1083_ gnd vdd FILL
X_1502_ \u_ball.y_pos\[0] \u_ball.y_pos\[1] \u_ball.y_pos\[2] _650_ vdd gnd NAND3X1
XFILL_0__830_ gnd vdd FILL
X_833_ _306_ _251_ _545_ _546_ vdd gnd OAI21X1
X_1099_ _454_ _451_ _457_ _450_ vdd gnd AOI21X1
XFILL_0__1139_ gnd vdd FILL
X_1311_ _382_ _381_ _436_ vdd gnd NAND2X1
X_1120_ vdd _173_ _171_ clk_bF$buf0 \u_bricks.regBricks\[9] vdd 
+ gnd
+ DFFSR
X_871_ _501_ _502_ _503_ vdd gnd AND2X2
XFILL_0__1177_ gnd vdd FILL
XFILL_0__924_ gnd vdd FILL
X_927_ \u_ball.y_ball\[4] _54_ vdd gnd INVX2
X_1405_ _656_ _654_ _655_ _574_ vdd gnd OAI21X1
X_736_ _469__bF$buf3 vdd _676_ clk_bF$buf7 hit_brick vdd 
+ gnd
+ DFFSR
X_1214_ \u_ball.x_ball\[5] _142_ _141_ vdd gnd NOR2X1
X_965_ _218_ _202_ _201_ vdd gnd NOR2X1
XFILL73650x72150 gnd vdd FILL
X_1443_ _651_ _650_ _607_ _600_ vdd gnd OAI21X1
X_1023_ _306_ _280_ _258_ _261_ _257_ vdd 
+ gnd
+ OAI22X1
X_774_ _255_ _2_ _720_ _466_ vdd gnd OAI21X1
X_1252_ _419_ _325_ _326_ _324_ vdd gnd NAND3X1
X_1308_ _379_ _378_ vdd gnd INVX1
XFILL74250x10950 gnd vdd FILL
X_1481_ \u_ctrl.State\[4] _633_ _631_ _687_ vdd gnd AOI21X1
X_1061_ _453_ _456_ _295_ vdd gnd NOR2X1
X_1117_ vdd _173_ _184_ clk_bF$buf7 \u_bricks.regBricks\[1] vdd 
+ gnd
+ DFFSR
XFILL_0__865_ gnd vdd FILL
X_868_ _25_ _472_ _495_ _506_ vdd gnd OAI21X1
X_1290_ \u_ball.x_pos\[0] _362_ _361_ _360_ vdd gnd OAI21X1
X_1346_ btn_left _413_ _412_ vdd gnd NOR2X1
X_1155_ _89_ _115_ pixel_brick vdd gnd AND2X2
X_1384_ vdd _673__bF$buf3 _671_ clk_bF$buf3 \u_ball.x_pos\[0] vdd 
+ gnd
+ DFFSR
XFILL_0__1004_ gnd vdd FILL
X_1193_ _130_ _129_ _126_ vdd gnd NAND2X1
X_1249_ _419_ _405_ _323_ _322_ vdd gnd NAND3X1
XFILL_0__1042_ gnd vdd FILL
X_1478_ _652_ \u_ctrl.State_3_bF$buf1\ _629_ _628_ vdd gnd AOI21X1
X_1058_ _449_ _300_ _293_ _292_ vdd gnd OAI21X1
XFILL_0__1518_ gnd vdd FILL
X_1287_ \u_ball.x_pos\[0] _357_ vdd gnd INVX1
XFILL_0__1080_ gnd vdd FILL
X_830_ _547_ _543_ _548_ _549_ vdd gnd OAI21X1
X_1096_ \u_ball.x_paddle\[2] _447_ vdd gnd INVX1
XFILL_0__1174_ gnd vdd FILL
XFILL_0__921_ gnd vdd FILL
X_924_ _53_ _52_ _51_ vdd gnd NOR2X1
X_1402_ \u_ctrl.State_3_bF$buf3\ _653_ _572_ vdd gnd NAND2X1
X_733_ vdd _469__bF$buf0 _476_ clk_bF$buf4 \u_ball.y_ball\[2] vdd 
+ gnd
+ DFFSR
XFILL_0__1039_ gnd vdd FILL
X_1211_ \u_ball.x_ball\[5] _143_ _139_ vdd gnd NAND2X1
X_962_ _200_ _199_ _198_ vdd gnd NOR2X1
XFILL_0__1268_ gnd vdd FILL
X_1440_ _628_ _598_ _597_ vdd gnd NAND2X1
X_1020_ _255_ _254_ vdd gnd INVX4
X_771_ _291_ _4_ _460_ _5_ vdd gnd OAI21X1
XFILL_0__1077_ gnd vdd FILL
X_827_ _490_ _482_ _39_ _552_ vdd gnd AOI21X1
X_1305_ \u_ball.x_paddle\[2] _376_ _375_ vdd gnd NAND2X1
X_1114_ vdd _173_ _168_ clk_bF$buf6 \u_bricks.regBricks\[10] vdd 
+ gnd
+ DFFSR
XFILL_0__862_ gnd vdd FILL
X_865_ _504_ _491_ _508_ _509_ vdd gnd OAI21X1
XFILL_0__918_ gnd vdd FILL
X_1343_ \u_ball.x_paddle\[2] _428_ _409_ vdd gnd NAND2X1
X_1152_ \u_bricks.regBricks\[1] \u_bricks.regBricks\[14] _86_ vdd gnd NOR2X1
X_1208_ \u_bricks.regBricks\[2] _137_ vdd gnd INVX1
XFILL_0__956_ gnd vdd FILL
X_959_ _201_ _197_ _196_ _195_ vdd gnd AOI21X1
X_1381_ _673__bF$buf0 vdd _680_ clk_bF$buf2 _725_ vdd 
+ gnd
+ DFFSR
XFILL_0__1001_ gnd vdd FILL
X_1437_ \u_ctrl.State\[0] _595_ vdd gnd INVX1
X_1017_ \u_ball.x_ball\[5] \u_ball.x_ball\[4] _252_ _251_ vdd gnd NAND3X1
X_768_ _306_ _7_ _44_ _8_ vdd gnd OAI21X1
X_1190_ _124_ _165_ \u_ball.x_pos\[6] _123_ vdd gnd AOI21X1
XFILL_0__1230_ gnd vdd FILL
X_1246_ _434_ vdd _436_ clk_bF$buf2 \u_ball.x_paddle\[1] vdd 
+ gnd
+ DFFSR
X_997_ _232_ _233_ _283_ _231_ vdd gnd OAI21X1
X_1475_ \u_ball.y_pos\[1] _626_ vdd gnd INVX1
X_1055_ _309_ _290_ _289_ vdd gnd AND2X2
XFILL_0__1515_ gnd vdd FILL
X_1284_ _363_ _355_ _362_ _354_ vdd gnd AOI21X1
X_1093_ _449_ _456_ _445_ _444_ vdd gnd NAND3X1
X_1149_ \u_bricks.regBricks\[5] _83_ vdd gnd INVX1
XFILL_0__897_ gnd vdd FILL
XFILL74250x18150 gnd vdd FILL
X_1378_ vdd _673__bF$buf1 _668_ clk_bF$buf3 \u_ball.x_pos\[3] vdd 
+ gnd
+ DFFSR
XFILL_0__1171_ gnd vdd FILL
X_921_ _50_ _58_ _51_ _48_ vdd gnd AOI21X1
X_1187_ \u_bricks.regBricks\[11] \u_ball.x_pos\[3] _120_ vdd gnd NAND2X1
XFILL_0__1227_ gnd vdd FILL
X_730_ _722_ game_over vdd gnd BUFX2
XFILL_0__1036_ gnd vdd FILL
XFILL_0__1265_ gnd vdd FILL
XFILL_0__1074_ gnd vdd FILL
X_824_ _554_ _553_ _555_ vdd gnd NAND2X1
X_1302_ \u_ball.x_pos\[3] _372_ vdd gnd INVX1
X_1111_ vdd _173_ _179_ clk_bF$buf3 \u_bricks.regBricks\[2] vdd 
+ gnd
+ DFFSR
X_862_ _497_ \u_ball.x_ball\[1] \u_ball.x_ball\[0] _511_ _513_ vdd 
+ gnd
+ AOI22X1
XFILL_0__915_ gnd vdd FILL
X_918_ \u_ball.x_ball\[0] _46_ vdd gnd INVX1
X_1340_ _423_ _413_ _412_ _406_ vdd gnd AOI21X1
X_727_ _725_ v_sync vdd gnd BUFX2
X_1205_ \u_bricks.regBricks\[7] _135_ vdd gnd INVX1
XFILL_0__953_ gnd vdd FILL
X_956_ \u_ball.y_ball\[0] _193_ vdd gnd INVX1
X_1434_ _632_ _596_ _594_ _514_ vdd gnd OAI21X1
X_1014_ \u_ball.x_ball\[2] \u_ball.x_ball\[3] _248_ vdd gnd NOR2X1
X_765_ _192_ _175_ _10_ vdd gnd NAND2X1
X_1243_ _434_ vdd _439_ clk_bF$buf2 \u_ball.x_paddle\[6] vdd 
+ gnd
+ DFFSR
X_994_ _245_ _250_ _228_ vdd gnd NAND2X1
X_1472_ _624_ _625_ \u_ctrl.State_3_bF$buf2\ _623_ vdd gnd OAI21X1
X_1052_ _302_ _287_ _286_ vdd gnd NAND2X1
X_1108_ \u_ball.hit_paddle\ _459_ vdd gnd INVX1
X_859_ _518_ _515_ _519_ vdd gnd NAND2X1
X_1281_ \u_ball.x_pos\[5] _351_ vdd gnd INVX1
X_1337_ _418_ _428_ _403_ vdd gnd NOR2X1
X_1090_ _448_ _447_ _441_ vdd gnd NAND2X1
X_1146_ _83_ _82_ _81_ _80_ vdd gnd NAND3X1
XFILL_0__894_ gnd vdd FILL
X_897_ _193_ \u_ball.y_pos\[0] _35_ _26_ vdd gnd OAI21X1
XFILL74250x72150 gnd vdd FILL
X_1375_ _673__bF$buf1 vdd _688_ clk_bF$buf6 _723_ vdd 
+ gnd
+ DFFSR
X_1184_ _152_ _126_ _118_ _117_ vdd gnd OAI21X1
XFILL_0__1224_ gnd vdd FILL
XFILL_0__1033_ gnd vdd FILL
X_1469_ \u_ball.y_pos\[2] _621_ vdd gnd INVX1
X_1049_ \u_ball.x_paddle\[6] _284_ _283_ vdd gnd NAND2X1
XFILL_0__1262_ gnd vdd FILL
X_1278_ \u_ball.x_paddle\[6] _349_ _348_ vdd gnd NOR2X1
XFILL_0__1071_ gnd vdd FILL
X_821_ _518_ _557_ _536_ _558_ vdd gnd NAND3X1
X_1087_ \u_ball.x_paddle\[1] \u_ball.x_paddle\[2] _321_ vdd gnd NOR2X1
XFILL_0__912_ gnd vdd FILL
X_915_ \u_ball.x2\ _222_ _44_ _43_ vdd gnd OAI21X1
X_1202_ _158_ _150_ _133_ vdd gnd NOR2X1
XFILL_0__950_ gnd vdd FILL
X_953_ \u_ball.y_ball\[1] \u_ball.sign_y\ _191_ vdd gnd NAND2X1
XFILL_0__1259_ gnd vdd FILL
X_1431_ \u_ctrl.State\[1] _659_ _591_ vdd gnd NAND2X1
X_1011_ game_init \u_ball.hit_paddle\ _245_ vdd gnd NOR2X1
X_762_ \u_ball.y_ball\[0] _10_ _12_ _13_ vdd gnd OAI21X1
XFILL_0__1068_ gnd vdd FILL
X_818_ _291_ \u_ball.x_pos\[4] _558_ _560_ _562_ vdd 
+ gnd
+ AOI22X1
X_1240_ \u_ball.x_ball\[4] _164_ vdd gnd INVX1
X_991_ _460_ _241_ _226_ _481_ vdd gnd OAI21X1
XFILL_0__1297_ gnd vdd FILL
X_1105_ \u_ball.x_paddle\[1] \u_ball.x_paddle\[2] \u_ball.x_paddle\[3] _456_ vdd gnd NAND3X1
X_856_ _515_ _518_ _521_ _522_ vdd gnd NAND3X1
XFILL_0__909_ gnd vdd FILL
X_1334_ _417_ _404_ _401_ _400_ vdd gnd OAI21X1
XFILL73650x32550 gnd vdd FILL
X_1143_ _132_ _79_ _78_ _77_ vdd gnd NAND3X1
X_894_ \u_ball.y_ball\[1] _36_ _37_ _471_ vdd gnd OAI21X1
XFILL_0__947_ gnd vdd FILL
X_1372_ _673__bF$buf2 vdd _665_ clk_bF$buf6 \u_ctrl.cnt_v_sync\[1] vdd 
+ gnd
+ DFFSR
X_1428_ \u_ctrl.State\[1] \u_ctrl.State\[2] _593_ _590_ vdd gnd OAI21X1
X_1008_ _243_ _242_ vdd gnd INVX1
X_759_ _58_ _52_ _50_ _15_ vdd gnd NAND3X1
X_1181_ \u_bricks.regBricks\[6] _130_ _114_ vdd gnd NAND2X1
XFILL_0__1221_ gnd vdd FILL
X_1237_ \u_ball.x_ball\[6] _161_ vdd gnd INVX1
XFILL_0__985_ gnd vdd FILL
X_988_ _224_ _223_ vdd gnd INVX1
XFILL_0__1030_ gnd vdd FILL
X_1466_ _620_ _619_ \u_ctrl.State_3_bF$buf2\ _618_ vdd gnd OAI21X1
X_1046_ _452_ _281_ _282_ _280_ vdd gnd OAI21X1
X_797_ _704_ _694_ _705_ vdd gnd AND2X2
X_1275_ _416_ _350_ _346_ _345_ vdd gnd AOI21X1
X_1084_ gnd _318_ vdd gnd INVX1
XFILL74250x25350 gnd vdd FILL
X_1369_ _673__bF$buf2 vdd _517_ clk_bF$buf6 \u_ctrl.State\[1] vdd 
+ gnd
+ DFFSR
X_912_ _42_ _41_ vdd gnd INVX1
X_1178_ \u_ball.x_pos\[6] _111_ vdd gnd INVX1
XFILL_0__1218_ gnd vdd FILL
XFILL74250x7350 gnd vdd FILL
XFILL_0__1027_ gnd vdd FILL
X_950_ _189_ _190_ _188_ vdd gnd NOR2X1
XFILL_0__1256_ gnd vdd FILL
XFILL_0__1065_ gnd vdd FILL
X_815_ \u_ball.y_pos\[4] _677_ vdd gnd INVX1
XFILL_0__1294_ gnd vdd FILL
X_1522_ _434_ vdd _432_ clk_bF$buf1 \u_ball.x_paddle\[3] vdd 
+ gnd
+ DFFSR
X_1102_ \u_ball.x_paddle\[4] _453_ vdd gnd INVX2
X_853_ _509_ _524_ _525_ vdd gnd AND2X2
XFILL_0__906_ gnd vdd FILL
X_909_ _39_ _38_ vdd gnd INVX1
X_1331_ _417_ _397_ vdd gnd INVX1
X_1140_ reset _173_ vdd gnd INVX4
X_891_ _25_ _483_ vdd gnd INVX1
XFILL_0__944_ gnd vdd FILL
X_947_ _192_ _254_ _186_ _477_ vdd gnd OAI21X1
X_1425_ _662_ _644_ _629_ _589_ vdd gnd OAI21X1
X_1005_ _450_ _307_ _302_ _239_ vdd gnd OAI21X1
X_756_ \u_ball.y_ball\[5] _16_ _17_ _463_ vdd gnd AOI21X1
X_1234_ _162_ _159_ _165_ _184_ vdd gnd AOI21X1
XFILL_0__982_ gnd vdd FILL
X_985_ \u_ball.hit_paddle\ _221_ _220_ vdd gnd NAND2X1
X_1463_ \u_ball.x_pos\[6] _616_ vdd gnd INVX1
X_1043_ \u_ball.x_ball\[3] _278_ _277_ vdd gnd NAND2X1
X_794_ hit_brick _707_ vdd gnd INVX1
X_1519_ _716_ _717_ _718_ _724_ vdd gnd NAND3X1
X_1272_ _418_ \u_ball.x_pos\[5] _348_ _342_ vdd gnd OAI21X1
X_1328_ _416_ _423_ _396_ _414_ _394_ vdd 
+ gnd
+ AOI22X1
X_1081_ _444_ _440_ _316_ _315_ vdd gnd NAND3X1
X_1137_ _74_ _159_ _75_ _172_ vdd gnd AOI21X1
X_888_ \u_ball.y_ball\[0] _32_ _486_ vdd gnd NAND2X1
XFILL74250x46950 gnd vdd FILL
X_1366_ _469__bF$buf1 vdd _480_ clk_bF$buf5 \u_ball.x2\ vdd 
+ gnd
+ DFFSR
XFILL73950x61350 gnd vdd FILL
XFILL73950x28950 gnd vdd FILL
X_1175_ \u_bricks.regBricks\[5] \u_ball.x_pos\[3] _109_ _108_ vdd gnd NAND3X1
XFILL_0__1215_ gnd vdd FILL
XFILL_0__979_ gnd vdd FILL
XFILL_0__1253_ gnd vdd FILL
X_1269_ _344_ _343_ _340_ _339_ vdd gnd AOI21X1
XFILL_0__1062_ gnd vdd FILL
X_812_ _689_ _690_ vdd gnd INVX1
X_1498_ _722_ _0_ _646_ vdd gnd NOR2X1
X_1078_ _446_ _442_ _453_ _312_ vdd gnd OAI21X1
XFILL_0__1291_ gnd vdd FILL
X_850_ \u_ball.x_ball\[0] \u_ball.x_ball\[1] \u_ball.x_ball\[2] _529_ vdd gnd NOR3X1
XFILL_0__903_ gnd vdd FILL
X_906_ \u_ball.y_ball\[1] _36_ _35_ vdd gnd NAND2X1
XFILL_0__941_ gnd vdd FILL
X_944_ \u_ball.sign_y\ _174_ vdd gnd INVX1
X_1422_ _661_ _587_ _591_ _586_ vdd gnd OAI21X1
X_1002_ _270_ _266_ _236_ vdd gnd NAND2X1
X_753_ _10_ _19_ _707_ _20_ vdd gnd OAI21X1
XFILL_0__1059_ gnd vdd FILL
X_809_ \u_ball.y_pos\[4] _54_ _62_ \u_ball.y_pos\[3] _693_ vdd 
+ gnd
+ OAI22X1
X_1231_ \u_ball.x_ball\[4] _157_ _156_ vdd gnd NAND2X1
X_982_ _219_ _218_ vdd gnd INVX1
XFILL_0__1288_ gnd vdd FILL
X_1460_ _615_ _614_ _616_ _613_ vdd gnd OAI21X1
X_1040_ \u_ball.x_ball\[1] \u_ball.x_paddle\[1] _274_ vdd gnd NOR2X1
X_791_ _509_ _524_ _549_ _249_ _710_ vdd 
+ gnd
+ AOI22X1
XFILL_0__1097_ gnd vdd FILL
X_1516_ pixel_ball _716_ vdd gnd INVX1
X_847_ \u_ball.x_pos\[3] _532_ vdd gnd INVX1
X_1325_ _399_ _392_ _439_ vdd gnd NAND2X1
X_1134_ _163_ _158_ _72_ vdd gnd OR2X2
X_885_ \u_ball.y_ball\[0] _32_ _488_ _489_ vdd gnd OAI21X1
XFILL_0__938_ gnd vdd FILL
X_1363_ btn_right _429_ vdd gnd INVX1
X_1419_ _588_ _585_ _584_ _672_ vdd gnd OAI21X1
X_1172_ \u_bricks.regBricks\[14] _130_ _105_ vdd gnd NAND2X1
XFILL_0__1212_ gnd vdd FILL
X_1228_ _154_ _155_ \u_bricks.regBricks\[14] _153_ vdd gnd OAI21X1
XFILL_0__976_ gnd vdd FILL
X_979_ \u_ball.x2\ _460_ _299_ _215_ vdd gnd OAI21X1
XFILL74250x150 gnd vdd FILL
X_1457_ \u_ball.y_pos\[3] _620_ _611_ vdd gnd NOR2X1
X_1037_ \u_ball.x_ball\[2] _276_ _272_ _271_ vdd gnd OAI21X1
X_788_ pixel_paddle _709_ _710_ _712_ vdd gnd NAND3X1
XFILL_0__1250_ gnd vdd FILL
X_1266_ _345_ _339_ _337_ _336_ vdd gnd OAI21X1
XFILL74250x32550 gnd vdd FILL
X_1495_ \u_ctrl.State_3_bF$buf0\ \u_ctrl.State\[0] _643_ vdd gnd NOR2X1
X_1075_ _457_ _451_ _454_ _309_ vdd gnd NAND3X1
XFILL_0__900_ gnd vdd FILL
X_903_ \u_ball.y_pos\[0] _32_ vdd gnd INVX1
X_1169_ \u_bricks.regBricks\[13] \u_ball.x_pos\[3] _129_ _102_ vdd gnd NAND3X1
XFILL_0__1209_ gnd vdd FILL
X_1398_ \u_ctrl.cnt_v_sync\[1] _569_ vdd gnd INVX1
X_941_ _67_ _68_ _66_ vdd gnd NOR2X1
X_750_ _203_ _4_ _22_ vdd gnd NAND2X1
X_806_ _695_ _696_ vdd gnd INVX1
XFILL_0_BUFX2_insert1 gnd vdd FILL
XFILL_0__1285_ gnd vdd FILL
XFILL_0__1094_ gnd vdd FILL
X_1513_ \u_ctrl.cnt_v_sync\[0] \u_ctrl.cnt_v_sync\[1] _661_ vdd gnd NOR2X1
X_844_ _534_ _533_ _532_ _535_ vdd gnd AOI21X1
X_1322_ _391_ _396_ _389_ vdd gnd NAND2X1
X_1131_ _72_ _70_ vdd gnd INVX1
X_882_ _37_ _33_ _492_ vdd gnd NAND2X1
XFILL_0__935_ gnd vdd FILL
X_938_ _222_ \u_ball.y_ball\[2] game_init _63_ vdd gnd AOI21X1
X_1360_ \u_ball.x_paddle\[5] \u_ball.x_paddle\[1] _426_ vdd gnd NOR2X1
XFILL73350x72150 gnd vdd FILL
X_1416_ _583_ _643_ _582_ _671_ vdd gnd AOI21X1
X_747_ _291_ _254_ _24_ _23_ _461_ vdd 
+ gnd
+ OAI22X1
X_1225_ _154_ _151_ vdd gnd INVX2
XFILL_0__973_ gnd vdd FILL
X_976_ \u_ball.sign_x\ _443_ _212_ vdd gnd NAND2X1
X_1454_ _651_ _628_ _609_ _682_ vdd gnd OAI21X1
X_1034_ _446_ _321_ _453_ _268_ vdd gnd OAI21X1
X_785_ _215_ _217_ _45_ _713_ vdd gnd AOI21X1
X_1263_ \u_ball.x_pos\[4] _416_ _333_ vdd gnd NAND2X1
X_1319_ _397_ _403_ _394_ _387_ vdd gnd OAI21X1
X_1492_ _662_ _646_ _641_ _640_ vdd gnd OAI21X1
X_1072_ \u_ball.x_ball\[6] _306_ vdd gnd INVX4
X_1128_ _149_ _159_ _82_ _167_ vdd gnd AOI21X1
X_879_ _492_ _487_ _495_ vdd gnd AND2X2
X_1357_ _428_ _424_ _423_ vdd gnd NAND2X1
X_900_ \u_ball.y_pos\[2] _175_ _29_ vdd gnd NAND2X1
X_1166_ \u_ball.y_pos\[3] \u_ball.y_pos\[5] _99_ vdd gnd OR2X2
XFILL_0__1206_ gnd vdd FILL
XCLKBUF1_insert4 clk clk_bF$buf7 vdd gnd CLKBUF1
XCLKBUF1_insert5 clk clk_bF$buf6 vdd gnd CLKBUF1
XCLKBUF1_insert6 clk clk_bF$buf5 vdd gnd CLKBUF1
XCLKBUF1_insert7 clk clk_bF$buf4 vdd gnd CLKBUF1
XCLKBUF1_insert8 clk clk_bF$buf3 vdd gnd CLKBUF1
XCLKBUF1_insert9 clk clk_bF$buf2 vdd gnd CLKBUF1
X_1395_ _567_ _569_ _566_ vdd gnd NOR2X1
X_803_ \u_ball.y_ball\[5] _678_ _699_ vdd gnd NOR2X1
X_1489_ _638_ \u_ctrl.State_3_bF$buf3\ _658_ _637_ vdd gnd AOI21X1
X_1069_ _450_ _307_ _304_ _303_ vdd gnd OAI21X1
XFILL_0__1109_ gnd vdd FILL
XFILL_0__1282_ gnd vdd FILL
X_1298_ _378_ _373_ _369_ _368_ vdd gnd OAI21X1
XFILL_0__1091_ gnd vdd FILL
X_1510_ _662_ _659_ _658_ vdd gnd NOR2X1
X_841_ _536_ _518_ _537_ _538_ vdd gnd AOI21X1
XFILL_0__932_ gnd vdd FILL
X_935_ _68_ _65_ _61_ vdd gnd NOR2X1
X_1413_ \u_ball.x_pos\[1] _581_ _580_ _670_ vdd gnd OAI21X1
X_744_ vdd _469__bF$buf0 _474_ clk_bF$buf4 \u_ball.y_ball\[4] vdd 
+ gnd
+ DFFSR
X_1222_ _151_ _149_ _152_ _182_ vdd gnd AOI21X1
XFILL_0__970_ gnd vdd FILL
X_973_ \u_ball.sign_x\ _449_ _209_ vdd gnd NAND2X1
XFILL_0__1279_ gnd vdd FILL
X_1451_ _649_ _606_ vdd gnd INVX1
X_1031_ _453_ _285_ _452_ _265_ vdd gnd OAI21X1
X_782_ _213_ _210_ _196_ _715_ vdd gnd AOI21X1
X_1507_ \u_ball.x_pos\[4] _655_ vdd gnd INVX1
X_838_ _251_ _540_ _541_ vdd gnd NAND2X1
X_1260_ \u_ball.y_pos\[4] \u_ball.y_pos\[3] _330_ vdd gnd AND2X2
XFILL_0__1300_ gnd vdd FILL
X_1316_ _419_ _387_ _385_ _384_ vdd gnd NAND3X1
X_1125_ vdd _173_ _183_ clk_bF$buf7 \u_bricks.regBricks\[14] vdd 
+ gnd
+ DFFSR
X_876_ \u_ball.x_ball\[1] _497_ _498_ vdd gnd NAND2X1
XFILL_0__929_ gnd vdd FILL
X_1354_ _429_ _421_ _422_ _420_ vdd gnd AOI21X1
X_1163_ \u_ball.x_pos\[2] \u_ball.x_pos\[0] _96_ vdd gnd NOR2X1
XFILL_0__1203_ gnd vdd FILL
X_1219_ \u_ball.x_ball\[5] _150_ _161_ _146_ vdd gnd OAI21X1
XFILL_0__967_ gnd vdd FILL
X_1392_ _567_ \u_ctrl.State\[1] \u_ctrl.State_3_bF$buf1\ _564_ vdd gnd AOI21X1
X_1448_ _657_ _604_ _628_ _603_ vdd gnd OAI21X1
X_1028_ _291_ _267_ _263_ _262_ vdd gnd OAI21X1
X_779_ \u_ball.x_ball\[3] _255_ _720_ vdd gnd NAND2X1

.ends
.end
