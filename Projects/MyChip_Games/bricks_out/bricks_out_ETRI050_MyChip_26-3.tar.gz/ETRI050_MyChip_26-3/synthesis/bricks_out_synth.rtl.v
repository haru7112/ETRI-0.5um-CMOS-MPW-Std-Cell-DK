/* Verilog module written by vlog2Verilog (qflow) */
/* With explicit power connections */

module bricks_out(
    inout vdd,
    inout gnd,
    input clk,
    input reset,
    output v_sync,
    output pixel,
    output p_tick,
    input btn_left,
    input btn_right,
    output game_over,
    output game_complete,
    input game_new
);

wire _588_ ;
wire _168_ ;
wire _60_ ;
wire _397_ ;
wire \u_ball.sign_x  ;
wire _703_ ;
wire _19_ ;
wire _512_ ;
wire _321_ ;
wire _57_ ;
wire _550_ ;
wire _130_ ;
wire _606_ ;
wire _415_ ;
wire _95_ ;
wire _644_ ;
wire _224_ ;
wire pixel_brick ;
wire _453_ ;
wire _509_ ;
wire _682_ ;
wire _262_ ;
wire _318_ ;
wire _491_ ;
wire _547_ ;
wire _127_ ;
wire _356_ ;
wire btn_right ;
wire _585_ ;
wire _165_ ;
wire _394_ ;
wire _679_ ;
wire _259_ ;
wire _488_ ;
wire _700_ ;
wire _297_ ;
wire _16_ ;
wire _54_ ;
wire _603_ ;
wire _412_ ;
wire _92_ ;
wire _641_ ;
wire _221_ ;
wire _450_ ;
wire _506_ ;
wire _315_ ;
wire _544_ ;
wire _124_ ;
wire _353_ ;
wire _409_ ;
wire _89_ ;
wire _582_ ;
wire _162_ ;
wire _638_ ;
wire _218_ ;
wire _391_ ;
wire _447_ ;
wire _676_ ;
wire _256_ ;
wire _485_ ;
wire _294_ ;
wire _13_ ;
wire _579_ ;
wire _159_ ;
wire _51_ ;
wire _388_ ;
wire _600_ ;
wire _197_ ;
wire _7_ ;
wire _503_ ;
wire _312_ ;
wire _48_ ;
wire _541_ ;
wire _121_ ;
wire _350_ ;
wire _406_ ;
wire _86_ ;
wire _635_ ;
wire _215_ ;
wire _444_ ;
wire _673_ ;
wire _253_ ;
wire _309_ ;
wire _482_ ;
wire _538_ ;
wire _118_ ;
wire _291_ ;
wire _10_ ;
wire _347_ ;
wire _576_ ;
wire _156_ ;
wire _385_ ;
wire pixel ;
wire _194_ ;
wire _479_ ;
wire _288_ ;
wire _4_ ;
wire _500_ ;
wire hit_brick ;
wire _45_ ;
wire _403_ ;
wire _83_ ;
wire _632_ ;
wire _212_ ;
wire _441_ ;
wire _670_ ;
wire _250_ ;
wire _726_ ;
wire _306_ ;
wire _535_ ;
wire _115_ ;
wire _344_ ;
wire _573_ ;
wire _153_ ;
wire _629_ ;
wire _209_ ;
wire _382_ ;
wire _438_ ;
wire _191_ ;
wire _667_ ;
wire _247_ ;
wire _476_ ;
wire clk_bF$buf0 ;
wire clk_bF$buf1 ;
wire clk_bF$buf2 ;
wire clk_bF$buf3 ;
wire clk_bF$buf4 ;
wire clk_bF$buf5 ;
wire clk_bF$buf6 ;
wire clk_bF$buf7 ;
wire _285_ ;
wire _1_ ;
wire _42_ ;
wire _379_ ;
wire _188_ ;
wire _400_ ;
wire _80_ ;
wire _723_ ;
wire _303_ ;
wire [6:0] \u_ball.x_ball  ;
wire _39_ ;
wire _532_ ;
wire _112_ ;
wire _341_ ;
wire clk ;
wire _77_ ;
wire _570_ ;
wire _150_ ;
wire _626_ ;
wire _206_ ;
wire _435_ ;
wire _664_ ;
wire _244_ ;
wire _473_ ;
wire _529_ ;
wire _109_ ;
wire _282_ ;
wire _338_ ;
wire _567_ ;
wire _147_ ;
wire _376_ ;
wire _185_ ;
wire _699_ ;
wire _279_ ;
wire _720_ ;
wire _300_ ;
wire _36_ ;
wire _74_ ;
wire _623_ ;
wire _203_ ;
wire _432_ ;
wire pixel_paddle ;
wire _661_ ;
wire _241_ ;
wire _717_ ;
wire _470_ ;
wire _526_ ;
wire _106_ ;
wire _335_ ;
wire _564_ ;
wire _144_ ;
wire [2:0] \u_ctrl.cnt_v_sync  ;
wire _373_ ;
wire _429_ ;
wire _182_ ;
wire _658_ ;
wire _238_ ;
wire _467_ ;
wire _696_ ;
wire _276_ ;
wire _33_ ;
wire \u_ball.hit_paddle  ;
wire _599_ ;
wire _179_ ;
wire _71_ ;
wire _620_ ;
wire _200_ ;
wire _714_ ;
wire _523_ ;
wire _103_ ;
wire \u_ctrl.State_3_bF$buf3  ;
wire _332_ ;
wire _68_ ;
wire _561_ ;
wire _141_ ;
wire _617_ ;
wire _370_ ;
wire _426_ ;
wire _655_ ;
wire _235_ ;
wire _464_ ;
wire _693_ ;
wire _273_ ;
wire _329_ ;
wire _558_ ;
wire _138_ ;
wire _30_ ;
wire _367_ ;
wire _596_ ;
wire _176_ ;
wire _499_ ;
wire _711_ ;
wire _27_ ;
wire _520_ ;
wire _100_ ;
wire \u_ctrl.State_3_bF$buf0  ;
wire _65_ ;
wire _614_ ;
wire _423_ ;
wire _652_ ;
wire _232_ ;
wire _708_ ;
wire _461_ ;
wire _517_ ;
wire _690_ ;
wire _270_ ;
wire _326_ ;
wire _555_ ;
wire _135_ ;
wire _364_ ;
wire _593_ ;
wire _173_ ;
wire _649_ ;
wire _229_ ;
wire _458_ ;
wire _687_ ;
wire _267_ ;
wire _496_ ;
wire _24_ ;
wire _62_ ;
wire _399_ ;
wire _611_ ;
wire _420_ ;
wire _705_ ;
wire _514_ ;
wire _323_ ;
wire _59_ ;
wire _552_ ;
wire _132_ ;
wire _608_ ;
wire _361_ ;
wire _417_ ;
wire _97_ ;
wire _590_ ;
wire _170_ ;
wire _646_ ;
wire _226_ ;
wire _455_ ;
wire _684_ ;
wire _264_ ;
wire _493_ ;
wire _549_ ;
wire _129_ ;
wire _21_ ;
wire _358_ ;
wire _587_ ;
wire _167_ ;
wire _396_ ;
wire \u_ball.x2  ;
wire _702_ ;
wire _299_ ;
wire _18_ ;
wire _511_ ;
wire _320_ ;
wire _56_ ;
wire _605_ ;
wire _414_ ;
wire _94_ ;
wire _643_ ;
wire _223_ ;
wire _452_ ;
wire _508_ ;
wire _681_ ;
wire _261_ ;
wire _317_ ;
wire _490_ ;
wire _546_ ;
wire _126_ ;
wire _355_ ;
wire game_over ;
wire _584_ ;
wire _164_ ;
wire _393_ ;
wire _449_ ;
wire _678_ ;
wire _258_ ;
wire _487_ ;
wire _296_ ;
wire _15_ ;
wire _53_ ;
wire _602_ ;
wire _199_ ;
wire _411_ ;
wire _91_ ;
wire _640_ ;
wire _220_ ;
wire _9_ ;
wire _505_ ;
wire _314_ ;
wire _543_ ;
wire _123_ ;
wire _352_ ;
wire _408_ ;
wire _88_ ;
wire _581_ ;
wire _161_ ;
wire _637_ ;
wire _217_ ;
wire _390_ ;
wire _446_ ;
wire _675_ ;
wire _255_ ;
wire _484_ ;
wire _293_ ;
wire _12_ ;
wire _349_ ;
wire _578_ ;
wire _158_ ;
wire _50_ ;
wire _387_ ;
wire _196_ ;
wire _6_ ;
wire _502_ ;
wire _311_ ;
wire _47_ ;
wire _540_ ;
wire _120_ ;
wire [6:0] \u_ball.x_paddle  ;
wire _405_ ;
wire _85_ ;
wire _634_ ;
wire _214_ ;
wire _443_ ;
wire _672_ ;
wire _252_ ;
wire _308_ ;
wire _481_ ;
wire _537_ ;
wire _117_ ;
wire _290_ ;
wire _346_ ;
wire _575_ ;
wire _155_ ;
wire _384_ ;
wire _193_ ;
wire _669_ ;
wire _249_ ;
wire _478_ ;
wire _287_ ;
wire _3_ ;
wire game_complete ;
wire _44_ ;
wire _402_ ;
wire _82_ ;
wire _631_ ;
wire _211_ ;
wire _440_ ;
wire _725_ ;
wire _305_ ;
wire _534_ ;
wire _114_ ;
wire _343_ ;
wire _79_ ;
wire _572_ ;
wire _152_ ;
wire _628_ ;
wire _208_ ;
wire _381_ ;
wire [5:0] \u_ball.y_pos  ;
wire _437_ ;
wire _190_ ;
wire _666_ ;
wire _246_ ;
wire pixel_ball ;
wire _475_ ;
wire _284_ ;
wire _0_ ;
wire v_sync ;
wire _569_ ;
wire _149_ ;
wire _41_ ;
wire _378_ ;
wire _187_ ;
wire _722_ ;
wire _302_ ;
wire _38_ ;
wire _531_ ;
wire _111_ ;
wire _340_ ;
wire _76_ ;
wire _625_ ;
wire _205_ ;
wire _434_ ;
wire _663_ ;
wire _243_ ;
wire _719_ ;
wire _472_ ;
wire _528_ ;
wire _108_ ;
wire _281_ ;
wire _337_ ;
wire _566_ ;
wire _146_ ;
wire _375_ ;
wire _184_ ;
wire _469_ ;
wire _698_ ;
wire _278_ ;
wire _35_ ;
wire _73_ ;
wire _622_ ;
wire _202_ ;
wire _431_ ;
wire _660_ ;
wire _240_ ;
wire _716_ ;
wire _525_ ;
wire _105_ ;
wire _334_ ;
wire _563_ ;
wire _143_ ;
wire _619_ ;
wire _372_ ;
wire _428_ ;
wire _181_ ;
wire _657_ ;
wire _237_ ;
wire _466_ ;
wire _695_ ;
wire _275_ ;
wire _32_ ;
wire _369_ ;
wire _598_ ;
wire _178_ ;
wire _70_ ;
wire _713_ ;
wire _29_ ;
wire _522_ ;
wire _102_ ;
wire \u_ctrl.State_3_bF$buf2  ;
wire _331_ ;
wire _67_ ;
wire _560_ ;
wire _140_ ;
wire _616_ ;
wire _425_ ;
wire _654_ ;
wire _234_ ;
wire _463_ ;
wire _519_ ;
wire _692_ ;
wire _272_ ;
wire game_init ;
wire _328_ ;
wire _557_ ;
wire _137_ ;
wire [4:0] \u_ctrl.State  ;
wire _366_ ;
wire _595_ ;
wire _175_ ;
wire _689_ ;
wire _269_ ;
wire _498_ ;
wire _710_ ;
wire _26_ ;
wire _64_ ;
wire _613_ ;
wire _422_ ;
wire _651_ ;
wire _231_ ;
wire _707_ ;
wire _460_ ;
wire _516_ ;
wire [5:0] \u_ball.y_ball  ;
wire _325_ ;
wire _554_ ;
wire _134_ ;
wire _363_ ;
wire _419_ ;
wire _99_ ;
wire _592_ ;
wire _172_ ;
wire _648_ ;
wire _228_ ;
wire _457_ ;
wire _686_ ;
wire _266_ ;
wire _495_ ;
wire _23_ ;
wire _589_ ;
wire _169_ ;
wire _61_ ;
wire _398_ ;
wire _610_ ;
wire \u_ball.sign_y  ;
wire _704_ ;
wire _513_ ;
wire _673__bF$buf0 ;
wire _673__bF$buf1 ;
wire _673__bF$buf2 ;
wire _673__bF$buf3 ;
wire _322_ ;
wire _58_ ;
wire _551_ ;
wire _131_ ;
wire _607_ ;
wire _360_ ;
wire _416_ ;
wire _96_ ;
wire _645_ ;
wire _225_ ;
wire game_new ;
wire _454_ ;
wire _683_ ;
wire _263_ ;
wire _319_ ;
wire _492_ ;
wire _548_ ;
wire _128_ ;
wire _20_ ;
wire _357_ ;
wire _586_ ;
wire _166_ ;
wire _395_ ;
wire _489_ ;
wire _701_ ;
wire _298_ ;
wire _17_ ;
wire _510_ ;
wire _55_ ;
wire _604_ ;
wire _413_ ;
wire _93_ ;
wire _642_ ;
wire _222_ ;
wire _451_ ;
wire _507_ ;
wire _680_ ;
wire _260_ ;
wire _316_ ;
wire _545_ ;
wire _125_ ;
wire _354_ ;
wire _583_ ;
wire _163_ ;
wire _639_ ;
wire _219_ ;
wire _392_ ;
wire _448_ ;
wire _677_ ;
wire _257_ ;
wire _486_ ;
wire _295_ ;
wire _14_ ;
wire _52_ ;
wire _389_ ;
wire _601_ ;
wire _198_ ;
wire _410_ ;
wire _90_ ;
wire _8_ ;
wire _504_ ;
wire _313_ ;
wire _49_ ;
wire _542_ ;
wire _122_ ;
wire _351_ ;
wire _407_ ;
wire _87_ ;
wire _580_ ;
wire _160_ ;
wire _636_ ;
wire _216_ ;
wire _445_ ;
wire btn_left ;
wire _674_ ;
wire _254_ ;
wire _483_ ;
wire _539_ ;
wire _119_ ;
wire _292_ ;
wire _11_ ;
wire _348_ ;
wire _577_ ;
wire _157_ ;
wire _386_ ;
wire _195_ ;
wire _289_ ;
wire _5_ ;
wire _501_ ;
wire _310_ ;
wire _46_ ;
wire _404_ ;
wire _84_ ;
wire _633_ ;
wire _213_ ;
wire _442_ ;
wire _469__bF$buf0 ;
wire _469__bF$buf1 ;
wire _469__bF$buf2 ;
wire _469__bF$buf3 ;
wire _671_ ;
wire _251_ ;
wire _307_ ;
wire _480_ ;
wire _536_ ;
wire _116_ ;
wire _345_ ;
wire _574_ ;
wire _154_ ;
wire _383_ ;
wire _439_ ;
wire _192_ ;
wire _668_ ;
wire _248_ ;
wire _477_ ;
wire _286_ ;
wire _2_ ;
wire _43_ ;
wire _189_ ;
wire _401_ ;
wire _81_ ;
wire _630_ ;
wire _210_ ;
wire _724_ ;
wire _304_ ;
wire _533_ ;
wire _113_ ;
wire _342_ ;
wire _78_ ;
wire _571_ ;
wire _151_ ;
wire [6:0] \u_ball.x_pos  ;
wire _627_ ;
wire _207_ ;
wire _380_ ;
wire _436_ ;
wire _665_ ;
wire _245_ ;
wire _474_ ;
wire _283_ ;
wire _339_ ;
wire _568_ ;
wire _148_ ;
wire _40_ ;
wire _377_ ;
wire _186_ ;
wire _721_ ;
wire _301_ ;
wire _37_ ;
wire _530_ ;
wire _110_ ;
wire _75_ ;
wire _624_ ;
wire _204_ ;
wire _433_ ;
wire _662_ ;
wire _242_ ;
wire _718_ ;
wire _471_ ;
wire _527_ ;
wire _107_ ;
wire _280_ ;
wire _336_ ;
wire _565_ ;
wire _145_ ;
wire _374_ ;
wire _183_ ;
wire _659_ ;
wire _239_ ;
wire _468_ ;
wire _697_ ;
wire _277_ ;
wire _34_ ;
wire _72_ ;
wire _621_ ;
wire _201_ ;
wire _430_ ;
wire _715_ ;
wire _524_ ;
wire _104_ ;
wire _333_ ;
wire _69_ ;
wire _562_ ;
wire _142_ ;
wire _618_ ;
wire _371_ ;
wire _427_ ;
wire _180_ ;
wire _656_ ;
wire _236_ ;
wire _465_ ;
wire _694_ ;
wire _274_ ;
wire _559_ ;
wire _139_ ;
wire _31_ ;
wire _368_ ;
wire _597_ ;
wire _177_ ;
wire _712_ ;
wire _28_ ;
wire _521_ ;
wire _101_ ;
wire \u_ctrl.State_3_bF$buf1  ;
wire _330_ ;
wire _66_ ;
wire _615_ ;
wire _424_ ;
wire _653_ ;
wire _233_ ;
wire _709_ ;
wire _462_ ;
wire _518_ ;
wire _691_ ;
wire _271_ ;
wire p_tick ;
wire _327_ ;
wire _556_ ;
wire _136_ ;
wire _365_ ;
wire _594_ ;
wire _174_ ;
wire _459_ ;
wire _688_ ;
wire _268_ ;
wire _497_ ;
wire _25_ ;
wire _63_ ;
wire [15:0] \u_bricks.regBricks  ;
wire _612_ ;
wire reset ;
wire _421_ ;
wire _650_ ;
wire _230_ ;
wire _706_ ;
wire _515_ ;
wire _324_ ;
wire _553_ ;
wire _133_ ;
wire _609_ ;
wire _362_ ;
wire _418_ ;
wire _98_ ;
wire _591_ ;
wire _171_ ;
wire _647_ ;
wire _227_ ;
wire _456_ ;
wire _685_ ;
wire _265_ ;
wire _494_ ;
wire _22_ ;
wire _359_ ;

BUFX2 BUFX2_insert19 (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ctrl.State [3]),
    .Y(\u_ctrl.State_3_bF$buf0 )
);

BUFX2 BUFX2_insert18 (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ctrl.State [3]),
    .Y(\u_ctrl.State_3_bF$buf1 )
);

BUFX2 BUFX2_insert17 (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ctrl.State [3]),
    .Y(\u_ctrl.State_3_bF$buf2 )
);

BUFX2 BUFX2_insert16 (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ctrl.State [3]),
    .Y(\u_ctrl.State_3_bF$buf3 )
);

BUFX2 BUFX2_insert15 (
    .vdd(vdd),
    .gnd(gnd),
    .A(_469_),
    .Y(_469__bF$buf0)
);

BUFX2 BUFX2_insert14 (
    .vdd(vdd),
    .gnd(gnd),
    .A(_469_),
    .Y(_469__bF$buf1)
);

BUFX2 BUFX2_insert13 (
    .vdd(vdd),
    .gnd(gnd),
    .A(_469_),
    .Y(_469__bF$buf2)
);

BUFX2 BUFX2_insert12 (
    .vdd(vdd),
    .gnd(gnd),
    .A(_469_),
    .Y(_469__bF$buf3)
);

CLKBUF1 CLKBUF1_insert11 (
    .vdd(vdd),
    .gnd(gnd),
    .A(clk),
    .Y(clk_bF$buf0)
);

CLKBUF1 CLKBUF1_insert10 (
    .vdd(vdd),
    .gnd(gnd),
    .A(clk),
    .Y(clk_bF$buf1)
);

CLKBUF1 CLKBUF1_insert9 (
    .vdd(vdd),
    .gnd(gnd),
    .A(clk),
    .Y(clk_bF$buf2)
);

CLKBUF1 CLKBUF1_insert8 (
    .vdd(vdd),
    .gnd(gnd),
    .A(clk),
    .Y(clk_bF$buf3)
);

CLKBUF1 CLKBUF1_insert7 (
    .vdd(vdd),
    .gnd(gnd),
    .A(clk),
    .Y(clk_bF$buf4)
);

CLKBUF1 CLKBUF1_insert6 (
    .vdd(vdd),
    .gnd(gnd),
    .A(clk),
    .Y(clk_bF$buf5)
);

CLKBUF1 CLKBUF1_insert5 (
    .vdd(vdd),
    .gnd(gnd),
    .A(clk),
    .Y(clk_bF$buf6)
);

CLKBUF1 CLKBUF1_insert4 (
    .vdd(vdd),
    .gnd(gnd),
    .A(clk),
    .Y(clk_bF$buf7)
);

BUFX2 BUFX2_insert3 (
    .vdd(vdd),
    .gnd(gnd),
    .A(_673_),
    .Y(_673__bF$buf0)
);

BUFX2 BUFX2_insert2 (
    .vdd(vdd),
    .gnd(gnd),
    .A(_673_),
    .Y(_673__bF$buf1)
);

BUFX2 BUFX2_insert1 (
    .vdd(vdd),
    .gnd(gnd),
    .A(_673_),
    .Y(_673__bF$buf2)
);

BUFX2 BUFX2_insert0 (
    .vdd(vdd),
    .gnd(gnd),
    .A(_673_),
    .Y(_673__bF$buf3)
);

AOI22X1 _1000_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_ball [4]),
    .B(_235_),
    .C(_260_),
    .D(\u_ball.x_ball [5]),
    .Y(_234_)
);

NAND2X1 _1001_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_268_),
    .B(_281_),
    .Y(_235_)
);

NAND2X1 _1002_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_270_),
    .B(_266_),
    .Y(_236_)
);

AOI22X1 _1003_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_239_),
    .B(_305_),
    .C(_240_),
    .D(_238_),
    .Y(_237_)
);

OAI22X1 _1004_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_282_),
    .B(\u_ball.x_ball [6]),
    .C(_450_),
    .D(_307_),
    .Y(_238_)
);

OAI21X1 _1005_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_450_),
    .B(_307_),
    .C(_302_),
    .Y(_239_)
);

INVX1 _1006_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_302_),
    .Y(_240_)
);

AOI21X1 _1007_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_256_),
    .B(_458_),
    .C(_242_),
    .Y(_241_)
);

INVX1 _1008_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_243_),
    .Y(_242_)
);

AND2X2 _1009_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_244_),
    .B(_254_),
    .Y(_243_)
);

NAND3X1 _1010_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_246_),
    .B(_245_),
    .C(_249_),
    .Y(_244_)
);

NOR2X1 _1011_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(game_init),
    .B(\u_ball.hit_paddle ),
    .Y(_245_)
);

NAND3X1 _1012_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_306_),
    .B(_248_),
    .C(_247_),
    .Y(_246_)
);

NOR2X1 _1013_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_ball [5]),
    .B(\u_ball.x_ball [4]),
    .Y(_247_)
);

NOR2X1 _1014_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_ball [2]),
    .B(\u_ball.x_ball [3]),
    .Y(_248_)
);

INVX1 _1015_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_250_),
    .Y(_249_)
);

NOR2X1 _1016_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_306_),
    .B(_251_),
    .Y(_250_)
);

NAND3X1 _1017_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_ball [5]),
    .B(\u_ball.x_ball [4]),
    .C(_252_),
    .Y(_251_)
);

AOI21X1 _1018_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_253_),
    .B(_299_),
    .C(_449_),
    .Y(_252_)
);

NOR2X1 _1019_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_ball [0]),
    .B(\u_ball.x_ball [2]),
    .Y(_253_)
);

INVX4 _1020_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_255_),
    .Y(_254_)
);

NOR2X1 _1021_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(game_init),
    .B(_725_),
    .Y(_255_)
);

AOI22X1 _1022_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_257_),
    .B(_283_),
    .C(_286_),
    .D(_303_),
    .Y(_256_)
);

OAI22X1 _1023_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_306_),
    .B(_280_),
    .C(_258_),
    .D(_261_),
    .Y(_257_)
);

OAI21X1 _1024_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_ball [5]),
    .B(_260_),
    .C(_259_),
    .Y(_258_)
);

OAI21X1 _1025_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_paddle [6]),
    .B(_284_),
    .C(_306_),
    .Y(_259_)
);

OR2X2 _1026_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_264_),
    .B(_284_),
    .Y(_260_)
);

AOI21X1 _1027_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_270_),
    .B(_266_),
    .C(_262_),
    .Y(_261_)
);

OAI21X1 _1028_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_291_),
    .B(_267_),
    .C(_263_),
    .Y(_262_)
);

OAI21X1 _1029_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_284_),
    .B(_264_),
    .C(\u_ball.x_ball [5]),
    .Y(_263_)
);

INVX1 _1030_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_265_),
    .Y(_264_)
);

OAI21X1 _1031_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_453_),
    .B(_285_),
    .C(_452_),
    .Y(_265_)
);

AOI22X1 _1032_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_449_),
    .B(_269_),
    .C(_267_),
    .D(_291_),
    .Y(_266_)
);

AND2X2 _1033_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_281_),
    .B(_268_),
    .Y(_267_)
);

OAI21X1 _1034_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_446_),
    .B(_321_),
    .C(_453_),
    .Y(_268_)
);

INVX1 _1035_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_278_),
    .Y(_269_)
);

NAND3X1 _1036_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_275_),
    .B(_271_),
    .C(_277_),
    .Y(_270_)
);

OAI21X1 _1037_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_ball [2]),
    .B(_276_),
    .C(_272_),
    .Y(_271_)
);

AOI21X1 _1038_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_273_),
    .B(_319_),
    .C(_274_),
    .Y(_272_)
);

NAND2X1 _1039_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_ball [0]),
    .B(_318_),
    .Y(_273_)
);

NOR2X1 _1040_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_ball [1]),
    .B(\u_ball.x_paddle [1]),
    .Y(_274_)
);

NAND2X1 _1041_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_ball [2]),
    .B(_276_),
    .Y(_275_)
);

NOR2X1 _1042_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_321_),
    .B(_435_),
    .Y(_276_)
);

NAND2X1 _1043_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_ball [3]),
    .B(_278_),
    .Y(_277_)
);

NAND2X1 _1044_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_285_),
    .B(_279_),
    .Y(_278_)
);

NAND2X1 _1045_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_446_),
    .B(_321_),
    .Y(_279_)
);

OAI21X1 _1046_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_452_),
    .B(_281_),
    .C(_282_),
    .Y(_280_)
);

OR2X2 _1047_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_285_),
    .B(_453_),
    .Y(_281_)
);

INVX1 _1048_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_paddle [6]),
    .Y(_282_)
);

NAND2X1 _1049_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_paddle [6]),
    .B(_284_),
    .Y(_283_)
);

NOR3X1 _1050_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_453_),
    .B(_452_),
    .C(_285_),
    .Y(_284_)
);

OAI21X1 _1051_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_paddle [1]),
    .B(\u_ball.x_paddle [2]),
    .C(\u_ball.x_paddle [3]),
    .Y(_285_)
);

NAND2X1 _1052_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_302_),
    .B(_287_),
    .Y(_286_)
);

NAND3X1 _1053_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_305_),
    .B(_301_),
    .C(_288_),
    .Y(_287_)
);

OAI21X1 _1054_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_292_),
    .B(_296_),
    .C(_289_),
    .Y(_288_)
);

AND2X2 _1055_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_309_),
    .B(_290_),
    .Y(_289_)
);

NAND3X1 _1056_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_291_),
    .B(_312_),
    .C(_313_),
    .Y(_290_)
);

INVX2 _1057_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_ball [4]),
    .Y(_291_)
);

OAI21X1 _1058_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_449_),
    .B(_300_),
    .C(_293_),
    .Y(_292_)
);

OAI21X1 _1059_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_295_),
    .B(_294_),
    .C(\u_ball.x_ball [4]),
    .Y(_293_)
);

AND2X2 _1060_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_456_),
    .B(_453_),
    .Y(_294_)
);

NOR2X1 _1061_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_453_),
    .B(_456_),
    .Y(_295_)
);

AOI22X1 _1062_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_449_),
    .B(_300_),
    .C(_297_),
    .D(_320_),
    .Y(_296_)
);

NAND2X1 _1063_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_440_),
    .B(_298_),
    .Y(_297_)
);

OAI21X1 _1064_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_299_),
    .B(_448_),
    .C(_317_),
    .Y(_298_)
);

INVX2 _1065_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_ball [1]),
    .Y(_299_)
);

AND2X2 _1066_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_445_),
    .B(_456_),
    .Y(_300_)
);

INVX1 _1067_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_450_),
    .Y(_301_)
);

NOR2X1 _1068_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_paddle [6]),
    .B(_306_),
    .Y(_302_)
);

OAI21X1 _1069_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_450_),
    .B(_307_),
    .C(_304_),
    .Y(_303_)
);

AOI21X1 _1070_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_paddle [6]),
    .B(_306_),
    .C(_305_),
    .Y(_304_)
);

INVX1 _1071_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_454_),
    .Y(_305_)
);

INVX4 _1072_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_ball [6]),
    .Y(_306_)
);

AOI21X1 _1073_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_315_),
    .B(_310_),
    .C(_308_),
    .Y(_307_)
);

OAI21X1 _1074_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_ball [4]),
    .B(_311_),
    .C(_309_),
    .Y(_308_)
);

NAND3X1 _1075_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_457_),
    .B(_451_),
    .C(_454_),
    .Y(_309_)
);

AOI22X1 _1076_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_ball [3]),
    .B(_314_),
    .C(_311_),
    .D(\u_ball.x_ball [4]),
    .Y(_310_)
);

NAND2X1 _1077_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_312_),
    .B(_313_),
    .Y(_311_)
);

OAI21X1 _1078_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_446_),
    .B(_442_),
    .C(_453_),
    .Y(_312_)
);

OR2X2 _1079_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_456_),
    .B(_453_),
    .Y(_313_)
);

NAND2X1 _1080_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_456_),
    .B(_445_),
    .Y(_314_)
);

NAND3X1 _1081_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_444_),
    .B(_440_),
    .C(_316_),
    .Y(_315_)
);

NAND3X1 _1082_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_319_),
    .B(_317_),
    .C(_320_),
    .Y(_316_)
);

OAI22X1 _1083_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_ball [1]),
    .B(\u_ball.x_paddle [1]),
    .C(\u_ball.x_ball [0]),
    .D(_318_),
    .Y(_317_)
);

INVX1 _1084_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(gnd),
    .Y(_318_)
);

NAND2X1 _1085_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_ball [1]),
    .B(\u_ball.x_paddle [1]),
    .Y(_319_)
);

OAI21X1 _1086_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_321_),
    .B(_435_),
    .C(\u_ball.x_ball [2]),
    .Y(_320_)
);

NOR2X1 _1087_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_paddle [1]),
    .B(\u_ball.x_paddle [2]),
    .Y(_321_)
);

AND2X2 _1088_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_paddle [1]),
    .B(\u_ball.x_paddle [2]),
    .Y(_435_)
);

NAND3X1 _1089_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_443_),
    .B(_442_),
    .C(_441_),
    .Y(_440_)
);

NAND2X1 _1090_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_448_),
    .B(_447_),
    .Y(_441_)
);

NAND2X1 _1091_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_paddle [1]),
    .B(\u_ball.x_paddle [2]),
    .Y(_442_)
);

INVX2 _1092_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_ball [2]),
    .Y(_443_)
);

NAND3X1 _1093_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_449_),
    .B(_456_),
    .C(_445_),
    .Y(_444_)
);

OAI21X1 _1094_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_448_),
    .B(_447_),
    .C(_446_),
    .Y(_445_)
);

INVX1 _1095_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_paddle [3]),
    .Y(_446_)
);

INVX1 _1096_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_paddle [2]),
    .Y(_447_)
);

INVX1 _1097_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_paddle [1]),
    .Y(_448_)
);

INVX2 _1098_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_ball [3]),
    .Y(_449_)
);

AOI21X1 _1099_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_454_),
    .B(_451_),
    .C(_457_),
    .Y(_450_)
);

OAI21X1 _1100_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_453_),
    .B(_456_),
    .C(_452_),
    .Y(_451_)
);

INVX1 _1101_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_paddle [5]),
    .Y(_452_)
);

INVX2 _1102_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_paddle [4]),
    .Y(_453_)
);

NAND3X1 _1103_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_paddle [4]),
    .B(\u_ball.x_paddle [5]),
    .C(_455_),
    .Y(_454_)
);

INVX1 _1104_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_456_),
    .Y(_455_)
);

NAND3X1 _1105_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_paddle [1]),
    .B(\u_ball.x_paddle [2]),
    .C(\u_ball.x_paddle [3]),
    .Y(_456_)
);

INVX2 _1106_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_ball [5]),
    .Y(_457_)
);

NOR2X1 _1107_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(game_init),
    .B(_459_),
    .Y(_458_)
);

INVX1 _1108_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.hit_paddle ),
    .Y(_459_)
);

INVX2 _1109_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.sign_x ),
    .Y(_460_)
);

DFFSR _1110_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf7),
    .D(_462_),
    .Q(\u_ball.sign_y ),
    .R(_469__bF$buf3),
    .S(vdd)
);

DFFSR _1111_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf6),
    .D(_179_),
    .Q(\u_bricks.regBricks [2]),
    .R(vdd),
    .S(_173_)
);

DFFSR _1112_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf5),
    .D(_167_),
    .Q(\u_bricks.regBricks [0]),
    .R(vdd),
    .S(_173_)
);

DFFSR _1113_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf4),
    .D(_182_),
    .Q(\u_bricks.regBricks [8]),
    .R(vdd),
    .S(_173_)
);

DFFSR _1114_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf3),
    .D(_168_),
    .Q(\u_bricks.regBricks [10]),
    .R(vdd),
    .S(_173_)
);

DFFSR _1115_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf2),
    .D(_180_),
    .Q(\u_bricks.regBricks [15]),
    .R(vdd),
    .S(_173_)
);

DFFSR _1116_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf1),
    .D(_169_),
    .Q(\u_bricks.regBricks [5]),
    .R(vdd),
    .S(_173_)
);

DFFSR _1117_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf0),
    .D(_184_),
    .Q(\u_bricks.regBricks [1]),
    .R(vdd),
    .S(_173_)
);

DFFSR _1118_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf7),
    .D(_170_),
    .Q(\u_bricks.regBricks [13]),
    .R(vdd),
    .S(_173_)
);

DFFSR _1119_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf6),
    .D(_177_),
    .Q(\u_bricks.regBricks [4]),
    .R(vdd),
    .S(_173_)
);

DFFSR _1120_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf5),
    .D(_171_),
    .Q(\u_bricks.regBricks [9]),
    .R(vdd),
    .S(_173_)
);

DFFSR _1121_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf4),
    .D(_181_),
    .Q(\u_bricks.regBricks [11]),
    .R(vdd),
    .S(_173_)
);

DFFSR _1122_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf3),
    .D(_172_),
    .Q(\u_bricks.regBricks [6]),
    .R(vdd),
    .S(_173_)
);

DFFSR _1123_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf2),
    .D(_178_),
    .Q(\u_bricks.regBricks [7]),
    .R(vdd),
    .S(_173_)
);

DFFSR _1124_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf1),
    .D(_176_),
    .Q(\u_bricks.regBricks [3]),
    .R(vdd),
    .S(_173_)
);

DFFSR _1125_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf0),
    .D(_183_),
    .Q(\u_bricks.regBricks [14]),
    .R(vdd),
    .S(_173_)
);

AOI21X1 _1126_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_151_),
    .B(_133_),
    .C(_69_),
    .Y(_166_)
);

INVX1 _1127_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_bricks.regBricks [12]),
    .Y(_69_)
);

AOI21X1 _1128_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_149_),
    .B(_159_),
    .C(_82_),
    .Y(_167_)
);

AOI21X1 _1129_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_151_),
    .B(_136_),
    .C(_79_),
    .Y(_168_)
);

AOI21X1 _1130_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_70_),
    .B(_159_),
    .C(_83_),
    .Y(_169_)
);

INVX1 _1131_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_72_),
    .Y(_70_)
);

INVX1 _1132_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_71_),
    .Y(_170_)
);

OAI21X1 _1133_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_154_),
    .B(_72_),
    .C(\u_bricks.regBricks [13]),
    .Y(_71_)
);

OR2X2 _1134_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_163_),
    .B(_158_),
    .Y(_72_)
);

AOI21X1 _1135_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_151_),
    .B(_162_),
    .C(_73_),
    .Y(_171_)
);

INVX1 _1136_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_bricks.regBricks [9]),
    .Y(_73_)
);

AOI21X1 _1137_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_74_),
    .B(_159_),
    .C(_75_),
    .Y(_172_)
);

INVX1 _1138_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_155_),
    .Y(_74_)
);

INVX1 _1139_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_bricks.regBricks [6]),
    .Y(_75_)
);

INVX4 _1140_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(reset),
    .Y(_173_)
);

AND2X2 _1141_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_84_),
    .B(_76_),
    .Y(_0_)
);

NOR2X1 _1142_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_80_),
    .B(_77_),
    .Y(_76_)
);

NAND3X1 _1143_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_132_),
    .B(_79_),
    .C(_78_),
    .Y(_77_)
);

NOR2X1 _1144_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_bricks.regBricks [13]),
    .B(\u_bricks.regBricks [12]),
    .Y(_78_)
);

INVX1 _1145_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_bricks.regBricks [10]),
    .Y(_79_)
);

NAND3X1 _1146_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_83_),
    .B(_82_),
    .C(_81_),
    .Y(_80_)
);

NOR2X1 _1147_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_bricks.regBricks [9]),
    .B(\u_bricks.regBricks [6]),
    .Y(_81_)
);

INVX1 _1148_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_bricks.regBricks [0]),
    .Y(_82_)
);

INVX1 _1149_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_bricks.regBricks [5]),
    .Y(_83_)
);

NOR2X1 _1150_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_87_),
    .B(_85_),
    .Y(_84_)
);

NAND3X1 _1151_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_152_),
    .B(_148_),
    .C(_86_),
    .Y(_85_)
);

NOR2X1 _1152_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_bricks.regBricks [1]),
    .B(\u_bricks.regBricks [14]),
    .Y(_86_)
);

NAND3X1 _1153_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_135_),
    .B(_134_),
    .C(_88_),
    .Y(_87_)
);

NOR2X1 _1154_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_bricks.regBricks [15]),
    .B(\u_bricks.regBricks [2]),
    .Y(_88_)
);

AND2X2 _1155_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_89_),
    .B(_115_),
    .Y(pixel_brick)
);

AOI21X1 _1156_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_100_),
    .B(\u_ball.x_pos [5]),
    .C(_90_),
    .Y(_89_)
);

NAND3X1 _1157_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_95_),
    .B(_91_),
    .C(_98_),
    .Y(_90_)
);

OAI21X1 _1158_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.y_pos [1]),
    .B(_94_),
    .C(_92_),
    .Y(_91_)
);

NAND2X1 _1159_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.y_pos [1]),
    .B(_93_),
    .Y(_92_)
);

NAND2X1 _1160_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.y_pos [2]),
    .B(\u_ball.y_pos [0]),
    .Y(_93_)
);

NOR2X1 _1161_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.y_pos [2]),
    .B(\u_ball.y_pos [0]),
    .Y(_94_)
);

NAND2X1 _1162_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_97_),
    .B(_96_),
    .Y(_95_)
);

NOR2X1 _1163_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_pos [2]),
    .B(\u_ball.x_pos [0]),
    .Y(_96_)
);

INVX1 _1164_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_pos [1]),
    .Y(_97_)
);

NOR2X1 _1165_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.y_pos [4]),
    .B(_99_),
    .Y(_98_)
);

OR2X2 _1166_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.y_pos [3]),
    .B(\u_ball.y_pos [5]),
    .Y(_99_)
);

OAI22X1 _1167_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_101_),
    .B(_104_),
    .C(_112_),
    .D(_107_),
    .Y(_100_)
);

NAND3X1 _1168_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_pos [6]),
    .B(_102_),
    .C(_103_),
    .Y(_101_)
);

NAND3X1 _1169_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_bricks.regBricks [13]),
    .B(\u_ball.x_pos [3]),
    .C(_129_),
    .Y(_102_)
);

NAND3X1 _1170_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_bricks.regBricks [12]),
    .B(_130_),
    .C(_129_),
    .Y(_103_)
);

AOI21X1 _1171_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_105_),
    .B(_106_),
    .C(_129_),
    .Y(_104_)
);

NAND2X1 _1172_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_bricks.regBricks [14]),
    .B(_130_),
    .Y(_105_)
);

NAND2X1 _1173_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_bricks.regBricks [15]),
    .B(\u_ball.x_pos [3]),
    .Y(_106_)
);

NAND3X1 _1174_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_111_),
    .B(_110_),
    .C(_108_),
    .Y(_107_)
);

NAND3X1 _1175_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_bricks.regBricks [5]),
    .B(\u_ball.x_pos [3]),
    .C(_109_),
    .Y(_108_)
);

NAND2X1 _1176_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_pos [4]),
    .B(\u_ball.x_pos [5]),
    .Y(_109_)
);

NAND3X1 _1177_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_bricks.regBricks [4]),
    .B(_130_),
    .C(_129_),
    .Y(_110_)
);

INVX1 _1178_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_pos [6]),
    .Y(_111_)
);

AOI21X1 _1179_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_114_),
    .B(_113_),
    .C(_129_),
    .Y(_112_)
);

NAND2X1 _1180_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_bricks.regBricks [7]),
    .B(\u_ball.x_pos [3]),
    .Y(_113_)
);

NAND2X1 _1181_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_bricks.regBricks [6]),
    .B(_130_),
    .Y(_114_)
);

NAND3X1 _1182_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_131_),
    .B(_116_),
    .C(_122_),
    .Y(_115_)
);

OAI21X1 _1183_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_117_),
    .B(_119_),
    .C(\u_ball.x_pos [6]),
    .Y(_116_)
);

OAI21X1 _1184_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_152_),
    .B(_126_),
    .C(_118_),
    .Y(_117_)
);

NAND3X1 _1185_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_bricks.regBricks [9]),
    .B(\u_ball.x_pos [3]),
    .C(_129_),
    .Y(_118_)
);

AOI21X1 _1186_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_121_),
    .B(_120_),
    .C(_129_),
    .Y(_119_)
);

NAND2X1 _1187_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_bricks.regBricks [11]),
    .B(\u_ball.x_pos [3]),
    .Y(_120_)
);

NAND2X1 _1188_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_bricks.regBricks [10]),
    .B(_130_),
    .Y(_121_)
);

NAND3X1 _1189_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_127_),
    .B(_125_),
    .C(_123_),
    .Y(_122_)
);

AOI21X1 _1190_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_124_),
    .B(_165_),
    .C(\u_ball.x_pos [6]),
    .Y(_123_)
);

NOR2X1 _1191_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_pos [4]),
    .B(_130_),
    .Y(_124_)
);

OR2X2 _1192_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_126_),
    .B(\u_bricks.regBricks [0]),
    .Y(_125_)
);

NAND2X1 _1193_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_130_),
    .B(_129_),
    .Y(_126_)
);

OAI21X1 _1194_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_132_),
    .B(_130_),
    .C(_128_),
    .Y(_127_)
);

AOI21X1 _1195_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_130_),
    .B(\u_bricks.regBricks [2]),
    .C(_129_),
    .Y(_128_)
);

INVX2 _1196_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_pos [4]),
    .Y(_129_)
);

INVX2 _1197_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_pos [3]),
    .Y(_130_)
);

INVX1 _1198_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_pos [5]),
    .Y(_131_)
);

AOI21X1 _1199_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_145_),
    .B(_141_),
    .C(_132_),
    .Y(_176_)
);

INVX1 _1200_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_bricks.regBricks [3]),
    .Y(_132_)
);

AOI21X1 _1201_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_133_),
    .B(_159_),
    .C(_134_),
    .Y(_177_)
);

NOR2X1 _1202_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_158_),
    .B(_150_),
    .Y(_133_)
);

INVX1 _1203_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_bricks.regBricks [4]),
    .Y(_134_)
);

AOI21X1 _1204_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_138_),
    .B(_159_),
    .C(_135_),
    .Y(_178_)
);

INVX1 _1205_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_bricks.regBricks [7]),
    .Y(_135_)
);

AOI21X1 _1206_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_136_),
    .B(_159_),
    .C(_137_),
    .Y(_179_)
);

NOR2X1 _1207_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_ball [5]),
    .B(_156_),
    .Y(_136_)
);

INVX1 _1208_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_bricks.regBricks [2]),
    .Y(_137_)
);

AOI21X1 _1209_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_138_),
    .B(_151_),
    .C(_140_),
    .Y(_180_)
);

INVX1 _1210_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_139_),
    .Y(_138_)
);

NAND2X1 _1211_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_ball [5]),
    .B(_143_),
    .Y(_139_)
);

INVX1 _1212_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_bricks.regBricks [15]),
    .Y(_140_)
);

AOI21X1 _1213_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_144_),
    .B(_141_),
    .C(_148_),
    .Y(_181_)
);

NOR2X1 _1214_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_ball [5]),
    .B(_142_),
    .Y(_141_)
);

NAND2X1 _1215_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_160_),
    .B(_143_),
    .Y(_142_)
);

NOR2X1 _1216_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_157_),
    .B(_164_),
    .Y(_143_)
);

INVX1 _1217_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_145_),
    .Y(_144_)
);

NAND2X1 _1218_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_146_),
    .B(_147_),
    .Y(_145_)
);

OAI21X1 _1219_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_ball [5]),
    .B(_150_),
    .C(_161_),
    .Y(_146_)
);

NAND2X1 _1220_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_ball [6]),
    .B(_149_),
    .Y(_147_)
);

INVX1 _1221_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_bricks.regBricks [11]),
    .Y(_148_)
);

AOI21X1 _1222_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_151_),
    .B(_149_),
    .C(_152_),
    .Y(_182_)
);

NOR2X1 _1223_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_ball [5]),
    .B(_150_),
    .Y(_149_)
);

NAND2X1 _1224_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_157_),
    .B(_164_),
    .Y(_150_)
);

INVX2 _1225_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_154_),
    .Y(_151_)
);

INVX1 _1226_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_bricks.regBricks [8]),
    .Y(_152_)
);

INVX1 _1227_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_153_),
    .Y(_183_)
);

OAI21X1 _1228_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_154_),
    .B(_155_),
    .C(\u_bricks.regBricks [14]),
    .Y(_153_)
);

NAND2X1 _1229_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_ball [6]),
    .B(_160_),
    .Y(_154_)
);

OR2X2 _1230_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_156_),
    .B(_158_),
    .Y(_155_)
);

NAND2X1 _1231_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_ball [4]),
    .B(_157_),
    .Y(_156_)
);

INVX1 _1232_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_ball [3]),
    .Y(_157_)
);

INVX1 _1233_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_ball [5]),
    .Y(_158_)
);

AOI21X1 _1234_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_162_),
    .B(_159_),
    .C(_165_),
    .Y(_184_)
);

AND2X2 _1235_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_160_),
    .B(_161_),
    .Y(_159_)
);

AND2X2 _1236_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_725_),
    .B(hit_brick),
    .Y(_160_)
);

INVX1 _1237_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_ball [6]),
    .Y(_161_)
);

NOR2X1 _1238_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_ball [5]),
    .B(_163_),
    .Y(_162_)
);

NAND2X1 _1239_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_ball [3]),
    .B(_164_),
    .Y(_163_)
);

INVX1 _1240_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_ball [4]),
    .Y(_164_)
);

INVX1 _1241_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_bricks.regBricks [1]),
    .Y(_165_)
);

DFFSR _1242_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf7),
    .D(_475_),
    .Q(\u_ball.y_ball [3]),
    .R(_469__bF$buf2),
    .S(vdd)
);

DFFSR _1243_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf6),
    .D(_439_),
    .Q(\u_ball.x_paddle [6]),
    .R(_434_),
    .S(vdd)
);

DFFSR _1244_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf5),
    .D(_433_),
    .Q(\u_ball.x_paddle [2]),
    .R(_434_),
    .S(vdd)
);

DFFSR _1245_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf4),
    .D(_438_),
    .Q(\u_ball.x_paddle [4]),
    .R(_434_),
    .S(vdd)
);

DFFSR _1246_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf3),
    .D(_436_),
    .Q(\u_ball.x_paddle [1]),
    .R(_434_),
    .S(vdd)
);

DFFSR _1247_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf2),
    .D(_437_),
    .Q(\u_ball.x_paddle [5]),
    .R(_434_),
    .S(vdd)
);

OAI21X1 _1248_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_413_),
    .B(_419_),
    .C(_322_),
    .Y(_432_)
);

NAND3X1 _1249_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_419_),
    .B(_405_),
    .C(_323_),
    .Y(_322_)
);

OR2X2 _1250_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_407_),
    .B(_406_),
    .Y(_323_)
);

OAI21X1 _1251_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_380_),
    .B(_419_),
    .C(_324_),
    .Y(_433_)
);

NAND3X1 _1252_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_419_),
    .B(_325_),
    .C(_326_),
    .Y(_324_)
);

NAND2X1 _1253_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_410_),
    .B(_327_),
    .Y(_325_)
);

OR2X2 _1254_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_327_),
    .B(_410_),
    .Y(_326_)
);

OAI21X1 _1255_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_380_),
    .B(btn_left),
    .C(_328_),
    .Y(_327_)
);

INVX1 _1256_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_408_),
    .Y(_328_)
);

INVX2 _1257_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(reset),
    .Y(_434_)
);

NOR3X1 _1258_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_336_),
    .B(_329_),
    .C(_352_),
    .Y(pixel_paddle)
);

OAI21X1 _1259_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_346_),
    .B(_331_),
    .C(_330_),
    .Y(_329_)
);

AND2X2 _1260_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.y_pos [4]),
    .B(\u_ball.y_pos [3]),
    .Y(_330_)
);

AOI21X1 _1261_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_334_),
    .B(_333_),
    .C(_332_),
    .Y(_331_)
);

OAI21X1 _1262_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_416_),
    .B(\u_ball.x_pos [4]),
    .C(_350_),
    .Y(_332_)
);

NAND2X1 _1263_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_pos [4]),
    .B(_416_),
    .Y(_333_)
);

AOI21X1 _1264_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_335_),
    .B(_369_),
    .C(_371_),
    .Y(_334_)
);

OAI21X1 _1265_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_paddle [2]),
    .B(_376_),
    .C(_366_),
    .Y(_335_)
);

OAI21X1 _1266_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_345_),
    .B(_339_),
    .C(_337_),
    .Y(_336_)
);

AOI21X1 _1267_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_349_),
    .B(\u_ball.x_paddle [6]),
    .C(_338_),
    .Y(_337_)
);

INVX1 _1268_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.y_pos [5]),
    .Y(_338_)
);

AOI21X1 _1269_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_344_),
    .B(_343_),
    .C(_340_),
    .Y(_339_)
);

NAND2X1 _1270_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_342_),
    .B(_341_),
    .Y(_340_)
);

OAI21X1 _1271_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_416_),
    .B(\u_ball.x_pos [4]),
    .C(_346_),
    .Y(_341_)
);

OAI21X1 _1272_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_418_),
    .B(\u_ball.x_pos [5]),
    .C(_348_),
    .Y(_342_)
);

OR2X2 _1273_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_paddle [4]),
    .B(\u_ball.x_pos [4]),
    .Y(_343_)
);

OAI21X1 _1274_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_paddle [3]),
    .B(_372_),
    .C(_368_),
    .Y(_344_)
);

AOI21X1 _1275_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_416_),
    .B(_350_),
    .C(_346_),
    .Y(_345_)
);

OAI21X1 _1276_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_paddle [5]),
    .B(_351_),
    .C(_347_),
    .Y(_346_)
);

INVX1 _1277_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_348_),
    .Y(_347_)
);

NOR2X1 _1278_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_paddle [6]),
    .B(_349_),
    .Y(_348_)
);

INVX1 _1279_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_pos [6]),
    .Y(_349_)
);

NAND2X1 _1280_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_paddle [5]),
    .B(_351_),
    .Y(_350_)
);

INVX1 _1281_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_pos [5]),
    .Y(_351_)
);

AOI21X1 _1282_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_358_),
    .B(_354_),
    .C(_353_),
    .Y(_352_)
);

OR2X2 _1283_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.y_pos [1]),
    .B(\u_ball.y_pos [2]),
    .Y(_353_)
);

AOI21X1 _1284_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_363_),
    .B(_355_),
    .C(_362_),
    .Y(_354_)
);

NOR2X1 _1285_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_356_),
    .B(_366_),
    .Y(_355_)
);

OAI21X1 _1286_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_paddle [1]),
    .B(_377_),
    .C(_357_),
    .Y(_356_)
);

INVX1 _1287_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_pos [0]),
    .Y(_357_)
);

OR2X2 _1288_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_359_),
    .B(_363_),
    .Y(_358_)
);

OR2X2 _1289_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_360_),
    .B(_373_),
    .Y(_359_)
);

OAI21X1 _1290_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_pos [0]),
    .B(_362_),
    .C(_361_),
    .Y(_360_)
);

OAI21X1 _1291_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_paddle [1]),
    .B(_377_),
    .C(_374_),
    .Y(_361_)
);

INVX1 _1292_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.y_pos [0]),
    .Y(_362_)
);

NAND2X1 _1293_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_368_),
    .B(_364_),
    .Y(_363_)
);

NAND3X1 _1294_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_379_),
    .B(_366_),
    .C(_365_),
    .Y(_364_)
);

INVX1 _1295_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_369_),
    .Y(_365_)
);

OAI21X1 _1296_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_410_),
    .B(\u_ball.x_pos [1]),
    .C(_367_),
    .Y(_366_)
);

AND2X2 _1297_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_379_),
    .B(_375_),
    .Y(_367_)
);

OAI21X1 _1298_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_378_),
    .B(_373_),
    .C(_369_),
    .Y(_368_)
);

NOR2X1 _1299_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_371_),
    .B(_370_),
    .Y(_369_)
);

NOR2X1 _1300_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_pos [3]),
    .B(_413_),
    .Y(_370_)
);

NOR2X1 _1301_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_paddle [3]),
    .B(_372_),
    .Y(_371_)
);

INVX1 _1302_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_pos [3]),
    .Y(_372_)
);

AOI21X1 _1303_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_paddle [1]),
    .B(_377_),
    .C(_374_),
    .Y(_373_)
);

NAND2X1 _1304_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_379_),
    .B(_375_),
    .Y(_374_)
);

NAND2X1 _1305_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_paddle [2]),
    .B(_376_),
    .Y(_375_)
);

INVX1 _1306_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_pos [2]),
    .Y(_376_)
);

INVX1 _1307_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_pos [1]),
    .Y(_377_)
);

INVX1 _1308_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_379_),
    .Y(_378_)
);

NAND2X1 _1309_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_pos [2]),
    .B(_380_),
    .Y(_379_)
);

INVX1 _1310_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_paddle [2]),
    .Y(_380_)
);

NAND2X1 _1311_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_382_),
    .B(_381_),
    .Y(_436_)
);

NAND2X1 _1312_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_410_),
    .B(_419_),
    .Y(_381_)
);

OAI21X1 _1313_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_430_),
    .B(_420_),
    .C(\u_ball.x_paddle [1]),
    .Y(_382_)
);

NAND2X1 _1314_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_383_),
    .B(_384_),
    .Y(_437_)
);

OAI21X1 _1315_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_430_),
    .B(_420_),
    .C(\u_ball.x_paddle [5]),
    .Y(_383_)
);

NAND3X1 _1316_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_419_),
    .B(_387_),
    .C(_385_),
    .Y(_384_)
);

OR2X2 _1317_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_394_),
    .B(_386_),
    .Y(_385_)
);

OAI21X1 _1318_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_418_),
    .B(_428_),
    .C(_417_),
    .Y(_386_)
);

OAI21X1 _1319_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_397_),
    .B(_403_),
    .C(_394_),
    .Y(_387_)
);

OAI21X1 _1320_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_416_),
    .B(_419_),
    .C(_388_),
    .Y(_438_)
);

NAND3X1 _1321_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_419_),
    .B(_389_),
    .C(_390_),
    .Y(_388_)
);

NAND2X1 _1322_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_391_),
    .B(_396_),
    .Y(_389_)
);

OR2X2 _1323_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_396_),
    .B(_391_),
    .Y(_390_)
);

OAI21X1 _1324_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_416_),
    .B(btn_left),
    .C(_402_),
    .Y(_391_)
);

NAND2X1 _1325_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_399_),
    .B(_392_),
    .Y(_439_)
);

OAI21X1 _1326_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_398_),
    .B(_393_),
    .C(\u_ball.x_paddle [6]),
    .Y(_392_)
);

AOI22X1 _1327_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_394_),
    .B(_403_),
    .C(_397_),
    .D(_395_),
    .Y(_393_)
);

AOI22X1 _1328_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_416_),
    .B(_423_),
    .C(_396_),
    .D(_414_),
    .Y(_394_)
);

AND2X2 _1329_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_396_),
    .B(_414_),
    .Y(_395_)
);

AOI22X1 _1330_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_paddle [3]),
    .B(_428_),
    .C(_407_),
    .D(_406_),
    .Y(_396_)
);

INVX1 _1331_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_417_),
    .Y(_397_)
);

INVX1 _1332_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_419_),
    .Y(_398_)
);

NAND3X1 _1333_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_431_),
    .B(_419_),
    .C(_400_),
    .Y(_399_)
);

OAI21X1 _1334_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_417_),
    .B(_404_),
    .C(_401_),
    .Y(_400_)
);

NAND3X1 _1335_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_403_),
    .B(_402_),
    .C(_404_),
    .Y(_401_)
);

NAND2X1 _1336_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_416_),
    .B(_423_),
    .Y(_402_)
);

NOR2X1 _1337_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_418_),
    .B(_428_),
    .Y(_403_)
);

NAND3X1 _1338_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_414_),
    .B(_411_),
    .C(_405_),
    .Y(_404_)
);

NAND2X1 _1339_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_406_),
    .B(_407_),
    .Y(_405_)
);

AOI21X1 _1340_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_423_),
    .B(_413_),
    .C(_412_),
    .Y(_406_)
);

OAI21X1 _1341_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_410_),
    .B(_408_),
    .C(_409_),
    .Y(_407_)
);

AOI21X1 _1342_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_424_),
    .B(_428_),
    .C(\u_ball.x_paddle [2]),
    .Y(_408_)
);

NAND2X1 _1343_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_paddle [2]),
    .B(_428_),
    .Y(_409_)
);

INVX1 _1344_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_paddle [1]),
    .Y(_410_)
);

INVX1 _1345_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_412_),
    .Y(_411_)
);

NOR2X1 _1346_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(btn_left),
    .B(_413_),
    .Y(_412_)
);

INVX1 _1347_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_paddle [3]),
    .Y(_413_)
);

INVX1 _1348_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_415_),
    .Y(_414_)
);

NOR2X1 _1349_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(btn_left),
    .B(_416_),
    .Y(_415_)
);

INVX2 _1350_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_paddle [4]),
    .Y(_416_)
);

NAND2X1 _1351_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_418_),
    .B(_422_),
    .Y(_417_)
);

INVX1 _1352_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_paddle [5]),
    .Y(_418_)
);

NOR2X1 _1353_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_430_),
    .B(_420_),
    .Y(_419_)
);

AOI21X1 _1354_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_429_),
    .B(_421_),
    .C(_422_),
    .Y(_420_)
);

NAND3X1 _1355_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_paddle [6]),
    .B(\u_ball.x_paddle [4]),
    .C(\u_ball.x_paddle [5]),
    .Y(_421_)
);

INVX1 _1356_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_423_),
    .Y(_422_)
);

NAND2X1 _1357_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_428_),
    .B(_424_),
    .Y(_423_)
);

NAND3X1 _1358_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_427_),
    .B(_426_),
    .C(_425_),
    .Y(_424_)
);

NOR2X1 _1359_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_paddle [2]),
    .B(\u_ball.x_paddle [3]),
    .Y(_425_)
);

NOR2X1 _1360_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_paddle [5]),
    .B(\u_ball.x_paddle [1]),
    .Y(_426_)
);

NOR2X1 _1361_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_paddle [6]),
    .B(\u_ball.x_paddle [4]),
    .Y(_427_)
);

INVX2 _1362_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(btn_left),
    .Y(_428_)
);

INVX1 _1363_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(btn_right),
    .Y(_429_)
);

INVX1 _1364_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_725_),
    .Y(_430_)
);

INVX1 _1365_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_paddle [6]),
    .Y(_431_)
);

DFFSR _1366_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf1),
    .D(_480_),
    .Q(\u_ball.x2 ),
    .R(_469__bF$buf1),
    .S(vdd)
);

DFFSR _1367_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf0),
    .D(_686_),
    .Q(\u_ball.y_pos [0]),
    .R(vdd),
    .S(_673__bF$buf3)
);

DFFSR _1368_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf7),
    .D(_516_),
    .Q(\u_ctrl.State [2]),
    .R(_673__bF$buf2),
    .S(vdd)
);

DFFSR _1369_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf6),
    .D(_517_),
    .Q(\u_ctrl.State [1]),
    .R(_673__bF$buf1),
    .S(vdd)
);

DFFSR _1370_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf5),
    .D(_528_),
    .Q(\u_ctrl.State [0]),
    .R(vdd),
    .S(_673__bF$buf0)
);

DFFSR _1371_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf4),
    .D(_514_),
    .Q(\u_ctrl.State [3]),
    .R(_673__bF$buf3),
    .S(vdd)
);

DFFSR _1372_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf3),
    .D(_665_),
    .Q(\u_ctrl.cnt_v_sync [1]),
    .R(_673__bF$buf2),
    .S(vdd)
);

DFFSR _1373_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf2),
    .D(_683_),
    .Q(\u_ball.x_pos [6]),
    .R(vdd),
    .S(_673__bF$buf1)
);

DFFSR _1374_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf1),
    .D(_666_),
    .Q(\u_ball.x_pos [5]),
    .R(vdd),
    .S(_673__bF$buf0)
);

DFFSR _1375_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf0),
    .D(_688_),
    .Q(_723_),
    .R(_673__bF$buf3),
    .S(vdd)
);

DFFSR _1376_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf7),
    .D(_667_),
    .Q(\u_ball.x_pos [4]),
    .R(vdd),
    .S(_673__bF$buf2)
);

DFFSR _1377_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf6),
    .D(_684_),
    .Q(\u_ball.y_pos [2]),
    .R(vdd),
    .S(_673__bF$buf1)
);

DFFSR _1378_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf5),
    .D(_668_),
    .Q(\u_ball.x_pos [3]),
    .R(vdd),
    .S(_673__bF$buf0)
);

DFFSR _1379_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf4),
    .D(_687_),
    .Q(game_init),
    .R(_673__bF$buf3),
    .S(vdd)
);

DFFSR _1380_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf3),
    .D(_669_),
    .Q(\u_ball.x_pos [2]),
    .R(vdd),
    .S(_673__bF$buf2)
);

DFFSR _1381_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf2),
    .D(_680_),
    .Q(_725_),
    .R(_673__bF$buf1),
    .S(vdd)
);

DFFSR _1382_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf1),
    .D(_670_),
    .Q(\u_ball.x_pos [1]),
    .R(vdd),
    .S(_673__bF$buf0)
);

DFFSR _1383_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf0),
    .D(_685_),
    .Q(\u_ball.y_pos [1]),
    .R(vdd),
    .S(_673__bF$buf3)
);

DFFSR _1384_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf7),
    .D(_671_),
    .Q(\u_ball.x_pos [0]),
    .R(vdd),
    .S(_673__bF$buf2)
);

DFFSR _1385_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf6),
    .D(_681_),
    .Q(\u_ball.y_pos [5]),
    .R(vdd),
    .S(_673__bF$buf1)
);

DFFSR _1386_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf5),
    .D(_672_),
    .Q(\u_ctrl.cnt_v_sync [2]),
    .R(_673__bF$buf0),
    .S(vdd)
);

DFFSR _1387_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf4),
    .D(_512_),
    .Q(\u_ctrl.State [4]),
    .R(_673__bF$buf3),
    .S(vdd)
);

DFFSR _1388_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf3),
    .D(_679_),
    .Q(\u_ball.y_pos [4]),
    .R(vdd),
    .S(_673__bF$buf2)
);

DFFSR _1389_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf2),
    .D(_682_),
    .Q(\u_ball.y_pos [3]),
    .R(vdd),
    .S(_673__bF$buf1)
);

OAI21X1 _1390_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_588_),
    .B(_564_),
    .C(_563_),
    .Y(_664_)
);

NAND2X1 _1391_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ctrl.cnt_v_sync [0]),
    .B(_588_),
    .Y(_563_)
);

AOI21X1 _1392_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_567_),
    .B(\u_ctrl.State [1]),
    .C(\u_ctrl.State_3_bF$buf3 ),
    .Y(_564_)
);

AOI22X1 _1393_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_568_),
    .B(_565_),
    .C(_588_),
    .D(_569_),
    .Y(_665_)
);

OAI21X1 _1394_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_661_),
    .B(_566_),
    .C(\u_ctrl.State [1]),
    .Y(_565_)
);

NOR2X1 _1395_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_567_),
    .B(_569_),
    .Y(_566_)
);

INVX1 _1396_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ctrl.cnt_v_sync [0]),
    .Y(_567_)
);

AOI21X1 _1397_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_662_),
    .B(_595_),
    .C(\u_ctrl.State_3_bF$buf2 ),
    .Y(_568_)
);

INVX1 _1398_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ctrl.cnt_v_sync [1]),
    .Y(_569_)
);

OAI21X1 _1399_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_pos [5]),
    .B(_572_),
    .C(_570_),
    .Y(_666_)
);

OAI21X1 _1400_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_657_),
    .B(_614_),
    .C(_571_),
    .Y(_570_)
);

OAI21X1 _1401_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ctrl.State_3_bF$buf1 ),
    .B(_595_),
    .C(_615_),
    .Y(_571_)
);

NAND2X1 _1402_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ctrl.State_3_bF$buf0 ),
    .B(_653_),
    .Y(_572_)
);

AOI22X1 _1403_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_655_),
    .B(_643_),
    .C(_573_),
    .D(\u_ctrl.State_3_bF$buf3 ),
    .Y(_667_)
);

NAND2X1 _1404_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_574_),
    .B(_614_),
    .Y(_573_)
);

OAI21X1 _1405_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_656_),
    .B(_654_),
    .C(_655_),
    .Y(_574_)
);

OAI21X1 _1406_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_pos [3]),
    .B(_577_),
    .C(_575_),
    .Y(_668_)
);

OAI21X1 _1407_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_657_),
    .B(_654_),
    .C(_576_),
    .Y(_575_)
);

OAI21X1 _1408_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ctrl.State_3_bF$buf2 ),
    .B(_595_),
    .C(_656_),
    .Y(_576_)
);

OR2X2 _1409_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_654_),
    .B(_657_),
    .Y(_577_)
);

MUX2X1 _1410_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_578_),
    .B(\u_ball.x_pos [2]),
    .S(_579_),
    .Y(_669_)
);

AOI21X1 _1411_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_657_),
    .B(\u_ctrl.State [0]),
    .C(\u_ball.x_pos [2]),
    .Y(_578_)
);

NAND2X1 _1412_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_pos [1]),
    .B(_582_),
    .Y(_579_)
);

OAI21X1 _1413_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_pos [1]),
    .B(_581_),
    .C(_580_),
    .Y(_670_)
);

OAI21X1 _1414_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_657_),
    .B(_583_),
    .C(\u_ball.x_pos [1]),
    .Y(_580_)
);

AOI21X1 _1415_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_657_),
    .B(\u_ctrl.State [0]),
    .C(_582_),
    .Y(_581_)
);

AOI21X1 _1416_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_583_),
    .B(_643_),
    .C(_582_),
    .Y(_671_)
);

NOR2X1 _1417_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_657_),
    .B(_583_),
    .Y(_582_)
);

INVX1 _1418_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_pos [0]),
    .Y(_583_)
);

OAI21X1 _1419_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_588_),
    .B(_585_),
    .C(_584_),
    .Y(_672_)
);

NAND2X1 _1420_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ctrl.cnt_v_sync [2]),
    .B(_588_),
    .Y(_584_)
);

NOR2X1 _1421_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ctrl.State_3_bF$buf1 ),
    .B(_586_),
    .Y(_585_)
);

OAI21X1 _1422_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_661_),
    .B(_587_),
    .C(_591_),
    .Y(_586_)
);

NAND2X1 _1423_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ctrl.State [1]),
    .B(\u_ctrl.cnt_v_sync [2]),
    .Y(_587_)
);

OAI21X1 _1424_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_657_),
    .B(_638_),
    .C(_589_),
    .Y(_588_)
);

OAI21X1 _1425_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_662_),
    .B(_644_),
    .C(_629_),
    .Y(_589_)
);

INVX8 _1426_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(reset),
    .Y(_673_)
);

NAND3X1 _1427_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_645_),
    .B(_633_),
    .C(_590_),
    .Y(_528_)
);

OAI21X1 _1428_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ctrl.State [1]),
    .B(\u_ctrl.State [2]),
    .C(_593_),
    .Y(_590_)
);

NOR2X1 _1429_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_593_),
    .B(_637_),
    .Y(_517_)
);

AOI21X1 _1430_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_592_),
    .B(_591_),
    .C(_593_),
    .Y(_516_)
);

NAND2X1 _1431_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ctrl.State [1]),
    .B(_659_),
    .Y(_591_)
);

OAI21X1 _1432_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_648_),
    .B(_652_),
    .C(\u_ctrl.State_3_bF$buf0 ),
    .Y(_592_)
);

INVX1 _1433_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_646_),
    .Y(_593_)
);

OAI21X1 _1434_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_632_),
    .B(_596_),
    .C(_594_),
    .Y(_514_)
);

NAND2X1 _1435_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ctrl.State [2]),
    .B(_646_),
    .Y(_594_)
);

AOI21X1 _1436_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_596_),
    .B(_595_),
    .C(game_new),
    .Y(_512_)
);

INVX1 _1437_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ctrl.State [0]),
    .Y(_595_)
);

INVX1 _1438_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ctrl.State [4]),
    .Y(_596_)
);

OAI21X1 _1439_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_607_),
    .B(_628_),
    .C(_597_),
    .Y(_679_)
);

NAND2X1 _1440_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_628_),
    .B(_598_),
    .Y(_597_)
);

OAI21X1 _1441_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_599_),
    .B(_601_),
    .C(\u_ctrl.State_3_bF$buf3 ),
    .Y(_598_)
);

INVX1 _1442_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_600_),
    .Y(_599_)
);

OAI21X1 _1443_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_651_),
    .B(_650_),
    .C(_607_),
    .Y(_600_)
);

NOR2X1 _1444_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_607_),
    .B(_606_),
    .Y(_601_)
);

AOI21X1 _1445_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_657_),
    .B(_641_),
    .C(_602_),
    .Y(_680_)
);

AOI21X1 _1446_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_638_),
    .B(_641_),
    .C(_725_),
    .Y(_602_)
);

OAI21X1 _1447_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_608_),
    .B(_628_),
    .C(_603_),
    .Y(_681_)
);

OAI21X1 _1448_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_657_),
    .B(_604_),
    .C(_628_),
    .Y(_603_)
);

AND2X2 _1449_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_605_),
    .B(_648_),
    .Y(_604_)
);

OAI21X1 _1450_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_607_),
    .B(_606_),
    .C(_608_),
    .Y(_605_)
);

INVX1 _1451_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_649_),
    .Y(_606_)
);

INVX1 _1452_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.y_pos [4]),
    .Y(_607_)
);

INVX1 _1453_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.y_pos [5]),
    .Y(_608_)
);

OAI21X1 _1454_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_651_),
    .B(_628_),
    .C(_609_),
    .Y(_682_)
);

NAND2X1 _1455_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_610_),
    .B(_628_),
    .Y(_609_)
);

OAI21X1 _1456_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_649_),
    .B(_611_),
    .C(\u_ctrl.State_3_bF$buf2 ),
    .Y(_610_)
);

NOR2X1 _1457_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.y_pos [3]),
    .B(_620_),
    .Y(_611_)
);

AOI22X1 _1458_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_616_),
    .B(_643_),
    .C(_612_),
    .D(\u_ctrl.State_3_bF$buf1 ),
    .Y(_683_)
);

NAND2X1 _1459_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_652_),
    .B(_613_),
    .Y(_612_)
);

OAI21X1 _1460_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_615_),
    .B(_614_),
    .C(_616_),
    .Y(_613_)
);

INVX1 _1461_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_653_),
    .Y(_614_)
);

INVX1 _1462_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_pos [5]),
    .Y(_615_)
);

INVX1 _1463_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_pos [6]),
    .Y(_616_)
);

OAI21X1 _1464_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_621_),
    .B(_628_),
    .C(_617_),
    .Y(_684_)
);

NAND2X1 _1465_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_618_),
    .B(_628_),
    .Y(_617_)
);

OAI21X1 _1466_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_620_),
    .B(_619_),
    .C(\u_ctrl.State_3_bF$buf0 ),
    .Y(_618_)
);

NOR2X1 _1467_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.y_pos [2]),
    .B(_625_),
    .Y(_619_)
);

INVX1 _1468_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_650_),
    .Y(_620_)
);

INVX1 _1469_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.y_pos [2]),
    .Y(_621_)
);

OAI21X1 _1470_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_626_),
    .B(_628_),
    .C(_622_),
    .Y(_685_)
);

NAND2X1 _1471_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_623_),
    .B(_628_),
    .Y(_622_)
);

OAI21X1 _1472_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_624_),
    .B(_625_),
    .C(\u_ctrl.State_3_bF$buf3 ),
    .Y(_623_)
);

NOR2X1 _1473_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.y_pos [0]),
    .B(\u_ball.y_pos [1]),
    .Y(_624_)
);

NOR2X1 _1474_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_630_),
    .B(_626_),
    .Y(_625_)
);

INVX1 _1475_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.y_pos [1]),
    .Y(_626_)
);

OAI21X1 _1476_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_630_),
    .B(_628_),
    .C(_627_),
    .Y(_686_)
);

OAI21X1 _1477_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_630_),
    .B(_657_),
    .C(_628_),
    .Y(_627_)
);

AOI21X1 _1478_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_652_),
    .B(\u_ctrl.State_3_bF$buf2 ),
    .C(_629_),
    .Y(_628_)
);

OAI21X1 _1479_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ctrl.State_3_bF$buf1 ),
    .B(\u_ctrl.State [0]),
    .C(_645_),
    .Y(_629_)
);

INVX1 _1480_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.y_pos [0]),
    .Y(_630_)
);

AOI21X1 _1481_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ctrl.State [4]),
    .B(_633_),
    .C(_631_),
    .Y(_687_)
);

AOI21X1 _1482_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_632_),
    .B(\u_ctrl.State [0]),
    .C(game_init),
    .Y(_631_)
);

INVX1 _1483_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(game_new),
    .Y(_632_)
);

NAND2X1 _1484_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(game_new),
    .B(\u_ctrl.State [0]),
    .Y(_633_)
);

OAI21X1 _1485_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_663_),
    .B(_639_),
    .C(_634_),
    .Y(_688_)
);

NAND3X1 _1486_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_636_),
    .B(_635_),
    .C(_637_),
    .Y(_634_)
);

NOR2X1 _1487_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ctrl.State [0]),
    .B(\u_ctrl.State [2]),
    .Y(_635_)
);

INVX1 _1488_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_640_),
    .Y(_636_)
);

AOI21X1 _1489_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_638_),
    .B(\u_ctrl.State_3_bF$buf0 ),
    .C(_658_),
    .Y(_637_)
);

NOR2X1 _1490_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_648_),
    .B(_652_),
    .Y(_638_)
);

NOR3X1 _1491_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_658_),
    .B(_640_),
    .C(_647_),
    .Y(_639_)
);

OAI21X1 _1492_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_662_),
    .B(_646_),
    .C(_641_),
    .Y(_640_)
);

OAI21X1 _1493_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_643_),
    .B(_644_),
    .C(_642_),
    .Y(_641_)
);

OAI21X1 _1494_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ctrl.State [1]),
    .B(\u_ctrl.State [2]),
    .C(_645_),
    .Y(_642_)
);

NOR2X1 _1495_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ctrl.State_3_bF$buf3 ),
    .B(\u_ctrl.State [0]),
    .Y(_643_)
);

INVX1 _1496_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_645_),
    .Y(_644_)
);

OAI21X1 _1497_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_722_),
    .B(_0_),
    .C(\u_ctrl.State_3_bF$buf2 ),
    .Y(_645_)
);

NOR2X1 _1498_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_722_),
    .B(_0_),
    .Y(_646_)
);

NOR3X1 _1499_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_657_),
    .B(_648_),
    .C(_652_),
    .Y(_647_)
);

NAND3X1 _1500_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.y_pos [5]),
    .B(\u_ball.y_pos [4]),
    .C(_649_),
    .Y(_648_)
);

NOR2X1 _1501_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_651_),
    .B(_650_),
    .Y(_649_)
);

NAND3X1 _1502_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.y_pos [0]),
    .B(\u_ball.y_pos [1]),
    .C(\u_ball.y_pos [2]),
    .Y(_650_)
);

INVX1 _1503_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.y_pos [3]),
    .Y(_651_)
);

NAND3X1 _1504_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_pos [6]),
    .B(\u_ball.x_pos [5]),
    .C(_653_),
    .Y(_652_)
);

NOR3X1 _1505_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_656_),
    .B(_655_),
    .C(_654_),
    .Y(_653_)
);

NAND3X1 _1506_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_pos [1]),
    .B(\u_ball.x_pos [0]),
    .C(\u_ball.x_pos [2]),
    .Y(_654_)
);

INVX1 _1507_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_pos [4]),
    .Y(_655_)
);

INVX1 _1508_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_pos [3]),
    .Y(_656_)
);

INVX4 _1509_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ctrl.State_3_bF$buf1 ),
    .Y(_657_)
);

NOR2X1 _1510_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_662_),
    .B(_659_),
    .Y(_658_)
);

NOR2X1 _1511_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ctrl.cnt_v_sync [2]),
    .B(_660_),
    .Y(_659_)
);

INVX1 _1512_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_661_),
    .Y(_660_)
);

NOR2X1 _1513_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ctrl.cnt_v_sync [0]),
    .B(\u_ctrl.cnt_v_sync [1]),
    .Y(_661_)
);

INVX1 _1514_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ctrl.State [1]),
    .Y(_662_)
);

INVX1 _1515_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_723_),
    .Y(_663_)
);

INVX1 _1516_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(pixel_ball),
    .Y(_716_)
);

INVX1 _1517_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(pixel_paddle),
    .Y(_717_)
);

INVX1 _1518_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(pixel_brick),
    .Y(_718_)
);

NAND3X1 _1519_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_716_),
    .B(_717_),
    .C(_718_),
    .Y(_724_)
);

DFFSR _1520_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf1),
    .D(_461_),
    .Q(\u_ball.x_ball [4]),
    .R(_469__bF$buf0),
    .S(vdd)
);

DFFSR _1521_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf0),
    .D(_166_),
    .Q(\u_bricks.regBricks [12]),
    .R(vdd),
    .S(_173_)
);

DFFSR _1522_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf7),
    .D(_432_),
    .Q(\u_ball.x_paddle [3]),
    .R(_434_),
    .S(vdd)
);

DFFSR _1523_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf6),
    .D(_664_),
    .Q(\u_ctrl.cnt_v_sync [0]),
    .R(_673__bF$buf0),
    .S(vdd)
);

BUFX2 _727_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_725_),
    .Y(v_sync)
);

BUFX2 _728_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_724_),
    .Y(pixel)
);

BUFX2 _729_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_723_),
    .Y(p_tick)
);

BUFX2 _730_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_722_),
    .Y(game_over)
);

BUFX2 _731_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_0_),
    .Y(game_complete)
);

DFFSR _732_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf5),
    .D(_463_),
    .Q(\u_ball.y_ball [5]),
    .R(_469__bF$buf3),
    .S(vdd)
);

DFFSR _733_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf4),
    .D(_476_),
    .Q(\u_ball.y_ball [2]),
    .R(vdd),
    .S(_469__bF$buf2)
);

DFFSR _734_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf3),
    .D(_464_),
    .Q(_722_),
    .R(_469__bF$buf1),
    .S(vdd)
);

DFFSR _735_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf2),
    .D(_479_),
    .Q(\u_ball.x_ball [5]),
    .R(_469__bF$buf0),
    .S(vdd)
);

DFFSR _736_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf1),
    .D(_676_),
    .Q(hit_brick),
    .R(_469__bF$buf3),
    .S(vdd)
);

DFFSR _737_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf0),
    .D(_465_),
    .Q(\u_ball.x_ball [6]),
    .R(_469__bF$buf2),
    .S(vdd)
);

DFFSR _738_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf7),
    .D(_561_),
    .Q(\u_ball.hit_paddle ),
    .R(_469__bF$buf1),
    .S(vdd)
);

DFFSR _739_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf6),
    .D(_466_),
    .Q(\u_ball.x_ball [3]),
    .R(_469__bF$buf0),
    .S(vdd)
);

DFFSR _740_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf5),
    .D(_477_),
    .Q(\u_ball.y_ball [1]),
    .R(_469__bF$buf3),
    .S(vdd)
);

DFFSR _741_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf4),
    .D(_467_),
    .Q(\u_ball.x_ball [2]),
    .R(_469__bF$buf2),
    .S(vdd)
);

DFFSR _742_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf3),
    .D(_481_),
    .Q(\u_ball.sign_x ),
    .R(_469__bF$buf1),
    .S(vdd)
);

DFFSR _743_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf2),
    .D(_468_),
    .Q(\u_ball.x_ball [1]),
    .R(_469__bF$buf0),
    .S(vdd)
);

DFFSR _744_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf1),
    .D(_474_),
    .Q(\u_ball.y_ball [4]),
    .R(vdd),
    .S(_469__bF$buf3)
);

DFFSR _745_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf0),
    .D(_473_),
    .Q(\u_ball.x_ball [0]),
    .R(_469__bF$buf2),
    .S(vdd)
);

DFFSR _746_ (
    .vdd(vdd),
    .gnd(gnd),
    .CLK(clk_bF$buf7),
    .D(_478_),
    .Q(\u_ball.y_ball [0]),
    .R(_469__bF$buf1),
    .S(vdd)
);

OAI22X1 _747_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_291_),
    .B(_254_),
    .C(_24_),
    .D(_23_),
    .Y(_461_)
);

OAI21X1 _748_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_203_),
    .B(_4_),
    .C(_221_),
    .Y(_24_)
);

INVX1 _749_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_22_),
    .Y(_23_)
);

NAND2X1 _750_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_203_),
    .B(_4_),
    .Y(_22_)
);

AOI21X1 _751_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_725_),
    .B(_20_),
    .C(_21_),
    .Y(_462_)
);

OAI21X1 _752_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.sign_y ),
    .B(_223_),
    .C(_44_),
    .Y(_21_)
);

OAI21X1 _753_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_10_),
    .B(_19_),
    .C(_707_),
    .Y(_20_)
);

NAND3X1 _754_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_62_),
    .B(_54_),
    .C(_18_),
    .Y(_19_)
);

INVX1 _755_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.y_ball [5]),
    .Y(_18_)
);

AOI21X1 _756_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.y_ball [5]),
    .B(_16_),
    .C(_17_),
    .Y(_463_)
);

OAI21X1 _757_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.y_ball [5]),
    .B(_16_),
    .C(_44_),
    .Y(_17_)
);

AOI21X1 _758_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_15_),
    .B(_14_),
    .C(_222_),
    .Y(_16_)
);

NAND3X1 _759_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_58_),
    .B(_52_),
    .C(_50_),
    .Y(_15_)
);

NAND3X1 _760_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_59_),
    .B(_53_),
    .C(_61_),
    .Y(_14_)
);

AOI21X1 _761_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_13_),
    .B(_9_),
    .C(game_init),
    .Y(_464_)
);

OAI21X1 _762_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.y_ball [0]),
    .B(_10_),
    .C(_12_),
    .Y(_13_)
);

INVX1 _763_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_11_),
    .Y(_12_)
);

NAND3X1 _764_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.y_ball [3]),
    .B(\u_ball.y_ball [4]),
    .C(\u_ball.y_ball [5]),
    .Y(_11_)
);

NAND2X1 _765_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_192_),
    .B(_175_),
    .Y(_10_)
);

INVX1 _766_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_722_),
    .Y(_9_)
);

AOI21X1 _767_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_306_),
    .B(_7_),
    .C(_8_),
    .Y(_465_)
);

OAI21X1 _768_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_306_),
    .B(_7_),
    .C(_44_),
    .Y(_8_)
);

NAND3X1 _769_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_6_),
    .B(_3_),
    .C(_5_),
    .Y(_7_)
);

NOR2X1 _770_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_222_),
    .B(_199_),
    .Y(_6_)
);

OAI21X1 _771_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_291_),
    .B(_4_),
    .C(_460_),
    .Y(_5_)
);

AND2X2 _772_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_206_),
    .B(_205_),
    .Y(_4_)
);

OAI21X1 _773_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_218_),
    .B(_202_),
    .C(_457_),
    .Y(_3_)
);

OAI21X1 _774_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_255_),
    .B(_2_),
    .C(_720_),
    .Y(_466_)
);

OAI21X1 _775_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_207_),
    .B(_726_),
    .C(_1_),
    .Y(_2_)
);

AOI21X1 _776_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_726_),
    .B(_207_),
    .C(game_init),
    .Y(_1_)
);

OAI21X1 _777_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_460_),
    .B(_443_),
    .C(_721_),
    .Y(_726_)
);

NAND2X1 _778_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_210_),
    .B(_213_),
    .Y(_721_)
);

NAND2X1 _779_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_ball [3]),
    .B(_255_),
    .Y(_720_)
);

OAI21X1 _780_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_443_),
    .B(_254_),
    .C(_719_),
    .Y(_467_)
);

OAI21X1 _781_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_213_),
    .B(_210_),
    .C(_715_),
    .Y(_719_)
);

AOI21X1 _782_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_213_),
    .B(_210_),
    .C(_196_),
    .Y(_715_)
);

OAI22X1 _783_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_299_),
    .B(_254_),
    .C(_713_),
    .D(_714_),
    .Y(_468_)
);

OAI21X1 _784_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_216_),
    .B(_214_),
    .C(_221_),
    .Y(_714_)
);

AOI21X1 _785_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_215_),
    .B(_217_),
    .C(_45_),
    .Y(_713_)
);

INVX8 _786_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(reset),
    .Y(_469_)
);

AOI21X1 _787_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_712_),
    .B(_459_),
    .C(_254_),
    .Y(_561_)
);

NAND3X1 _788_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(pixel_paddle),
    .B(_709_),
    .C(_710_),
    .Y(_712_)
);

AOI21X1 _789_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_711_),
    .B(_707_),
    .C(_254_),
    .Y(_676_)
);

NAND3X1 _790_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(pixel_brick),
    .B(_709_),
    .C(_710_),
    .Y(_711_)
);

AOI22X1 _791_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_509_),
    .B(_524_),
    .C(_549_),
    .D(_249_),
    .Y(_710_)
);

AOI21X1 _792_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_553_),
    .B(_554_),
    .C(_708_),
    .Y(_709_)
);

NAND3X1 _793_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_694_),
    .B(_675_),
    .C(_704_),
    .Y(_708_)
);

INVX1 _794_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(hit_brick),
    .Y(_707_)
);

NOR3X1 _795_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_525_),
    .B(_550_),
    .C(_706_),
    .Y(pixel_ball)
);

NAND3X1 _796_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_675_),
    .B(_705_),
    .C(_555_),
    .Y(_706_)
);

AND2X2 _797_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_704_),
    .B(_694_),
    .Y(_705_)
);

AOI21X1 _798_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_701_),
    .B(_703_),
    .C(_696_),
    .Y(_704_)
);

OAI21X1 _799_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.y_ball [3]),
    .B(_702_),
    .C(_690_),
    .Y(_703_)
);

INVX1 _800_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.y_pos [3]),
    .Y(_702_)
);

NAND3X1 _801_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_698_),
    .B(_700_),
    .C(_697_),
    .Y(_701_)
);

OAI21X1 _802_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_54_),
    .B(\u_ball.y_pos [4]),
    .C(_699_),
    .Y(_700_)
);

NOR2X1 _803_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.y_ball [5]),
    .B(_678_),
    .Y(_699_)
);

OAI21X1 _804_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_62_),
    .B(\u_ball.y_pos [3]),
    .C(_689_),
    .Y(_698_)
);

OAI21X1 _805_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_175_),
    .B(\u_ball.y_pos [2]),
    .C(_691_),
    .Y(_697_)
);

INVX1 _806_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_695_),
    .Y(_696_)
);

AOI22X1 _807_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_545_),
    .B(\u_ball.x_ball [6]),
    .C(\u_ball.y_ball [5]),
    .D(_678_),
    .Y(_695_)
);

OAI21X1 _808_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_693_),
    .B(_692_),
    .C(_690_),
    .Y(_694_)
);

OAI22X1 _809_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.y_pos [4]),
    .B(_54_),
    .C(_62_),
    .D(\u_ball.y_pos [3]),
    .Y(_693_)
);

AOI22X1 _810_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_62_),
    .B(\u_ball.y_pos [3]),
    .C(_691_),
    .D(_27_),
    .Y(_692_)
);

NAND3X1 _811_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_34_),
    .B(_29_),
    .C(_26_),
    .Y(_691_)
);

INVX1 _812_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_689_),
    .Y(_690_)
);

OAI22X1 _813_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.y_ball [4]),
    .B(_677_),
    .C(\u_ball.y_ball [5]),
    .D(_678_),
    .Y(_689_)
);

INVX1 _814_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.y_pos [5]),
    .Y(_678_)
);

INVX1 _815_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.y_pos [4]),
    .Y(_677_)
);

OAI21X1 _816_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_556_),
    .B(_562_),
    .C(_674_),
    .Y(_675_)
);

AOI22X1 _817_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_457_),
    .B(\u_ball.x_pos [5]),
    .C(_306_),
    .D(\u_ball.x_pos [6]),
    .Y(_674_)
);

AOI22X1 _818_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_291_),
    .B(\u_ball.x_pos [4]),
    .C(_558_),
    .D(_560_),
    .Y(_562_)
);

AOI22X1 _819_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_559_),
    .B(\u_ball.x_ball [4]),
    .C(\u_ball.x_ball [3]),
    .D(_532_),
    .Y(_560_)
);

INVX1 _820_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_pos [4]),
    .Y(_559_)
);

NAND3X1 _821_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_518_),
    .B(_557_),
    .C(_536_),
    .Y(_558_)
);

NAND2X1 _822_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_pos [3]),
    .B(_449_),
    .Y(_557_)
);

NOR2X1 _823_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_pos [5]),
    .B(_457_),
    .Y(_556_)
);

NAND2X1 _824_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_554_),
    .B(_553_),
    .Y(_555_)
);

AND2X2 _825_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_504_),
    .B(_523_),
    .Y(_554_)
);

OAI21X1 _826_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_552_),
    .B(_551_),
    .C(_507_),
    .Y(_553_)
);

AOI21X1 _827_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_490_),
    .B(_482_),
    .C(_39_),
    .Y(_552_)
);

AOI21X1 _828_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_496_),
    .B(_494_),
    .C(_38_),
    .Y(_551_)
);

AND2X2 _829_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_549_),
    .B(_249_),
    .Y(_550_)
);

OAI21X1 _830_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_547_),
    .B(_543_),
    .C(_548_),
    .Y(_549_)
);

NAND2X1 _831_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_pos [6]),
    .B(_544_),
    .Y(_548_)
);

OAI22X1 _832_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_pos [5]),
    .B(_541_),
    .C(_546_),
    .D(_544_),
    .Y(_547_)
);

OAI21X1 _833_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_306_),
    .B(_251_),
    .C(_545_),
    .Y(_546_)
);

INVX1 _834_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_pos [6]),
    .Y(_545_)
);

AND2X2 _835_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_251_),
    .B(_306_),
    .Y(_544_)
);

AND2X2 _836_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_542_),
    .B(_539_),
    .Y(_543_)
);

AOI22X1 _837_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_pos [4]),
    .B(_531_),
    .C(_541_),
    .D(\u_ball.x_pos [5]),
    .Y(_542_)
);

NAND2X1 _838_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_251_),
    .B(_540_),
    .Y(_541_)
);

NAND2X1 _839_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_457_),
    .B(_527_),
    .Y(_540_)
);

OAI22X1 _840_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_pos [4]),
    .B(_531_),
    .C(_535_),
    .D(_538_),
    .Y(_539_)
);

AOI21X1 _841_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_536_),
    .B(_518_),
    .C(_537_),
    .Y(_538_)
);

OAI21X1 _842_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_ball [3]),
    .B(\u_ball.x_pos [3]),
    .C(_526_),
    .Y(_537_)
);

OAI21X1 _843_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_510_),
    .B(_513_),
    .C(_515_),
    .Y(_536_)
);

AOI21X1 _844_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_534_),
    .B(_533_),
    .C(_532_),
    .Y(_535_)
);

NAND2X1 _845_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_449_),
    .B(_529_),
    .Y(_534_)
);

NAND2X1 _846_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_ball [3]),
    .B(_526_),
    .Y(_533_)
);

INVX1 _847_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_pos [3]),
    .Y(_532_)
);

NAND2X1 _848_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_527_),
    .B(_530_),
    .Y(_531_)
);

OAI21X1 _849_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_449_),
    .B(_529_),
    .C(_291_),
    .Y(_530_)
);

NOR3X1 _850_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_ball [0]),
    .B(\u_ball.x_ball [1]),
    .C(\u_ball.x_ball [2]),
    .Y(_529_)
);

NAND3X1 _851_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_ball [4]),
    .B(\u_ball.x_ball [3]),
    .C(_526_),
    .Y(_527_)
);

NAND3X1 _852_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_46_),
    .B(_299_),
    .C(_443_),
    .Y(_526_)
);

AND2X2 _853_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_509_),
    .B(_524_),
    .Y(_525_)
);

INVX1 _854_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_523_),
    .Y(_524_)
);

NAND2X1 _855_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_520_),
    .B(_522_),
    .Y(_523_)
);

NAND3X1 _856_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_515_),
    .B(_518_),
    .C(_521_),
    .Y(_522_)
);

OAI21X1 _857_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_510_),
    .B(_41_),
    .C(_498_),
    .Y(_521_)
);

OAI21X1 _858_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_510_),
    .B(_513_),
    .C(_519_),
    .Y(_520_)
);

NAND2X1 _859_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_518_),
    .B(_515_),
    .Y(_519_)
);

NAND2X1 _860_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_pos [2]),
    .B(_443_),
    .Y(_518_)
);

OR2X2 _861_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_443_),
    .B(\u_ball.x_pos [2]),
    .Y(_515_)
);

AOI22X1 _862_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_497_),
    .B(\u_ball.x_ball [1]),
    .C(\u_ball.x_ball [0]),
    .D(_511_),
    .Y(_513_)
);

INVX1 _863_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_pos [0]),
    .Y(_511_)
);

NOR2X1 _864_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_ball [1]),
    .B(_497_),
    .Y(_510_)
);

OAI21X1 _865_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_504_),
    .B(_491_),
    .C(_508_),
    .Y(_509_)
);

NAND3X1 _866_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_507_),
    .B(_505_),
    .C(_506_),
    .Y(_508_)
);

NAND2X1 _867_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_502_),
    .B(_501_),
    .Y(_507_)
);

OAI21X1 _868_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_25_),
    .B(_472_),
    .C(_495_),
    .Y(_506_)
);

NAND3X1 _869_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_485_),
    .B(_493_),
    .C(_483_),
    .Y(_505_)
);

NAND3X1 _870_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_494_),
    .B(_496_),
    .C(_503_),
    .Y(_504_)
);

AND2X2 _871_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_501_),
    .B(_502_),
    .Y(_503_)
);

NAND2X1 _872_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_42_),
    .B(_500_),
    .Y(_502_)
);

OR2X2 _873_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_500_),
    .B(_42_),
    .Y(_501_)
);

AND2X2 _874_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_498_),
    .B(_499_),
    .Y(_500_)
);

NAND2X1 _875_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_pos [1]),
    .B(_299_),
    .Y(_499_)
);

NAND2X1 _876_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_ball [1]),
    .B(_497_),
    .Y(_498_)
);

INVX1 _877_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_pos [1]),
    .Y(_497_)
);

NAND3X1 _878_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_485_),
    .B(_483_),
    .C(_495_),
    .Y(_496_)
);

AND2X2 _879_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_492_),
    .B(_487_),
    .Y(_495_)
);

OAI21X1 _880_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_25_),
    .B(_472_),
    .C(_493_),
    .Y(_494_)
);

NAND2X1 _881_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_487_),
    .B(_492_),
    .Y(_493_)
);

NAND2X1 _882_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_37_),
    .B(_33_),
    .Y(_492_)
);

AOI21X1 _883_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_490_),
    .B(_482_),
    .C(_38_),
    .Y(_491_)
);

NAND3X1 _884_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_485_),
    .B(_489_),
    .C(_483_),
    .Y(_490_)
);

OAI21X1 _885_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.y_ball [0]),
    .B(_32_),
    .C(_488_),
    .Y(_489_)
);

INVX1 _886_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_487_),
    .Y(_488_)
);

NAND3X1 _887_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_486_),
    .B(_35_),
    .C(_34_),
    .Y(_487_)
);

NAND2X1 _888_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.y_ball [0]),
    .B(_32_),
    .Y(_486_)
);

NAND3X1 _889_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_34_),
    .B(_26_),
    .C(_484_),
    .Y(_485_)
);

INVX1 _890_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_470_),
    .Y(_484_)
);

INVX1 _891_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_25_),
    .Y(_483_)
);

OAI21X1 _892_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_25_),
    .B(_472_),
    .C(_30_),
    .Y(_482_)
);

AOI21X1 _893_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_471_),
    .B(_35_),
    .C(_470_),
    .Y(_472_)
);

OAI21X1 _894_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.y_ball [1]),
    .B(_36_),
    .C(_37_),
    .Y(_471_)
);

NAND2X1 _895_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_29_),
    .B(_27_),
    .Y(_470_)
);

AOI22X1 _896_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_29_),
    .B(_27_),
    .C(_26_),
    .D(_34_),
    .Y(_25_)
);

OAI21X1 _897_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_193_),
    .B(\u_ball.y_pos [0]),
    .C(_35_),
    .Y(_26_)
);

NAND2X1 _898_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.y_ball [2]),
    .B(_28_),
    .Y(_27_)
);

INVX1 _899_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.y_pos [2]),
    .Y(_28_)
);

NAND2X1 _900_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.y_pos [2]),
    .B(_175_),
    .Y(_29_)
);

OAI21X1 _901_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_37_),
    .B(_33_),
    .C(_31_),
    .Y(_30_)
);

OAI21X1 _902_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.y_ball [0]),
    .B(_32_),
    .C(_33_),
    .Y(_31_)
);

INVX1 _903_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.y_pos [0]),
    .Y(_32_)
);

NAND2X1 _904_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_35_),
    .B(_34_),
    .Y(_33_)
);

NAND2X1 _905_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.y_pos [1]),
    .B(_192_),
    .Y(_34_)
);

NAND2X1 _906_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.y_ball [1]),
    .B(_36_),
    .Y(_35_)
);

INVX1 _907_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.y_pos [1]),
    .Y(_36_)
);

NOR2X1 _908_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.y_pos [0]),
    .B(_193_),
    .Y(_37_)
);

INVX1 _909_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_39_),
    .Y(_38_)
);

NAND2X1 _910_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_40_),
    .B(_41_),
    .Y(_39_)
);

NAND2X1 _911_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_pos [0]),
    .B(_46_),
    .Y(_40_)
);

INVX1 _912_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_42_),
    .Y(_41_)
);

NOR2X1 _913_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_pos [0]),
    .B(_46_),
    .Y(_42_)
);

OAI22X1 _914_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_46_),
    .B(_43_),
    .C(_45_),
    .D(_196_),
    .Y(_473_)
);

OAI21X1 _915_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x2 ),
    .B(_222_),
    .C(_44_),
    .Y(_43_)
);

INVX1 _916_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(game_init),
    .Y(_44_)
);

INVX1 _917_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_216_),
    .Y(_45_)
);

INVX1 _918_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_ball [0]),
    .Y(_46_)
);

AOI22X1 _919_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_54_),
    .B(_255_),
    .C(_47_),
    .D(_49_),
    .Y(_474_)
);

NOR2X1 _920_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_196_),
    .B(_48_),
    .Y(_47_)
);

AOI21X1 _921_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_50_),
    .B(_58_),
    .C(_51_),
    .Y(_48_)
);

NAND3X1 _922_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_58_),
    .B(_51_),
    .C(_50_),
    .Y(_49_)
);

OAI21X1 _923_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_62_),
    .B(_174_),
    .C(_61_),
    .Y(_50_)
);

NOR2X1 _924_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_53_),
    .B(_52_),
    .Y(_51_)
);

NOR2X1 _925_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.sign_y ),
    .B(_54_),
    .Y(_52_)
);

NOR2X1 _926_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.y_ball [4]),
    .B(_174_),
    .Y(_53_)
);

INVX2 _927_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.y_ball [4]),
    .Y(_54_)
);

OAI22X1 _928_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_62_),
    .B(_254_),
    .C(_55_),
    .D(_56_),
    .Y(_475_)
);

OAI21X1 _929_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_57_),
    .B(_61_),
    .C(_221_),
    .Y(_55_)
);

AND2X2 _930_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_61_),
    .B(_57_),
    .Y(_56_)
);

NAND2X1 _931_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_58_),
    .B(_59_),
    .Y(_57_)
);

NAND2X1 _932_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_62_),
    .B(_174_),
    .Y(_58_)
);

INVX1 _933_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_60_),
    .Y(_59_)
);

NOR2X1 _934_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_62_),
    .B(_174_),
    .Y(_60_)
);

NOR2X1 _935_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_68_),
    .B(_65_),
    .Y(_61_)
);

INVX2 _936_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.y_ball [3]),
    .Y(_62_)
);

OAI21X1 _937_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_64_),
    .B(_65_),
    .C(_63_),
    .Y(_476_)
);

AOI21X1 _938_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_222_),
    .B(\u_ball.y_ball [2]),
    .C(game_init),
    .Y(_63_)
);

OAI21X1 _939_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_185_),
    .B(_66_),
    .C(_725_),
    .Y(_64_)
);

AND2X2 _940_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_66_),
    .B(_185_),
    .Y(_65_)
);

NOR2X1 _941_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_67_),
    .B(_68_),
    .Y(_66_)
);

NOR2X1 _942_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.y_ball [2]),
    .B(\u_ball.sign_y ),
    .Y(_67_)
);

NOR2X1 _943_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_175_),
    .B(_174_),
    .Y(_68_)
);

INVX1 _944_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.sign_y ),
    .Y(_174_)
);

INVX1 _945_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.y_ball [2]),
    .Y(_175_)
);

OAI21X1 _946_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_193_),
    .B(_189_),
    .C(_191_),
    .Y(_185_)
);

OAI21X1 _947_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_192_),
    .B(_254_),
    .C(_186_),
    .Y(_477_)
);

OAI21X1 _948_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.y_ball [0]),
    .B(_188_),
    .C(_187_),
    .Y(_186_)
);

AOI21X1 _949_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_188_),
    .B(\u_ball.y_ball [0]),
    .C(_196_),
    .Y(_187_)
);

NOR2X1 _950_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_189_),
    .B(_190_),
    .Y(_188_)
);

NOR2X1 _951_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.y_ball [1]),
    .B(\u_ball.sign_y ),
    .Y(_189_)
);

INVX1 _952_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_191_),
    .Y(_190_)
);

NAND2X1 _953_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.y_ball [1]),
    .B(\u_ball.sign_y ),
    .Y(_191_)
);

INVX1 _954_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.y_ball [1]),
    .Y(_192_)
);

MUX2X1 _955_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_196_),
    .B(_254_),
    .S(_193_),
    .Y(_478_)
);

INVX1 _956_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.y_ball [0]),
    .Y(_193_)
);

OAI21X1 _957_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_457_),
    .B(_254_),
    .C(_194_),
    .Y(_479_)
);

OAI21X1 _958_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_201_),
    .B(_197_),
    .C(_195_),
    .Y(_194_)
);

AOI21X1 _959_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_201_),
    .B(_197_),
    .C(_196_),
    .Y(_195_)
);

INVX2 _960_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_221_),
    .Y(_196_)
);

INVX1 _961_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_198_),
    .Y(_197_)
);

NOR2X1 _962_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_200_),
    .B(_199_),
    .Y(_198_)
);

NOR2X1 _963_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_460_),
    .B(_457_),
    .Y(_199_)
);

NOR2X1 _964_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.sign_x ),
    .B(\u_ball.x_ball [5]),
    .Y(_200_)
);

NOR2X1 _965_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_218_),
    .B(_202_),
    .Y(_201_)
);

AOI21X1 _966_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_206_),
    .B(_205_),
    .C(_203_),
    .Y(_202_)
);

NAND2X1 _967_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_219_),
    .B(_204_),
    .Y(_203_)
);

NAND2X1 _968_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_460_),
    .B(_291_),
    .Y(_204_)
);

OAI21X1 _969_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_ball [2]),
    .B(\u_ball.x_ball [3]),
    .C(\u_ball.sign_x ),
    .Y(_205_)
);

NAND3X1 _970_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_210_),
    .B(_207_),
    .C(_213_),
    .Y(_206_)
);

NAND2X1 _971_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_209_),
    .B(_208_),
    .Y(_207_)
);

NAND2X1 _972_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_ball [3]),
    .B(_460_),
    .Y(_208_)
);

NAND2X1 _973_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.sign_x ),
    .B(_449_),
    .Y(_209_)
);

NAND2X1 _974_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_212_),
    .B(_211_),
    .Y(_210_)
);

NAND2X1 _975_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x_ball [2]),
    .B(_460_),
    .Y(_211_)
);

NAND2X1 _976_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.sign_x ),
    .B(_443_),
    .Y(_212_)
);

OAI21X1 _977_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_216_),
    .B(_214_),
    .C(_217_),
    .Y(_213_)
);

NAND2X1 _978_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_217_),
    .B(_215_),
    .Y(_214_)
);

OAI21X1 _979_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x2 ),
    .B(_460_),
    .C(_299_),
    .Y(_215_)
);

NOR2X1 _980_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x2 ),
    .B(\u_ball.x_ball [0]),
    .Y(_216_)
);

NAND3X1 _981_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.sign_x ),
    .B(\u_ball.x_ball [1]),
    .C(_225_),
    .Y(_217_)
);

INVX1 _982_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_219_),
    .Y(_218_)
);

NAND2X1 _983_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.sign_x ),
    .B(\u_ball.x_ball [4]),
    .Y(_219_)
);

OAI22X1 _984_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_225_),
    .B(_223_),
    .C(_220_),
    .D(_256_),
    .Y(_480_)
);

NAND2X1 _985_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.hit_paddle ),
    .B(_221_),
    .Y(_220_)
);

NOR2X1 _986_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(game_init),
    .B(_222_),
    .Y(_221_)
);

INVX2 _987_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_725_),
    .Y(_222_)
);

INVX1 _988_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_224_),
    .Y(_223_)
);

OAI21X1 _989_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(game_init),
    .B(\u_ball.hit_paddle ),
    .C(_254_),
    .Y(_224_)
);

INVX1 _990_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(\u_ball.x2 ),
    .Y(_225_)
);

OAI21X1 _991_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_460_),
    .B(_241_),
    .C(_226_),
    .Y(_481_)
);

NAND3X1 _992_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_230_),
    .B(_243_),
    .C(_227_),
    .Y(_226_)
);

OAI21X1 _993_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_229_),
    .B(_237_),
    .C(_228_),
    .Y(_227_)
);

NAND2X1 _994_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_245_),
    .B(_250_),
    .Y(_228_)
);

INVX1 _995_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_458_),
    .Y(_229_)
);

NAND3X1 _996_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_458_),
    .B(_231_),
    .C(_237_),
    .Y(_230_)
);

OAI21X1 _997_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_232_),
    .B(_233_),
    .C(_283_),
    .Y(_231_)
);

NOR2X1 _998_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_306_),
    .B(_280_),
    .Y(_232_)
);

AOI21X1 _999_ (
    .vdd(vdd),
    .gnd(gnd),
    .A(_236_),
    .B(_234_),
    .C(_258_),
    .Y(_233_)
);

endmodule
