/* Verilog module written by vlog2Verilog (qflow) */
/* With explicit power connections */

module bricks_out(
    inout vdd,
    inout gnd,
    input clk,
    input reset,
    output v_sync,
    output pixel,
    output p_tick,
    input btn_left,
    input btn_right,
    output game_over,
    output game_complete,
    input game_new
);

wire _588_ ;
wire _168_ ;
wire _60_ ;
wire _397_ ;
wire \u_ball.sign_x  ;
wire _703_ ;
wire _19_ ;
wire _512_ ;
wire _321_ ;
wire _57_ ;
wire _550_ ;
wire _130_ ;
wire _606_ ;
wire _415_ ;
wire _95_ ;
wire _644_ ;
wire _224_ ;
wire pixel_brick ;
wire _453_ ;
wire _509_ ;
wire _682_ ;
wire _262_ ;
wire _318_ ;
wire _491_ ;
wire _547_ ;
wire _127_ ;
wire _356_ ;
wire btn_right ;
wire _585_ ;
wire _165_ ;
wire _394_ ;
wire _679_ ;
wire _259_ ;
wire _488_ ;
wire _700_ ;
wire _297_ ;
wire _16_ ;
wire _54_ ;
wire _603_ ;
wire _412_ ;
wire _92_ ;
wire _641_ ;
wire _221_ ;
wire _450_ ;
wire _506_ ;
wire _315_ ;
wire _544_ ;
wire _124_ ;
wire _353_ ;
wire _409_ ;
wire _89_ ;
wire _582_ ;
wire _162_ ;
wire _638_ ;
wire _218_ ;
wire _391_ ;
wire _447_ ;
wire _676_ ;
wire _256_ ;
wire _485_ ;
wire _294_ ;
wire _13_ ;
wire _579_ ;
wire _159_ ;
wire _51_ ;
wire _388_ ;
wire _600_ ;
wire _197_ ;
wire _7_ ;
wire _503_ ;
wire _312_ ;
wire _48_ ;
wire _541_ ;
wire _121_ ;
wire _350_ ;
wire _406_ ;
wire _86_ ;
wire _635_ ;
wire _215_ ;
wire _444_ ;
wire _673_ ;
wire _253_ ;
wire _309_ ;
wire _482_ ;
wire _538_ ;
wire _118_ ;
wire _291_ ;
wire _10_ ;
wire _347_ ;
wire _576_ ;
wire _156_ ;
wire _385_ ;
wire pixel ;
wire _194_ ;
wire _479_ ;
wire _288_ ;
wire _4_ ;
wire _500_ ;
wire hit_brick ;
wire _45_ ;
wire _403_ ;
wire _83_ ;
wire _632_ ;
wire _212_ ;
wire _441_ ;
wire _670_ ;
wire _250_ ;
wire _726_ ;
wire _306_ ;
wire _535_ ;
wire _115_ ;
wire _344_ ;
wire _573_ ;
wire _153_ ;
wire _629_ ;
wire _209_ ;
wire _382_ ;
wire _438_ ;
wire _191_ ;
wire _667_ ;
wire _247_ ;
wire _476_ ;
wire clk_bF$buf0 ;
wire clk_bF$buf1 ;
wire clk_bF$buf2 ;
wire clk_bF$buf3 ;
wire clk_bF$buf4 ;
wire clk_bF$buf5 ;
wire clk_bF$buf6 ;
wire clk_bF$buf7 ;
wire _285_ ;
wire _1_ ;
wire _42_ ;
wire _379_ ;
wire _188_ ;
wire _400_ ;
wire _80_ ;
wire _723_ ;
wire _303_ ;
wire [6:0] \u_ball.x_ball  ;
wire _39_ ;
wire _532_ ;
wire _112_ ;
wire _341_ ;
wire clk ;
wire _77_ ;
wire _570_ ;
wire _150_ ;
wire _626_ ;
wire _206_ ;
wire _435_ ;
wire _664_ ;
wire _244_ ;
wire _473_ ;
wire _529_ ;
wire _109_ ;
wire _282_ ;
wire _338_ ;
wire _567_ ;
wire _147_ ;
wire _376_ ;
wire _185_ ;
wire _699_ ;
wire _279_ ;
wire _720_ ;
wire _300_ ;
wire _36_ ;
wire _74_ ;
wire _623_ ;
wire _203_ ;
wire _432_ ;
wire pixel_paddle ;
wire _661_ ;
wire _241_ ;
wire _717_ ;
wire _470_ ;
wire _526_ ;
wire _106_ ;
wire _335_ ;
wire _564_ ;
wire _144_ ;
wire [2:0] \u_ctrl.cnt_v_sync  ;
wire _373_ ;
wire _429_ ;
wire _182_ ;
wire _658_ ;
wire _238_ ;
wire _467_ ;
wire _696_ ;
wire _276_ ;
wire _33_ ;
wire \u_ball.hit_paddle  ;
wire _599_ ;
wire _179_ ;
wire _71_ ;
wire _620_ ;
wire _200_ ;
wire _714_ ;
wire _523_ ;
wire _103_ ;
wire \u_ctrl.State_3_bF$buf3  ;
wire _332_ ;
wire _68_ ;
wire _561_ ;
wire _141_ ;
wire _617_ ;
wire _370_ ;
wire _426_ ;
wire _655_ ;
wire _235_ ;
wire _464_ ;
wire _693_ ;
wire _273_ ;
wire _329_ ;
wire _558_ ;
wire _138_ ;
wire _30_ ;
wire _367_ ;
wire _596_ ;
wire _176_ ;
wire _499_ ;
wire _711_ ;
wire _27_ ;
wire _520_ ;
wire _100_ ;
wire \u_ctrl.State_3_bF$buf0  ;
wire _65_ ;
wire _614_ ;
wire _423_ ;
wire _652_ ;
wire _232_ ;
wire _708_ ;
wire _461_ ;
wire _517_ ;
wire _690_ ;
wire _270_ ;
wire _326_ ;
wire _555_ ;
wire _135_ ;
wire _364_ ;
wire _593_ ;
wire _173_ ;
wire _649_ ;
wire _229_ ;
wire _458_ ;
wire _687_ ;
wire _267_ ;
wire _496_ ;
wire _24_ ;
wire _62_ ;
wire _399_ ;
wire _611_ ;
wire _420_ ;
wire _705_ ;
wire _514_ ;
wire _323_ ;
wire _59_ ;
wire _552_ ;
wire _132_ ;
wire _608_ ;
wire _361_ ;
wire _417_ ;
wire _97_ ;
wire _590_ ;
wire _170_ ;
wire _646_ ;
wire _226_ ;
wire _455_ ;
wire _684_ ;
wire _264_ ;
wire _493_ ;
wire _549_ ;
wire _129_ ;
wire _21_ ;
wire _358_ ;
wire _587_ ;
wire _167_ ;
wire _396_ ;
wire \u_ball.x2  ;
wire _702_ ;
wire _299_ ;
wire _18_ ;
wire _511_ ;
wire _320_ ;
wire _56_ ;
wire _605_ ;
wire _414_ ;
wire _94_ ;
wire _643_ ;
wire _223_ ;
wire _452_ ;
wire _508_ ;
wire _681_ ;
wire _261_ ;
wire _317_ ;
wire _490_ ;
wire _546_ ;
wire _126_ ;
wire _355_ ;
wire game_over ;
wire _584_ ;
wire _164_ ;
wire _393_ ;
wire _449_ ;
wire _678_ ;
wire _258_ ;
wire _487_ ;
wire _296_ ;
wire _15_ ;
wire _53_ ;
wire _602_ ;
wire _199_ ;
wire _411_ ;
wire _91_ ;
wire _640_ ;
wire _220_ ;
wire _9_ ;
wire _505_ ;
wire _314_ ;
wire _543_ ;
wire _123_ ;
wire _352_ ;
wire _408_ ;
wire _88_ ;
wire _581_ ;
wire _161_ ;
wire _637_ ;
wire _217_ ;
wire _390_ ;
wire _446_ ;
wire _675_ ;
wire _255_ ;
wire _484_ ;
wire _293_ ;
wire _12_ ;
wire _349_ ;
wire _578_ ;
wire _158_ ;
wire _50_ ;
wire _387_ ;
wire _196_ ;
wire _6_ ;
wire _502_ ;
wire _311_ ;
wire _47_ ;
wire _540_ ;
wire _120_ ;
wire [6:1] \u_ball.x_paddle  ;
wire _405_ ;
wire _85_ ;
wire _634_ ;
wire _214_ ;
wire _443_ ;
wire _672_ ;
wire _252_ ;
wire _308_ ;
wire _481_ ;
wire _537_ ;
wire _117_ ;
wire _290_ ;
wire _346_ ;
wire _575_ ;
wire _155_ ;
wire _384_ ;
wire _193_ ;
wire _669_ ;
wire _249_ ;
wire _478_ ;
wire _287_ ;
wire _3_ ;
wire game_complete ;
wire _44_ ;
wire _402_ ;
wire _82_ ;
wire _631_ ;
wire _211_ ;
wire _440_ ;
wire _725_ ;
wire _305_ ;
wire _534_ ;
wire _114_ ;
wire _343_ ;
wire _79_ ;
wire _572_ ;
wire _152_ ;
wire _628_ ;
wire _208_ ;
wire _381_ ;
wire [5:0] \u_ball.y_pos  ;
wire _437_ ;
wire _190_ ;
wire _666_ ;
wire _246_ ;
wire pixel_ball ;
wire _475_ ;
wire _284_ ;
wire _0_ ;
wire v_sync ;
wire _569_ ;
wire _149_ ;
wire _41_ ;
wire _378_ ;
wire _187_ ;
wire _722_ ;
wire _302_ ;
wire _38_ ;
wire _531_ ;
wire _111_ ;
wire _340_ ;
wire _76_ ;
wire _625_ ;
wire _205_ ;
wire _434_ ;
wire _663_ ;
wire _243_ ;
wire _719_ ;
wire _472_ ;
wire _528_ ;
wire _108_ ;
wire _281_ ;
wire _337_ ;
wire _566_ ;
wire _146_ ;
wire _375_ ;
wire _184_ ;
wire _469_ ;
wire _698_ ;
wire _278_ ;
wire _35_ ;
wire _73_ ;
wire _622_ ;
wire _202_ ;
wire _431_ ;
wire _660_ ;
wire _240_ ;
wire _716_ ;
wire _525_ ;
wire _105_ ;
wire _334_ ;
wire _563_ ;
wire _143_ ;
wire _619_ ;
wire _372_ ;
wire _428_ ;
wire _181_ ;
wire _657_ ;
wire _237_ ;
wire _466_ ;
wire _695_ ;
wire _275_ ;
wire _32_ ;
wire _369_ ;
wire _598_ ;
wire _178_ ;
wire _70_ ;
wire _713_ ;
wire _29_ ;
wire _522_ ;
wire _102_ ;
wire \u_ctrl.State_3_bF$buf2  ;
wire _331_ ;
wire _67_ ;
wire _560_ ;
wire _140_ ;
wire _616_ ;
wire _425_ ;
wire _654_ ;
wire _234_ ;
wire _463_ ;
wire _519_ ;
wire _692_ ;
wire _272_ ;
wire game_init ;
wire _328_ ;
wire _557_ ;
wire _137_ ;
wire [4:0] \u_ctrl.State  ;
wire _366_ ;
wire _595_ ;
wire _175_ ;
wire _689_ ;
wire _269_ ;
wire _498_ ;
wire _710_ ;
wire _26_ ;
wire _64_ ;
wire _613_ ;
wire _422_ ;
wire _651_ ;
wire _231_ ;
wire _707_ ;
wire _460_ ;
wire _516_ ;
wire [5:0] \u_ball.y_ball  ;
wire _325_ ;
wire _554_ ;
wire _134_ ;
wire _363_ ;
wire _419_ ;
wire _99_ ;
wire _592_ ;
wire _172_ ;
wire _648_ ;
wire _228_ ;
wire _457_ ;
wire _686_ ;
wire _266_ ;
wire _495_ ;
wire _23_ ;
wire _589_ ;
wire _169_ ;
wire _61_ ;
wire _398_ ;
wire _610_ ;
wire \u_ball.sign_y  ;
wire _704_ ;
wire _513_ ;
wire _673__bF$buf0 ;
wire _673__bF$buf1 ;
wire _673__bF$buf2 ;
wire _673__bF$buf3 ;
wire _322_ ;
wire _58_ ;
wire _551_ ;
wire _131_ ;
wire _607_ ;
wire _360_ ;
wire _416_ ;
wire _96_ ;
wire _645_ ;
wire _225_ ;
wire game_new ;
wire _454_ ;
wire _683_ ;
wire _263_ ;
wire _319_ ;
wire _492_ ;
wire _548_ ;
wire _128_ ;
wire _20_ ;
wire _357_ ;
wire _586_ ;
wire _166_ ;
wire _395_ ;
wire _489_ ;
wire _701_ ;
wire _298_ ;
wire _17_ ;
wire _510_ ;
wire _55_ ;
wire _604_ ;
wire _413_ ;
wire _93_ ;
wire _642_ ;
wire _222_ ;
wire _451_ ;
wire _507_ ;
wire _680_ ;
wire _260_ ;
wire _316_ ;
wire _545_ ;
wire _125_ ;
wire _354_ ;
wire _583_ ;
wire _163_ ;
wire _639_ ;
wire _219_ ;
wire _392_ ;
wire _448_ ;
wire _677_ ;
wire _257_ ;
wire _486_ ;
wire _295_ ;
wire _14_ ;
wire _52_ ;
wire _389_ ;
wire _601_ ;
wire _198_ ;
wire _410_ ;
wire _90_ ;
wire _8_ ;
wire _504_ ;
wire _313_ ;
wire _49_ ;
wire _542_ ;
wire _122_ ;
wire _351_ ;
wire _407_ ;
wire _87_ ;
wire _580_ ;
wire _160_ ;
wire _636_ ;
wire _216_ ;
wire _445_ ;
wire btn_left ;
wire _674_ ;
wire _254_ ;
wire _483_ ;
wire _539_ ;
wire _119_ ;
wire _292_ ;
wire _11_ ;
wire _348_ ;
wire _577_ ;
wire _157_ ;
wire _386_ ;
wire _195_ ;
wire _289_ ;
wire _5_ ;
wire _501_ ;
wire _310_ ;
wire _46_ ;
wire _404_ ;
wire _84_ ;
wire _633_ ;
wire _213_ ;
wire _442_ ;
wire _469__bF$buf0 ;
wire _469__bF$buf1 ;
wire _469__bF$buf2 ;
wire _469__bF$buf3 ;
wire _671_ ;
wire _251_ ;
wire _307_ ;
wire _480_ ;
wire _536_ ;
wire _116_ ;
wire _345_ ;
wire _574_ ;
wire _154_ ;
wire _383_ ;
wire _439_ ;
wire _192_ ;
wire _668_ ;
wire _248_ ;
wire _477_ ;
wire _286_ ;
wire _2_ ;
wire _43_ ;
wire _189_ ;
wire _401_ ;
wire _81_ ;
wire _630_ ;
wire _210_ ;
wire _724_ ;
wire _304_ ;
wire _533_ ;
wire _113_ ;
wire _342_ ;
wire _78_ ;
wire _571_ ;
wire _151_ ;
wire [6:0] \u_ball.x_pos  ;
wire _627_ ;
wire _207_ ;
wire _380_ ;
wire _436_ ;
wire _665_ ;
wire _245_ ;
wire _474_ ;
wire _283_ ;
wire _339_ ;
wire _568_ ;
wire _148_ ;
wire _40_ ;
wire _377_ ;
wire _186_ ;
wire _721_ ;
wire _301_ ;
wire _37_ ;
wire _530_ ;
wire _110_ ;
wire _75_ ;
wire _624_ ;
wire _204_ ;
wire _433_ ;
wire _662_ ;
wire _242_ ;
wire _718_ ;
wire _471_ ;
wire _527_ ;
wire _107_ ;
wire _280_ ;
wire _336_ ;
wire _565_ ;
wire _145_ ;
wire _374_ ;
wire _183_ ;
wire _659_ ;
wire _239_ ;
wire _468_ ;
wire _697_ ;
wire _277_ ;
wire _34_ ;
wire _72_ ;
wire _621_ ;
wire _201_ ;
wire _430_ ;
wire _715_ ;
wire _524_ ;
wire _104_ ;
wire _333_ ;
wire _69_ ;
wire _562_ ;
wire _142_ ;
wire _618_ ;
wire _371_ ;
wire _427_ ;
wire _180_ ;
wire _656_ ;
wire _236_ ;
wire _465_ ;
wire _694_ ;
wire _274_ ;
wire _559_ ;
wire _139_ ;
wire _31_ ;
wire _368_ ;
wire _597_ ;
wire _177_ ;
wire _712_ ;
wire _28_ ;
wire _521_ ;
wire _101_ ;
wire \u_ctrl.State_3_bF$buf1  ;
wire _330_ ;
wire _66_ ;
wire _615_ ;
wire _424_ ;
wire _653_ ;
wire _233_ ;
wire _709_ ;
wire _462_ ;
wire _518_ ;
wire _691_ ;
wire _271_ ;
wire p_tick ;
wire _327_ ;
wire _556_ ;
wire _136_ ;
wire _365_ ;
wire _594_ ;
wire _174_ ;
wire _459_ ;
wire _688_ ;
wire _268_ ;
wire _497_ ;
wire _25_ ;
wire _63_ ;
wire [15:0] \u_bricks.regBricks  ;
wire _612_ ;
wire reset ;
wire _421_ ;
wire _650_ ;
wire _230_ ;
wire _706_ ;
wire _515_ ;
wire _324_ ;
wire _553_ ;
wire _133_ ;
wire _609_ ;
wire _362_ ;
wire _418_ ;
wire _98_ ;
wire _591_ ;
wire _171_ ;
wire _647_ ;
wire _227_ ;
wire _456_ ;
wire _685_ ;
wire _265_ ;
wire _494_ ;
wire _22_ ;
wire _359_ ;

FILL FILL_0__1241_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX2 _1257_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(reset),
    .Y(_434_)
);

INVX1 _800_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [3]),
    .Y(_702_)
);

NAND3X1 _1486_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_636_),
    .B(_635_),
    .C(_637_),
    .Y(_634_)
);

AND2X2 _1066_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_445_),
    .B(_456_),
    .Y(_300_)
);

FILL FILL_0__1106_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1295_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_369_),
    .Y(_365_)
);

DFFSR _1389_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_673__bF$buf3),
    .D(_682_),
    .CLK(clk_bF$buf3),
    .Q(\u_ball.y_pos [3])
);

NAND2X1 _932_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_62_),
    .B(_174_),
    .Y(_58_)
);

INVX1 _1198_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [5]),
    .Y(_131_)
);

FILL FILL_0__1238_ (
    .gnd(gnd),
    .vdd(vdd)
);

MUX2X1 _1410_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_578_),
    .B(\u_ball.x_pos [2]),
    .S(_579_),
    .Y(_669_)
);

DFFSR _741_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_469__bF$buf1),
    .S(vdd),
    .D(_467_),
    .CLK(clk_bF$buf5),
    .Q(\u_ball.x_ball [2])
);

NAND3X1 _970_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_210_),
    .B(_207_),
    .C(_213_),
    .Y(_206_)
);

FILL FILL_0__1276_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _1504_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [6]),
    .B(\u_ball.x_pos [5]),
    .C(_653_),
    .Y(_652_)
);

AND2X2 _835_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_251_),
    .B(_306_),
    .Y(_544_)
);

OAI21X1 _1313_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_430_),
    .B(_420_),
    .C(\u_ball.x_paddle [1]),
    .Y(_382_)
);

DFFSR _1122_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_173_),
    .D(_172_),
    .CLK(clk_bF$buf0),
    .Q(\u_bricks.regBricks [6])
);

OR2X2 _873_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_500_),
    .B(_42_),
    .Y(_501_)
);

FILL FILL_0__926_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _929_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_57_),
    .B(_61_),
    .C(_221_),
    .Y(_55_)
);

NAND2X1 _1351_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_418_),
    .B(_422_),
    .Y(_417_)
);

OAI21X1 _1407_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_657_),
    .B(_654_),
    .C(_576_),
    .Y(_575_)
);

DFFSR _738_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_469__bF$buf2),
    .S(vdd),
    .D(_561_),
    .CLK(clk_bF$buf5),
    .Q(\u_ball.hit_paddle )
);

NAND2X1 _1160_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [2]),
    .B(\u_ball.y_pos [0]),
    .Y(_93_)
);

FILL FILL_0__1200_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1216_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_157_),
    .B(_164_),
    .Y(_143_)
);

FILL FILL_0__964_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _967_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_219_),
    .B(_204_),
    .Y(_203_)
);

AOI21X1 _1445_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_657_),
    .B(_641_),
    .C(_602_),
    .Y(_680_)
);

OAI21X1 _1025_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [6]),
    .B(_284_),
    .C(_306_),
    .Y(_259_)
);

AOI21X1 _776_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_726_),
    .B(_207_),
    .C(game_init),
    .Y(_1_)
);

OR2X2 _1254_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_327_),
    .B(_410_),
    .Y(_326_)
);

INVX1 _1483_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(game_new),
    .Y(_632_)
);

NAND2X1 _1063_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_440_),
    .B(_298_),
    .Y(_297_)
);

FILL FILL_0__1103_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1119_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_173_),
    .D(_177_),
    .CLK(clk_bF$buf7),
    .Q(\u_bricks.regBricks [4])
);

INVX1 _1292_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [0]),
    .Y(_362_)
);

FILL FILL_0__1332_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1348_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_415_),
    .Y(_414_)
);

NAND3X1 _1157_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_95_),
    .B(_91_),
    .C(_98_),
    .Y(_90_)
);

DFFSR _1386_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_673__bF$buf2),
    .S(vdd),
    .D(_672_),
    .CLK(clk_bF$buf6),
    .Q(\u_ctrl.cnt_v_sync [2])
);

AOI21X1 _1195_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_130_),
    .B(\u_bricks.regBricks [2]),
    .C(_129_),
    .Y(_128_)
);

FILL FILL_0__1235_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__999_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1273_ (
    .gnd(gnd),
    .vdd(vdd)
);

OR2X2 _1289_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_360_),
    .B(_373_),
    .Y(_359_)
);

FILL FILL_0__1329_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1501_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_651_),
    .B(_650_),
    .Y(_649_)
);

OAI22X1 _832_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [5]),
    .B(_541_),
    .C(_546_),
    .D(_544_),
    .Y(_547_)
);

INVX2 _1098_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [3]),
    .Y(_449_)
);

INVX1 _1310_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [2]),
    .Y(_380_)
);

NAND3X1 _870_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_494_),
    .B(_496_),
    .C(_503_),
    .Y(_504_)
);

NOR2X1 _926_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [4]),
    .B(_174_),
    .Y(_53_)
);

NAND2X1 _1404_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_574_),
    .B(_614_),
    .Y(_573_)
);

DFFSR _735_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_469__bF$buf1),
    .S(vdd),
    .D(_479_),
    .CLK(clk_bF$buf7),
    .Q(\u_ball.x_ball [5])
);

AOI21X1 _1213_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_144_),
    .B(_141_),
    .C(_148_),
    .Y(_181_)
);

FILL FILL_0__961_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _964_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.sign_x ),
    .B(\u_ball.x_ball [5]),
    .Y(_200_)
);

INVX1 _1442_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_600_),
    .Y(_599_)
);

AOI22X1 _1022_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_257_),
    .B(_283_),
    .C(_286_),
    .D(_303_),
    .Y(_256_)
);

OAI21X1 _773_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_218_),
    .B(_202_),
    .C(_457_),
    .Y(_3_)
);

AND2X2 _829_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_549_),
    .B(_249_),
    .Y(_550_)
);

OAI21X1 _1251_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_380_),
    .B(_419_),
    .C(_324_),
    .Y(_433_)
);

INVX1 _1307_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [1]),
    .Y(_377_)
);

INVX1 _1480_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [0]),
    .Y(_630_)
);

AND2X2 _1060_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_456_),
    .B(_453_),
    .Y(_294_)
);

FILL FILL_0__1100_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1116_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_173_),
    .D(_169_),
    .CLK(clk_bF$buf7),
    .Q(\u_bricks.regBricks [5])
);

NAND2X1 _867_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_502_),
    .B(_501_),
    .Y(_507_)
);

INVX1 _1345_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_412_),
    .Y(_411_)
);

NOR2X1 _1154_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_bricks.regBricks [15]),
    .B(\u_bricks.regBricks [2]),
    .Y(_88_)
);

FILL FILL_0__958_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1383_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_673__bF$buf0),
    .D(_685_),
    .CLK(clk_bF$buf2),
    .Q(\u_ball.y_pos [1])
);

OAI21X1 _1439_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_607_),
    .B(_628_),
    .C(_597_),
    .Y(_679_)
);

NOR2X1 _1019_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [0]),
    .B(\u_ball.x_ball [2]),
    .Y(_253_)
);

FILL FILL_0__767_ (
    .gnd(gnd),
    .vdd(vdd)
);

OR2X2 _1192_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_126_),
    .B(\u_bricks.regBricks [0]),
    .Y(_125_)
);

FILL FILL_0__1232_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1248_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_413_),
    .B(_419_),
    .C(_322_),
    .Y(_432_)
);

FILL FILL_0__996_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _999_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_236_),
    .B(_234_),
    .C(_258_),
    .Y(_233_)
);

FILL FILL73950x3750 (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1477_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_630_),
    .B(_657_),
    .C(_628_),
    .Y(_627_)
);

INVX2 _1057_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [4]),
    .Y(_291_)
);

FILL FILL_0__1270_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1286_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [1]),
    .B(_377_),
    .C(_357_),
    .Y(_356_)
);

FILL FILL_0__1326_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1095_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [3]),
    .Y(_446_)
);

FILL FILL74250x68550 (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _923_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_62_),
    .B(_174_),
    .C(_61_),
    .Y(_50_)
);

NAND3X1 _1189_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_127_),
    .B(_125_),
    .C(_123_),
    .Y(_122_)
);

OAI21X1 _1401_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State_3_bF$buf3 ),
    .B(_595_),
    .C(_615_),
    .Y(_571_)
);

DFFSR _732_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_469__bF$buf3),
    .S(vdd),
    .D(_463_),
    .CLK(clk_bF$buf4),
    .Q(\u_ball.y_ball [5])
);

INVX1 _1210_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_139_),
    .Y(_138_)
);

INVX1 _961_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_198_),
    .Y(_197_)
);

NOR2X1 _770_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_222_),
    .B(_199_),
    .Y(_6_)
);

OAI21X1 _826_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_552_),
    .B(_551_),
    .C(_507_),
    .Y(_553_)
);

NAND2X1 _1304_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_379_),
    .B(_375_),
    .Y(_374_)
);

DFFSR _1113_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_173_),
    .D(_182_),
    .CLK(clk_bF$buf0),
    .Q(\u_bricks.regBricks [8])
);

NOR2X1 _864_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [1]),
    .B(_497_),
    .Y(_510_)
);

AOI21X1 _1342_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_424_),
    .B(_428_),
    .C(\u_ball.x_paddle [2]),
    .Y(_408_)
);

FILL FILL_0__1399_ (
    .gnd(gnd),
    .vdd(vdd)
);

BUFX2 _729_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_723_),
    .Y(p_tick)
);

NAND3X1 _1151_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_152_),
    .B(_148_),
    .C(_86_),
    .Y(_85_)
);

NOR2X1 _1207_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [5]),
    .B(_156_),
    .Y(_136_)
);

OAI21X1 _958_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_201_),
    .B(_197_),
    .C(_195_),
    .Y(_194_)
);

DFFSR _1380_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_673__bF$buf0),
    .D(_669_),
    .CLK(clk_bF$buf3),
    .Q(\u_ball.x_pos [2])
);

AOI21X1 _1436_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_596_),
    .B(_595_),
    .C(game_new),
    .Y(_512_)
);

NOR2X1 _1016_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_306_),
    .B(_251_),
    .Y(_250_)
);

FILL FILL_0__764_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _767_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_306_),
    .B(_7_),
    .C(_8_),
    .Y(_465_)
);

DFFSR _1245_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_434_),
    .S(vdd),
    .D(_438_),
    .CLK(clk_bF$buf1),
    .Q(\u_ball.x_paddle [4])
);

FILL FILL_0__993_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _996_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_458_),
    .B(_231_),
    .C(_237_),
    .Y(_230_)
);

NOR2X1 _1474_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_630_),
    .B(_626_),
    .Y(_625_)
);

OAI21X1 _1054_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_292_),
    .B(_296_),
    .C(_289_),
    .Y(_288_)
);

OR2X2 _1283_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [1]),
    .B(\u_ball.y_pos [2]),
    .Y(_353_)
);

FILL FILL_0__1323_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1339_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_406_),
    .B(_407_),
    .Y(_405_)
);

INVX2 _1092_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [2]),
    .Y(_443_)
);

FILL FILL73650x28950 (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1148_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_bricks.regBricks [0]),
    .Y(_82_)
);

INVX1 _899_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [2]),
    .Y(_28_)
);

FILL FILL_0__1361_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1377_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_673__bF$buf3),
    .D(_684_),
    .CLK(clk_bF$buf1),
    .Q(\u_ball.y_pos [2])
);

FILL FILL_0__1417_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _920_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_196_),
    .B(_48_),
    .Y(_47_)
);

AOI21X1 _1186_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_121_),
    .B(_120_),
    .C(_129_),
    .Y(_119_)
);

NOR2X1 _823_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [5]),
    .B(_457_),
    .Y(_556_)
);

NAND3X1 _1089_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_443_),
    .B(_442_),
    .C(_441_),
    .Y(_440_)
);

FILL FILL74250x54150 (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1301_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [3]),
    .B(_372_),
    .Y(_371_)
);

FILL FILL_0__1358_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1110_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_469__bF$buf0),
    .S(vdd),
    .D(_462_),
    .CLK(clk_bF$buf4),
    .Q(\u_ball.sign_y )
);

OR2X2 _861_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_443_),
    .B(\u_ball.x_pos [2]),
    .Y(_515_)
);

INVX1 _917_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_216_),
    .Y(_45_)
);

FILL FILL_0__1396_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _1204_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_138_),
    .B(_159_),
    .C(_135_),
    .Y(_178_)
);

MUX2X1 _955_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_196_),
    .B(_254_),
    .S(_193_),
    .Y(_478_)
);

INVX1 _1433_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_646_),
    .Y(_593_)
);

NOR2X1 _1013_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [5]),
    .B(\u_ball.x_ball [4]),
    .Y(_247_)
);

FILL FILL_0__761_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _764_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [3]),
    .B(\u_ball.y_ball [4]),
    .C(\u_ball.y_ball [5]),
    .Y(_11_)
);

DFFSR _1242_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_469__bF$buf2),
    .S(vdd),
    .D(_475_),
    .CLK(clk_bF$buf4),
    .Q(\u_ball.y_ball [3])
);

FILL FILL_0__990_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _993_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_229_),
    .B(_237_),
    .C(_228_),
    .Y(_227_)
);

NAND2X1 _1471_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_623_),
    .B(_628_),
    .Y(_622_)
);

OAI21X1 _1051_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [1]),
    .B(\u_ball.x_paddle [2]),
    .C(\u_ball.x_paddle [3]),
    .Y(_285_)
);

NOR2X1 _1107_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(game_init),
    .B(_459_),
    .Y(_458_)
);

OAI21X1 _858_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_510_),
    .B(_513_),
    .C(_519_),
    .Y(_520_)
);

NAND2X1 _1280_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [5]),
    .B(_351_),
    .Y(_350_)
);

FILL FILL_0__1320_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1336_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_416_),
    .B(_423_),
    .Y(_402_)
);

INVX1 _1145_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_bricks.regBricks [10]),
    .Y(_79_)
);

AOI22X1 _896_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_29_),
    .B(_27_),
    .C(_26_),
    .D(_34_),
    .Y(_25_)
);

DFFSR _1374_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_673__bF$buf2),
    .D(_666_),
    .CLK(clk_bF$buf2),
    .Q(\u_ball.x_pos [5])
);

FILL FILL_0__1414_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__758_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1183_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_117_),
    .B(_119_),
    .C(\u_ball.x_pos [6]),
    .Y(_116_)
);

NAND2X1 _1239_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [3]),
    .B(_164_),
    .Y(_163_)
);

FILL FILL_0__987_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1468_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_650_),
    .Y(_620_)
);

INVX1 _1048_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [6]),
    .Y(_282_)
);

FILL FILL_0__796_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _799_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [3]),
    .B(_702_),
    .C(_690_),
    .Y(_703_)
);

INVX1 _1277_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_348_),
    .Y(_347_)
);

FILL FILL_0__1317_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _820_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [4]),
    .Y(_559_)
);

OAI21X1 _1086_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_321_),
    .B(_435_),
    .C(\u_ball.x_ball [2]),
    .Y(_320_)
);

FILL FILL_0__1355_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI22X1 _914_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_46_),
    .B(_43_),
    .C(_45_),
    .D(_196_),
    .Y(_473_)
);

FILL FILL_0__1393_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1449_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _1201_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_133_),
    .B(_159_),
    .C(_134_),
    .Y(_177_)
);

INVX1 _952_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_191_),
    .Y(_190_)
);

AOI21X1 _1430_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_592_),
    .B(_591_),
    .C(_593_),
    .Y(_516_)
);

NAND3X1 _1010_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_246_),
    .B(_245_),
    .C(_249_),
    .Y(_244_)
);

AOI21X1 _761_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_13_),
    .B(_9_),
    .C(game_init),
    .Y(_464_)
);

AOI22X1 _817_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_457_),
    .B(\u_ball.x_pos [5]),
    .C(_306_),
    .D(\u_ball.x_pos [6]),
    .Y(_674_)
);

INVX1 _990_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x2 ),
    .Y(_225_)
);

INVX1 _1104_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_456_),
    .Y(_455_)
);

NAND2X1 _855_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_520_),
    .B(_522_),
    .Y(_523_)
);

NAND3X1 _1333_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_431_),
    .B(_419_),
    .C(_400_),
    .Y(_399_)
);

NOR2X1 _1142_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_80_),
    .B(_77_),
    .Y(_76_)
);

AOI21X1 _893_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_471_),
    .B(_35_),
    .C(_470_),
    .Y(_472_)
);

AOI21X1 _949_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_188_),
    .B(\u_ball.y_ball [0]),
    .C(_196_),
    .Y(_187_)
);

DFFSR _1371_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_673__bF$buf1),
    .S(vdd),
    .D(_514_),
    .CLK(clk_bF$buf3),
    .Q(\u_ctrl.State [3])
);

FILL FILL_0__1411_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _1427_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_645_),
    .B(_633_),
    .C(_590_),
    .Y(_528_)
);

AOI21X1 _1007_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_256_),
    .B(_458_),
    .C(_242_),
    .Y(_241_)
);

FILL FILL_0__755_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _758_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_15_),
    .B(_14_),
    .C(_222_),
    .Y(_16_)
);

NAND2X1 _1180_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_bricks.regBricks [7]),
    .B(\u_ball.x_pos [3]),
    .Y(_113_)
);

AND2X2 _1236_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_725_),
    .B(hit_brick),
    .Y(_160_)
);

INVX2 _987_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_725_),
    .Y(_222_)
);

NAND2X1 _1465_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_618_),
    .B(_628_),
    .Y(_617_)
);

NAND2X1 _1045_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_446_),
    .B(_321_),
    .Y(_279_)
);

FILL FILL_0__793_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _796_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_675_),
    .B(_705_),
    .C(_555_),
    .Y(_706_)
);

OAI21X1 _1274_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [3]),
    .B(_372_),
    .C(_368_),
    .Y(_344_)
);

FILL FILL_0__1314_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI22X1 _1083_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [1]),
    .B(\u_ball.x_paddle [1]),
    .C(\u_ball.x_ball [0]),
    .D(_318_),
    .Y(_317_)
);

INVX1 _1139_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_bricks.regBricks [6]),
    .Y(_75_)
);

FILL FILL_0__1352_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1368_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_673__bF$buf2),
    .S(vdd),
    .D(_516_),
    .CLK(clk_bF$buf6),
    .Q(\u_ctrl.State [2])
);

FILL FILL_0__1408_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _911_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [0]),
    .B(_46_),
    .Y(_40_)
);

NAND3X1 _1177_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_bricks.regBricks [4]),
    .B(_130_),
    .C(_129_),
    .Y(_110_)
);

FILL FILL_0__1390_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1446_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL74250x61350 (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _814_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [5]),
    .Y(_678_)
);

FILL FILL74250x28950 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL73950x43350 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1349_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1521_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_173_),
    .D(_166_),
    .CLK(clk_bF$buf0),
    .Q(\u_bricks.regBricks [12])
);

INVX1 _1101_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [5]),
    .Y(_452_)
);

NAND3X1 _852_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_46_),
    .B(_299_),
    .C(_443_),
    .Y(_526_)
);

NOR2X1 _908_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [0]),
    .B(_193_),
    .Y(_37_)
);

AOI22X1 _1330_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [3]),
    .B(_428_),
    .C(_407_),
    .D(_406_),
    .Y(_396_)
);

INVX1 _890_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_470_),
    .Y(_484_)
);

OAI21X1 _946_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_193_),
    .B(_189_),
    .C(_191_),
    .Y(_185_)
);

OAI21X1 _1424_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_657_),
    .B(_638_),
    .C(_589_),
    .Y(_588_)
);

OAI22X1 _1004_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_282_),
    .B(\u_ball.x_ball [6]),
    .C(_450_),
    .D(_307_),
    .Y(_238_)
);

FILL FILL_0__752_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _755_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [5]),
    .Y(_18_)
);

INVX1 _1233_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [5]),
    .Y(_158_)
);

OAI22X1 _984_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_225_),
    .B(_223_),
    .C(_220_),
    .D(_256_),
    .Y(_480_)
);

INVX1 _1462_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [5]),
    .Y(_615_)
);

NOR2X1 _1042_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_321_),
    .B(_435_),
    .Y(_276_)
);

FILL FILL_0__790_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _793_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_694_),
    .B(_675_),
    .C(_704_),
    .Y(_708_)
);

INVX1 _1518_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(pixel_brick),
    .Y(_718_)
);

OAI21X1 _849_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_449_),
    .B(_529_),
    .C(_291_),
    .Y(_530_)
);

OAI21X1 _1271_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_416_),
    .B(\u_ball.x_pos [4]),
    .C(_346_),
    .Y(_341_)
);

FILL FILL_0__1311_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI22X1 _1327_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_394_),
    .B(_403_),
    .C(_397_),
    .D(_395_),
    .Y(_393_)
);

NAND2X1 _1080_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_456_),
    .B(_445_),
    .Y(_314_)
);

INVX1 _1136_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_bricks.regBricks [9]),
    .Y(_73_)
);

NAND3X1 _887_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_486_),
    .B(_35_),
    .C(_34_),
    .Y(_487_)
);

INVX1 _1365_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [6]),
    .Y(_431_)
);

FILL FILL_0__1405_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__749_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _1174_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_111_),
    .B(_110_),
    .C(_108_),
    .Y(_107_)
);

FILL FILL_0__1443_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1459_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_652_),
    .B(_613_),
    .Y(_612_)
);

NAND2X1 _1039_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [0]),
    .B(_318_),
    .Y(_273_)
);

FILL FILL_0__787_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1268_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [5]),
    .Y(_338_)
);

FILL FILL_0__1308_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1481_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _811_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_34_),
    .B(_29_),
    .C(_26_),
    .Y(_691_)
);

OAI21X1 _1497_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_722_),
    .B(_0_),
    .C(\u_ctrl.State_3_bF$buf0 ),
    .Y(_645_)
);

NAND2X1 _1077_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_312_),
    .B(_313_),
    .Y(_311_)
);

FILL FILL_0__1346_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _905_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [1]),
    .B(_192_),
    .Y(_34_)
);

NOR2X1 _943_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_175_),
    .B(_174_),
    .Y(_68_)
);

FILL FILL74250x14550 (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1421_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State_3_bF$buf1 ),
    .B(_586_),
    .Y(_585_)
);

NAND2X1 _1001_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_268_),
    .B(_281_),
    .Y(_235_)
);

OAI21X1 _752_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.sign_y ),
    .B(_223_),
    .C(_44_),
    .Y(_21_)
);

FILL FILL_0__1478_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _808_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_693_),
    .B(_692_),
    .C(_690_),
    .Y(_694_)
);

OR2X2 _1230_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_156_),
    .B(_158_),
    .Y(_155_)
);

NAND3X1 _981_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.sign_x ),
    .B(\u_ball.x_ball [1]),
    .C(_225_),
    .Y(_217_)
);

NAND3X1 _790_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(pixel_brick),
    .B(_709_),
    .C(_710_),
    .Y(_711_)
);

INVX1 _1515_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_723_),
    .Y(_663_)
);

NAND2X1 _846_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [3]),
    .B(_526_),
    .Y(_533_)
);

OAI21X1 _1324_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_416_),
    .B(btn_left),
    .C(_402_),
    .Y(_391_)
);

OAI21X1 _1133_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_154_),
    .B(_72_),
    .C(\u_bricks.regBricks [13]),
    .Y(_71_)
);

NAND3X1 _884_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_485_),
    .B(_489_),
    .C(_483_),
    .Y(_490_)
);

INVX2 _1362_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(btn_left),
    .Y(_428_)
);

FILL FILL_0__1402_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1418_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [0]),
    .Y(_583_)
);

INVX1 _749_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_22_),
    .Y(_23_)
);

AOI21X1 _1171_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_105_),
    .B(_106_),
    .C(_129_),
    .Y(_104_)
);

INVX1 _1227_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_153_),
    .Y(_183_)
);

NAND2X1 _978_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_217_),
    .B(_215_),
    .Y(_214_)
);

FILL FILL_0__1440_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1456_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_649_),
    .B(_611_),
    .C(\u_ctrl.State_3_bF$buf2 ),
    .Y(_610_)
);

NAND3X1 _1036_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_275_),
    .B(_271_),
    .C(_277_),
    .Y(_270_)
);

FILL FILL_0__784_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _787_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_712_),
    .B(_459_),
    .C(_254_),
    .Y(_561_)
);

OAI21X1 _1265_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [2]),
    .B(_376_),
    .C(_366_),
    .Y(_335_)
);

FILL FILL_0__1305_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1494_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State [1]),
    .B(\u_ctrl.State [2]),
    .C(_645_),
    .Y(_642_)
);

OAI21X1 _1074_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [4]),
    .B(_311_),
    .C(_309_),
    .Y(_308_)
);

BUFX2 BUFX2_insert0 (
    .gnd(gnd),
    .vdd(vdd),
    .A(_673_),
    .Y(_673__bF$buf3)
);

BUFX2 BUFX2_insert1 (
    .gnd(gnd),
    .vdd(vdd),
    .A(_673_),
    .Y(_673__bF$buf2)
);

BUFX2 BUFX2_insert2 (
    .gnd(gnd),
    .vdd(vdd),
    .A(_673_),
    .Y(_673__bF$buf1)
);

BUFX2 BUFX2_insert3 (
    .gnd(gnd),
    .vdd(vdd),
    .A(_673_),
    .Y(_673__bF$buf0)
);

FILL FILL_0__1343_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1359_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [2]),
    .B(\u_ball.x_paddle [3]),
    .Y(_425_)
);

OAI21X1 _902_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [0]),
    .B(_32_),
    .C(_33_),
    .Y(_31_)
);

NAND3X1 _1168_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [6]),
    .B(_102_),
    .C(_103_),
    .Y(_101_)
);

AOI21X1 _1397_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_662_),
    .B(_595_),
    .C(\u_ctrl.State_3_bF$buf1 ),
    .Y(_568_)
);

FILL FILL_0__1437_ (
    .gnd(gnd),
    .vdd(vdd)
);

AND2X2 _940_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_66_),
    .B(_185_),
    .Y(_65_)
);

FILL FILL_0__1475_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _805_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_175_),
    .B(\u_ball.y_pos [2]),
    .C(_691_),
    .Y(_697_)
);

FILL FILL73950x50550 (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1512_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_661_),
    .Y(_660_)
);

OAI21X1 _843_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_510_),
    .B(_513_),
    .C(_515_),
    .Y(_536_)
);

NAND3X1 _1321_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_419_),
    .B(_389_),
    .C(_390_),
    .Y(_388_)
);

AOI21X1 _1130_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_70_),
    .B(_159_),
    .C(_83_),
    .Y(_169_)
);

NAND2X1 _881_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_487_),
    .B(_492_),
    .Y(_493_)
);

OAI21X1 _937_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_64_),
    .B(_65_),
    .C(_63_),
    .Y(_476_)
);

AOI21X1 _1415_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_657_),
    .B(\u_ctrl.State [0]),
    .C(_582_),
    .Y(_581_)
);

DFFSR _746_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_469__bF$buf3),
    .S(vdd),
    .D(_478_),
    .CLK(clk_bF$buf1),
    .Q(\u_ball.y_ball [0])
);

NAND2X1 _1224_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_157_),
    .B(_164_),
    .Y(_150_)
);

NAND2X1 _975_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [2]),
    .B(_460_),
    .Y(_211_)
);

INVX1 _1453_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [5]),
    .Y(_608_)
);

AND2X2 _1033_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_281_),
    .B(_268_),
    .Y(_267_)
);

FILL FILL_0__781_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _784_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_216_),
    .B(_214_),
    .C(_221_),
    .Y(_714_)
);

INVX4 _1509_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State_3_bF$buf2 ),
    .Y(_657_)
);

OAI21X1 _1262_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_416_),
    .B(\u_ball.x_pos [4]),
    .C(_350_),
    .Y(_332_)
);

FILL FILL_0__1302_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1318_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_418_),
    .B(_428_),
    .C(_417_),
    .Y(_386_)
);

NOR3X1 _1491_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_658_),
    .B(_640_),
    .C(_647_),
    .Y(_639_)
);

INVX1 _1071_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_454_),
    .Y(_305_)
);

INVX1 _1127_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_bricks.regBricks [12]),
    .Y(_69_)
);

NAND3X1 _878_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_485_),
    .B(_483_),
    .C(_495_),
    .Y(_496_)
);

FILL FILL_0__1340_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1356_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_423_),
    .Y(_422_)
);

NOR2X1 _1165_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [4]),
    .B(_99_),
    .Y(_98_)
);

OAI21X1 _1394_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_661_),
    .B(_566_),
    .C(\u_ctrl.State [1]),
    .Y(_565_)
);

FILL FILL_0__1434_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__778_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1259_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_346_),
    .B(_331_),
    .C(_330_),
    .Y(_329_)
);

FILL FILL_0__1472_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _802_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_54_),
    .B(\u_ball.y_pos [4]),
    .C(_699_),
    .Y(_700_)
);

INVX1 _1488_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_640_),
    .Y(_636_)
);

NOR2X1 _1068_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [6]),
    .B(_306_),
    .Y(_302_)
);

AND2X2 _1297_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_379_),
    .B(_375_),
    .Y(_367_)
);

FILL FILL_0__1337_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI22X1 _840_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [4]),
    .B(_531_),
    .C(_535_),
    .D(_538_),
    .Y(_539_)
);

NOR2X1 _934_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_62_),
    .B(_174_),
    .Y(_60_)
);

FILL FILL74250x21750 (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1412_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [1]),
    .B(_582_),
    .Y(_579_)
);

DFFSR _743_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_469__bF$buf0),
    .S(vdd),
    .D(_468_),
    .CLK(clk_bF$buf4),
    .Q(\u_ball.x_ball [1])
);

FILL FILL_0__1469_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1221_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_bricks.regBricks [11]),
    .Y(_148_)
);

NAND2X1 _972_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [3]),
    .B(_460_),
    .Y(_208_)
);

FILL FILL74250x3750 (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1450_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_607_),
    .B(_606_),
    .C(_608_),
    .Y(_605_)
);

INVX1 _1030_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_265_),
    .Y(_264_)
);

OAI21X1 _781_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_213_),
    .B(_210_),
    .C(_715_),
    .Y(_719_)
);

NAND3X1 _1506_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [1]),
    .B(\u_ball.x_pos [0]),
    .C(\u_ball.x_pos [2]),
    .Y(_654_)
);

AOI22X1 _837_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [4]),
    .B(_531_),
    .C(_541_),
    .D(\u_ball.x_pos [5]),
    .Y(_542_)
);

OAI21X1 _1315_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_430_),
    .B(_420_),
    .C(\u_ball.x_paddle [5]),
    .Y(_383_)
);

DFFSR _1124_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_173_),
    .D(_176_),
    .CLK(clk_bF$buf0),
    .Q(\u_bricks.regBricks [3])
);

NAND2X1 _875_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [1]),
    .B(_299_),
    .Y(_499_)
);

NOR2X1 _1353_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_430_),
    .B(_420_),
    .Y(_419_)
);

OR2X2 _1409_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_654_),
    .B(_657_),
    .Y(_577_)
);

NAND2X1 _1162_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_97_),
    .B(_96_),
    .Y(_95_)
);

NAND2X1 _1218_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_146_),
    .B(_147_),
    .Y(_145_)
);

OAI21X1 _969_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [2]),
    .B(\u_ball.x_ball [3]),
    .C(\u_ball.sign_x ),
    .Y(_205_)
);

NAND2X1 _1391_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.cnt_v_sync [0]),
    .B(_588_),
    .Y(_563_)
);

FILL FILL_0__1431_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1447_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_608_),
    .B(_628_),
    .C(_603_),
    .Y(_681_)
);

AOI21X1 _1027_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_270_),
    .B(_266_),
    .C(_262_),
    .Y(_261_)
);

FILL FILL_0__775_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _778_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_210_),
    .B(_213_),
    .Y(_721_)
);

INVX1 _1256_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_408_),
    .Y(_328_)
);

OAI21X1 _1485_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_663_),
    .B(_639_),
    .C(_634_),
    .Y(_688_)
);

INVX2 _1065_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [1]),
    .Y(_299_)
);

FILL FILL73350x28950 (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _1294_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_379_),
    .B(_366_),
    .C(_365_),
    .Y(_364_)
);

FILL FILL_0__1334_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0_BUFX2_insert12 (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1159_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [1]),
    .B(_93_),
    .Y(_92_)
);

FILL FILL_0_BUFX2_insert15 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0_BUFX2_insert18 (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1388_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_673__bF$buf0),
    .D(_679_),
    .CLK(clk_bF$buf2),
    .Q(\u_ball.y_pos [4])
);

FILL FILL_0__1428_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _931_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_58_),
    .B(_59_),
    .Y(_57_)
);

INVX2 _1197_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [3]),
    .Y(_130_)
);

DFFSR _740_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_469__bF$buf3),
    .S(vdd),
    .D(_477_),
    .CLK(clk_bF$buf4),
    .Q(\u_ball.y_ball [1])
);

FILL FILL_0__1466_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1503_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [3]),
    .Y(_651_)
);

INVX1 _834_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [6]),
    .Y(_545_)
);

NAND2X1 _1312_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_410_),
    .B(_419_),
    .Y(_381_)
);

DFFSR _1121_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_173_),
    .D(_181_),
    .CLK(clk_bF$buf7),
    .Q(\u_bricks.regBricks [11])
);

NAND2X1 _872_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_42_),
    .B(_500_),
    .Y(_502_)
);

OAI22X1 _928_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_62_),
    .B(_254_),
    .C(_55_),
    .D(_56_),
    .Y(_475_)
);

INVX2 _1350_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [4]),
    .Y(_416_)
);

OAI21X1 _1406_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [3]),
    .B(_577_),
    .C(_575_),
    .Y(_668_)
);

DFFSR _737_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_469__bF$buf1),
    .S(vdd),
    .D(_465_),
    .CLK(clk_bF$buf5),
    .Q(\u_ball.x_ball [6])
);

NAND2X1 _1215_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_160_),
    .B(_143_),
    .Y(_142_)
);

AOI21X1 _966_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_206_),
    .B(_205_),
    .C(_203_),
    .Y(_202_)
);

NOR2X1 _1444_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_607_),
    .B(_606_),
    .Y(_601_)
);

OAI21X1 _1024_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [5]),
    .B(_260_),
    .C(_259_),
    .Y(_258_)
);

FILL FILL_0__772_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _775_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_207_),
    .B(_726_),
    .C(_1_),
    .Y(_2_)
);

FILL FILL_0__828_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1253_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_410_),
    .B(_327_),
    .Y(_325_)
);

NAND2X1 _1309_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [2]),
    .B(_380_),
    .Y(_379_)
);

AOI21X1 _1482_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_632_),
    .B(\u_ctrl.State [0]),
    .C(game_init),
    .Y(_631_)
);

AOI22X1 _1062_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_449_),
    .B(_300_),
    .C(_297_),
    .D(_320_),
    .Y(_296_)
);

DFFSR _1118_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_173_),
    .D(_170_),
    .CLK(clk_bF$buf0),
    .Q(\u_bricks.regBricks [13])
);

NAND3X1 _869_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_485_),
    .B(_493_),
    .C(_483_),
    .Y(_505_)
);

OAI21X1 _1291_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [1]),
    .B(_377_),
    .C(_374_),
    .Y(_361_)
);

INVX1 _1347_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [3]),
    .Y(_413_)
);

AOI21X1 _1156_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_100_),
    .B(\u_ball.x_pos [5]),
    .C(_90_),
    .Y(_89_)
);

DFFSR _1385_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_673__bF$buf3),
    .D(_681_),
    .CLK(clk_bF$buf3),
    .Q(\u_ball.y_pos [5])
);

FILL FILL_0__1425_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__769_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1194_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_132_),
    .B(_130_),
    .C(_128_),
    .Y(_127_)
);

FILL FILL_0__1463_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1479_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State_3_bF$buf3 ),
    .B(\u_ctrl.State [0]),
    .C(_645_),
    .Y(_629_)
);

OAI21X1 _1059_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_295_),
    .B(_294_),
    .C(\u_ball.x_ball [4]),
    .Y(_293_)
);

OR2X2 _1288_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_359_),
    .B(_363_),
    .Y(_358_)
);

NAND3X1 _1500_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [5]),
    .B(\u_ball.y_pos [4]),
    .C(_649_),
    .Y(_648_)
);

NAND2X1 _831_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [6]),
    .B(_544_),
    .Y(_548_)
);

INVX1 _1097_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [1]),
    .Y(_448_)
);

FILL FILL_0__1137_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _925_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.sign_y ),
    .B(_54_),
    .Y(_52_)
);

FILL FILL73950x10950 (
    .gnd(gnd),
    .vdd(vdd)
);

AOI22X1 _1403_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_655_),
    .B(_643_),
    .C(_573_),
    .D(\u_ctrl.State_3_bF$buf0 ),
    .Y(_667_)
);

FILL FILL_0__731_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _734_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_469__bF$buf2),
    .S(vdd),
    .D(_464_),
    .CLK(clk_bF$buf4),
    .Q(_722_)
);

INVX1 _1212_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_bricks.regBricks [15]),
    .Y(_140_)
);

NOR2X1 _963_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_460_),
    .B(_457_),
    .Y(_199_)
);

OAI21X1 _1441_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_599_),
    .B(_601_),
    .C(\u_ctrl.State_3_bF$buf2 ),
    .Y(_598_)
);

NOR2X1 _1021_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(game_init),
    .B(_725_),
    .Y(_255_)
);

AND2X2 _772_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_206_),
    .B(_205_),
    .Y(_4_)
);

FILL FILL_0__1498_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__825_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _828_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_496_),
    .B(_494_),
    .C(_38_),
    .Y(_551_)
);

OR2X2 _1250_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_407_),
    .B(_406_),
    .Y(_323_)
);

INVX1 _1306_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [2]),
    .Y(_376_)
);

DFFSR _1115_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_173_),
    .D(_180_),
    .CLK(clk_bF$buf7),
    .Q(\u_bricks.regBricks [15])
);

NAND3X1 _866_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_507_),
    .B(_505_),
    .C(_506_),
    .Y(_508_)
);

INVX1 _1344_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [1]),
    .Y(_410_)
);

FILL FILL_0__728_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _1153_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_135_),
    .B(_134_),
    .C(_88_),
    .Y(_87_)
);

AOI21X1 _1209_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_138_),
    .B(_151_),
    .C(_140_),
    .Y(_180_)
);

DFFSR _1382_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_673__bF$buf3),
    .D(_670_),
    .CLK(clk_bF$buf1),
    .Q(\u_ball.x_pos [1])
);

FILL FILL_0__1422_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1438_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State [4]),
    .Y(_596_)
);

AOI21X1 _1018_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_253_),
    .B(_299_),
    .C(_449_),
    .Y(_252_)
);

NAND3X1 _769_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_6_),
    .B(_3_),
    .C(_5_),
    .Y(_7_)
);

NOR2X1 _1191_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [4]),
    .B(_130_),
    .Y(_124_)
);

DFFSR _1247_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_434_),
    .S(vdd),
    .D(_437_),
    .CLK(clk_bF$buf1),
    .Q(\u_ball.x_paddle [5])
);

NOR2X1 _998_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_306_),
    .B(_280_),
    .Y(_232_)
);

FILL FILL_0__1460_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1476_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_630_),
    .B(_628_),
    .C(_627_),
    .Y(_686_)
);

NAND3X1 _1056_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_291_),
    .B(_312_),
    .C(_313_),
    .Y(_290_)
);

NOR2X1 _1285_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_356_),
    .B(_366_),
    .Y(_355_)
);

OAI21X1 _1094_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_448_),
    .B(_447_),
    .C(_446_),
    .Y(_445_)
);

FILL FILL_0__1134_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1363_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1379_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_673__bF$buf1),
    .S(vdd),
    .D(_687_),
    .CLK(clk_bF$buf3),
    .Q(game_init)
);

FILL FILL_0__1419_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _922_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_58_),
    .B(_51_),
    .C(_50_),
    .Y(_49_)
);

NAND2X1 _1188_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_bricks.regBricks [10]),
    .B(_130_),
    .Y(_121_)
);

OAI21X1 _1400_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_657_),
    .B(_614_),
    .C(_571_),
    .Y(_570_)
);

BUFX2 _731_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_0_),
    .Y(game_complete)
);

FILL FILL_0__1457_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX2 _960_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_221_),
    .Y(_196_)
);

FILL FILL73650x43350 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1495_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__822_ (
    .gnd(gnd),
    .vdd(vdd)
);

AND2X2 _825_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_504_),
    .B(_523_),
    .Y(_554_)
);

AOI21X1 _1303_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [1]),
    .B(_377_),
    .C(_374_),
    .Y(_373_)
);

DFFSR _1112_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_173_),
    .D(_167_),
    .CLK(clk_bF$buf0),
    .Q(\u_bricks.regBricks [0])
);

FILL FILL_0__860_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _863_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [0]),
    .Y(_511_)
);

FILL FILL_0__1169_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI22X1 _919_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_54_),
    .B(_255_),
    .C(_47_),
    .D(_49_),
    .Y(_474_)
);

OAI21X1 _1341_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_410_),
    .B(_408_),
    .C(_409_),
    .Y(_407_)
);

BUFX2 _728_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_724_),
    .Y(pixel)
);

NOR2X1 _1150_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_87_),
    .B(_85_),
    .Y(_84_)
);

AOI21X1 _1206_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_136_),
    .B(_159_),
    .C(_137_),
    .Y(_179_)
);

OAI21X1 _957_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_457_),
    .B(_254_),
    .C(_194_),
    .Y(_479_)
);

NAND2X1 _1435_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State [2]),
    .B(_646_),
    .Y(_594_)
);

INVX1 _1015_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_250_),
    .Y(_249_)
);

INVX1 _766_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_722_),
    .Y(_9_)
);

FILL FILL_0__819_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1244_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_434_),
    .S(vdd),
    .D(_433_),
    .CLK(clk_bF$buf1),
    .Q(\u_ball.x_paddle [2])
);

INVX1 _995_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_458_),
    .Y(_229_)
);

NOR2X1 _1473_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [0]),
    .B(\u_ball.y_pos [1]),
    .Y(_624_)
);

NAND3X1 _1053_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_305_),
    .B(_301_),
    .C(_288_),
    .Y(_287_)
);

FILL FILL_0__1513_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX2 _1109_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.sign_x ),
    .Y(_460_)
);

FILL FILL_0__857_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _1282_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_358_),
    .B(_354_),
    .C(_353_),
    .Y(_352_)
);

NAND3X1 _1338_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_414_),
    .B(_411_),
    .C(_405_),
    .Y(_404_)
);

NAND2X1 _1091_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [1]),
    .B(\u_ball.x_paddle [2]),
    .Y(_442_)
);

FILL FILL_0__1131_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1147_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_bricks.regBricks [9]),
    .B(\u_bricks.regBricks [6]),
    .Y(_81_)
);

NAND2X1 _898_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [2]),
    .B(_28_),
    .Y(_27_)
);

DFFSR _1376_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_673__bF$buf1),
    .D(_667_),
    .CLK(clk_bF$buf6),
    .Q(\u_ball.x_pos [4])
);

NAND3X1 _1185_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_bricks.regBricks [9]),
    .B(\u_ball.x_pos [3]),
    .C(_129_),
    .Y(_118_)
);

FILL FILL_0__1454_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__798_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1279_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [6]),
    .Y(_349_)
);

FILL FILL_0__1492_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _822_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [3]),
    .B(_449_),
    .Y(_557_)
);

AND2X2 _1088_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [1]),
    .B(\u_ball.x_paddle [2]),
    .Y(_435_)
);

FILL FILL_0__1128_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1300_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [3]),
    .B(_413_),
    .Y(_370_)
);

NAND2X1 _860_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [2]),
    .B(_443_),
    .Y(_518_)
);

FILL FILL_0__1166_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _916_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(game_init),
    .Y(_44_)
);

INVX1 _1203_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_bricks.regBricks [4]),
    .Y(_134_)
);

INVX1 _954_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [1]),
    .Y(_192_)
);

OAI21X1 _1432_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_648_),
    .B(_652_),
    .C(\u_ctrl.State_3_bF$buf3 ),
    .Y(_592_)
);

NAND3X1 _1012_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_306_),
    .B(_248_),
    .C(_247_),
    .Y(_246_)
);

INVX1 _763_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_11_),
    .Y(_12_)
);

FILL FILL_0__1489_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__816_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI22X1 _819_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_559_),
    .B(\u_ball.x_ball [4]),
    .C(\u_ball.x_ball [3]),
    .D(_532_),
    .Y(_560_)
);

INVX1 _1241_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_bricks.regBricks [1]),
    .Y(_165_)
);

NAND3X1 _992_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_230_),
    .B(_243_),
    .C(_227_),
    .Y(_226_)
);

FILL FILL73950x72150 (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1470_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_626_),
    .B(_628_),
    .C(_622_),
    .Y(_685_)
);

NOR3X1 _1050_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_453_),
    .B(_452_),
    .C(_285_),
    .Y(_284_)
);

FILL FILL_0__1510_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX2 _1106_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [5]),
    .Y(_457_)
);

FILL FILL_0__854_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _857_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_510_),
    .B(_41_),
    .C(_498_),
    .Y(_521_)
);

NAND3X1 _1335_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_403_),
    .B(_402_),
    .C(_404_),
    .Y(_401_)
);

NOR2X1 _1144_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_bricks.regBricks [13]),
    .B(\u_bricks.regBricks [12]),
    .Y(_78_)
);

FILL FILL_0__892_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _895_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_29_),
    .B(_27_),
    .Y(_470_)
);

DFFSR _1373_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_673__bF$buf0),
    .D(_683_),
    .CLK(clk_bF$buf2),
    .Q(\u_ball.x_pos [6])
);

NOR2X1 _1429_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_593_),
    .B(_637_),
    .Y(_517_)
);

AND2X2 _1009_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_244_),
    .B(_254_),
    .Y(_243_)
);

NAND3X1 _1182_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_131_),
    .B(_116_),
    .C(_122_),
    .Y(_115_)
);

NOR2X1 _1238_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [5]),
    .B(_163_),
    .Y(_162_)
);

OAI21X1 _989_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(game_init),
    .B(\u_ball.hit_paddle ),
    .C(_254_),
    .Y(_224_)
);

FILL FILL_0__1451_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1467_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [2]),
    .B(_625_),
    .Y(_619_)
);

OR2X2 _1047_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_285_),
    .B(_453_),
    .Y(_281_)
);

AOI21X1 _798_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_701_),
    .B(_703_),
    .C(_696_),
    .Y(_704_)
);

FILL FILL_0__1507_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1276_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [5]),
    .B(_351_),
    .C(_347_),
    .Y(_346_)
);

NAND2X1 _1085_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [1]),
    .B(\u_ball.x_paddle [1]),
    .Y(_319_)
);

FILL FILL_0__889_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1163_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _913_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [0]),
    .B(_46_),
    .Y(_42_)
);

AOI21X1 _1179_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_114_),
    .B(_113_),
    .C(_129_),
    .Y(_112_)
);

INVX1 _1200_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_bricks.regBricks [3]),
    .Y(_132_)
);

FILL FILL73650x50550 (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _951_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [1]),
    .B(\u_ball.sign_y ),
    .Y(_189_)
);

NAND3X1 _760_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_59_),
    .B(_53_),
    .C(_61_),
    .Y(_14_)
);

FILL FILL_0__1486_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__813_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _816_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_556_),
    .B(_562_),
    .C(_674_),
    .Y(_675_)
);

DFFSR _1523_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_673__bF$buf2),
    .S(vdd),
    .D(_664_),
    .CLK(clk_bF$buf6),
    .Q(\u_ctrl.cnt_v_sync [0])
);

NAND3X1 _1103_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [4]),
    .B(\u_ball.x_paddle [5]),
    .C(_455_),
    .Y(_454_)
);

FILL FILL_0__851_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _854_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_523_),
    .Y(_524_)
);

INVX1 _1332_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_419_),
    .Y(_398_)
);

AND2X2 _1141_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_84_),
    .B(_76_),
    .Y(_0_)
);

OAI21X1 _892_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_25_),
    .B(_472_),
    .C(_30_),
    .Y(_482_)
);

FILL FILL_0__1198_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _948_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [0]),
    .B(_188_),
    .C(_187_),
    .Y(_186_)
);

DFFSR _1370_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_673__bF$buf1),
    .D(_528_),
    .CLK(clk_bF$buf0),
    .Q(\u_ctrl.State [0])
);

FILL FILL74250x43350 (
    .gnd(gnd),
    .vdd(vdd)
);

INVX8 _1426_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(reset),
    .Y(_673_)
);

INVX1 _1006_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_302_),
    .Y(_240_)
);

OAI21X1 _757_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [5]),
    .B(_16_),
    .C(_44_),
    .Y(_17_)
);

AND2X2 _1235_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_160_),
    .B(_161_),
    .Y(_159_)
);

NOR2X1 _986_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(game_init),
    .B(_222_),
    .Y(_221_)
);

OAI21X1 _1464_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_621_),
    .B(_628_),
    .C(_617_),
    .Y(_684_)
);

NAND2X1 _1044_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_285_),
    .B(_279_),
    .Y(_278_)
);

NOR3X1 _795_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_525_),
    .B(_550_),
    .C(_706_),
    .Y(pixel_ball)
);

FILL FILL_0__1504_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__848_ (
    .gnd(gnd),
    .vdd(vdd)
);

OR2X2 _1273_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [4]),
    .B(\u_ball.x_pos [4]),
    .Y(_343_)
);

AND2X2 _1329_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_396_),
    .B(_414_),
    .Y(_395_)
);

NAND3X1 _1082_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_319_),
    .B(_317_),
    .C(_320_),
    .Y(_316_)
);

INVX1 _1138_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_155_),
    .Y(_74_)
);

FILL FILL_0__886_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _889_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_34_),
    .B(_26_),
    .C(_484_),
    .Y(_485_)
);

DFFSR _1367_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_673__bF$buf3),
    .D(_686_),
    .CLK(clk_bF$buf1),
    .Q(\u_ball.y_pos [0])
);

FILL FILL_0__1160_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _910_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_40_),
    .B(_41_),
    .Y(_39_)
);

NAND2X1 _1176_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [4]),
    .B(\u_ball.x_pos [5]),
    .Y(_109_)
);

FILL FILL_0__1025_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1483_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__810_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI22X1 _813_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [4]),
    .B(_677_),
    .C(\u_ball.y_ball [5]),
    .D(_678_),
    .Y(_689_)
);

NOR3X1 _1499_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_657_),
    .B(_648_),
    .C(_652_),
    .Y(_647_)
);

OR2X2 _1079_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_456_),
    .B(_453_),
    .Y(_313_)
);

DFFSR _1520_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_469__bF$buf1),
    .S(vdd),
    .D(_461_),
    .CLK(clk_bF$buf5),
    .Q(\u_ball.x_ball [4])
);

OAI21X1 _1100_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_453_),
    .B(_456_),
    .C(_452_),
    .Y(_451_)
);

NAND3X1 _851_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [4]),
    .B(\u_ball.x_ball [3]),
    .C(_526_),
    .Y(_527_)
);

FILL FILL_0__1157_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _907_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [1]),
    .Y(_36_)
);

FILL FILL_0__1195_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _945_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [2]),
    .Y(_175_)
);

NAND2X1 _1423_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State [1]),
    .B(\u_ctrl.cnt_v_sync [2]),
    .Y(_587_)
);

AOI22X1 _1003_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_239_),
    .B(_305_),
    .C(_240_),
    .D(_238_),
    .Y(_237_)
);

NAND3X1 _754_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_62_),
    .B(_54_),
    .C(_18_),
    .Y(_19_)
);

FILL FILL_0__807_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL73950x46950 (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1232_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [3]),
    .Y(_157_)
);

NAND2X1 _983_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.sign_x ),
    .B(\u_ball.x_ball [4]),
    .Y(_219_)
);

INVX1 _1461_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_653_),
    .Y(_614_)
);

NAND2X1 _1041_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [2]),
    .B(_276_),
    .Y(_275_)
);

AOI21X1 _792_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_553_),
    .B(_554_),
    .C(_708_),
    .Y(_709_)
);

FILL FILL_0__1501_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1517_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(pixel_paddle),
    .Y(_717_)
);

FILL FILL_0__845_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _848_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_527_),
    .B(_530_),
    .Y(_531_)
);

NAND2X1 _1270_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_342_),
    .B(_341_),
    .Y(_340_)
);

OAI21X1 _1326_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_398_),
    .B(_393_),
    .C(\u_ball.x_paddle [6]),
    .Y(_392_)
);

AOI21X1 _1135_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_151_),
    .B(_162_),
    .C(_73_),
    .Y(_171_)
);

FILL FILL_0__883_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _886_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_487_),
    .Y(_488_)
);

INVX1 _1364_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_725_),
    .Y(_430_)
);

NAND2X1 _1173_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_bricks.regBricks [15]),
    .B(\u_ball.x_pos [3]),
    .Y(_106_)
);

NAND2X1 _1229_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [6]),
    .B(_160_),
    .Y(_154_)
);

FILL FILL_0__1022_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI22X1 _1458_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_616_),
    .B(_643_),
    .C(_612_),
    .D(\u_ctrl.State_3_bF$buf1 ),
    .Y(_683_)
);

AOI21X1 _1038_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_273_),
    .B(_319_),
    .C(_274_),
    .Y(_272_)
);

AOI21X1 _789_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_711_),
    .B(_707_),
    .C(_254_),
    .Y(_676_)
);

AOI21X1 _1267_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_349_),
    .B(\u_ball.x_paddle [6]),
    .C(_338_),
    .Y(_337_)
);

AOI22X1 _810_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_62_),
    .B(\u_ball.y_pos [3]),
    .C(_691_),
    .D(_27_),
    .Y(_692_)
);

INVX1 _1496_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_645_),
    .Y(_644_)
);

AOI22X1 _1076_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [3]),
    .B(_314_),
    .C(_311_),
    .D(\u_ball.x_ball [4]),
    .Y(_310_)
);

FILL FILL_0__1154_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _904_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_35_),
    .B(_34_),
    .Y(_33_)
);

OAI21X1 _1399_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [5]),
    .B(_572_),
    .C(_570_),
    .Y(_666_)
);

FILL FILL_0__1019_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1192_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _942_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [2]),
    .B(\u_ball.sign_y ),
    .Y(_67_)
);

CLKBUF1 CLKBUF1_insert10 (
    .gnd(gnd),
    .vdd(vdd),
    .A(clk),
    .Y(clk_bF$buf1)
);

CLKBUF1 CLKBUF1_insert11 (
    .gnd(gnd),
    .vdd(vdd),
    .A(clk),
    .Y(clk_bF$buf0)
);

NAND2X1 _1420_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.cnt_v_sync [2]),
    .B(_588_),
    .Y(_584_)
);

AOI22X1 _1000_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [4]),
    .B(_235_),
    .C(_260_),
    .D(\u_ball.x_ball [5]),
    .Y(_234_)
);

AOI21X1 _751_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_725_),
    .B(_20_),
    .C(_21_),
    .Y(_462_)
);

FILL FILL_0__1057_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__804_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI22X1 _807_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_545_),
    .B(\u_ball.x_ball [6]),
    .C(\u_ball.y_ball [5]),
    .D(_678_),
    .Y(_695_)
);

NOR2X1 _980_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x2 ),
    .B(\u_ball.x_ball [0]),
    .Y(_216_)
);

INVX1 _1514_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State [1]),
    .Y(_662_)
);

FILL FILL_0__842_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _845_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_449_),
    .B(_529_),
    .Y(_534_)
);

OR2X2 _1323_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_396_),
    .B(_391_),
    .Y(_390_)
);

INVX1 _1132_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_71_),
    .Y(_170_)
);

FILL FILL_0__880_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _883_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_490_),
    .B(_482_),
    .C(_38_),
    .Y(_491_)
);

FILL FILL74250x50550 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1189_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _939_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_185_),
    .B(_66_),
    .C(_725_),
    .Y(_64_)
);

NOR2X1 _1361_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [6]),
    .B(\u_ball.x_paddle [4]),
    .Y(_427_)
);

FILL FILL73950x7350 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL73950x32550 (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1417_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_657_),
    .B(_583_),
    .Y(_582_)
);

OAI21X1 _748_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_203_),
    .B(_4_),
    .C(_221_),
    .Y(_24_)
);

NAND3X1 _1170_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_bricks.regBricks [12]),
    .B(_130_),
    .C(_129_),
    .Y(_103_)
);

INVX1 _1226_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_bricks.regBricks [8]),
    .Y(_152_)
);

OAI21X1 _977_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_216_),
    .B(_214_),
    .C(_217_),
    .Y(_213_)
);

NAND2X1 _1455_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_610_),
    .B(_628_),
    .Y(_609_)
);

INVX1 _1035_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_278_),
    .Y(_269_)
);

INVX8 _786_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(reset),
    .Y(_469_)
);

FILL FILL_0__839_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _1264_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_335_),
    .B(_369_),
    .C(_371_),
    .Y(_334_)
);

OAI21X1 _1493_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_643_),
    .B(_644_),
    .C(_642_),
    .Y(_641_)
);

AOI21X1 _1073_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_315_),
    .B(_310_),
    .C(_308_),
    .Y(_307_)
);

AOI21X1 _1129_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_151_),
    .B(_136_),
    .C(_79_),
    .Y(_168_)
);

FILL FILL_0__877_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _1358_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_427_),
    .B(_426_),
    .C(_425_),
    .Y(_424_)
);

FILL FILL_0__1151_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _901_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_37_),
    .B(_33_),
    .C(_31_),
    .Y(_30_)
);

OAI22X1 _1167_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_101_),
    .B(_104_),
    .C(_112_),
    .D(_107_),
    .Y(_100_)
);

INVX1 _1396_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.cnt_v_sync [0]),
    .Y(_567_)
);

FILL FILL_0__1016_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1054_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__801_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _804_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_62_),
    .B(\u_ball.y_pos [3]),
    .C(_689_),
    .Y(_698_)
);

NOR2X1 _1299_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_371_),
    .B(_370_),
    .Y(_369_)
);

NOR2X1 _1511_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.cnt_v_sync [2]),
    .B(_660_),
    .Y(_659_)
);

OAI21X1 _842_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [3]),
    .B(\u_ball.x_pos [3]),
    .C(_526_),
    .Y(_537_)
);

FILL FILL_0__1148_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1320_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_416_),
    .B(_419_),
    .C(_388_),
    .Y(_438_)
);

FILL FILL73650x10950 (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _880_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_25_),
    .B(_472_),
    .C(_493_),
    .Y(_494_)
);

FILL FILL_0__1186_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX2 _936_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [3]),
    .Y(_62_)
);

OAI21X1 _1414_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_657_),
    .B(_583_),
    .C(\u_ball.x_pos [1]),
    .Y(_580_)
);

DFFSR _745_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_469__bF$buf3),
    .S(vdd),
    .D(_473_),
    .CLK(clk_bF$buf5),
    .Q(\u_ball.x_ball [0])
);

NOR2X1 _1223_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [5]),
    .B(_150_),
    .Y(_149_)
);

NAND2X1 _974_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_212_),
    .B(_211_),
    .Y(_210_)
);

INVX1 _1452_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [4]),
    .Y(_607_)
);

AOI22X1 _1032_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_449_),
    .B(_269_),
    .C(_267_),
    .D(_291_),
    .Y(_266_)
);

FILL FILL_0_CLKBUF1_insert4 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0_CLKBUF1_insert6 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0_CLKBUF1_insert9 (
    .gnd(gnd),
    .vdd(vdd)
);

OAI22X1 _783_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_299_),
    .B(_254_),
    .C(_713_),
    .D(_714_),
    .Y(_468_)
);

FILL FILL_0__1089_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1508_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [3]),
    .Y(_656_)
);

FILL FILL_0__836_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _839_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_457_),
    .B(_527_),
    .Y(_540_)
);

AOI21X1 _1261_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_334_),
    .B(_333_),
    .C(_332_),
    .Y(_331_)
);

OR2X2 _1317_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_394_),
    .B(_386_),
    .Y(_385_)
);

NOR2X1 _1490_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_648_),
    .B(_652_),
    .Y(_638_)
);

AOI21X1 _1070_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [6]),
    .B(_306_),
    .C(_305_),
    .Y(_304_)
);

AOI21X1 _1126_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_151_),
    .B(_133_),
    .C(_69_),
    .Y(_166_)
);

FILL FILL_0__874_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _877_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [1]),
    .Y(_497_)
);

NAND3X1 _1355_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [6]),
    .B(\u_ball.x_paddle [4]),
    .C(\u_ball.x_paddle [5]),
    .Y(_421_)
);

INVX1 _1164_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [1]),
    .Y(_97_)
);

AOI22X1 _1393_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_568_),
    .B(_565_),
    .C(_588_),
    .D(_569_),
    .Y(_665_)
);

FILL FILL_0__1013_ (
    .gnd(gnd),
    .vdd(vdd)
);

AND2X2 _1449_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_605_),
    .B(_648_),
    .Y(_604_)
);

OAI21X1 _1029_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_284_),
    .B(_264_),
    .C(\u_ball.x_ball [5]),
    .Y(_263_)
);

NOR3X1 _1258_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_336_),
    .B(_329_),
    .C(_352_),
    .Y(pixel_paddle)
);

FILL FILL_0__1051_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _801_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_698_),
    .B(_700_),
    .C(_697_),
    .Y(_701_)
);

NOR2X1 _1487_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State [0]),
    .B(\u_ctrl.State [2]),
    .Y(_635_)
);

INVX1 _1067_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_450_),
    .Y(_301_)
);

OAI21X1 _1296_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_410_),
    .B(\u_ball.x_pos [1]),
    .C(_367_),
    .Y(_366_)
);

FILL FILL_0__1145_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1183_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _933_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_60_),
    .Y(_59_)
);

AOI21X1 _1199_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_145_),
    .B(_141_),
    .C(_132_),
    .Y(_176_)
);

AOI21X1 _1411_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_657_),
    .B(\u_ctrl.State [0]),
    .C(\u_ball.x_pos [2]),
    .Y(_578_)
);

DFFSR _742_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_469__bF$buf2),
    .S(vdd),
    .D(_481_),
    .CLK(clk_bF$buf5),
    .Q(\u_ball.sign_x )
);

FILL FILL_0__1048_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1220_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [6]),
    .B(_149_),
    .Y(_147_)
);

NAND2X1 _971_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_209_),
    .B(_208_),
    .Y(_207_)
);

OAI21X1 _780_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_443_),
    .B(_254_),
    .C(_719_),
    .Y(_467_)
);

FILL FILL_0__1086_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR3X1 _1505_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_656_),
    .B(_655_),
    .C(_654_),
    .Y(_653_)
);

FILL FILL_0__833_ (
    .gnd(gnd),
    .vdd(vdd)
);

AND2X2 _836_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_542_),
    .B(_539_),
    .Y(_543_)
);

NAND2X1 _1314_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_383_),
    .B(_384_),
    .Y(_437_)
);

DFFSR _1123_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_173_),
    .D(_178_),
    .CLK(clk_bF$buf7),
    .Q(\u_bricks.regBricks [7])
);

FILL FILL_0__871_ (
    .gnd(gnd),
    .vdd(vdd)
);

AND2X2 _874_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_498_),
    .B(_499_),
    .Y(_500_)
);

INVX1 _1352_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [5]),
    .Y(_418_)
);

OAI21X1 _1408_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State_3_bF$buf0 ),
    .B(_595_),
    .C(_656_),
    .Y(_576_)
);

DFFSR _739_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_469__bF$buf2),
    .S(vdd),
    .D(_466_),
    .CLK(clk_bF$buf5),
    .Q(\u_ball.x_ball [3])
);

NOR2X1 _1161_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [2]),
    .B(\u_ball.y_pos [0]),
    .Y(_94_)
);

INVX1 _1217_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_145_),
    .Y(_144_)
);

NAND2X1 _968_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_460_),
    .B(_291_),
    .Y(_204_)
);

OAI21X1 _1390_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_588_),
    .B(_564_),
    .C(_563_),
    .Y(_664_)
);

FILL FILL_0__1010_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _1446_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_638_),
    .B(_641_),
    .C(_725_),
    .Y(_602_)
);

OR2X2 _1026_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_264_),
    .B(_284_),
    .Y(_260_)
);

OAI21X1 _777_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_460_),
    .B(_443_),
    .C(_721_),
    .Y(_726_)
);

OAI21X1 _1255_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_380_),
    .B(btn_left),
    .C(_328_),
    .Y(_327_)
);

NAND2X1 _1484_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(game_new),
    .B(\u_ctrl.State [0]),
    .Y(_633_)
);

OAI21X1 _1064_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_299_),
    .B(_448_),
    .C(_317_),
    .Y(_298_)
);

FILL FILL_0__868_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1293_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_368_),
    .B(_364_),
    .Y(_363_)
);

NOR2X1 _1349_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(btn_left),
    .B(_416_),
    .Y(_415_)
);

FILL FILL_0__1142_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1158_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [1]),
    .B(_94_),
    .C(_92_),
    .Y(_91_)
);

DFFSR _1387_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_673__bF$buf0),
    .S(vdd),
    .D(_512_),
    .CLK(clk_bF$buf2),
    .Q(\u_ctrl.State [4])
);

FILL FILL_0__1007_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1180_ (
    .gnd(gnd),
    .vdd(vdd)
);

AND2X2 _930_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_61_),
    .B(_57_),
    .Y(_56_)
);

INVX2 _1196_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [4]),
    .Y(_129_)
);

BUFX2 BUFX2_insert12 (
    .gnd(gnd),
    .vdd(vdd),
    .A(_469_),
    .Y(_469__bF$buf3)
);

BUFX2 BUFX2_insert13 (
    .gnd(gnd),
    .vdd(vdd),
    .A(_469_),
    .Y(_469__bF$buf2)
);

BUFX2 BUFX2_insert14 (
    .gnd(gnd),
    .vdd(vdd),
    .A(_469_),
    .Y(_469__bF$buf1)
);

BUFX2 BUFX2_insert15 (
    .gnd(gnd),
    .vdd(vdd),
    .A(_469_),
    .Y(_469__bF$buf0)
);

BUFX2 BUFX2_insert16 (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State [3]),
    .Y(\u_ctrl.State_3_bF$buf3 )
);

BUFX2 BUFX2_insert17 (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State [3]),
    .Y(\u_ctrl.State_3_bF$buf2 )
);

BUFX2 BUFX2_insert18 (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State [3]),
    .Y(\u_ctrl.State_3_bF$buf1 )
);

BUFX2 BUFX2_insert19 (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State [3]),
    .Y(\u_ctrl.State_3_bF$buf0 )
);

FILL FILL_0__1045_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1083_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _1502_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [0]),
    .B(\u_ball.y_pos [1]),
    .C(\u_ball.y_pos [2]),
    .Y(_650_)
);

FILL FILL_0__830_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _833_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_306_),
    .B(_251_),
    .C(_545_),
    .Y(_546_)
);

AOI21X1 _1099_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_454_),
    .B(_451_),
    .C(_457_),
    .Y(_450_)
);

FILL FILL_0__1139_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1311_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_382_),
    .B(_381_),
    .Y(_436_)
);

DFFSR _1120_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_173_),
    .D(_171_),
    .CLK(clk_bF$buf0),
    .Q(\u_bricks.regBricks [9])
);

AND2X2 _871_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_501_),
    .B(_502_),
    .Y(_503_)
);

FILL FILL_0__1177_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__924_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX2 _927_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [4]),
    .Y(_54_)
);

OAI21X1 _1405_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_656_),
    .B(_654_),
    .C(_655_),
    .Y(_574_)
);

DFFSR _736_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_469__bF$buf3),
    .S(vdd),
    .D(_676_),
    .CLK(clk_bF$buf7),
    .Q(hit_brick)
);

NOR2X1 _1214_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [5]),
    .B(_142_),
    .Y(_141_)
);

NOR2X1 _965_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_218_),
    .B(_202_),
    .Y(_201_)
);

FILL FILL73650x72150 (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1443_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_651_),
    .B(_650_),
    .C(_607_),
    .Y(_600_)
);

OAI22X1 _1023_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_306_),
    .B(_280_),
    .C(_258_),
    .D(_261_),
    .Y(_257_)
);

OAI21X1 _774_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_255_),
    .B(_2_),
    .C(_720_),
    .Y(_466_)
);

NAND3X1 _1252_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_419_),
    .B(_325_),
    .C(_326_),
    .Y(_324_)
);

INVX1 _1308_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_379_),
    .Y(_378_)
);

FILL FILL74250x10950 (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _1481_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State [4]),
    .B(_633_),
    .C(_631_),
    .Y(_687_)
);

NOR2X1 _1061_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_453_),
    .B(_456_),
    .Y(_295_)
);

DFFSR _1117_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_173_),
    .D(_184_),
    .CLK(clk_bF$buf7),
    .Q(\u_bricks.regBricks [1])
);

FILL FILL_0__865_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _868_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_25_),
    .B(_472_),
    .C(_495_),
    .Y(_506_)
);

OAI21X1 _1290_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [0]),
    .B(_362_),
    .C(_361_),
    .Y(_360_)
);

NOR2X1 _1346_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(btn_left),
    .B(_413_),
    .Y(_412_)
);

AND2X2 _1155_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_89_),
    .B(_115_),
    .Y(pixel_brick)
);

DFFSR _1384_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_673__bF$buf3),
    .D(_671_),
    .CLK(clk_bF$buf3),
    .Q(\u_ball.x_pos [0])
);

FILL FILL_0__1004_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1193_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_130_),
    .B(_129_),
    .Y(_126_)
);

NAND3X1 _1249_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_419_),
    .B(_405_),
    .C(_323_),
    .Y(_322_)
);

FILL FILL_0__1042_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _1478_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_652_),
    .B(\u_ctrl.State_3_bF$buf1 ),
    .C(_629_),
    .Y(_628_)
);

OAI21X1 _1058_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_449_),
    .B(_300_),
    .C(_293_),
    .Y(_292_)
);

FILL FILL_0__1518_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1287_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [0]),
    .Y(_357_)
);

FILL FILL_0__1080_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _830_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_547_),
    .B(_543_),
    .C(_548_),
    .Y(_549_)
);

INVX1 _1096_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [2]),
    .Y(_447_)
);

FILL FILL_0__1174_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__921_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _924_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_53_),
    .B(_52_),
    .Y(_51_)
);

NAND2X1 _1402_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State_3_bF$buf3 ),
    .B(_653_),
    .Y(_572_)
);

DFFSR _733_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_469__bF$buf0),
    .D(_476_),
    .CLK(clk_bF$buf4),
    .Q(\u_ball.y_ball [2])
);

FILL FILL_0__1039_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1211_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [5]),
    .B(_143_),
    .Y(_139_)
);

NOR2X1 _962_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_200_),
    .B(_199_),
    .Y(_198_)
);

FILL FILL_0__1268_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1440_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_628_),
    .B(_598_),
    .Y(_597_)
);

INVX4 _1020_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_255_),
    .Y(_254_)
);

OAI21X1 _771_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_291_),
    .B(_4_),
    .C(_460_),
    .Y(_5_)
);

FILL FILL_0__1077_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _827_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_490_),
    .B(_482_),
    .C(_39_),
    .Y(_552_)
);

NAND2X1 _1305_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [2]),
    .B(_376_),
    .Y(_375_)
);

DFFSR _1114_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_173_),
    .D(_168_),
    .CLK(clk_bF$buf6),
    .Q(\u_bricks.regBricks [10])
);

FILL FILL_0__862_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _865_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_504_),
    .B(_491_),
    .C(_508_),
    .Y(_509_)
);

FILL FILL_0__918_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1343_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [2]),
    .B(_428_),
    .Y(_409_)
);

NOR2X1 _1152_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_bricks.regBricks [1]),
    .B(\u_bricks.regBricks [14]),
    .Y(_86_)
);

INVX1 _1208_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_bricks.regBricks [2]),
    .Y(_137_)
);

FILL FILL_0__956_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _959_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_201_),
    .B(_197_),
    .C(_196_),
    .Y(_195_)
);

DFFSR _1381_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_673__bF$buf0),
    .S(vdd),
    .D(_680_),
    .CLK(clk_bF$buf2),
    .Q(_725_)
);

FILL FILL_0__1001_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1437_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State [0]),
    .Y(_595_)
);

NAND3X1 _1017_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [5]),
    .B(\u_ball.x_ball [4]),
    .C(_252_),
    .Y(_251_)
);

OAI21X1 _768_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_306_),
    .B(_7_),
    .C(_44_),
    .Y(_8_)
);

AOI21X1 _1190_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_124_),
    .B(_165_),
    .C(\u_ball.x_pos [6]),
    .Y(_123_)
);

FILL FILL_0__1230_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1246_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_434_),
    .S(vdd),
    .D(_436_),
    .CLK(clk_bF$buf2),
    .Q(\u_ball.x_paddle [1])
);

OAI21X1 _997_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_232_),
    .B(_233_),
    .C(_283_),
    .Y(_231_)
);

INVX1 _1475_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [1]),
    .Y(_626_)
);

AND2X2 _1055_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_309_),
    .B(_290_),
    .Y(_289_)
);

FILL FILL_0__1515_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _1284_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_363_),
    .B(_355_),
    .C(_362_),
    .Y(_354_)
);

NAND3X1 _1093_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_449_),
    .B(_456_),
    .C(_445_),
    .Y(_444_)
);

INVX1 _1149_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_bricks.regBricks [5]),
    .Y(_83_)
);

FILL FILL_0__897_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL74250x18150 (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1378_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_673__bF$buf1),
    .D(_668_),
    .CLK(clk_bF$buf3),
    .Q(\u_ball.x_pos [3])
);

FILL FILL_0__1171_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _921_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_50_),
    .B(_58_),
    .C(_51_),
    .Y(_48_)
);

NAND2X1 _1187_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_bricks.regBricks [11]),
    .B(\u_ball.x_pos [3]),
    .Y(_120_)
);

FILL FILL_0__1227_ (
    .gnd(gnd),
    .vdd(vdd)
);

BUFX2 _730_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_722_),
    .Y(game_over)
);

FILL FILL_0__1036_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1265_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1074_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _824_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_554_),
    .B(_553_),
    .Y(_555_)
);

INVX1 _1302_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [3]),
    .Y(_372_)
);

DFFSR _1111_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_173_),
    .D(_179_),
    .CLK(clk_bF$buf3),
    .Q(\u_bricks.regBricks [2])
);

AOI22X1 _862_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_497_),
    .B(\u_ball.x_ball [1]),
    .C(\u_ball.x_ball [0]),
    .D(_511_),
    .Y(_513_)
);

FILL FILL_0__915_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _918_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [0]),
    .Y(_46_)
);

AOI21X1 _1340_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_423_),
    .B(_413_),
    .C(_412_),
    .Y(_406_)
);

BUFX2 _727_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_725_),
    .Y(v_sync)
);

INVX1 _1205_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_bricks.regBricks [7]),
    .Y(_135_)
);

FILL FILL_0__953_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _956_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [0]),
    .Y(_193_)
);

OAI21X1 _1434_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_632_),
    .B(_596_),
    .C(_594_),
    .Y(_514_)
);

NOR2X1 _1014_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [2]),
    .B(\u_ball.x_ball [3]),
    .Y(_248_)
);

NAND2X1 _765_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_192_),
    .B(_175_),
    .Y(_10_)
);

DFFSR _1243_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_434_),
    .S(vdd),
    .D(_439_),
    .CLK(clk_bF$buf2),
    .Q(\u_ball.x_paddle [6])
);

NAND2X1 _994_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_245_),
    .B(_250_),
    .Y(_228_)
);

OAI21X1 _1472_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_624_),
    .B(_625_),
    .C(\u_ctrl.State_3_bF$buf2 ),
    .Y(_623_)
);

NAND2X1 _1052_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_302_),
    .B(_287_),
    .Y(_286_)
);

INVX1 _1108_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.hit_paddle ),
    .Y(_459_)
);

NAND2X1 _859_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_518_),
    .B(_515_),
    .Y(_519_)
);

INVX1 _1281_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [5]),
    .Y(_351_)
);

NOR2X1 _1337_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_418_),
    .B(_428_),
    .Y(_403_)
);

NAND2X1 _1090_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_448_),
    .B(_447_),
    .Y(_441_)
);

NAND3X1 _1146_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_83_),
    .B(_82_),
    .C(_81_),
    .Y(_80_)
);

FILL FILL_0__894_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _897_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_193_),
    .B(\u_ball.y_pos [0]),
    .C(_35_),
    .Y(_26_)
);

FILL FILL74250x72150 (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1375_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_673__bF$buf1),
    .S(vdd),
    .D(_688_),
    .CLK(clk_bF$buf6),
    .Q(_723_)
);

OAI21X1 _1184_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_152_),
    .B(_126_),
    .C(_118_),
    .Y(_117_)
);

FILL FILL_0__1224_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1033_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1469_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [2]),
    .Y(_621_)
);

NAND2X1 _1049_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [6]),
    .B(_284_),
    .Y(_283_)
);

FILL FILL_0__1262_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1278_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [6]),
    .B(_349_),
    .Y(_348_)
);

FILL FILL_0__1071_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _821_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_518_),
    .B(_557_),
    .C(_536_),
    .Y(_558_)
);

NOR2X1 _1087_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [1]),
    .B(\u_ball.x_paddle [2]),
    .Y(_321_)
);

FILL FILL_0__912_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _915_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x2 ),
    .B(_222_),
    .C(_44_),
    .Y(_43_)
);

NOR2X1 _1202_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_158_),
    .B(_150_),
    .Y(_133_)
);

FILL FILL_0__950_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _953_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [1]),
    .B(\u_ball.sign_y ),
    .Y(_191_)
);

FILL FILL_0__1259_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1431_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State [1]),
    .B(_659_),
    .Y(_591_)
);

NOR2X1 _1011_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(game_init),
    .B(\u_ball.hit_paddle ),
    .Y(_245_)
);

OAI21X1 _762_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [0]),
    .B(_10_),
    .C(_12_),
    .Y(_13_)
);

FILL FILL_0__1068_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI22X1 _818_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_291_),
    .B(\u_ball.x_pos [4]),
    .C(_558_),
    .D(_560_),
    .Y(_562_)
);

INVX1 _1240_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [4]),
    .Y(_164_)
);

OAI21X1 _991_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_460_),
    .B(_241_),
    .C(_226_),
    .Y(_481_)
);

FILL FILL_0__1297_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _1105_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [1]),
    .B(\u_ball.x_paddle [2]),
    .C(\u_ball.x_paddle [3]),
    .Y(_456_)
);

NAND3X1 _856_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_515_),
    .B(_518_),
    .C(_521_),
    .Y(_522_)
);

FILL FILL_0__909_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1334_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_417_),
    .B(_404_),
    .C(_401_),
    .Y(_400_)
);

FILL FILL73650x32550 (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _1143_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_132_),
    .B(_79_),
    .C(_78_),
    .Y(_77_)
);

OAI21X1 _894_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [1]),
    .B(_36_),
    .C(_37_),
    .Y(_471_)
);

FILL FILL_0__947_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1372_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_673__bF$buf2),
    .S(vdd),
    .D(_665_),
    .CLK(clk_bF$buf6),
    .Q(\u_ctrl.cnt_v_sync [1])
);

OAI21X1 _1428_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State [1]),
    .B(\u_ctrl.State [2]),
    .C(_593_),
    .Y(_590_)
);

INVX1 _1008_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_243_),
    .Y(_242_)
);

NAND3X1 _759_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_58_),
    .B(_52_),
    .C(_50_),
    .Y(_15_)
);

NAND2X1 _1181_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_bricks.regBricks [6]),
    .B(_130_),
    .Y(_114_)
);

FILL FILL_0__1221_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1237_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [6]),
    .Y(_161_)
);

FILL FILL_0__985_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _988_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_224_),
    .Y(_223_)
);

FILL FILL_0__1030_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1466_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_620_),
    .B(_619_),
    .C(\u_ctrl.State_3_bF$buf2 ),
    .Y(_618_)
);

OAI21X1 _1046_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_452_),
    .B(_281_),
    .C(_282_),
    .Y(_280_)
);

AND2X2 _797_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_704_),
    .B(_694_),
    .Y(_705_)
);

AOI21X1 _1275_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_416_),
    .B(_350_),
    .C(_346_),
    .Y(_345_)
);

INVX1 _1084_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(gnd),
    .Y(_318_)
);

FILL FILL74250x25350 (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1369_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_673__bF$buf2),
    .S(vdd),
    .D(_517_),
    .CLK(clk_bF$buf6),
    .Q(\u_ctrl.State [1])
);

INVX1 _912_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_42_),
    .Y(_41_)
);

INVX1 _1178_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [6]),
    .Y(_111_)
);

FILL FILL_0__1218_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL74250x7350 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1027_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _950_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_189_),
    .B(_190_),
    .Y(_188_)
);

FILL FILL_0__1256_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1065_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _815_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [4]),
    .Y(_677_)
);

FILL FILL_0__1294_ (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1522_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_434_),
    .S(vdd),
    .D(_432_),
    .CLK(clk_bF$buf1),
    .Q(\u_ball.x_paddle [3])
);

INVX2 _1102_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [4]),
    .Y(_453_)
);

AND2X2 _853_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_509_),
    .B(_524_),
    .Y(_525_)
);

FILL FILL_0__906_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _909_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_39_),
    .Y(_38_)
);

INVX1 _1331_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_417_),
    .Y(_397_)
);

INVX4 _1140_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(reset),
    .Y(_173_)
);

INVX1 _891_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_25_),
    .Y(_483_)
);

FILL FILL_0__944_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _947_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_192_),
    .B(_254_),
    .C(_186_),
    .Y(_477_)
);

OAI21X1 _1425_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_662_),
    .B(_644_),
    .C(_629_),
    .Y(_589_)
);

OAI21X1 _1005_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_450_),
    .B(_307_),
    .C(_302_),
    .Y(_239_)
);

AOI21X1 _756_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [5]),
    .B(_16_),
    .C(_17_),
    .Y(_463_)
);

AOI21X1 _1234_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_162_),
    .B(_159_),
    .C(_165_),
    .Y(_184_)
);

FILL FILL_0__982_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _985_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.hit_paddle ),
    .B(_221_),
    .Y(_220_)
);

INVX1 _1463_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [6]),
    .Y(_616_)
);

NAND2X1 _1043_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [3]),
    .B(_278_),
    .Y(_277_)
);

INVX1 _794_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(hit_brick),
    .Y(_707_)
);

NAND3X1 _1519_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_716_),
    .B(_717_),
    .C(_718_),
    .Y(_724_)
);

OAI21X1 _1272_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_418_),
    .B(\u_ball.x_pos [5]),
    .C(_348_),
    .Y(_342_)
);

AOI22X1 _1328_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_416_),
    .B(_423_),
    .C(_396_),
    .D(_414_),
    .Y(_394_)
);

NAND3X1 _1081_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_444_),
    .B(_440_),
    .C(_316_),
    .Y(_315_)
);

AOI21X1 _1137_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_74_),
    .B(_159_),
    .C(_75_),
    .Y(_172_)
);

NAND2X1 _888_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [0]),
    .B(_32_),
    .Y(_486_)
);

FILL FILL74250x46950 (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1366_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_469__bF$buf1),
    .S(vdd),
    .D(_480_),
    .CLK(clk_bF$buf5),
    .Q(\u_ball.x2 )
);

FILL FILL73950x61350 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL73950x28950 (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _1175_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_bricks.regBricks [5]),
    .B(\u_ball.x_pos [3]),
    .C(_109_),
    .Y(_108_)
);

FILL FILL_0__1215_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__979_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1253_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _1269_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_344_),
    .B(_343_),
    .C(_340_),
    .Y(_339_)
);

FILL FILL_0__1062_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _812_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_689_),
    .Y(_690_)
);

NOR2X1 _1498_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_722_),
    .B(_0_),
    .Y(_646_)
);

OAI21X1 _1078_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_446_),
    .B(_442_),
    .C(_453_),
    .Y(_312_)
);

FILL FILL_0__1291_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR3X1 _850_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [0]),
    .B(\u_ball.x_ball [1]),
    .C(\u_ball.x_ball [2]),
    .Y(_529_)
);

FILL FILL_0__903_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _906_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [1]),
    .B(_36_),
    .Y(_35_)
);

FILL FILL_0__941_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _944_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.sign_y ),
    .Y(_174_)
);

OAI21X1 _1422_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_661_),
    .B(_587_),
    .C(_591_),
    .Y(_586_)
);

NAND2X1 _1002_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_270_),
    .B(_266_),
    .Y(_236_)
);

OAI21X1 _753_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_10_),
    .B(_19_),
    .C(_707_),
    .Y(_20_)
);

FILL FILL_0__1059_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI22X1 _809_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [4]),
    .B(_54_),
    .C(_62_),
    .D(\u_ball.y_pos [3]),
    .Y(_693_)
);

NAND2X1 _1231_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [4]),
    .B(_157_),
    .Y(_156_)
);

INVX1 _982_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_219_),
    .Y(_218_)
);

FILL FILL_0__1288_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1460_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_615_),
    .B(_614_),
    .C(_616_),
    .Y(_613_)
);

NOR2X1 _1040_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [1]),
    .B(\u_ball.x_paddle [1]),
    .Y(_274_)
);

AOI22X1 _791_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_509_),
    .B(_524_),
    .C(_549_),
    .D(_249_),
    .Y(_710_)
);

FILL FILL_0__1097_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1516_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(pixel_ball),
    .Y(_716_)
);

INVX1 _847_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [3]),
    .Y(_532_)
);

NAND2X1 _1325_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_399_),
    .B(_392_),
    .Y(_439_)
);

OR2X2 _1134_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_163_),
    .B(_158_),
    .Y(_72_)
);

OAI21X1 _885_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [0]),
    .B(_32_),
    .C(_488_),
    .Y(_489_)
);

FILL FILL_0__938_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1363_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(btn_right),
    .Y(_429_)
);

OAI21X1 _1419_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_588_),
    .B(_585_),
    .C(_584_),
    .Y(_672_)
);

NAND2X1 _1172_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_bricks.regBricks [14]),
    .B(_130_),
    .Y(_105_)
);

FILL FILL_0__1212_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1228_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_154_),
    .B(_155_),
    .C(\u_bricks.regBricks [14]),
    .Y(_153_)
);

FILL FILL_0__976_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _979_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x2 ),
    .B(_460_),
    .C(_299_),
    .Y(_215_)
);

FILL FILL74250x150 (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1457_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [3]),
    .B(_620_),
    .Y(_611_)
);

OAI21X1 _1037_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [2]),
    .B(_276_),
    .C(_272_),
    .Y(_271_)
);

NAND3X1 _788_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(pixel_paddle),
    .B(_709_),
    .C(_710_),
    .Y(_712_)
);

FILL FILL_0__1250_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1266_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_345_),
    .B(_339_),
    .C(_337_),
    .Y(_336_)
);

FILL FILL74250x32550 (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1495_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State_3_bF$buf0 ),
    .B(\u_ctrl.State [0]),
    .Y(_643_)
);

NAND3X1 _1075_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_457_),
    .B(_451_),
    .C(_454_),
    .Y(_309_)
);

FILL FILL_0__900_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _903_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [0]),
    .Y(_32_)
);

NAND3X1 _1169_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_bricks.regBricks [13]),
    .B(\u_ball.x_pos [3]),
    .C(_129_),
    .Y(_102_)
);

FILL FILL_0__1209_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1398_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.cnt_v_sync [1]),
    .Y(_569_)
);

NOR2X1 _941_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_67_),
    .B(_68_),
    .Y(_66_)
);

NAND2X1 _750_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_203_),
    .B(_4_),
    .Y(_22_)
);

INVX1 _806_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_695_),
    .Y(_696_)
);

FILL FILL_0_BUFX2_insert1 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1285_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1094_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1513_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.cnt_v_sync [0]),
    .B(\u_ctrl.cnt_v_sync [1]),
    .Y(_661_)
);

AOI21X1 _844_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_534_),
    .B(_533_),
    .C(_532_),
    .Y(_535_)
);

NAND2X1 _1322_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_391_),
    .B(_396_),
    .Y(_389_)
);

INVX1 _1131_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_72_),
    .Y(_70_)
);

NAND2X1 _882_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_37_),
    .B(_33_),
    .Y(_492_)
);

FILL FILL_0__935_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _938_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_222_),
    .B(\u_ball.y_ball [2]),
    .C(game_init),
    .Y(_63_)
);

NOR2X1 _1360_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [5]),
    .B(\u_ball.x_paddle [1]),
    .Y(_426_)
);

FILL FILL73350x72150 (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _1416_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_583_),
    .B(_643_),
    .C(_582_),
    .Y(_671_)
);

OAI22X1 _747_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_291_),
    .B(_254_),
    .C(_24_),
    .D(_23_),
    .Y(_461_)
);

INVX2 _1225_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_154_),
    .Y(_151_)
);

FILL FILL_0__973_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _976_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.sign_x ),
    .B(_443_),
    .Y(_212_)
);

OAI21X1 _1454_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_651_),
    .B(_628_),
    .C(_609_),
    .Y(_682_)
);

OAI21X1 _1034_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_446_),
    .B(_321_),
    .C(_453_),
    .Y(_268_)
);

AOI21X1 _785_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_215_),
    .B(_217_),
    .C(_45_),
    .Y(_713_)
);

NAND2X1 _1263_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [4]),
    .B(_416_),
    .Y(_333_)
);

OAI21X1 _1319_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_397_),
    .B(_403_),
    .C(_394_),
    .Y(_387_)
);

OAI21X1 _1492_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_662_),
    .B(_646_),
    .C(_641_),
    .Y(_640_)
);

INVX4 _1072_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [6]),
    .Y(_306_)
);

AOI21X1 _1128_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_149_),
    .B(_159_),
    .C(_82_),
    .Y(_167_)
);

AND2X2 _879_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_492_),
    .B(_487_),
    .Y(_495_)
);

NAND2X1 _1357_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_428_),
    .B(_424_),
    .Y(_423_)
);

NAND2X1 _900_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [2]),
    .B(_175_),
    .Y(_29_)
);

OR2X2 _1166_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [3]),
    .B(\u_ball.y_pos [5]),
    .Y(_99_)
);

FILL FILL_0__1206_ (
    .gnd(gnd),
    .vdd(vdd)
);

CLKBUF1 CLKBUF1_insert4 (
    .gnd(gnd),
    .vdd(vdd),
    .A(clk),
    .Y(clk_bF$buf7)
);

CLKBUF1 CLKBUF1_insert5 (
    .gnd(gnd),
    .vdd(vdd),
    .A(clk),
    .Y(clk_bF$buf6)
);

CLKBUF1 CLKBUF1_insert6 (
    .gnd(gnd),
    .vdd(vdd),
    .A(clk),
    .Y(clk_bF$buf5)
);

CLKBUF1 CLKBUF1_insert7 (
    .gnd(gnd),
    .vdd(vdd),
    .A(clk),
    .Y(clk_bF$buf4)
);

CLKBUF1 CLKBUF1_insert8 (
    .gnd(gnd),
    .vdd(vdd),
    .A(clk),
    .Y(clk_bF$buf3)
);

CLKBUF1 CLKBUF1_insert9 (
    .gnd(gnd),
    .vdd(vdd),
    .A(clk),
    .Y(clk_bF$buf2)
);

NOR2X1 _1395_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_567_),
    .B(_569_),
    .Y(_566_)
);

NOR2X1 _803_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [5]),
    .B(_678_),
    .Y(_699_)
);

AOI21X1 _1489_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_638_),
    .B(\u_ctrl.State_3_bF$buf3 ),
    .C(_658_),
    .Y(_637_)
);

OAI21X1 _1069_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_450_),
    .B(_307_),
    .C(_304_),
    .Y(_303_)
);

FILL FILL_0__1109_ (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL_0__1282_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1298_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_378_),
    .B(_373_),
    .C(_369_),
    .Y(_368_)
);

FILL FILL_0__1091_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1510_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_662_),
    .B(_659_),
    .Y(_658_)
);

AOI21X1 _841_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_536_),
    .B(_518_),
    .C(_537_),
    .Y(_538_)
);

FILL FILL_0__932_ (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _935_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_68_),
    .B(_65_),
    .Y(_61_)
);

OAI21X1 _1413_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [1]),
    .B(_581_),
    .C(_580_),
    .Y(_670_)
);

DFFSR _744_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_469__bF$buf0),
    .D(_474_),
    .CLK(clk_bF$buf4),
    .Q(\u_ball.y_ball [4])
);

AOI21X1 _1222_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_151_),
    .B(_149_),
    .C(_152_),
    .Y(_182_)
);

FILL FILL_0__970_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _973_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.sign_x ),
    .B(_449_),
    .Y(_209_)
);

FILL FILL_0__1279_ (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1451_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_649_),
    .Y(_606_)
);

OAI21X1 _1031_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_453_),
    .B(_285_),
    .C(_452_),
    .Y(_265_)
);

AOI21X1 _782_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_213_),
    .B(_210_),
    .C(_196_),
    .Y(_715_)
);

INVX1 _1507_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [4]),
    .Y(_655_)
);

NAND2X1 _838_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_251_),
    .B(_540_),
    .Y(_541_)
);

AND2X2 _1260_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_pos [4]),
    .B(\u_ball.y_pos [3]),
    .Y(_330_)
);

FILL FILL_0__1300_ (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _1316_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_419_),
    .B(_387_),
    .C(_385_),
    .Y(_384_)
);

DFFSR _1125_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_173_),
    .D(_183_),
    .CLK(clk_bF$buf7),
    .Q(\u_bricks.regBricks [14])
);

NAND2X1 _876_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [1]),
    .B(_497_),
    .Y(_498_)
);

FILL FILL_0__929_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _1354_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_429_),
    .B(_421_),
    .C(_422_),
    .Y(_420_)
);

NOR2X1 _1163_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_pos [2]),
    .B(\u_ball.x_pos [0]),
    .Y(_96_)
);

FILL FILL_0__1203_ (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1219_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [5]),
    .B(_150_),
    .C(_161_),
    .Y(_146_)
);

FILL FILL_0__967_ (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _1392_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_567_),
    .B(\u_ctrl.State [1]),
    .C(\u_ctrl.State_3_bF$buf1 ),
    .Y(_564_)
);

OAI21X1 _1448_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_657_),
    .B(_604_),
    .C(_628_),
    .Y(_603_)
);

OAI21X1 _1028_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_291_),
    .B(_267_),
    .C(_263_),
    .Y(_262_)
);

NAND2X1 _779_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_ball [3]),
    .B(_255_),
    .Y(_720_)
);

endmodule
